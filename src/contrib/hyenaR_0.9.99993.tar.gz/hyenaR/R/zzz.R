#' Internal functions for loading/unloading/attaching the package
#'
#' @inheritParams arguments
#' @name attach_load
#' @aliases attach_load, .onAttach, .onLoad, .onUnload
NULL


#' @describeIn attach_load Display welcome message
#'
#' This function should not be called by the user.
#' It displays a message when the package is being loaded.
#'
#' @export
#'
.onAttach <- function(libname, pkgname) {
  packageStartupMessage( ## display message
    "\n",
    "Welcome to ", crayon::green("hyenaR"), " v", utils::packageDescription("hyenaR")$Version,
    "\n",
    .logo,
    "\n",
    "\n",
    "Run:",
    "\n",
    " - ", crayon::blue("build_vignette_news()"), " for news",
    "\n",
    " - ", crayon::blue("build_vignette_grammar()"), " for an organized list of all functions",
    "\n",
    " - ", crayon::blue("build_vignette_data.summary()"), " for summary statistics about the population",
    "\n",
    " - ", crayon::blue("build_vignette_errors()"), " for multiple checks on the raw data",
    "\n",
    " - ", crayon::blue("build_vignette_tutorial.ranks()"), " for an old (not so great) tutorial",
    "\n",
    " - ", crayon::blue("build_vignette_devel()"), " for developer tips & guidelines",
    "\n",
    " - ", crayon::blue("help(package = 'hyenaR')"), " to access all help files",
    "\n",
    "\n",
    find_package_tip()
  )
}


## Setting object storing package info
.hyenaR <- new.env(parent = emptyenv())


#' @describeIn attach_load Load the package
#'
#' This function should not be called by the user.
#' This function stores the global options of the R session before the load of the package,
#' so that such setting can be restored safely once the package is unloaded. Also set the default
#' setting for the general options in hyenaR.
#'
#' @seealso [`hyenaR_options`]
#'
#' @export
#'
.onLoad <- function(libname, pkgname) {

  ## define some flags for displaying messages only once per session:
  .hyenaR$flag_CPUcores <- FALSE

  ## backup original R options:
  .hyenaR$backup_options <- .Options

  ## add hyenaR option to .Options:
  options(
    list(
      hyenaR_CPUcores = 2,   ## define global option CPUcores
      hyenaR_verbose = TRUE) ## define global option verbose
  )
}


#' @describeIn attach_load Unload the package
#'
#' This function should not be called by the user.
#' This function restores the global options of the R session on the unload of the package.
#'
#' @export
#'
.onUnload <- function(libpath) {
  if (exists(".hyenaR")) {
    options(.hyenaR$backup_options)  ## reset R options to their backed up values
  }
}


#' Provide some basic information about the code of the package
#'
#' This is a function for development purpose only. This function provides the
#' number of functions and lines of code of the package. The results depend on
#' whether the function is called from the compiled or the raw package. When
#' called from the compiled package, the number of functions only gives the
#' number of exported functions, and the number of lines of code no longer
#' includes documentation and examples.
#'
#' @note This function does not work with `devtools::load_all(".")`.
#'
#' @export
#'
find_package_info <- function() {
  message(paste("Number of exported functions =", length(ls("package:hyenaR")) - 1)) ## remove one for the pipe
  if (requireNamespace("R.utils", quietly = TRUE)) {
    files <- dir(paste0(find.package(package = "hyenaR"), "/R/"))
    filenames_R <- paste0(find.package(package = "hyenaR"), "/R/", files)
    lines_code <- sum(sapply(filenames_R, function(file) R.utils::countLines(file)))
    message(paste("Number of lines of code =", lines_code, "\nNote: the numbers are only reliable if the package is loaded using library()\nand not via devtools!"))
  } else {
    message("Install the package R.utils for more info.")
  }
  return(invisible(NULL))
}


#' Display tips about how to use the package
#'
#' This function returns one tip about how to use the package.
#'
#' Note for developers: let's try to write many tips for hyenaR!
#'
#' @export
#'
#' @examples
#' find_package_tip()
#'
find_package_tip <- function() {
  alltips <- c("a call to rm(list = ls()) will remove all the R objects created in your R session, but not the loaded database. \n This is because the loaded database is hidden.",
               "knowing well how to use the tidyverse package {dplyr} will greatly help you to use 'hyenaR' efficiently. \n The best place to learn about it is probably https://r4ds.had.co.nz/transform.html",
               "it is good practice to update your R packages frequently using update.packages(ask = FALSE, checkBuild = TRUE) or similar.",
               "a call to find_pop_id() gives you all the IDs present in loaded database.",
               "a call to e.g. extract_database_row('A-001') will extract all the info known about this individual from the database.",
               "create_id_starting.table() is the best function to start most workflow. It is a very flexible, so check its documentation to discover how to customize all its arguments!",
               "you can suggest developers many more tips you would like to see here.\n Fill in an issue on GitHub for that or just talk to the developers.")
  tip <- sample(alltips, size = 1)
  paste0("Tip:\n ", crayon::green(tip))
}


#' @describeIn attach_load The logo of the package
#'
#' @export
#'
.logo <-
  c("                                                         ", "\n",
   "                             .             &&#           ", "\n",
   "                          .&%/&%.    %   .&(//(&&        ", "\n",
   "                         (%/////%&.#&%/&%&#//////%%      ", "\n",
   "                         &%///&(////##//////&%////&(     ", "\n",
   "                         #&///&/////////////(#////&*     ", "\n",
   "                          *&#%////////////////&%&&       ", "\n",
   "                            %#&#/////&%%///////%&        ", "\n",
   "                            #%//////////////////%&       ", "\n",
   "           /(/              %&&&&%///////////////&(      ", "\n",
   "       .&&//%&               &(///////#%%////////(&      ", "\n",
   "   && %&///(&                   /(////////////////&(     ", "\n",
   "   &&&#////&&%/           /&&&&%#(////////////////&&     ", "\n",
   "   %%//////%&.       (&&%/////%&&%////////////////#&     ", "\n",
   "   .&#/////&,    .&&&&&////////////////////////////&     ", "\n",
   "     %&////%& .&&/%&&#/////////////////////////////&(    ", "\n",
   "       %&(//#&%/////////%&&////////////////////////%&    ", "\n",
   "          %&%/////#&&#////%////////////////////////#&    ", "\n",
   "           &%//////////////////////////////////////%&    ", "\n",
   "          (&&#/////////////////////////////////////&#    ", "\n",
   "          %&#//////////////////&&///////#/////////%&     ", "\n",
   "          %&////////////////&(/&&(/////#(////////%&      ", "\n",
   "          %&//////(%////////(&(////////&////////%%       ", "\n",
   "          &&#%#/////&&&//////#&////////&///////%&        ", "\n",
   "          &%///////#&,#&%&&&&&&&///////&//////(&         ", "\n",
   "          &(//////&%...&%/////(&(//////&/////(&          ", "\n",
   "         ,&%/////&(....&%/////&&&&&%(//%/////&*          ", "\n",
   "          *%&#//&,....(&/////#%.%#//////////&(           ", "\n")
