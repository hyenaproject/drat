#' @describeIn create_family create a table with the type of interaction between ID.1 and ID.2.
#'
#' The classification is based on the relatedness of the two interacting parties and their migratory status.
#' This lead to the following possibilities:
#' migrant_migrant
#' migrant_native
#' native_migrant
#' native_unrelated
#' native_related
#'
#' For each type of interaction, the winner of the interaction will be determined following a different rule.
#'
#' @return Returns a 7 columns data frame with ID.1, ID.2, date, ID.1_life_stage, ID.2_life_stage, mrcaID, and type of interaction.
#' @export
#' @examples
#' create_dyad_interaction.type(ID.1 = "A-084", ID.2 = "A-001", "1997-04-01")
#'
create_dyad_interaction.type <- function(ID.1, ID.2, at) {

  input <- tibble::tibble(ID.1 = check_function_arg.ID(ID.1, argument.name = 'ID.1'),
                          ID.2 = check_function_arg.ID(ID.2, argument.name = 'ID.2'),
                          date = check_function_arg.date(at))

  output <- input %>%
    dplyr::distinct() %>%
    dplyr::mutate(ID.1_is_migrant = fetch_id_is.migrant(ID.1, at, migrant.mother.as.native = TRUE),
                  ID.2_is_migrant = fetch_id_is.migrant(ID.2, at, migrant.mother.as.native = TRUE),
                  mrcaID = purrr::map2_chr(ID.1, ID.2, find_dyad_id.ancestor.MRCA, filiation = "mother_social"),
                  type = dplyr::case_when(.data$ID.1_is_migrant & .data$ID.2_is_migrant ~ "migrant_migrant",
                                         !.data$ID.1_is_migrant & .data$ID.2_is_migrant ~ "native_migrant",
                                         .data$ID.1_is_migrant & !.data$ID.2_is_migrant ~ "migrant_native",
                                         !.data$ID.1_is_migrant & !.data$ID.2_is_migrant & !(is.na(.data$mrcaID)) ~ "native_related",
                                         !.data$ID.1_is_migrant & !.data$ID.2_is_migrant  & is.na(.data$mrcaID) ~ "native_unrelated",
                                         TRUE ~ NA_character_))

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = c("ID.1", "ID.2", "date"),
                        duplicates = "none")
}


#' @describeIn fetch_family fetch the type of interaction between ID.1 and ID.2.
#'
#' The classification is based on the relatedness of the two interacting parties and their migratory status.
#' This lead to the following possibilities:
#' migrant_migrant
#' migrant_native
#' native_migrant
#' native_unrelated
#' native_related
#'
#' For each type of interaction, the winner of the interaction will be determined following a different rule.
#'
#' @return Returns the type of interaction of a dyadic interaction.
#' @export
#' @examples
#' fetch_dyad_interaction.type(ID.1 = c("A-010", "A-084"), ID.2 = "A-001", "1997-04-01")
#'
fetch_dyad_interaction.type <- function(ID.1, ID.2, at) {
  create_dyad_interaction.type(ID.1 = ID.1, ID.2 = ID.2, at = at)$type
}


#################################################################################

#' @describeIn find_family find the winner of an interaction between two migrants
#'
#' The ID with the longer tenure wins the interaction.
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.migrant <- function(ID.1, ID.2, at){
  out <- fetch_id_duration.tenure(ID = c(ID.1, ID.2), at = at) ## the longest tenure wins

  if (out[1] > out[2]) winner <- ID.1
  else if (out[1] < out[2]) winner <- ID.2
  else winner <- NA_character_

  winner
}

#################################################################################

#' @describeIn find_family find the winner of an interaction between a native and an migrant.
#'
#' The native ID wins the interaction.
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.migrant <- function(nativeID, migrantID){
  nativeID ## the native wins
}

#################################################################################

#' Find the winner of interaction between two unrelated natives.
#'
#' The ID with most related individuals in the clan wins the interaction.
#'
#' @describeIn find_family find the winner of an interaction between two unrelated natives.
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.unrelated <- function(ID.1, ID.2, date){  ## remove the cubs ?

  clan <- fetch_id_clan.current(ID.1, date) ## slow

  input <- create_id_starting.table(clan = clan, at = date,
                                    lifestage = c("!cub", "!dead"))

  output <- input %>%
    dplyr::rowwise() %>%
    dplyr::mutate(relat_ID.1 = find_dyad_relatedness(ID.1 = .data$ID, ID.2 = {{ID.1}}, filiation = "mother_social"), ### TODO try with a relat matrix
                  relat_ID.2 = find_dyad_relatedness(ID.1 = .data$ID, ID.2 = {{ID.2}}, filiation = "mother_social"))

  ID.1_sup <- sum(!is.na(output$relat_ID.1))
  ID.2_sup <- sum(!is.na(output$relat_ID.2))

  if (ID.1_sup > ID.2_sup) winner <- ID.1  ## the one with the most relatives wins
  else if (ID.1_sup < ID.2_sup) winner <- ID.2
  else winner <- NA_character_

  winner
}

#################################################################################

#' Find the winner of interaction between two related natives.
#'
#' The ID supported by the MRCA wins the interaction.
#'
#' @describeIn find_family find the winner of an interaction between two related natives.
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.related <- function(ID.1, ID.2){

     find_dyad_MRCA.choice(ID.1, ID.2) ## the one supported by the MRCA wins
}

#################################################################################

#' @describeIn find_family find the winner of an interaction.
#'
#' This function applies the different functions according to the type of interaction.
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_interaction.winner.from.interaction.type <- function(ID.1, ID.2, at, interaction.type){

  if (interaction.type == "native_related") winner <- find_dyad_winner.native.related(ID.1, ID.2) ## MRCA youngest ascendency
  else if (interaction.type == "native_unrelated") winner <- find_dyad_winner.native.unrelated(ID.1, ID.2, at) ## relatedness
  else if (interaction.type == "migrant_migrant") winner <- find_dyad_winner.migrant(ID.1, ID.2, date) ## tenure
  else if (interaction.type == "migrant_native") winner <- find_dyad_winner.native.migrant(nativeID = ID.2, migrantID = ID.1) ## clan members
  else if (interaction.type == "native_migrant") winner <- find_dyad_winner.native.migrant(nativeID = ID.1, migrantID = ID.2) ## clan memebers
  else NA_character_
}

#################################################################################

#' @describeIn fetch_family fetch the winner of an interaction.
#'
#' This function returns the winner of an interaction according the the social-support rules.
#' It first classifies interaction based on the migratory status and relatedness of ID.1 and ID.2.
#' Then it applies the following rules:
#'
#' migrant_migrant -> the ID with longest tenure wins the interaction
#' migrant_native -> the native ID wins the interaction.
#' native_migrant -> the native ID wins the interaction.
#' native_unrelated -> the ID with the most living related ID within the clan wins the interaction.
#' native_related -> the ID supported by the MRCA wins the interaction.
#'
#' In the case of twins and their descendant it returns NA.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' fetch_dyad_interaction.winner("A-001", "A-084", "1997-04-10")
fetch_dyad_interaction.winner <- function(ID.1, ID.2, at){

  input_tbl <- create_dyad_interaction.type(ID.1, ID.2, at)

  output_tbl <- input_tbl %>%
    dplyr::rowwise() %>%
    dplyr::mutate(winner = find_dyad_interaction.winner.from.interaction.type(ID.1 = .data$ID.1, ID.2 = .data$ID.2, at = .data$date, interaction.type = .data$type))

  check_function_output(input_tbl,
                        output_tbl,
                        join.by = c("ID.1", "ID.2", "date"),
                        duplicates = "none",
                        output.IDcolumn = "winner")
}

#################################################################################

#' @describeIn find_family find the supported individual from the MRCA.
#'
#' Apply the youngest ascendancy rule.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' find_dyad_MRCA.choice("A-001", "A-084")
find_dyad_MRCA.choice <- function(ID.1, ID.2){

  ID.1 <- check_function_arg.ID(ID.1, arg.max.length = 1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, arg.max.length = 1, argument.name = 'ID.2')

  MRCA <- find_dyad_id.ancestor.MRCA(ID.1, ID.2, filiation = "mother_social") ## can pass filiation as an argument filiation if wanted

  if (is.na(MRCA)) { ## no common ancestor ### can be removed if function work only on related IDs.
    winner <- NA_character_

  } else {## check which of the daughter of the MRCA is the youngest (will be supported by the MRCA)

      if (fetch_id_is.descendant(ID.1, ID.2)) winner <- ID.2 ## if ID.1 is descendant of ID.2 ID.2 wins
      else if (fetch_id_is.descendant(ID.2, ID.1)) winner <- ID.1 ## if ID.2 is descendant of ID.1 ID.1 wins
      else winner <- find_id_id.descendant.of.youngest.offspring(c(ID.1, ID.2), MRCA) ## winner is the descendant of the youngest
  }
  winner
}


#################################################################################

#' @describeIn create_family creates a table with bystander and their information relatively to the interacting parties.
#'
#' Create a table with all potential supporter in the clan (clan member - cubs), and information to compute the different rules.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' create_dyad_table.bystander("A-001", "A-084", "1997-04-10")

create_dyad_table.bystander <- function(ID.1, ID.2, at) {  ### will need either to rename it or to make if vector compatible or

  ID.1 <- check_function_arg.ID(ID.1, arg.max.length = 1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, arg.max.length = 1, argument.name = 'ID.2')

  if (!all(fetch_id_is.alive(ID = c(ID.1, ID.2), at = at))) {
    stop("social support cannot be computed because ID.1 and/or ID.2 is dead at the date provided with 'at'.")
  }

  date <- check_function_arg.date(at)

  clan_1 <- fetch_id_clan.current(ID.1, at = date)  ## slow
  clan_2 <- fetch_id_clan.current(ID.2, at = date)  ## slow

  if (clan_1 != clan_2) stop("ID.1 and ID.2 are not from the same clan")
  ####### get information about the clan members
  MRCA_choice <- find_dyad_MRCA.choice(ID.1, ID.2) ## find the winner

  interaction_type <- create_dyad_interaction.type(ID.1, ID.2, at = at)[["type"]]
  ### get all clan members and their ancestors and life_stage
  tab <- create_id_starting.table(clan = clan_1, at = date, lifestage = c("!cub", "!dead"))

  tab %>%
    dplyr::mutate(ID.1 = ID.1,
                  ID.2 = ID.2,
                  type = interaction_type,
                  life_stage = fetch_id_lifestage(.data$ID, !!date), ### rule_1 is migrant or native keep the lifestage function to let the possibility to remove the cubs
                  relat_ID.1 = fetch_dyad_relatedness(.data$ID, ID.1), ## rule_2 is related to one or the other
                  relat_ID.2 = fetch_dyad_relatedness(.data$ID, ID.2), ## rule_2 is related to one or the other
                  supported_mrcaID = MRCA_choice, ## rule_3 find the ID supported by the MRCA (youngest ascendency)
                  loser = ifelse(.data$supported_mrcaID == .data$ID.1, .data$ID.2, ifelse(.data$supported_mrcaID == .data$ID.2, .data$ID.1, NA)),
                  follow_MRCA = fetch_id_follow.MRCA.choice(.data$ID, .data$loser[1]))

}

##################################################################################
#' @describeIn fetch_family fetch the individual following the  MRCA. i.e. the descendant of younger offspring.
#'
#' Flag the individual that follow the MRCA choice. These IDs are related to both interacting IDs and descendant of a
#' younger sister than the loser of the interaction.
#'
#' @return Returns a logical indicating if an ID follow the choice of the MRCA.
#' @export
#' @examples
#' fetch_id_follow.MRCA.choice(ID = c("A-010", "A-018"), loserID = "A-010")
#'
fetch_id_follow.MRCA.choice <- function(ID, loserID) {

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          loserID = check_function_arg.ID(loserID, arg.max.length = 1, argument.name = 'loserID'))

  if (is.na(loserID)) {
    output <- input %>%
      dplyr::distinct() %>%
      dplyr::mutate(loser_descend = NA_character_)

  } else {
    ### flag the descendant of older sisters
    loser_line <- find_id_id.ancestor.all(loserID, filiation = "mother_social")
    losers <- c(loserID, find_id_id.sibling.older(loser_line))

    output <- input %>%
      dplyr::distinct() %>%
      dplyr::mutate(relat = fetch_dyad_relatedness(.data$ID, !!loserID),
                    loser_descend = !fetch_id_is.descendant(.data$ID, losers),
                    loser_descend = ifelse(is.na(.data$relat), FALSE, .data$loser_descend))
  }

  check_function_output(input,
                        output,
                        join.by = "ID",
                        duplicates = "input",
                        output.IDcolumn = "loser_descend")

}


######################################################################################
#' @describeIn find_family find the supporters of ID.1 when interacting against ID.2
#'
#' Identify the supporters for ID.1, when it interacts with ID.2.
#' If you want the supporters for ID.2, just rerun the function swapping the inputs for ID.1 and ID.2.
#' An interaction is first classified into on of the categories obtained by [create_dyad_interaction.type].
#' Second, according to the type of interaction it applies the following rules:
#' migrant_migrant -> cannot identify the IDs of supporters; returns NA.
#' migrant_native -> IDs related to the migrant
#' native_migrant -> IDs of native individuals not related to the migrant
#' native_unrelated -> IDs related to ID.1
#' native_related -> if ID.1 is supported by MRCA, IDs following the MRCA (according to [fetch_id_follow.MRCA.choice]), otherwise no one
#'
#' @return Return the supporters of ID.1
#' @export
#' @examples
#' find_dyad_supporter(ID.1 = "A-046", ID.2 = "A-041", at = "1996-06-23")
#' find_dyad_supporter(ID.1 = "A-046", ID.2 = "A-018", at = "1996-06-23")
#'
find_dyad_supporter <- function(ID.1, ID.2, at) {

  ID.1 <- check_function_arg.ID(ID.1, arg.max.length = 1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, arg.max.length = 1, argument.name = 'ID.2')
  at <- check_function_arg.date(at)

  ## check if missing individuals
  if (is.na(ID.1) || is.na(ID.2)) return(NA_character_)

  ## check if ID.1 and ID.2 is alive
  if (!any(fetch_id_is.alive(c(ID.1, ID.2), at =  at))) {
    out <- NA_character_
    warning(paste("One ID is not alive at:", at))
    }

  tab <- create_dyad_table.bystander(ID.1 = ID.1, ID.2 = ID.2, at = at) %>%
    dplyr::mutate(migrant = fetch_id_is.migrant(.data$ID, at = at, migrant.mother.as.native = TRUE))

  ## unrelated natal = all relatives
  if (tab$type[1] == "native_unrelated") {
    out <- tab$ID[!is.na(tab$relat_ID.1)]
    ## related natal = the ones following the MRCA
  } else if (tab$type[1] == "native_related") {
    # twins
    if (is.na(tab$loser[1])) {
      out <- NA_character_
    # focal is the loser
    } else if(ID.1 == tab$loser[1]) {
      out <- character(0)
    # focal is the winner
    } else {
      out <- tab$ID[!is.na(tab$follow_MRCA) & tab$follow_MRCA]
    }

    ## migrant native = count the number of native
  } else if (tab$type[1] == "migrant_native") {
    out <- tab$ID[!is.na(tab$relat_ID.1)]
  } else if (tab$type[1] == "native_migrant") {
    out <- setdiff(tab$ID[!is.na(tab$migrant) & !tab$migrant], ## all natives support ID.1
                   tab$ID[!is.na(tab$relat_ID.2)]) ## except those related to ID.2
  } else {
    out <- NA_character_
    warning("both individuals are migrants; no defined way to identify supporters")
  }
  setdiff(out, ID.1)
}


######################################################################################
#' @describeIn find_family find the number of supporters of ID.1 when interacting against ID.2
#'
#' Count the supporters for ID.1, when it interacts with ID.2.
#' If you want the number of supporters for ID.2, just rerun the function swapping the inputs for ID.1 and ID.2.
#' An interaction is first classified into on of the categories obtained by [create_dyad_interaction.type].
#' Second, according to the type of interaction it applies the following rules:
#' migrant_migrant -> cannot count the number of supporter; returns NA.
#' migrant_native -> count IDs related to the migrant
#' native_migrant -> count IDs native and not related to the migrant
#' native_unrelated -> count IDs related to ID.1
#' native_related -> if ID.1 is supported by MRCA, count IDs following the MRCA (according to [fetch_id_follow.MRCA.choice]), otherwise 0
#'
#' @return Return the supporters of ID.1
#' @export
#' @examples
#' find_dyad_number.supporter(ID.1 = "A-046", ID.2 = "A-041", at = "1996-06-23")
#' find_dyad_number.supporter(ID.1 = "A-046", ID.2 = "A-018", at = "1996-06-23")
#'
find_dyad_number.supporter <- function(ID.1, ID.2, at) {
  res <- find_dyad_supporter(ID.1 = ID.1, ID.2 = ID.2, at = at)
  find_vector_length.without.na(res)
}


##################################################################################
#' @describeIn fetch_family fetch the supporters of ID.1 when interacting against ID.2
#'
#' Identify the supporters for ID.1, when it interacts with ID.2.
#' This functions is a wrapper calling [find_dyad_supporter] on vectorial inputs.
#'
#' @return Return a list with the supporters for each value of ID.1.
#' @export
#' @examples
#' fetch_dyad_supporter(ID.1 = c("A-046", "A-041", "A-046"),
#'                      ID.2 = c("A-041", "A-046", "A-041"),
#'                      at = "1996-06-23")
#'
#' if (require("dplyr") && require("tidyr")) {
#' ## the following needs you to load dplyr and tidyr:
#'
#' tibble(ID.1 = c("A-046", "A-041"),
#'        ID.2 = c("A-041", "A-046"),
#'        at = "1996-06-23") %>%
#'    mutate(supporter_ID.1 = fetch_dyad_supporter(ID.1 = ID.1, ID.2 = ID.2, at = at),
#'           supporter_ID.2 = fetch_dyad_supporter(ID.1 = ID.2, ID.2 = ID.1, at = at)) -> tb_support
#'
#' tb_support
#'
#' ## extract supporters ID.1 as columns:
#' tb_support %>%
#'    select(- supporter_ID.2) %>%
#'    unnest_wider(supporter_ID.1, names_sep = "_supporter_")
#'
#' ## extract supporters ID.1 as rows:
#' tb_support %>%
#'    select(- supporter_ID.2) %>%
#'    unnest_longer(supporter_ID.1)
#'
#' ## or for simple check:
#' tb_support$supporter_ID.1
#'
#' ## count supporters:
#' tb_support %>%
#'    rowwise() %>%
#'    mutate(number_supporters.ID1 = length(supporter_ID.1),
#'           number_supporters.ID2 =  length(supporter_ID.2)) %>%
#'    ungroup()
#'
#'  }
#'
fetch_dyad_supporter <- function(ID.1, ID.2, at, CPUcores = NULL, .parallel.min = 20, drop = TRUE) {

  input <- tibble::tibble(ID.1 = !!ID.1,
                          ID.2 = !!ID.2,
                          at = !!at)

  input_unique <- unique(input)

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input_unique) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if(is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## Before we loop, we want to make sure the cache exists, otherwise, each iteration of a parallel loop would build its own cache.
  if (!"life_history" %in% find_package_cached.table()) {
    create_id_life.history.table() ## trigger caching
  }

  ## We loop ## TODO: we should loop only on unique combination, but we need a general wrapper for that...
  if (CPUcores > 1 && nrow(input_unique) >= .parallel.min) {
    out <- furrr::future_pmap(input_unique, find_dyad_supporter,
                              .progress = TRUE,
                              .options = furrr::furrr_options(globals = ".database"))
  } else {
    if (CPUcores > 1 && (nrow(input_unique) < .parallel.min)) {
      message(paste0("Argument CPUcores ignored as less than", .parallel.min,  " cases to compute."))
    }
    out <- purrr::pmap(input_unique, find_dyad_supporter)
  }

  input_unique %>%
    dplyr::mutate(ID_supporter = out) -> out_table

  out <- check_function_output(input.tbl = input, output.tbl = out_table,
                               join.by = c("ID.1", "ID.2", "at"), duplicates = "input",
                               output.IDcolumn = "ID_supporter")


  ## name list output if unique:
  if (length(unique(input$ID.1)) == length(input$ID.1)) {
    names(out) <- ID.1
  }

  ## autocollapse:
  if (drop) {
    if (all(sapply(out, length) == 1)) {
     out <- sapply(out, function(x) `[`(x, 1))
    }

    if (length(out) == 1) {
      out <- unlist(out)
      names(out) <- NULL
    } else if (length(out) == 0) {
      out <- character(0)
    }
  }

  ## return
  out
}


##################################################################################
#' @describeIn fetch_family fetch the number of supporters of ID.1 when interacting against ID.2
#'
#' Count the supporters for ID.1, when it interacts with ID.2.
#' This functions is a wrapper calling [find_dyad_number.supporter] on vectorial inputs.
#'
#' @return Return a list with the number of supporters for each value of ID.1.
#' @export
#' @examples
#' fetch_dyad_number.supporter(ID.1 = c("A-046", "A-041", "A-046"),
#'                             ID.2 = c("A-041", "A-046", "A-041"),
#'                             at = "1996-06-23")
#'
fetch_dyad_number.supporter <- function(ID.1, ID.2, at, CPUcores = NULL, .parallel.min = 20) {

  out <- fetch_dyad_supporter(ID.1 = ID.1, ID.2 = ID.2, at = at, CPUcores = CPUcores, .parallel.min = .parallel.min, drop = FALSE)

  out_nb <- sapply(out, find_vector_length.without.na)

  if (length(unique(ID.1)) == length(ID.1)) {
    names(out_nb) <- ID.1
  }

  ## return
  out_nb
}
