
#' @describeIn fetch_family fetch the tracks tables for individual(s) (used internally for any work with package {amt}, which handles home ranges)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_track.table usage:
#' fetch_id_track.table(c("A-001", "A-010"),
#'                      from = c("1996/10/01", "1996/01/01"),
#'                      to = c("1996/10/02", "1997/12/01"))
#'
fetch_id_track.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                 fill = TRUE, first.event = "observation", debug = FALSE) {

  ## temporary fix (not in Description since amt 0.1.5 is not on CRAN)
  if (utils::packageVersion("amt") < "0.1.5") {
    stop("Version of the package amt prior from 0.1.5 won't work; run remotes::install_github('jmsigner/amt') to install the latest version.")
    }

  sightings <- fetch_id_sighting.table(ID = ID, from = from, to = to, at = at,
                                       fill = fill, first.event = first.event, debug = debug)

  ## to shut up verbose amt::mk_track
  quiet_mk_track <- function(...) {
    withCallingHandlers(amt::mk_track(...), message = function(m) invokeRestart("muffleMessage"))
  }

  tracks <- purrr::map(sightings, ~ quiet_mk_track(tbl = .x, .x = longitude, .y = latitude, .t = sighting_time,
                       crs = 4326,
                       all_cols = TRUE, order_by_ts = TRUE))

  ## replace empty sighting tables by empty tracking tables (with matching columns):
  for (i in seq_along(tracks)) {
    if (is.null(tracks[[i]])) {
      tracks[[i]] <-  tibble::tibble()
    }
  }

  tracks
}


#' @describeIn fetch_family fetch the tracks tables for clan(s) (used internally for any work with package {amt}, which handles home ranges)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_track.table usage:
#' fetch_clan_track.table(c("A", "L"),
#'                        from = c("1996/10/01", "1996/01/01"),
#'                        to = c("1996/10/02", "1997/12/01"))
#'
fetch_clan_track.table <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                   at = NULL, from = NULL, to = NULL,
                                   clan.overlap = "any", lifestage.overlap = "any",
                                   fill = TRUE, first.event = "observation",
                                   debug = FALSE) {

  ## temporary fix (not in Description since amt 0.1.5 is not on CRAN)
  if (utils::packageVersion("amt") < "0.1.5") {
    stop("Version of the package amt prior from 0.1.5 won't work; run remotes::install_github('jmsigner/amt') to install the latest version.")
  }

  sightings <- fetch_clan_sighting.table(clan = clan, sex = sex, lifestage = lifestage,
                                         at = at, from = from, to = to,
                                         clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                         fill = fill, first.event = first.event,
                                         debug = debug)

  ## to shut up verbose amt::mk_track
  quiet_mk_track <- function(...) {
    withCallingHandlers(amt::mk_track(...), message = function(m) invokeRestart("muffleMessage"))
  }

  tracks <- purrr::map(sightings, ~ quiet_mk_track(tbl = .x, .x = longitude, .y = latitude, .t = sighting_time,
                                                   crs = 4326,
                                                   all_cols = TRUE, order_by_ts = TRUE))

  ## replace empty sighting tables by empty tracking tables (with matching columns):
  for (i in seq_along(tracks)) {
    if (is.null(tracks[[i]])) {
      tracks[[i]] <-  tibble::tibble()
    }
  }

  tracks
}


#' @describeIn fetch_family fetch the home range for individual(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_homerange:
#' fetch_id_homerange(c("A-001", "A-010", "A-001"),
#'                    from = c("1996/10/01", "1996/01/01", "1996/01/01"),
#'                    to = c("1996/10/02", "1997/12/01", "1996/10/02"))
#'
fetch_id_homerange <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                               fill = TRUE, first.event = "observation", debug = FALSE,
                               hr.method = "mcp", hr.args = list(), hr.raw = FALSE) {

  hr.method <- check_function_arg.hr.method(hr.method)

  tracks <- fetch_id_track.table(ID = ID, from = from, to = to, at = at,
                                 fill = fill, first.event = first.event, debug = FALSE) ## debug must be FALSE here since we use debug here for hr.method

  hr_fn_text <- paste0("amt::hr_", hr.method)
  hr_fn <- eval(parse(text = hr_fn_text))

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug || grepl("package", x = e)) {if (grepl("package", x = e)) stop(e); message(e); cat("\n")}; NA}

  ## TODO: make parallel?
  geom_list <- purrr::map(tracks, ~ tryCatch(do.call(hr_fn, c(list(x = na.omit(.x), keep.data = FALSE), hr.args)), error = err_fn(e)))

  if (!hr.raw) {
    geom_list <- purrr::map(geom_list, function(geom) geom[[1]]["geometry"][[1]])
  }

  geom_list
}


#' @describeIn fetch_family fetch the home range for clan(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_homerange:
#' fetch_clan_homerange(c("A", "L", "A"),
#'                      from = c("1996/10/01", "1996/01/01", "1996/01/01"),
#'                      to = c("1996/10/02", "1997/12/01", "1996/10/02"))
#'
fetch_clan_homerange <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                 at = NULL, from = NULL, to = NULL,
                                 clan.overlap = "any", lifestage.overlap = "any",
                                 fill = TRUE, first.event = "observation",
                                 debug = FALSE,
                                 hr.method = "mcp", hr.args = list(), hr.raw = FALSE) {

  hr.method <- check_function_arg.hr.method(hr.method)

  tracks <- fetch_clan_track.table(clan = clan, sex = sex, lifestage = lifestage,
                                   at = at, from = from, to = to,
                                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                   fill = fill, first.event = first.event,
                                   debug = FALSE) ## debug must be FALSE here since we use debug here for hr.method

  hr_fn_text <- paste0("amt::hr_", hr.method)
  hr_fn <- eval(parse(text = hr_fn_text))

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; NA}

  ## TODO: make parallel?
  geom_list <- purrr::map(tracks, ~ tryCatch(do.call(hr_fn, c(list(x = na.omit(.x), keep.data = FALSE), hr.args)), error = err_fn(e)))

  if (!hr.raw) {
    geom_list <- purrr::map(geom_list, function(geom) geom[[1]]["geometry"][[1]])
  }

  geom_list
}


#' @describeIn fetch_family fetch the home range area (in km^2) for individual(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_homerange.area usage:
#' fetch_id_homerange.area(c("A-001", "A-010"),
#'                         from = c("1996/10/01", "1996/01/01"),
#'                         to = c("1996/10/02", "1997/12/01"))
#'
fetch_id_homerange.area <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                    fill = TRUE, first.event = "observation", debug = FALSE,
                                    hr.method = "mcp", hr.args = list()) {

  geom_list <- fetch_id_homerange(ID = ID, from = from, to = to, at = at,
                                  fill = fill, first.event = first.event, debug = debug,
                                  hr.method = hr.method, hr.args = hr.args, hr.raw = TRUE)

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; NA}

  area <- purrr::map(geom_list, ~ tryCatch(amt::hr_area(x = .x)$area / 1e6, error = err_fn(e)))

  ## collapse as vector if possible (not possible e.g. when hr.method = "akde" since returns intervals):
  if (max(unlist(purrr::map(area, length))) < 2) {
    area <- unlist(area)
  }

  area
}


#' @describeIn fetch_family fetch the home range area (in km^2) for clan(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_homerange.area usage:
#' fetch_clan_homerange.area(c("A", "L"),
#'                           from = c("1996/10/01", "1996/01/01"),
#'                           to = c("1996/10/02", "1997/12/01"))
#'
fetch_clan_homerange.area <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                      at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      fill = TRUE, first.event = "observation",
                                      debug = FALSE,
                                      hr.method = "mcp", hr.args = list()) {

  geom_list <- fetch_clan_homerange(clan = clan, sex = sex, lifestage = lifestage,
                                    at = at, from = from, to = to,
                                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                    fill = fill, first.event = first.event, debug = debug,
                                    hr.method = hr.method, hr.args = hr.args, hr.raw = TRUE)

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; NA}

  area <- purrr::map(geom_list, ~ tryCatch(amt::hr_area(x = .x)$area / 1e6, error = err_fn(e)))

  ## collapse as vector if possible (not possible e.g. when hr.method = "akde" since returns intervals):
  if (max(unlist(purrr::map(area, length))) < 2) {
    area <- unlist(area)
  }

  area
}


#' @describeIn check_family Check arguments 'hr.method'.
#' @export
#' @examples
#'
#' check_function_arg.hr.method("mcp")
#'
check_function_arg.hr.method <- function(hr.method) {

  if (length(hr.method) != 1L) {
    stop("The argument 'hr.method' should be of length one.")
  }

  possible_args <- c('akde', 'kde', 'mcp', 'locoh')

  if (!is.character(hr.method)) {
    stop(paste0("The argument 'hr.method' should be a quotted string of characters such as: '", paste(possible_args, collapse = "', '"), "'"))
  }

  if (!hr.method %in% possible_args) {
    stop(paste0("Unknown argument 'hr.method'; it should be one of the following: '", paste(possible_args, collapse = "', '"), "'"))
  }

  hr.method
}



#' Reshape a table containing a column with spatial information into a simple feature (sf) object
#'
#' This function transforms a table containing one spatial list column into a proper sf object.
#' This is useful to work easily with **ggplot2** and **sf** with objects such as those produced by [fetch_clan_homerange()].
#' Note that it drops the rows of the table with no spatial information.
#'
#' @inheritParams arguments
#'
#' @return a sf object.
#' @export
#'
#' @examples
#'
#' ## Let's work with the home ranges of clans based on adult female 95% MCP:
#' if (require("dplyr")) {
#'
#' load_package_database.dummy()
#'
#' ### the raw output produced by fetch function is a tibble with a list-column:
#' tibble(clan = find_clan_name.all()) %>%
#'        mutate(hr = fetch_clan_homerange(clan = clan,
#'                                         sex = "female",
#'                                         lifestage = "adult"),
#'               sightings = fetch_clan_sighting.point(clan = clan,
#'                                                     sex = "female",
#'                                                     lifestage = "adult")) -> tbl
#' tbl
#'
#' ### conversion to sf (great for plots):
#' sf_clans <- reshape_table_sf(tbl,
#'                              column.polygon = "hr",
#'                              column.point = "sightings")
#'
#' \dontrun{
#'   if (require("ggplot2")) {
#'     ggplot(sf_clans) +
#'       geom_sf(aes(geometry = hr, colour = clan), alpha = 0.5) +
#'       geom_sf(aes(geometry = sightings, colour = clan),
#'               alpha = 0.6, size = 1) +
#'       geom_sf(data = sf_hyenaR$rim_polygon, colour = "brown", fill = NA) +
#'       ## to avoid issues caused by rare wrong coordinates on full data:
#'       coord_sf(ylim = c(-3.26, -3.09), xlim = c(35.48, 35.67))
#' }
#' }
#'
#' ### conversion to spatial tibble (great for spatial computations):
#' spatial_tbl <- tibble(sf_clans) ## note: use output from reshape_table_sf()
#'
#' \dontrun{
#'   if (require("sf")) {
#'     spatial_tbl %>%
#'       mutate(centre = st_centroid(hr))
#'
#'     #### also possible with sf object but not always needed:
#'     sf_clans %>%
#'       mutate(centre = st_centroid(hr))
#' }
#' }
#' }
#'
reshape_table_sf <- function(tbl, column.polygon = NULL, column.point = NULL) {

  column.polygon <- check_function_arg.column.any.table(column.polygon, tbl = tbl, null.ok = TRUE)
  column.point <- check_function_arg.column.any.table(column.point, tbl = tbl, null.ok = TRUE)

  if (is.null(column.polygon) && is.null(column.point)) {
    stop("Both 'column.polygon' and 'column.point' cannot be NULL!")
  }

  row.before.drop <- nrow(tbl)

  if (!is.null(column.polygon)) {
    loose <- purrr::map_lgl(tbl[, column.polygon, drop = TRUE], ~ "logical" %in% class(.x))
    tbl <- tbl[!loose, ]
  }

  if (!is.null(column.point)) {
    loose <- purrr::map_lgl(tbl[, column.point, drop = TRUE], ~ "logical" %in% class(.x))
    tbl <- tbl[!loose, ]
  }

  nrow.dropped <- row.before.drop - nrow(tbl)
  if (nrow.dropped > 0) {
    message(paste(nrow.dropped, "rows have been discarded since they did not contain any spatial information"))
  }

  column <- c(column.polygon, column.point)
  tbl_non_spatial <- tbl %>% dplyr::select(-!!column)


  tbl_spatial <- tbl_non_spatial

  if (!is.null(column.polygon)) {
    spatial.polygon  <- do.call(c, tbl[, column.polygon, drop = TRUE])
    tbl_spatial <- dplyr::bind_cols(tbl_spatial, !!column.polygon := spatial.polygon)
  }
  if (!is.null(column.point)) {
    spatial.point  <- sf::st_as_sfc(tbl[, column.point, drop = TRUE])
    tbl_spatial <- dplyr::bind_cols(tbl_spatial, !!column.point := spatial.point)
  }

  sf::st_as_sf(tbl_spatial)
}

globalVariables(":=") # we cannot reexport the colon equal operator because it is not a function!


#' List of simple feature collections for hyenaR
#'
#' This object is a list of simple feature collections (sfc) for hyenaR.
#' This allows for you to plot various spatial objects such as the crater rim,
#' the roads, the rivers, the transects and more (see examples below).
#' You can also use these sfc to computate spatial metrics (e.g. area of the crater).
#'
#' @name sf_hyenaR
#' @docType data
#' @keywords sf
#'
#' @examples
#' ## Here is the list of everything you can use:
#' names(sf_hyenaR)
#'
#' ## Example of simple computation:
#' if (require("sf")) {
#'   area_crater <- st_area(sf_hyenaR$rim_polygon)
#'   units(area_crater) <- "km^2"
#'   area_crater
#' }
#'
#' ## Example of plot:
#' \dontrun{
#' if (require("ggplot2")) {
#'  ggplot() +
#'  geom_sf(data = sf_hyenaR$rim_polygon, colour = "brown", fill = "lightgreen") +
#'    geom_sf(data = sf_hyenaR$roads_crater, colour = "black") +
#'    geom_sf(data = sf_hyenaR$waterbodies_lakes, fill = "blue", colour = NA) +
#'    geom_sf(data = sf_hyenaR$rivers_main, colour = "blue") +
#'    theme_classic()
#' }
#' }
NULL
