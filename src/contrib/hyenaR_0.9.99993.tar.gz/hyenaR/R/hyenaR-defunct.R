#' Defunct Functions in Package hyenaR
#'
#' The functions or variables listed here are no longer part of hyenaR as they are no longer needed.
#'
#' @param ... Arguments formerly passed to the function that is now defunct.
#'
#' @name hyenaR-defunct
NULL

# Example not pointing to new function: DO NOT UNCOMMENT SINCE OLD FUNCTION NOW GONE

#  ###########################
#
#  #' @describeIn hyenaR-defunct Defunct function
#  #' @export
#  #'
#  indv_summary <- function(...) .Defunct(package = 'hyenaR')
#

# Example pointing to new function: DO NOT REMOVE AS USED IN EXAMPLE OF fetch_function_is.defunct

###########################
#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_sex <- function(...) .Defunct("fetch_id_sex")
