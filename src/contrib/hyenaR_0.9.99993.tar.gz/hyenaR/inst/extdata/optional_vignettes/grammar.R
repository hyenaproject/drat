## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  rows.print = 100
)
library(hyenaR)
library(stringr)

## ---- include = FALSE---------------------------------------------------------
all_fn <- ls("package:hyenaR")
all_fn <- all_fn[!fetch_function_is.defunct(all_fn)]
all_3parts_fn <- all_fn[str_count(all_fn, "\\_") == 2]
all_non3parts_fn <- setdiff(all_fn, all_3parts_fn)

## ---- echo = FALSE------------------------------------------------------------
all_verbs <- str_replace(string = all_3parts_fn, pattern = "^(.*)\\_.*\\_.*$", "\\1")
verbs <- table(all_verbs)
verbs_tbl <- tibble::tibble(verbs = names(verbs), functions = !!verbs)
verbs_meaning <- c(build = "build something and write it on the hard drive",
                   check = "check that something is OK (internal)",
                   create = "create a table",
                   delete = "delete something (internal)",
                   download = "dowload files",
                   extract = "extract elements from a table (mostly internal)",
                   fetch = "fetch information to build a new column",
                   find = "find out information",
                   load = "load a dataset",
                   multifetch = "fetch information to build a several columns at once",
                   plot = "plot something",
                   recode = "recode a variable",
                   reshape = "reshape the structure of a table"
                   )
verbs_tbl$meaning <- verbs_meaning[match(verbs_tbl$verbs, names(verbs_meaning))]
verbs_tbl

## ---- include = FALSE---------------------------------------------------------
fn_by_verb <- purrr::map(verbs_tbl$verbs, ~ all_3parts_fn[all_verbs == .x])
names(fn_by_verb) <- verbs_tbl$verbs
fn_by_verb

## ----run template on each verb, include = FALSE-------------------------------
job <- purrr::map(names(fn_by_verb), ~ knitr::knit_expand(file = "verb_template.Rmd", fn = .x))

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("add" := fn_by_verb[["add"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("as" := fn_by_verb[["as"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("build" := fn_by_verb[["build"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("check" := fn_by_verb[["check"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("create" := fn_by_verb[["create"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("cur" := fn_by_verb[["cur"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("data" := fn_by_verb[["data"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("db" := fn_by_verb[["db"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("delete" := fn_by_verb[["delete"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("dev" := fn_by_verb[["dev"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("df" := fn_by_verb[["df"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("download" := fn_by_verb[["download"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("dplyr" := fn_by_verb[["dplyr"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("extract" := fn_by_verb[["extract"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("fetch" := fn_by_verb[["fetch"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("find" := fn_by_verb[["find"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("group" := fn_by_verb[["group"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("install" := fn_by_verb[["install"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("invoke" := fn_by_verb[["invoke"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("is" := fn_by_verb[["is"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("load" := fn_by_verb[["load"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("multifetch" := fn_by_verb[["multifetch"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("mutate" := fn_by_verb[["mutate"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("new" := fn_by_verb[["new"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("plot" := fn_by_verb[["plot"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("r" := fn_by_verb[["r"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("recode" := fn_by_verb[["recode"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("rename" := fn_by_verb[["rename"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("reshape" := fn_by_verb[["reshape"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("retrieve" := fn_by_verb[["retrieve"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("select" := fn_by_verb[["select"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("sql" := fn_by_verb[["sql"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("summarise" := fn_by_verb[["summarise"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("summarize" := fn_by_verb[["summarize"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("tbl" := fn_by_verb[["tbl"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("test" := fn_by_verb[["test"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("validate" := fn_by_verb[["validate"]])

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble("wrap" := fn_by_verb[["wrap"]])

## ---- echo = FALSE------------------------------------------------------------
all_targets <- str_replace(string = all_3parts_fn, pattern = "^.*\\_(.*)\\_.*$", "\\1")
targets <- table(all_targets)
targets_tbl <- tibble::tibble(targets = names(targets),
                              functions = !!targets) %>%
  dplyr::rowwise() %>%
  dplyr::mutate(example = all_3parts_fn[all_targets == targets][1])
targets_tbl

## ---- echo = FALSE------------------------------------------------------------
tibble::tibble(non_conventional = all_non3parts_fn)

