context("Test functions related to spatial tasks")

## ID LEVEL

test_that("fetch_id_track.table returns the correct output", {
  ref <-
    list(
      `A-001` = structure(
        list(
          x_ = numeric(0),
          y_ = numeric(0),
          t_ = structure(
            numeric(0),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct", "POSIXt")
          ),
          ID = character(0),
          sighting_clan = character(0),
          from = structure(numeric(0), class = "Date"),
          to = structure(numeric(0), class = "Date")
        ),
        row.names = integer(0),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(
          list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        )
      ),
      `A-010` = structure(
        list(
          x_ = c(35.5405, 35.52633, 35.5245, 35.50167, 35.50417),
          y_ = c(-3.17117,-3.1525,-3.14617,-3.17533,-3.14017),
          t_ = structure(
            c(832683000, 835513440, 837240300, 837839280, 837843000),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct", "POSIXt")
          ),
          ID = c("A-010", "A-010", "A-010", "A-010", "A-010"),
          sighting_clan = c("A", "A", "A", "A", "A"),
          from = structure(c(9496, 9496, 9496, 9496, 9496), class = "Date"),
          to = structure(c(9709, 9709, 9709, 9709, 9709), class = "Date")
        ),
        row.names = c(NA,5L),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(
          list(input = "EPSG:4326",
               wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        )
      )
    )
  job <- fetch_id_track.table(c("A-001", "A-010"),
                              from = c("1996/10/01", "1996/01/01"),
                              to = c("1996/10/02", "1996/08/01"))
  expect_equal(ref, job)
})

test_that("fetch_id_homerange returns the correct output", {
  ref <-
    list(
      `A-001` = NA,
      `A-010` = structure(
        list(`95%` = structure(
          list(structure(
            c(35.5405, 35.50417, 35.5245, 35.5405, -3.17117, -3.14017, -3.14617, -3.17117),
            .Dim = c(4L, 2L),
            .Dimnames = list(c("1", "4", "3", "1"), c("x_", "y_"))
          )), class = c("XY", "POLYGON", "sfg")
        )),
        class = c("sfc_POLYGON", "sfc"),
        precision = 0,
        bbox = structure(
          c(
            xmin = 35.50417,
            ymin = -3.17117,
            xmax = 35.5405,
            ymax = -3.14017
          ),
          class = "bbox"
        ),
        crs = structure(
          list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        ),
        n_empty = 0L
      )
    )
  skip_if_not_installed("lwgeom")
  job <- fetch_id_homerange(c("A-001", "A-010"),
                            from = c("1996/10/01", "1996/01/01"),
                            to = c("1996/10/02", "1996/08/01"))
  expect_equal(ref, job)
})

test_that("fetch_id_homerange.area returns the correct output", {
  ref <- c(`A-001` = NA, `A-010` = 2.53355339074135)
  skip_if_not_installed("lwgeom")
  job <- fetch_id_homerange.area(c("A-001", "A-010"),
                                 from = c("1996/10/01", "1996/01/01"),
                                 to = c("1996/10/02", "1996/08/01"))
  expect_equal(ref, job)
})


## CLAN LEVEL

test_that("fetch_clan_track.table returns the correct output", {
  ref <-
    list(
      A = structure(
        list(
          x_ = numeric(0),
          y_ = numeric(0),
          t_ = structure(
            numeric(0),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct", "POSIXt")
          ),
          ID = character(0),
          sighting_clan = character(0),
          clan = character(0),
          from = structure(numeric(0), class = "Date"),
          to = structure(numeric(0), class = "Date")
        ),
        row.names = integer(0),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(
          list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        )
      ),
      L = structure(
        list(
          x_ = c(35.60183, 35.60067, 35.5965, 35.59617, 35.55333),
          y_ = c(-3.19167,-3.19267,-3.19567,-3.201,-3.17867),
          t_ = structure(
            c(827992380, 827992500, 827992920, 827993400, 827996280),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct",
                      "POSIXt")
          ),
          ID = c("L-011", "L-009", "L-009", "L-002", "L-004"),
          sighting_clan = c("L", "L", "L", "L", "L"),
          clan = c("L", "L", "L", "L", "L"),
          from = structure(c(9556, 9556, 9556, 9556, 9556), class = "Date"),
          to = structure(c(9587, 9587, 9587, 9587, 9587), class = "Date")
        ),
        row.names = c(NA, 5L),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(
          list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        )
      )
    )
  job <- fetch_clan_track.table(c("A", "L"),
                                sex = "female",
                                lifestage = "adult",
                                from = c("1996/10/01", "1996/03/01"),
                                to = c("1996/10/02", "1996/04/01"))
  expect_equal(ref, job)
})

test_that("fetch_clan_homerange returns the correct output", {
  ref <-
    list(
      A = NA,
      L = structure(
        list(`95%` = structure(
          list(structure(
            c(
              35.59617,
              35.5965,
              35.60183,
              35.59617,
              -3.201,
              -3.19567,
              -3.19167,
              -3.201
            ),
            .Dim = c(4L, 2L),
            .Dimnames = list(c("4", "3", "1", "4"),
                             c("x_", "y_"))
          )), class = c("XY", "POLYGON", "sfg")
        )),
        class = c("sfc_POLYGON",
                  "sfc"),
        precision = 0,
        bbox = structure(
          c(
            xmin = 35.59617,
            ymin = -3.201,
            xmax = 35.60183,
            ymax = -3.19167
          ),
          class = "bbox"
        ),
        crs = structure(
          list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
          class = "crs"
        ),
        n_empty = 0L
      )
    )
  skip_if_not_installed("lwgeom")
  job <- fetch_clan_homerange(c("A", "L"),
                              sex = "female",
                              lifestage = "adult",
                              from = c("1996/10/01", "1996/03/01"),
                              to = c("1996/10/02", "1996/04/01"))
  expect_equal(ref, job)
})

test_that("fetch_clan_homerange.area returns the correct output", {
  ref <- c(A = NA, L = 0.166468042570719)
  skip_if_not_installed("lwgeom")
  job <- fetch_clan_homerange.area(c("A", "L"),
                                   sex = "female",
                                   lifestage = "adult",
                                   from = c("1996/10/01", "1996/03/01"),
                                   to = c("1996/10/02", "1996/04/01"))
  expect_equal(ref, job)
})


## RESHAPE function

test_that("fetch_clan_homerange.area returns the correct output", {
  ref <-
    structure(
      list(
        hr = structure(
          list(`95%` = structure(
            list(structure(
              c(
                35.59617,
                35.5965,
                35.60183,
                35.59617,
                -3.201,
                -3.19567,
                -3.19167,
                -3.201
              ),
              .Dim = c(4L, 2L),
              .Dimnames = list(c("4", "3", "1", "4"),
                               c("x_", "y_"))
            )), class = c("XY", "POLYGON", "sfg")
          )),
          class = c("sfc_POLYGON",
                    "sfc"),
          precision = 0,
          bbox = structure(
            c(
              xmin = 35.59617,
              ymin = -3.201,
              xmax = 35.60183,
              ymax = -3.19167
            ),
            class = "bbox"
          ),
          crs = structure(
            list(input = "EPSG:4326", wkt = "GEOGCRS[\"WGS 84\",\n    DATUM[\"World Geodetic System 1984\",\n        ELLIPSOID[\"WGS 84\",6378137,298.257223563,\n            LENGTHUNIT[\"metre\",1]]],\n    PRIMEM[\"Greenwich\",0,\n        ANGLEUNIT[\"degree\",0.0174532925199433]],\n    CS[ellipsoidal,2],\n        AXIS[\"geodetic latitude (Lat)\",north,\n            ORDER[1],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n        AXIS[\"geodetic longitude (Lon)\",east,\n            ORDER[2],\n            ANGLEUNIT[\"degree\",0.0174532925199433]],\n    USAGE[\n        SCOPE[\"Horizontal component of 3D system.\"],\n        AREA[\"World.\"],\n        BBOX[-90,-180,90,180]],\n    ID[\"EPSG\",4326]]"),
            class = "crs"
          ),
          n_empty = 0L
        ),
        sightings = structure(
          list(L = structure(
            c(
              35.59617,
              35.55333,
              35.60067,
              35.5965,
              35.60183,
              -3.201,
              -3.17867,
              -3.19267,-3.19567,
              -3.19167
            ),
            .Dim = c(5L, 2L),
            class = c("XY", "MULTIPOINT", "sfg")
          )),
          class = c("sfc_MULTIPOINT", "sfc"),
          precision = 0,
          bbox = structure(
            c(
              xmin = 35.55333,
              ymin = -3.201,
              xmax = 35.60183,
              ymax = -3.17867
            ),
            class = "bbox"
          ),
          crs = structure(list(input = NA_character_, wkt = NA_character_), class = "crs"),
          n_empty = 0L
        )
      ),
      row.names = c(NA,-1L),
      class = c("sf", "tbl_df", "tbl", "data.frame"),
      sf_column = "hr",
      agr = structure(
        c(sightings = NA_integer_),
        class = "factor",
        .Label = c("constant",
                   "aggregate", "identity")
      )
    )
  skip_if_not_installed("lwgeom")
  hr <- fetch_clan_homerange(c("A", "L"),
                             sex = "female",
                             lifestage = "adult",
                             from = c("1996/10/01", "1996/03/01"),
                             to = c("1996/10/02", "1996/04/01"))
  sightings <- fetch_clan_sighting.point(c("A", "L"),
                                         sex = "female",
                                         lifestage = "adult",
                                         from = c("1996/10/01", "1996/03/01"),
                                         to = c("1996/10/02", "1996/04/01"))
  tbl <- tibble::tibble(hr = hr, sightings = sightings)
  job <- reshape_table_sf(tbl,
                          column.polygon = "hr",
                          column.point = "sightings")
  expect_equal(ref, job)
})


context("Test presence of spatial objets")

test_that("sf_hyenaR is available and of correct length", {
  expect_length(sf_hyenaR, 10)
})

