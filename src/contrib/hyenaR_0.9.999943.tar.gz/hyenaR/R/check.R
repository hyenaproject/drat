#' Internal functions to check for expected conditions inside other functions
#'
#' ```check_function_xxx``` functions are used to check that
#' users have provided allowable argument values to a function. ```check_database_xxx```
#' functions are used to check for any data discrepancies during the process of
#' database building.
#'
#' @inheritParams arguments
#' @name check_family
#' @aliases check_family check
#'
#' @examples
#' ## Load the dummy dataset:
#' load_package_database.dummy()
NULL


#' @describeIn check_family Check the argument 'clan'
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.clan(c("A", "L"))
#' check_function_arg.clan(.fill = TRUE)
check_function_arg.clan <- function(clan = NULL, strict = TRUE, .fill = FALSE, main.clans = FALSE, full.clan.names = FALSE, input.unique = FALSE) {

  main.clans      <- check_function_arg.logical(main.clans)
  possible_clans <- find_clan_name.all(main.clans = main.clans, full.clan.names = full.clan.names)

  if (is.null(clan)) {
    if (.fill) return(possible_clans)
    stop("The argument 'clan' has not been defined.")
  } else {
    if (any(!clan[!is.na(clan)] %in% possible_clans)) {
      if (strict) {
        stop(paste(c("The argument 'clan' contains clan(s) not corresponding to possible ones:",
                     unique(clan[!is.na(clan) & !clan %in% possible_clans])), collapse = " "))
      } else {
        warning("Clan(s) not corresponding to possible ones have been dropped.")
        clan <- clan[clan %in% possible_clans]
      }
    }
    if (input.unique & (length(unique(clan)) < length(clan))) {
      stop("Expecting unique clanIDs. Please remove any duplicates.")
    }
  }
  clan
}


#' @describeIn check_family Check the argument 'column' for extraction in the table hyenas.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.column("sex", tbl.name = "hyenas")
check_function_arg.column <- function(column, tbl.name) {
  if (length(tbl.name) != 1) {
    stop("The argument 'tbl.name' should be of length 1.")
  }
  tbl <- extract_database_table(tbl.names = tbl.name)
  check_function_arg.column.any.table(column, tbl)
}


#' @describeIn check_family Check the argument 'column' for extraction in any table.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' tbl <- data.frame(foo = 1)
#' check_function_arg.column.any.table("foo", tbl = tbl)
check_function_arg.column.any.table <- function(column, tbl, null.ok = FALSE) {

  if (null.ok && is.null(column)) {
    return(NULL)
  }

  if (length(column) != 1) {
    stop("The argument 'column' should be of length 1.")
  }
  if (!inherits(tbl, "data.frame")) {
    stop("The argument 'tbl' should be a tibble or data.frame")
  }
  if (!column %in% colnames(tbl)) {
    stop("The argument 'column' does not correspond to a column name!")
  }
  column
}

#' @describeIn check_family Check arguments 'date'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.date("1996/12/21")
check_function_arg.date <- function(date, argument.name = "date", arg.max.length = Inf,
                                    .fill = FALSE, fill.value = NULL, data.type = "hyena") {

  if (is.null(date)) {

    if (.fill) {

      if (is.null(fill.value)) {

        stop("When `fill` is TRUE a date must be provided using `fill.value`")

      } else {

        date <- Recall(fill.value, argument.name = "fill.value", data.type = data.type, arg.max.length = 1)

      }

    } else {

      stop("Some dates have not been defined.")

    }

  }

  if (length(date) > arg.max.length) {

    stop(paste("The function you are using can only handle", arg.max.length, "date(s)"))

  }

  error_msg <- paste0("The argument '", argument.name, "' should be in the order year-month-day (e.g. '2000/02/29' or '2000-02-29') and must be valid, e.g. not '2000-06-31' since there are not 31 days in June).")

  ## The following catches error associated with the first element only, but this
  ## matters since the first element shapes the formatting of all elements:
  raw_date <- date ## for backup

  date <- tryCatch(recode_x_date(date),
                   error = function(cond) {
                     stop(error_msg)
                   },
                   warning = function(cond) {
                     if (grepl(cond$message, pattern = "failed to parse")) {
                       stop(error_msg)
                     }
                   })

  ## The following catches all remaining errors:
  if (!all(is.na(raw_date[is.na(date)]))) { ## since as.Date only test the format of the first element, other element my have been turned into NAs even if the date is not NA
    stop(error_msg)
  }

  date_no_NA <- date[!is.na(date) & date != Inf]

  #When we are dealing with dates related to hyena data (the default) check that dates are within observation period
  #No such check is needed for weather stations. Weather data can exist before first conception (if we get historical data)
  #Weather data can also exist later than most recent observation (if hyena data has not been updated recently)
  if (data.type == "hyena") {

    if (any(date_no_NA < find_pop_date.conception.first()) || any(date_no_NA > find_pop_date.observation.last())) {
      stop(paste0("The argument '", argument.name, "' is incorrect. All dates should be between ",
                  find_pop_date.conception.first(), " (the earliest conception date in the data) and ", find_pop_date.observation.last(),
                  " (the last sighting date in the data)."))
    }

  }

  date

}


#' @describeIn check_family Check arguments 'duration'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.duration(10)
#' check_function_arg.duration(lubridate::duration(10, "year"))
check_function_arg.duration <- function(duration) {
  if (missing(duration) | is.null(duration) | !inherits(duration, c("numeric", "Duration"))) {
    stop("The argument 'duration' has not been defined.")
  }
  duration
}


#' @describeIn check_family Check the argument 'overlap', it should always be
#' used with argument describing time window (e.g. 'from' , 'to')
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.overlap("start")

check_function_arg.overlap <- function(overlap = NULL) {
  if (length(overlap) != 1) {
    stop("The argument 'overlap' should be of length 1.")
  }
  if (is.null(overlap)) {
    stop("The argument 'overlap' has not been defined.")
  }
  possible <- c("start", "end", "within", "always", "any")
  if (!overlap %in% possible) {
    stop(paste(c("The argument 'overlap' should one of:\n ", paste0("'", possible, "' ")), collapse = ""))
  }
  overlap
}


#' @describeIn check_family Check arguments 'filiation'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.filiation("mother_social")
check_function_arg.filiation <- function(filiation, .fill = FALSE) {
  possible_filiation <- c("mother_social", "mother_genetic", "mother_social_genetic", "father")

  if (missing(filiation) || is.null(filiation) && .fill == TRUE) {

    filiation <- possible_filiation

  } else if (missing(filiation) || is.null(filiation) || !inherits(filiation, "character") ||
             !all(filiation %in% possible_filiation)) {
    stop("The argument 'filiation' has not been set correctly. It must be: 'mother_social', 'mother_genetic', 'mother_social_genetic', 'father', or a combination of those.")
  }
  filiation
}

#' @describeIn check_family Check the argument 'ID'
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.ID("A-001")
#' check_function_arg.ID(.fill = TRUE)
check_function_arg.ID <- function(ID = NULL, argument.name = 'ID', strict = TRUE, .fill = FALSE, arg.max.length = Inf) {

  possible_IDs <- extract_database_table("hyenas") %>%
    dplyr::pull(.data$ID) %>%
    sort()

  if (is.null(ID)) {
    if (.fill) return(possible_IDs)
    stop(paste0("The argument '", argument.name, "' has not been defined."))
  }

  if (is.list(ID)) {
    stop(paste0("The function you are using cannot take list of list-column as an input for ", argument.name, ". Perhaps you need to unnest first."))
  }

  if (all(is.na(ID))) {
    ID <- rep(NA_character_, length(ID))
  }

  if (length(ID) > arg.max.length) {
    stop(paste0("The function you are using can only handle ", arg.max.length, " ", argument.name, "(s)"))
  }

  not_existing <- ID[!is.na(ID) & !ID %in% possible_IDs]

  if (length(not_existing) > 0) {

    if (strict) {
      stop(paste0("The argument '", argument.name, "' contains ", argument.name, "(s) not corresponding to possible ones: ", paste(unique(not_existing), collapse = " ")))
    }

    warning(paste0(argument.name, "(s) not corresponding to possible ones have been dropped."))
    ID <- ID[ID %in% possible_IDs]
  }

  ID
}


#' @describeIn check_family Check the argument corresponding to folder paths
#' @export
#' @examples
#' check_function_arg.path("~/Download")
check_function_arg.path <- function(path, mustWork = FALSE) {
  path <- normalizePath(path, mustWork = mustWork)
  path
}


#' @describeIn check_family Check the argument 'period'
#' @export
#' @examples
#' check_function_arg.period("90 days")
check_function_arg.period <- function(period, null.ok = FALSE, coerce = TRUE){

  if (null.ok && is.null(period)) {
    return(NULL)
  }

  error_msg <- "The argument 'period' is incorrect, it should be of the same format as e.g. '10 days', '2 weeks', etc."

  ## missing test:
  if (missing(period) || is.null(period)) {
    stop(error_msg)
  }

  ## class test:
  if (!inherits(period, c("character", "Period"))) {
    stop(error_msg)
  }

  ## lubridate test:

  test_lubridate_OK <- !is.na(lubridate::as.period(period))

  if (!all(test_lubridate_OK)) {
    stop(error_msg)
  }

  ## base test: (we need it because lubridate does strange things with some input, e.g. lubridate::as.period("1 dys"))
  test_base_OK <- tryCatch(all(sapply(period, function(p) length(seq.Date(from = as.Date("1900/01/01"),
                                                                          to = as.Date("1900/01/02"),
                                                                          by = p))) > 0), error = function(e) FALSE)

  if (lubridate::as.period(period) != 0 && !test_base_OK) {
    ## Note R base does not handle period of 0 but we use that in the package,
    ## so we skip the base test for such a case.
    stop(error_msg)
  }

  ## Only coerce if needed and output:
  if (!coerce) {
    return(period) ## do not coerce to period for compatibility with both base R and lubridate!
  }

  lubridate::as.period(period)
}

#' @describeIn check_family Check the argument 'ranks'
#' @export
#' @examples
#' check_function_arg.ranks(1:2, std = FALSE)
#' check_function_arg.ranks(c(1, -1), std = TRUE)
#'
check_function_arg.ranks <- function(ranks, std = FALSE) {

  if (length(ranks[!is.na(ranks)]) == 0) return(ranks)

  if (std) {
    if (any((ranks[!is.na(ranks)] < -1) | (ranks[!is.na(ranks)] > 1))) {
      stop("The ranks should be standardized, that is all between -1 and 1.")
    }
  } else {
    if (!all(as.integer(ranks[!is.na(ranks)]) == ranks[!is.na(ranks)])) {
      stop("The ranks should be absolute, that is corresponding to integers (i.e. round numbers).")
    }
    if (any(ranks[!is.na(ranks)] < 1)) {
      stop("The ranks should be absolute, that is never below 1.")
    }
  }
  ranks
}

#' @describeIn check_family Check the argument 'lifestage'
#' @export
#' @examples
#' check_function_arg.lifestage("philopatric")
check_function_arg.lifestage <- function(lifestage = NULL, .fill = FALSE, arg.max.length = Inf) {

  ###Define possible lifestage and meta-lifestage values###
  #raw is the values that correspond to the 'life_stage' column in create_id_life.history.table
  #meta are lifestage arguments that correspond to multiple actual lifestages (e.g. adult != cub & subadult)
  raw_lifestage      <- c("cub", "subadult", "natal", "philopatric", "disperser", "transient",
                          "founder_male", "unknown",
                          paste0("selector_", 2:5),
                          paste0("foreigner_", 1:5),
                          "dead")
  meta_lifestage     <- c("adult", "selector", "all", "preselector", "alive",
                          "foreigner", "native", "sexually_active")
  possible_lifestage <- c(raw_lifestage, meta_lifestage)

  ###Fill in NULL if required###
  #Do this first. No need to check other statements if lifestage = NULL
  if (is.null(lifestage)) {
    if (.fill && arg.max.length == Inf) {
      #Don't fill 'dead'. Need to explicitly request 'dead' or 'all'
      lifestage <- setdiff(raw_lifestage, "dead")
      return(lifestage[order(lifestage)])
    }
    stop("The argument 'lifestage' has not been defined.")
  }

  ###Save the user input to create informative error message below###
  input_lifestage <- lifestage

  ###Determine if we are adding or negating lifestages###
  if (any(stringr::str_detect(lifestage, pattern = "^!"))) {

    if (!all(stringr::str_detect(lifestage, pattern = "^!"))) {
      stop("Lifestage accepts either a vector of lifestages to include or to negate (using '!'), not both.")
    }

    #Specify that we want to negate rather than add lifestages
    negate <- TRUE

    #Remove ! from lifestages now, we can work with them the same way for either negation or addition cases
    lifestage <- stringr::str_remove(lifestage, "!")

  } else {

    negate <- FALSE

  }

  ###Check that all lifestages are possible###
  #At this point we still need to allow 'dead' because it could be explicitly requested/negated
  if (any(!lifestage[!is.na(lifestage)] %in% possible_lifestage)) {
    stop(paste0(c("The argument 'lifestage' contains values not corresponding to possible ones: ",
                  crayon::yellow(paste(unique(lifestage[!is.na(lifestage) & !lifestage %in% possible_lifestage]), collapse = ", ")),
                  "\n Please choose from: ", crayon::yellow(paste(possible_lifestage, collapse = ", ")))))
  }

  ###Recode meta-lifestages to raw lifestages###
  #Made this a separate function to allow us to cleanly add new meta-lifestages later
  lifestage <- recode_lifestage_meta.to.raw(lifestage)

  ###Apply negation if necessary###
  if (negate) {
    #Always negate dead
    #You can only get dead individuals with 'dead' or 'all' lifestage call
    #FIXME: This meets our requirements, but means that 'dead' behaves differently to all other lifestages
    #It can only ever be returned through selection, never through negation. Acceptable?
    lifestage <- setdiff(raw_lifestage, c(lifestage, "dead"))
  }

  ###Check argument length###
  if (length(lifestage) > arg.max.length) {
    stop(paste0("The function you are using can only handle ", arg.max.length, " life stage(s). \n You have provided: ", crayon::yellow(paste(input_lifestage, collapse = ", ")),
                "\n This corresponds to the actual lifestages: ", crayon::yellow(paste(lifestage, collapse = ", "))))
  }

  lifestage[order(lifestage)]

}

#' @describeIn check_family Check any logical argument
#' @export
#' @examples
#' check_function_arg.logical(TRUE)
check_function_arg.logical <- function(logical, argument.name = "logical") {
  if (!is.logical(logical)) {
    stop(paste0("The argument '", argument.name, "' is incorrect, it should be TRUE or FALSE (unquoted)"))
  }

  logical
}

#' @describeIn check_family Check the argument 'unit'
#' @export
#' @examples
#' check_function_arg.unit(c("day", "days", "week", "weeks"))
check_function_arg.unit <- function(unit, arg.max.length = Inf) {
  if (length(unit) > arg.max.length) {
    stop(paste("The function you are using can only handle", arg.max.length, "unit(s)"))
  }
  unit %>% purrr::map_chr(~ case_when(
    .x == "days" ~ "day",
    .x == "weeks" ~ "week",
    .x == "months" ~ "month",
    .x == "years" ~ "year",
    .default = .x
  )) -> unit

  if (!all(unit %in% c("day", "week", "month", "year"))) {
    stop("The argument(s) 'unit' must be 'day', 'week', 'month', or 'year'!")
  }
  unit
}


#' @describeIn check_family Check if the database is loaded and if it is the dummy one
#'
#' This function should not be directly used by the user.
#'
#' Note for developers: this function triggers an error with an informative
#' message if there is no loaded database. It also displays a message if the
#' dummy database is the one that has been loaded by [load_package_database.dummy].
#'
#' @return This function returns nothing directly.
#' @export
#'
#' @seealso [load_package_database.dummy]
#'
#' @examples
#' check_database_is.loaded()
check_database_is.loaded <- function() {

  ## to limit multiple display of messages, we restrict the messages to shallow calls (i.e. those likely made by the user and not by internal functions)
  threshold_depth_nframe <- 9L
  depth_nframe <- sys.nframe()

  if (!exists(".database")) {
    stop("No loaded database. See ?load_package_database")
  }

  if (attr(.database, "datatype") == "dummy") {
    if (depth_nframe < threshold_depth_nframe) {
      message("Using the dummy dataset!")
    }
  }

  if (attr(.database, "datatype") == "sim") {
    if (depth_nframe < threshold_depth_nframe) {
      message("Using a simulated dataset!")
    }
  }

  invisible(NULL)

}

#' @describeIn check_family Check for errors in the database
#'
#' Check for integrity in the data/missing information including:
#' - All individuals die after being born
#' - All individuals give birth after 1yo
#' - All mothers/fathers are female/male
#'
#' @return A boolean (has the database passed all tests)
#' @export
#' @examples
#'
#' # Check dummy database
#' # check_database_is.correct()

check_database_is.correct <- function(debug = FALSE) {

  # Extract all records for every existing individual
  # Do this first so it only needs to be done once.
  all_indv <- create_id_starting.table(verbose = FALSE) %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID),
                  birthdate = fetch_id_date.birth(.data$ID),
                  deathdate = fetch_id_date.death(.data$ID),
                  surv = is.na(.data$deathdate),
                  mothergenetic = fetch_id_id.mother.genetic(.data$ID),
                  father = fetch_id_id.father(.data$ID))

  ###############################
  # TEST: Birth is before death #
  ###############################

  # Test to see if all individuals have a death date after their birth date
  flawed_deaths <- all_indv[!all_indv$surv & lubridate::ymd(all_indv$birthdate) > lubridate::ymd(all_indv$deathdate), ]

  number_flawed_deaths <- nrow(flawed_deaths)

  ##################################
  # TEST: Parents have correct sex #
  ##################################

  # Extract all individuals with a known mother
  flawed_maternity <- all_indv %>%
    dplyr::filter(!is.na(.data$mothergenetic)) %>%
    # Check that mother is female
    dplyr::mutate(mothersex = fetch_id_sex(ID = .data$mothergenetic),
           motherIsF = is.na(.data$mothersex) | .data$mothersex == "female") %>%
    dplyr::filter(!.data$motherIsF)

  number_flawed_maternity <- nrow(flawed_maternity)

  # Extract all individuals with a known father
  flawed_paternity <- all_indv %>%
    dplyr::filter(!is.na(.data$father)) %>%
    # Check that father is male
    dplyr::mutate(fathersex = fetch_id_sex(ID = .data$father),
           fatherIsM = is.na(.data$fathersex) | .data$fathersex == "male") %>%
    dplyr::filter(!.data$fatherIsM)

  number_flawed_paternity <- nrow(flawed_paternity)

  #######################################################
  # TEST: Dead individuals cannot be impacted by a coup #
  #######################################################

  # Extract all individuals dead and affected by a coup
  flawed_coups <- extract_database_table("rankchanges") |>
    tidyr::pivot_longer(cols = c("ID", "higher", "lower"), values_to = "ID") |>
    dplyr::mutate(ID_dead = !fetch_id_is.alive(ID = .data$ID, at = .data$date)) |>
    dplyr::filter(.data$ID_dead, .data$ID != "last") |>
    tidyr::pivot_wider(values_from = "ID", names_from = "name")

  number_flawed_coups <- nrow(flawed_coups)

  ################################
  # OUTPUT ALL INTEGRITY RESULTS #
  ################################

  tibble::tibble(
    integrity_issue = c("Flawed_death", "Flawed_maternity", "Flawed_paternity", "Flawed_coups"),
    total_number = c(number_flawed_deaths, number_flawed_maternity, number_flawed_paternity, number_flawed_coups),
    details = list(flawed_deaths, flawed_maternity, flawed_paternity, flawed_coups)
  ) -> output

  if (debug) {
    message(paste("Individuals with death before birth:", number_flawed_deaths))
    message(paste("Males assigned as mothers:", number_flawed_maternity))
    message(paste("Females assigned as mothers:", number_flawed_paternity))
    message(paste("Dead individuals affected by coups:", number_flawed_coups))
    message("See `details` in the list stored in the output for more details.")

    return(output)

  }

  allOK <- all(output$total_number == 0)
  if (!allOK & !debug) {
    message("There seem to be issues in the database, run `test <- check_database_is.correct(debug = TRUE)` and then `test$details` for details.")
  }
  if (allOK) {
    message("No problem detected in the database.")
  }

  allOK
}

#' @describeIn check_family Check that the arguments have the same length.
#'
#' @export
#' @examples
#' check_function_arg.litter.type(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = 0,
#' social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0)
#'
check_function_arg.litter.type <- function(daughters.nb, sons.nb, unknown.nb, social.daughters.nb, social.sons.nb, social.unknown.nb) {
  length_daughters.nb  <- ifelse(length(daughters.nb) == 1 && daughters.nb == 0, 0, length(daughters.nb))
  length_sons.nb    <- ifelse(length(sons.nb) == 1 && sons.nb == 0, 0, length(sons.nb))
  length_unknown.nb <- ifelse(length(unknown.nb) == 1 && unknown.nb == 0, 0, length(unknown.nb))
  length_social.daughters.nb <- ifelse(length(social.daughters.nb) == 1 && social.daughters.nb == 0, 0, length(social.daughters.nb))
  length_social.sons.nb <- ifelse(length(social.sons.nb) == 1 && social.sons.nb == 0, 0, length(social.sons.nb))
  length_social.unknown.nb <- ifelse(length(social.unknown.nb) == 1 && social.unknown.nb == 0, 0, length(social.unknown.nb))
  lengths <- unique(c(length_daughters.nb, length_sons.nb, length_unknown.nb, length_social.daughters.nb, length_social.sons.nb,
                      length_social.unknown.nb))
  lengths <- lengths[lengths != 0]
  ## check that lengths are good:
  if (length(lengths) > 1) {
    stop("recode_offspring.sex_litter.type needs arguments of same length or of value 0")
  }
  ## replicate 0 if needed:
  if (length(lengths) == 1) { ## don't do anything if only 0s
    if (length_daughters.nb == 0) daughters.nb <- rep(0, lengths)
    if (length_sons.nb == 0) sons.nb <- rep(0, lengths)
    if (length_unknown.nb == 0) unknown.nb <- rep(0, lengths)
    if (length_social.daughters.nb == 0) social.daughters.nb <- rep(0, lengths)
    if (length_social.sons.nb == 0) social.sons.nb <- rep(0, lengths)
    if (length_social.unknown.nb == 0) social.unknown.nb <- rep(0, lengths)
  }
  list(daughters.nb = daughters.nb, sons.nb = sons.nb, unknown.nb = unknown.nb, social.daughters.nb = social.daughters.nb, social.sons.nb = social.sons.nb, social.unknown.nb = social.unknown.nb)
}

#' @describeIn check_family Check that litter argument is correct.
#'
#' @export
#' @examples
#' check_function_arg.litter.ID(litterID = "A-001_003")
#' check_function_arg.litter.ID(.fill = TRUE)
#'
check_function_arg.litter.ID <- function(litterID = NULL, strict = TRUE, .fill = FALSE) {

  possible_litters <- find_pop_litterID(main.clans = FALSE)

  if (is.null(litterID)) {
    if (.fill) return(possible_litters)
    stop("The argument 'litter' has not been defined.")
  } else {
    if (any(!litterID[!is.na(litterID)] %in% possible_litters)) {
      if (strict) {
        stop("The argument 'litter' contains litterID(s) not corresponding to possible ones.")
      } else {
        warning("litterID(s) not corresponding to possible ones have been dropped.")
        litterID <- litterID[litterID %in% possible_litters]
      }
    }
  }
  if (length(litterID) == 0) {
    return(NA_character_)
  }
  litterID
}

#' @describeIn check_family Check arguments 'from', 'to', 'at'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' #Check when both from and to are provided
#' check_function_arg.date.fromtoat(from = "1996/12/21", to = "1997/12/21")
#'
#' #When either from or to are not provided, they can be filled
#' #using arguments fill, min.date and max.date
#' check_function_arg.date.fromtoat(to = "1997/12/21", .fill = TRUE,
#'                                  min.date = "1997-01-01")
#' check_function_arg.date.fromtoat(from = "1997/01/21", .fill = TRUE,
#'                                  max.date = "1997-12-01")
#'
#' #When at is provided, from/to have the same value
#' check_function_arg.date.fromtoat(at = "1997/12/21")
#'
#' #from/to and at cannot be provided together
#' #this will throw an error
#' #check_function_arg.date.fromtoat(from = "1995/12/21", at = "1996/12/21")

check_function_arg.date.fromtoat <- function(from = NULL, to = NULL, at = NULL,
                                             arg.max.length = Inf,
                                             .fill = TRUE,
                                             min.date = NULL,
                                             max.date = NULL,
                                             data.type = "hyena") {

  if (!.fill) { #If we will not fill, user must provide at or from/to.

    if (any(is.null(from), is.null(to)) && is.null(at)) {
      stop("Provide either a single date using argument `at` or \n a date range by providing both arguments `from` and `to`.")

    }

  }

  #Can't use from/to and at
  if (any(!is.null(from), !is.null(to)) && !is.null(at)) {
    stop("Provide either a single date using argument `at` or \n a date range by providing one or both arguments `from` or `to`.")

  }

  if (!is.null(at)) { # from and to are the same when using at
    #at is never filled (it's unclear what it would be filled with!)
    from <- check_function_arg.date(at, argument.name = "at", data.type = data.type)
    to   <- check_function_arg.date(at, argument.name = "at", data.type = data.type)
  } else {
    from <- check_function_arg.date(from, argument.name = "from", .fill = .fill, fill.value = min.date, data.type = data.type)
    to   <- check_function_arg.date(to, argument.name = "to", .fill = .fill, fill.value = max.date, data.type = data.type)
  }

  if (length(from) > arg.max.length || length(to) > arg.max.length) {

    stop(paste("The function you are using can only handle", arg.max.length, "date(s)"))

  }

  #Allow for NAs. Only check relationship between dates when both from/to are available.
  if (any(stats::na.omit(from > to))) {

    stop("'from' date must be earlier than (or the same as) 'to' date")

  }

  list(from = from, to = to)

}


#' @describeIn check_family Check arguments 'lineage'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.lineage("mothersocial")
#'
check_function_arg.lineage <- function(lineage) {
  possible_lineage <- c("mothersocial", "mothergenetic", "father")
  if (missing(lineage) || is.null(lineage) || !inherits(lineage, "character") || !all(lineage %in% possible_lineage)) {
    stop("The argument 'lineage' has not been set correctly. It must be: 'mothersocial', 'mothergenetic' or 'father'")
  }
  lineage
}

#' @describeIn check_family Check that sightings, selections and hyena tables are all consistent
#'
#' Use to check database tables before database is built.
#' Run within [build_package_database.full()].
#'
#' @return A boolean. Does every individual have a full record (TRUE/FALSE).

check_database_has.full.records <- function(hyenas.tbl, sightings.tbl, selections.tbl,
                                            verbose = TRUE) {

  if (verbose) {
    message("Checking that all individuals have full records in hyenas, sightings and selections...")
  }

  names_selections <- stringr::str_trim(unique(selections.tbl$ID)[!is.na(unique(selections.tbl$ID)) & unique(selections.tbl$ID) != ""])
  names_sightings  <- stringr::str_trim(unique(sightings.tbl$ID)[!is.na(unique(sightings.tbl$ID)) & unique(sightings.tbl$ID) != ""])
  names_hyenas     <- stringr::str_trim(unique(hyenas.tbl$ID)[!is.na(unique(hyenas.tbl$ID)) & unique(hyenas.tbl$ID) != ""])

  # Check that all individuals in hyena have a birthdate
  # Birthdates may be NA if they were not provided, or provided in the wrong format\
  # (i.e. not either yyyy-mm-dd or dd/mm/yyyy).
  # This should help identify typos
  names_missing_bday <- hyenas.tbl %>%
    dplyr::filter(is.na(.data$birthdate)) %>%
    dplyr::pull(.data$ID)

  # Check that any time there is a recorded selection that the individual must have a hyena and sightings record
  correct_selections_hyena     <- names_selections %in% names_hyenas
  correct_selections_sightings <- names_selections %in% names_sightings

  # Check that any time there is a recorded sighting that the individual must have a hyena record.
  correct_sightings <- names_sightings %in% names_hyenas

  # Check that anything in hyenas is also in sightings
  correct_hyenas <- names_hyenas %in% names_sightings

  if (all(correct_selections_hyena) &&
      all(correct_selections_sightings) &&
      all(correct_sightings) &&
      all(correct_hyenas) &&
      length(names_missing_bday) == 0) {
    if (verbose) {
      message("All individuals have full records!")
    }
    return(TRUE)
  } else {

    #First, give message about individuals missing from other tables.
    bad_records <- bind_rows(
      tibble::tibble(ID = names_selections[!correct_selections_hyena], table1 = "selections", table2 = "hyenas"),
      tibble::tibble(ID = names_selections[!correct_selections_sightings], table1 = "selections", table2 = "sightings"),
      tibble::tibble(ID = names_sightings[!correct_sightings], table1 = "sightings", table2 = "hyenas"),
      tibble::tibble(ID = names_hyenas[!correct_hyenas], table1 = "hyenas", table2 = "sightings")
    ) %>%
      dplyr::filter(!is.na(.data$ID))

    purrr::pwalk(
      .l = list(ID = bad_records$ID, table1 = bad_records$table1, table2 = bad_records$table2),
      .f = function(ID, table1, table2) {
        warning(crayon::yellow(glue::glue("'{ID}' has a record in {table1} but not in {table2}!")))
      }
    )

    #Then, message about missing bdays
    purrr::pwalk(
      .l = list(ID = names_missing_bday),
      .f = function(ID) {
        warning(crayon::yellow(glue::glue("'{ID}' does not have a birthday in the hyenas table!")))
      }
    )
  }
  return(FALSE)
}

#' @describeIn check_family Check that all date columns in a data frame have correct formats
#'
#' Use to check database tables before database is built.
#' Run within [build_package_database.full()].
#'
#' @return A boolean. Do all date columns have correct format?

check_database_date.cols <- function(tbl.name, tbl,
                                     verbose = TRUE) {

  #Select any columns that are dates and violate our formats
  date_cols <- tbl %>%
    dplyr::select(dplyr::contains("date"))

  test_cols <- apply(date_cols,
                     MARGIN = 2,
                     FUN = function(x){!check_database_date(x)})

  invalid_cols <- names(test_cols)[test_cols]

  if (length(invalid_cols) > 0) {
    purrr::map(invalid_cols,
               .f = function(colname, dataname){
                 warning(crayon::yellow(glue::glue("Column '{colname}' in '{dataname}' has rows with inproper or inconsistent date format.\nThis may be caused by text in date columns or dates that are not consistently DD-MM-YYYY or YYYY-MM-DD format.")))
               }, dataname = tbl.name)
    return(FALSE)
  } else {
    return(TRUE)
  }

}

#' @describeIn check_family Check that a vector of dates can all be parsed
#'
#' Use to test if a single date column is all valid.
#'
#' @return A boolean. Can all dates in a column be parsed.
check_database_date <- function(date){

  #If all is NA don't waste time running lubridate
  if (all(is.na(date))) {
    return(TRUE)
  } else {
    # If we have some non-NA...dates could conceivably be in YYYY-MM-DD or DD-MM-YYYY
    # however, if we just do a regex check we will miss errors caused by Americans (i.e. Arjun :))
    # using MM-DD-YYYY. Therefore, we need to try parse dates using either dmy or ymd and flag issues.
    if (all(is.na(date) | grepl(x = date, pattern = "^([0-9]{4}-[0-9]{2}-[0-9]{2})$"))) {
      tryCatch({lubridate::ymd(date); return(TRUE)},
               warning = function(w){
                 return(FALSE)
               },
               error = function(e){
                 return(FALSE)
               })
    } else if (all(is.na(date) | grepl(x = date, pattern = "^([0-9]{2}-[0-9]{2}-[0-9]{4})$"))) {
      tryCatch({lubridate::dmy(date); return(TRUE)},
               warning = function(w){
                 return(FALSE)
               },
               error = function(e){
                 return(FALSE)
               })
    } else {
      return(FALSE)
    }
  }

}

#' @describeIn check_family Check output of functions.
#'
#' This function should not be directly used by the user.
#' @export
#' @examples
#' input.tbl <- data.frame(ID = c("A-100", "A-100", "A-101", NA))
#'
#' output.tbl <- data.frame(ID = c("A-100", "A-101", NA),
#'                           sex = c("Female", "Male", NA))
#'
#' check_function_output(input.tbl = input.tbl,
#'              output.tbl = output.tbl,
#'              join.by = "ID",
#'              duplicates = "input",
#'              output.IDcolumn = "sex",
#'              debug = FALSE)
#'
check_function_output <- function(input.tbl,
                                  output.tbl,
                                  join.by,
                                  duplicates = "input",
                                  output.IDcolumn = NULL,
                                  debug = FALSE) {

  ## check input format
  input.tbl <- check_function_arg.tbl(input.tbl)
  output.tbl <- check_function_arg.tbl(output.tbl)
  duplicates <- check_function_arg.duplicates(duplicates)

  ## by input must be named:
  if (is.null(names(join.by))) {
    names(join.by) <- join.by
  }

  ## check the debug
  if (debug) output.IDcolumn <- NULL

  ## compute name of surrounding function:
  fun_name <- as.character(sys.call(1L))[[1]]

  ## trim inputs:
  input <- input.tbl[, names(join.by), drop = FALSE]
  output <- output.tbl[, join.by, drop = FALSE]

  ## check for duplicates:

  # input
  duplicates_in_input <- nrow(unique(input)) < nrow(input)
  if (!(duplicates == "input") && duplicates_in_input) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated input!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  # output
  duplicates_in_output <- nrow(unique(output)) < nrow(output)
  if (!(duplicates == "output") && duplicates_in_output) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated output!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  # both
  if ((duplicates == "none") && (duplicates_in_input || duplicates_in_output)) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated output or input!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  ## actual join job (left join to keep all the input IDs):
  out_temp <- dplyr::left_join(relationship = "many-to-many", input.tbl, output.tbl, by = join.by)

  ## check that the row order and length are correct:
  ref_input <- input[, names(join.by)]
  ref_output <- out_temp[, names(join.by)] ## select only the matching col of the temp_output
  ## Here we use drop for finner test of factors in case of single variables

  if (duplicates == "output") { ## rep output not input
    ref_output <- unique(ref_output) ## reduce the output to check if the order and length match the unduplicated input
  }

  ## compare variable class:
  types_in_ref_input <- sapply(ref_input, class)
  types_in_ref_output <- sapply(ref_output, class)

  if (!all(types_in_ref_input == types_in_ref_output)) {
    stop(paste0("Internal inconsistency detected by check_output:\nThe objects ref_input and not ref_output have missmatches in variable class (probably caused by a wrong usage of factors)!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  if (!(identical(ref_input, ref_output))) { ## check that the input and ouptut are correct
    stop(paste0("Internal inconsistency detected by check_output:\nDiscrepancy in row order/length between ref_input and ref_output!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  ## rename columns as in output table:
  colnames(out_temp)[match(names(join.by), colnames(out_temp))] <- join.by

  ## trim output with selected columns:
  if (is.null(output.IDcolumn)) {
    output.IDcolumn <- colnames(out_temp)
  }

  out_temp[, output.IDcolumn, drop = TRUE]
}

#' @describeIn check_family Check arguments 'tbl'.
#' @export
#' @examples
#' check_function_arg.tbl(data.frame(ID = c("A-100", "A-100", "A-101", NA)))
check_function_arg.tbl <- function(tbl){

  if (!inherits(tbl, c("data.frame", "tbl_df", "tbl"))) {
    stop(paste0("One of the arguments you are using is of the wrong class, it must be a tibble or a data.frame"))
  }

  if (!inherits(tbl, "tbl_df")) {
    tbl <- tibble::as_tibble(tbl)
  }
  tbl
}

#' @describeIn check_family Check arguments 'duplicates'.
#' @export
#' @examples
#' check_function_arg.duplicates("input")
check_function_arg.duplicates <- function(duplicates) {
  possible_arg <- c("input", "output", "none")
  if (missing(duplicates) || is.null(duplicates) ||
      !inherits(duplicates, "character") || length(duplicates) > 1 || !(duplicates %in% possible_arg)) {
    stop("The argument 'lineage' has not been set correctly. It must be: 'input', 'output' or 'none', exclusively")
  }
  duplicates
}


#' @describeIn check_family Check arguments 'verbose'.
#' @export
#' @examples
#' check_function_arg.verbose(TRUE)
#' check_function_arg.verbose(FALSE)
#' check_function_arg.verbose(NULL)
#'
check_function_arg.verbose <- function(verbose) {
  if (!is.null(verbose) && (!is.logical(verbose) || is.na(verbose))) {
    stop("The verbose argument of the function should be NULL, TRUE or FALSE")
  }
  if (is.null(verbose)) {
    verbose <- getOption("hyenaR_verbose")
  }
  verbose
}


#' @describeIn check_family Check arguments 'CPUcores'.
#' @export
#' @examples
#' check_function_arg.CPUcores(2)
#' check_function_arg.CPUcores(NULL)
#'
check_function_arg.CPUcores <- function(CPUcores, verbose = NULL) {

  verbose <- check_function_arg.verbose(verbose)

  if (!is.null(CPUcores) && !is.numeric(CPUcores)) {
    stop("The CPUcores argument of the function should be NULL, or a number")
  }
  if (is.null(CPUcores)) {
    CPUcores <- getOption("hyenaR_CPUcores")
  }
  CPUcores <- floor(CPUcores)  ## in case users give floating numbers...
  max_cpu <- parallel::detectCores()
  if (CPUcores > max_cpu) {
    stop(paste0("The CPUcores argument of the function should not be greater than the number of CPU cores available on your system (", max_cpu, ")"))
  }
  if (verbose && CPUcores < max_cpu && !.hyenaR$flag_CPUcores) {
    .hyenaR$flag_CPUcores <- TRUE
    message(paste0("The CPUcores argument of the function could be greater than what you are currently using since the number of CPU cores available on your system is ",
                   max_cpu,
                   ".\nYou can set the number of CPU cores to use in the entire package by setting \n'options(hyenaR_CPUcores = xx)', with 'xx' the number of CPU cores to use. ",
                   "\nNote: this message will only be displayed once per session.\n"))
  }
  CPUcores
}


#' @describeIn check_family Check if arguments is a character.
#' @export
#' @examples
#' check_function_class.is.character("bla")
#' check_function_class.is.character()
check_function_class.is.character <- function(character) {
  ## this function allows for testing even if the variable does not exist, which is the case is the argument is a placeholder for a column in the table...
  tryCatch(is.character(character), error = function(e) FALSE)
}

#' @describeIn check_family Check argument 'sex'.
#' @export
#' @examples
#' check_function_class.is.character("male")
check_function_arg.sex <- function(sex, .fill = TRUE, arg.max.length = Inf) {

  if (length(sex) > arg.max.length) {
    stop(paste("The function you are using can only handle", arg.max.length, "values for sex"))
  }

  possible_sex <- c("male", "female", NA_character_)

  check_function_class.is.character(sex)

  if (is.null(sex)) {
    if (.fill) {
      sex <- possible_sex
    } else {
      stop("The argument 'sex' has not been defined.")
    }
  } else {
    if (any(!sex[!is.na(sex)] %in% possible_sex)) {
      stop("The argument 'sex' can only contain 'male', 'female', and NA (for unknown sex).")
    }
  }

  sex

}

#' @describeIn check_family Check the arguments 'age' and 'min.age'
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' #Works for integer
#' check_function_arg.age(10L)
#'
#' #Works for double
#' check_function_arg.age(6.5)
#'
#' #Works for value of 0
#' check_function_arg.age(0)
check_function_arg.age <- function(age) {

  #Check that age is a numeric
  if (!is.numeric(age)) {

    stop("Age must be a numeric.")

  }

  #Check that age is non-negative
  if (any(age < 0, na.rm = TRUE)) {

    stop("Age must be a non-negative value.")

  }

  age

}

#' Check for meta-data issues in a single weather station file
#'
#' Checks include:
#' 1. Check that weather station is located within Ngorongoro Crater
#' 2. Check that there are no errors recorded in the meta-data
#'
#' @inheritParams arguments
#'
#' @return Data frame of meta-data
#' @export
check_weatherstation_metadata.file <- function(metadata, verbose = TRUE){

  #We will run all expected checks on weatherstation metadata

  #Create a column where we can store error information.
  metadata <- metadata %>%
    dplyr::mutate(error = FALSE,
                  message = NA_character_)

  #1. Check that weather station is within the Ngorongoro Crater
  #FIXME: May need to expand the acceptable area once we have a station on the rim
  weatherstation_location <- metadata %>%
    dplyr::filter(, .data$info %in% c("latitude", "longitude")) %>%
    tidyr::pivot_wider(names_from = "info", values_from = "value") %>%
    #For this quick check, we just work with geographic CRS
    recode_df_sf(crs = 'EPSG:32736')

  projected_rim <- sf_hyenaR$rim_polygon %>%
    sf::st_transform(crs = 'EPSG:32736')

  location_check_pass <- sf::st_within(weatherstation_location, projected_rim, sparse = FALSE)[1, ]

  message <- "Weather station location is outside the crater!"

  if (!location_check_pass) {

    metadata$error[metadata$info %in% c("latitude", "longitude")] <- TRUE
    metadata$message[metadata$info %in% c("latitude", "longitude")] <- "Weather station location is outside the crater!"

    if (verbose) {

      warning(message)

    }

  }

  #2. Check there are no errors
  error_data <- metadata %>%
    dplyr::filter(.data$metadata_category == "errors" & .data$info != "last_updated" & .data$value != 0)

  error_check_pass <- nrow(error_data) == 0

  message <- paste0("Weather station error in: ", crayon::yellow(error_data$info), "\n")

  if (!error_check_pass) {

    metadata$error[metadata$info %in% error_data$info] <- TRUE
    metadata$message[metadata$info %in% error_data$info] <- message

    if (verbose) {

      warning(message)

    }

  }

  metadata

}

#' Check for meta-data issues when combining weather data
#'
#' Checks include:
#' 1. Check data is from the same device (serial number)
#' 2. Check data is collected at same measurement interval
#' 3. Check data has been collected at the same locaation (lat/long)
#'
#' Check will pass if data locations are within 10m.
#' This allows for uncertainty in coordinate and the possibility
#' that weather stations will need to be moved slightly over time.
#'
#' @inheritParams arguments
#'
#' @return Data frame of meta-data.
#' @export
check_weatherstation_metadata.all <- function(metadata){

  #Combine meta-data so we can more easily run checks
  metadata <- dplyr::bind_rows(metadata) %>%
    dplyr::select("file_number", dplyr::everything())

  #1. Check configuration info is comparable
  config_data <- metadata %>%
    dplyr::filter(.data$metadata_category == "configuration") %>%
    tidyr::unnest(cols = "data") %>%
    tidyr::pivot_wider(names_from = "info", values_from = "value")

  #1a: Check that serial number is the same! Don't combine data from different stations
  serial_check_pass <- length(unique(config_data$serial_number)) == 1

  if (!serial_check_pass) {

    stop("Serial numbers of weather stations are different! Cannot combine data from different stations.")

  }

  #1b: Check that measurement intervals are the same. If not, throw warning (data are still usable)
  measurementint_check_pass <- length(unique(config_data$measurement_interval)) == 1

  if (!measurementint_check_pass) {

    warning("Data have been collected at different measurement intervals.")

  }

  #2. Check that locations are the same for each station
  location_distances <- metadata %>%
    dplyr::filter(.data$metadata_category == "location") %>%
    tidyr::unnest(cols = "data") %>%
    dplyr::filter(.data$info %in% c("latitude", "longitude")) %>%
    tidyr::pivot_wider(names_from = "info", values_from = "value") %>%
    #Here we're working with distances so would be good to use projected CRS by default
    #(regardless of what the user chooses as default)
    recode_df_sf(crs = 'EPSG:32736') %>%
    sf::st_distance() %>%
    as.numeric()

  location_check_pass <- all(location_distances <= 10)

  #If files are more than 10m apart then we will not combine data and throw an error!
  if (!location_check_pass) {

    stop("Different weather station files are from different locations! Check file meta-data.")

  }

  metadata

}

#' Check that data frame provided to convert to sf has required information.
#'
#' @inheritParams arguments
#' @return A data frame.
#' @export
#'
#' @examples
#' #Expects there to be latitude and longitude cols (doesn't check if it's sensible values!)
#' input <- data.frame(latitude = c(1, 2, 3), longitude = c(2, 3, 4))
#' check_df_sf(input)
#'
#' #This will fail!
#' #input2 <- data.frame(lat = c(1, 2, 3), long = c(2, 3, 4))
#' #check_df_sf(input2)
check_df_sf <- function(df){

  #Check that data frame has columns latitude and longitude
  if (!all(c("latitude", "longitude") %in% colnames(df))) {

    stop("Data frame must contain columns 'latitude' and 'longitude'")

  }

  return(df)

}

#' @describeIn check_family Check input variable exist in the weather dataset
#'
#' @return A character vector of column names
#' @export
#'
#' @examples
#' check_function_arg.variable.weather(c("temp", "rain"))
check_function_arg.variable.weather <- function(variable, .fill = TRUE){

  possible_variable_df <- data.frame(possible_variable = c("temp", "rain", "rainmax", "humidity", "pressure", "battery"),
                                     colname = c("air_temp", "precip", "precip_max_hourly", "relative_humidity", "atmospheric_pressure", "battery_percent"))

  #If no variable provided...
  if (is.null(variable)) {

    if (.fill) { #If we are filling (default) just return all colnames

      return(possible_variable_df$colname)

    } else {

      stop("Please provide atleast one variable.")

    }

  }

  if (!all(variable %in% possible_variable_df$possible_variable)) {

    stop(paste0(setdiff(variable, possible_variable_df$possible_variable), " is not a valid variable. Please use one of: ", possible_variable_df$possible_variables))

  } else {

    possible_variable_df %>%
      dplyr::filter(.data$possible_variable %in% {{variable}}) %>%
      dplyr::pull(.data$colname) -> output

    return(output)

  }

}

#' @describeIn check_family Check weather station names are valid.
#'
#' @return A character vector of weather station names
#' @export
#'
#' @examples
#' #Will work
#' check_function_arg.station("jua")
#'
#' #Won't work
#' #check_function_arg.station("not_a_station")
check_function_arg.station <- function(station){

  possible_stations <- sf_hyenaR$weather_stations$station_name

  if (!all(station %in% possible_stations)) {

    stop(paste0(setdiff(station, possible_stations), " is not a weather station name. Please use one of: ", paste(possible_stations, collapse = ", ")))

  } else {

    return(station)

  }

}


#' @describeIn check_family Check weather station locations are valid.
#'
#' @return A character vector of weather station locations
#' @export
#'
#' @examples
#' #Will work
#' check_function_arg.location.weather("acacia")
#'
#' #Won't work
#' #check_function_arg.location.weather("not_a_location")
check_function_arg.location.weather <- function(location){

  ## FIXME: Repetitive other checks that just compare to a possible set of categories
  # Could create a single func `check_function_arg.category(value, variable_name)`
  possible_values <- sf_hyenaR$weather_stations$location

  if (!all(location %in% possible_values)) {

    stop(paste0(setdiff(location, possible_values), " is not a weather station location. Please use one of: ", paste(possible_values, collapse = ", ")))

  } else {

    return(location)

  }

}

#' Load CRS from package options
#'
#' See [hyenaR_projection] for more information about choosing and changing CRS.
#'
#' @export
#' @examples
#' #Use recomended CRS
#' options(hyenaR_crs = 'EPSG:4326')
#' load_package_crs()
#'
#' #Non recommended CRS are possible but throw a warning
#' options(hyenaR_crs = 'EPSG:4979')
#' load_package_crs()
#'
#' #Reset to default
#' options(hyenaR_crs = 'EPSG:32736')
#'
#' \dontrun{
#' #Impossible CRS throw an error
#' options(hyenaR_crs = 0)
#' load_package_crs()
#'}
load_package_crs <- function(){

  #Check if CRS in options is actually possible
  crs <- tryCatch(sf::st_crs(getOption("hyenaR_crs")),
                  warning = function(w){
                    stop(paste0("CRS defined in option (", crs$input, ") not found. Consider using: ", paste(rec_CRS, collapse = ", ")))
                  })

  #Recommended CRS
  #WGS 84 / UTM zone 36S: 'EPSG:32736' (projected)
  #Arc 1960 / UTM zone 36S: 'EPSG:21036' (projected)
  #WGS84: 'EPSG:4326' (geographic)
  rec_CRS <- c(32736, 21036, 4326)
  parse_rec_CRS <- lapply(rec_CRS, FUN = sf::st_crs)

  if (getOption("hyenaR_crs.msg") & crs == parse_rec_CRS[[1]]) {
    message("\nUsing default projected CRS (WGS 84 / UTM zone 36S).\nRun options(hyenaR_crs = NEW_CRS_HERE) if you want to use a different CRS\nPlease see ?hyenaR_projection for more details on choosing a CRS.\n")
    options(hyenaR_crs.msg = FALSE)
  }

  if (!any(sapply(parse_rec_CRS, FUN = function(x){x == crs}))) {
    warning(paste0("Using CRS ", crs$input, ". Recommended CRS are 4326 (WGS84), 32736 (WGS 84 / UTM zone 36S), or 21036 (Arc 1960 / UTM zone 36S).\nOther CRS may not behave properly. Use with caution!!!"))
  }

  return(crs)

}
