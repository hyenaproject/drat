
## NOTE: these functions are used to compute relatedness for the social support computation.
##       They will be inappropriate to compute relatedness in a more general context.


#' @describeIn find_family find the ancestors of a given ID(s). The first being the focal id.
#' @return A vector of ID.
#' @export
#' @examples
#' # Load data (use dummy dataset)
#' load_package_database.dummy()
#' find_id_id.ancestor.all(ID = c("A-100", "A-008"), filiation = "mother_genetic")
#'
find_id_id.ancestor.all <- function(ID, filiation = "mother_genetic", ancestorID = NULL) {

  d <- list(check_function_arg.ID(ID))
  filiation <- check_function_arg.filiation(filiation)

  if (!(filiation %in% c("mother_genetic", "mother_social", "father"))) stop("Relatedness functions only accept 'mother_genetic', 'mother_social', 'father'")
  if (filiation == "mother_genetic") filiation <- "mothergenetic"
  if (filiation == "mother_social") filiation <- "mothersocial"

  .hyena_tbl <- extract_database_table("hyenas")

  i <- 1
  if (is.null(ancestorID)) {
    while (sum(!is.na(d[[i]])) > 0) {
    d[[i + 1]] <- .hyena_tbl[match(d[[i]], .hyena_tbl$ID), filiation, drop = TRUE]
    i <- i + 1
    }

  } else {
while (d[[i]] != ancestorID) { ## case when a known ancestors is set to stop the search
  if (i == 25) stop("Internal issue during the search of ancestors: the function 'find_id_id.ancestor.all()' attempted to look for an ancestor more than 25 generations older than 'ID'.")
      d[[i + 1]] <- .hyena_tbl[match(d[[i]], .hyena_tbl$ID), filiation, drop = TRUE]
      i <- i + 1
    }

  }
  c(stats::na.omit(unlist(d)))

}


#################################################################
#' @describeIn find_family find the relatedness coefficient between 2 ids following a filiation path (for social support computation).
#'
#' @return A coefficient of relatedness.
#' @export
#' @examples
#' load_package_database.dummy()
#' find_dyad_relatedness.via.filiation(ID.1 = "A-084", ID.2 = "A-001",
#'                                     filiation = "mother_genetic")
#'
find_dyad_relatedness.via.filiation <- function(ID.1, ID.2, filiation = "mother_genetic",
                                                verbose = TRUE) {

  if (verbose) {
    warning("This function is used to compute relatedness for social support code. DO NOT USE THIS FUNCTION TO CALCULATE RELATEDNESS FOR OTHER TASKS. Instead use `fetch_dyad_relatedness()`")
  }

  ID.1 <- check_function_arg.ID(ID.1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, argument.name = 'ID.2')
  filiation <- check_function_arg.filiation(filiation)

  line_A <- find_id_id.ancestor.all(as.character(ID.1), filiation = filiation)
  line_B <- find_id_id.ancestor.all(as.character(ID.2), filiation = filiation)

  if (length(base::intersect(line_A, line_B)) == 0) return(NA)

  ## common ancestor(s):
  steps_to_A_ancestor <- which(line_A %in% line_B)[1] - 1
  steps_to_B_ancestor <- which(line_B %in% line_A)[1] - 1
  0.5^(steps_to_A_ancestor + steps_to_B_ancestor)

}

#################################################################
#' @describeIn find_family find the most recent common ancestor between two idsf ollowing a filiation path (for social support computation).
#'
#' @inheritParams arguments
#' @return The id of the common ancestor.
#' @export
#' @examples
#' load_package_database.dummy()
#' find_dyad_id.ancestor.MRCA(ID.1 = "A-010", ID.2 = "A-001", filiation = "mother_genetic")
#'
find_dyad_id.ancestor.MRCA <- function(ID.1, ID.2, filiation = "mother_social") {

  ID.1 <- check_function_arg.ID(ID.1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, argument.name = 'ID.2')
  filiation <- check_function_arg.filiation(filiation)

  line_A <- find_id_id.ancestor.all(ID.1, filiation = filiation)
  line_B <- find_id_id.ancestor.all(ID.2, filiation = filiation)

  if (length(base::intersect(line_A, line_B)) == 0) return(NA)
  base::intersect(line_A, line_B)[1]
}

#################################################################
#' @describeIn fetch_family fetch the coefficient of relatedness between two hyenas via the chosen filiation (either `mother_social`, `mother_genetic` or `father`).
#'
#' @return A coefficient of relatedness.
#' @export
#' @examples
#' fetch_dyad_relatedness.via.filiation(ID.1 = c("A-084", "A-010"),
#'                                      ID.2 = c("A-010", "A-001"),
#'                                      filiation = "mother_social")

fetch_dyad_relatedness.via.filiation  <- function(ID.1, ID.2, filiation = "mother_genetic",
                                                  verbose = TRUE) {

  ID.1 <- check_function_arg.ID(ID.1, argument.name = 'ID.1')
  ID.2 <- check_function_arg.ID(ID.2, argument.name = 'ID.2')
  filiation <- check_function_arg.filiation(filiation)

  purrr::pmap_dbl(list(ID.1, ID.2), ~ find_dyad_relatedness.via.filiation(..1, ..2, filiation = filiation,
                                                                          verbose = verbose))
}


#' @describeIn create_family create a tidy table with individuals and their relatedness as computed following a filiation path (for social support computation).
#' @export
#' @examples
#'
#' #### Simple example of create_relatedness table usage:
#' create_dyad_relatedness.via.filiation.table(c("A-100", "L-003", "A-100", "A-010"),
#'                                             filiation = "father", verbose = FALSE)

create_dyad_relatedness.via.filiation.table <- function(ID, filiation = "mother_genetic", verbose = TRUE) {

  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation)
  ## create an empty matrix with output number of rows and 2 col
  input <- matrix(NA_character_, nrow = (length(ID) * (length(ID) - 1 )) / 2, ncol = 2)
  colnames(input) <- c("ID.1", "ID.2")

  ## add the IDs
  k <- 1
  for (i in 1:(length(ID) - 1)) {
    for (j in (i + 1):length(ID)) {
      input[k, 1] <- ID[i]
      input[k, 2] <- ID[j]
      k <- k + 1
    }
  }
  ## and turn into a df
  output <- tibble::as_tibble(input)

  ## calculate the relatedness via filiation
  output <- output %>%
    dplyr::mutate(relatedness = fetch_dyad_relatedness.via.filiation(ID.1 = .data$ID.1, .data$ID.2,
                                                                     filiation = filiation,
                                                                     verbose = verbose))
  return(output)
}
