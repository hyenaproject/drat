#' Build optional vignette
#'
#' This function aims at creating vignettes after the package installation.
#' These vignettes differ from those readily available in hyenaR.
#' Indeed, the vignette created here will use the real database, instead of the dummy data.
#' That means that you need to manually load the database before calling such function!
#'
#' Note for developers: Within the vignette, function can refer to `.database`.
#' For passing other parameters, just use `args.vignette` and refer in the vignette code
#' to `args.vignette$xxx`, with `xxx` being the name of the parameter you want to use.
#' @name build_vignette_family
#' @aliases build_vignette_family build_vignette
#' @inheritParams arguments
#' @export
#'
#' @examples
#' \dontrun{
#' build_package_vignette.extra(file.name = "effect_of_ranks.Rmd")
#' build_package_vignette.extra(file.name = "data_summary.Rmd")
#' build_package_vignette.extra(file.name = "vignette_skeleton.Rmd",
#'                              args.vignette = list(ID = "A-100"))
#' }
#'
build_package_vignette.extra <- function(file.name, use.quarto = NULL, args.vignette = list(), overwrite = FALSE, verbose = FALSE,
                                         devtools.ok = TRUE, require.data = TRUE) {

  verbose <- check_function_arg.verbose(verbose)

  ## The vignette source files are stored in different places depending on whether one
  ## uses the installed version of the package or the one loaded with devtools during
  ## the development of the package. We thus try both:
  path1 <- paste0(find.package("hyenaR"), "/inst/extdata/optional_vignettes")
  path2 <- paste0(find.package("hyenaR"), "/extdata/optional_vignettes")
  if (dir.exists(path1)) {
    path <- path1
    if (!devtools.ok) stop("This vignette cannot be created using the package loading from devtools, please restart your R session and use instead 'library(hyenaR)' to load the package before building the vignette.")
    message("Note: creation of vignette using the development version of the package (not the installed one)")
  }
  if (dir.exists(path2)) {
    path <- path2
    message("Note: creation of vignette using the installed version of the package (not the developemental one)")
  }
  path_complete <- paste(path, file.name, sep = "/")
  path_complete <- check_function_arg.path(path_complete, mustWork = TRUE)

  #Determine file extension. Slightly different behaviour for quarto or Rmarkdown
  file_type <- paste0(".", tools::file_ext(path_complete))

  ## We check if the vignette has already been created:
  path_html <- gsub(pattern = file_type, replacement = ".html", x =  path_complete)

  if (file.exists(path_html) && interactive() && !overwrite) {
      choice <- utils::menu(
        choices = c("Display that vignette", "Recreate the vignette"),
        title = "A vignette with the same name has already been created before. What do you want to do?"
      )
    if (choice == 0) {
      message("You have aborted the vignette creation by inputing 0.")
      return(invisible(NULL))
    }
    if (choice == 1) {
      utils::browseURL(path_html)
      return(invisible(path_html))
    }
  }

  #Check if quarto is being used. If not, decide based on file type
  if (is.null(use.quarto)) {
    if (file_type == ".Rmd") {
      use.quarto <- FALSE
    } else if (file_type == ".qmd") {
      use.quarto <- TRUE
    }
  }

  ## We check if {rmarkdown} is there because we don't have it  in IMPORTS:
  if (!use.quarto & !requireNamespace("rmarkdown", quietly = TRUE)) {
    stop("You need to install the package 'rmarkdown' to use this function.")
  } else if (use.quarto & !requireNamespace("quarto", quietly = TRUE)) {
    stop("You need to install the package 'quarto' to render this file or set `use.quarto = FALSE` in function options")
  }

  ## We don't want to build such vignettes on dummy data:
  if (require.data && (!exists(".database") || (attr(.database, "datatype") == "dummy"))) {
    stop("You must load the full database using e.g. load_package_database.full('path_to_database_SQLite_file') before using this function")
  }

  ## Create a clean environment with just what is needed: ## FIXME: currently export global envir and should not
  vignette_env <- new.env() ## before new.env(parent = as.environment("package:hyenaR")) to mask the global env, but that creates scoping issues
  assign("args.vignette", value = args.vignette, envir = vignette_env)
  ### Note: there seem to be no need to pass .database: hyenaR functions can find it
  ### even if it is not possible to access it directly and even though that it is not
  ### part of as.environment("package:hyenaR"). I don't get it...

  ## The actual job:
  message("The vignette is being created (be patient)...")
  if (!use.quarto) {
    vignette_path <- rmarkdown::render(path_complete, quiet = !verbose,
                                       envir = vignette_env,
                                       params = list(args.vignette = args.vignette))
  } else if (use.quarto) {
    vignette_path <- tryCatch({quarto::quarto_render(path_complete, quiet = !verbose,
                                                    execute_params = list(args.vignette = args.vignette,
                                                                          db.path = ifelse(require.data, .database$db.path, NA)))
      # Quarto doesn't return file path so we do this manually
      gsub(path_complete, pattern = file_type, replacement = ".html")},
                              error = function(e){
                                message("quarto package failed when rendering. Using rmarkdown instead")
                                rmarkdown::render(path_complete, quiet = !verbose,
                                                  envir = vignette_env,
                                                  params = list(args.vignette = args.vignette))
                              })
  }

  message("The vignette has be created and is stored at the following location:")
  message(vignette_path)

  ## We open the vignette:
  utils::browseURL(vignette_path)

  ## We return the path:
  invisible(vignette_path)
}


#' @describeIn build_vignette_family build the vignette where functions are tested on full dataset and on particular
#' biological cases.
#' @export
#' @examples
#' \dontrun{
#' build_vignette_bio.cases()
#' }
build_vignette_bio.cases <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "bio_cases.Rmd", overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}

#' @describeIn build_vignette_family contains a list of errors in the raw data that must be fixed.
#' @export
#' @examples
#' \dontrun{
#' build_vignette_errors()
#' }
build_vignette_errors <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "error_vignette.Rmd",
                               overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}


#' @describeIn build_vignette_family create a summary vignette for the given ID.
#' @export
#' @examples
#' ## Before running this, the full database must be loaded:
#' \dontrun{
#' build_vignette_id.summary(ID = "A-001")
#' }
build_vignette_id.summary <- function(ID, overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  ID <- check_function_arg.ID(ID)
  build_package_vignette.extra(file.name = "ID_summary.Rmd", args.vignette = list(ID = ID),
                               overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}


#' @describeIn build_vignette_family contains a summary of the population and of the data
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_data.summary()
#' }
build_vignette_data.summary <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "data_summary.Rmd", overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}


#' @describeIn build_vignette_family contains a tutorial leading to study the effect of ranks
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_tutorial.ranks()
#' }
build_vignette_tutorial.ranks <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "effect_of_ranks.Rmd", overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}


#' @describeIn build_vignette_family contains the NEWS of the package
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_news()
#' }
build_vignette_news <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "news.Rmd", devtools.ok = TRUE, require.data = FALSE,
                               overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}


#' @describeIn build_vignette_family contains the info for developers
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_devel()
#' }
build_vignette_devel <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "devel.Rmd", devtools.ok = TRUE, require.data = FALSE,
                               overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}

#' @describeIn build_vignette_family contains the vignette about the grammar of the package
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_grammar()
#' }
build_vignette_grammar <- function(overwrite = FALSE, use.quarto = NULL, verbose = FALSE) {
  build_package_vignette.extra(file.name = "grammar.Rmd", devtools.ok = FALSE, require.data = FALSE,
                               overwrite = overwrite, verbose = verbose,
                               use.quarto = use.quarto)
}

#' @describeIn build_vignette_family rebuild all vignettes at once (for testing purposes)
#'
#' @export
#' @examples
#' \dontrun{
#' build_vignette_all.rebuild()
#' }
build_vignette_all.rebuild <- function(use.quarto = NULL) {
  cat("Building vignette data summary...\n")
  build_vignette_data.summary(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette ID summary...\n")
  build_vignette_id.summary(ID = "A-001", overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette tutorial ranks...\n")
  build_vignette_tutorial.ranks(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette errors...\n")
  build_vignette_errors(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette bio cases...\n")
  build_vignette_bio.cases(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette grammar...\n")
  build_vignette_grammar(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette devel...\n")
  build_vignette_devel(overwrite = TRUE, use.quarto = use.quarto)
  cat("Building vignette NEWS...\n")
  build_vignette_news(overwrite = TRUE, use.quarto = use.quarto)
}

