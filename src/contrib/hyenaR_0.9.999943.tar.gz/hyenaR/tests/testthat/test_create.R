context("Test create_xxx functions")

test_that("all create functions return the correct type", {

  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_starting.table())[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-10-30", clan.overlap = "always", lifestage.overlap = "always"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_offspring.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_mate.conception.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table())[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count("A-001_003"))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count())[1], "tbl_df")
  expect_equal(class(create_id_offspring.count(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sighting_starting.table(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sample_starting.table(at = "1996/07/30"))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.table(litterID = c("A-001_003", "A-001_002")))[1], "tbl_df")
  expect_equal(class(create_id_offspring.table(ID = "A-001"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.mother(parentID = "A-001"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.father(parentID = "A-011"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.all(parentID = c("A-011", "A-001")))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.mother())[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.father())[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.all())[1], "tbl_df")
  expect_equal(class(create_cervus_input(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_offspring_father.candidate.table(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_dyad_table.bystander("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_relatedness.via.filiation.table(c("A-011", "A-001"), filiation = "mother_social", verbose = FALSE))[1], "tbl_df")
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_clan_rank.social("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_interaction.type("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
})


test_that("create_offspring_litterID.from.all works as intended", {
  ref <- structure(list(parentID = c("A-011", "A-011", "A-011", "A-058"),
                        offspringID = c("A-080", "A-092", "A-054", NA),
                        birthdate = structure(c(9658, 9798, 9487, NA), class = "Date"),
                        filiation = c("father","father", "father", NA),
                        litterID = c("A-002_001", "A-016_002", NA, NA)),
                   row.names = c(NA,  -4L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_offspring_litterID.from.all(parentID = c("A-011", "A-058"))
  expect_equal(ref, job)
})

#### CREATE_ID_STARTING.TABLE() #####

test_that("create_id_starting.table defaults are correct", {
  ############

  ### TEST 1: When no arguments are given, return all known individuals
  #Check expected outcome (ref1a) and raw data (ref1b)
  job1 <- create_id_starting.table()
  ref1a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                 "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                 "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                 "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                 "A-055", "A-056", "A-057", "A-058", "A-080", "A-081", "A-082",
                                 "A-083", "A-084", "A-085", "A-086", "A-087", "A-088", "A-089",
                                 "A-090", "A-091", "A-092", "A-093", "A-094", "A-095", "A-096",
                                 "A-097", "A-098", "A-099", "A-100", "A-113", "A-114", "L-001",
                                 "L-002", "L-003", "L-004", "L-005", "L-006", "L-007", "L-008",
                                 "L-009", "L-010", "L-011", "L-012", "L-013", "L-014", "L-015",
                                 "L-040", "L-041", "L-042", "L-043", "L-044", "L-045", "L-046",
                                 "L-047", "L-048", "L-049", "L-080", "L-081", "L-082", "L-083",
                                 "L-084", "L-085", "L-086", "L-087", "L-088", "L-089", "L-090",
                                 "L-091", "L-092", "L-093", "L-094", "L-095", "L-096", "L-097",
                                 "L-098", "L-099", "L-100", "L-101", "L-102", "L-103", "L-104",
                                 "L-105", "L-106", "L-108", "L-109", "L-110", "M-004", "M-047",
                                 "M-051", "M-053", "N-043", "S-002", "S-043")),
                     row.names = c(NA, -122L), class = c("tbl_df", "tbl", "data.frame"))
  ref1b <- extract_database_table("hyenas") %>%
    dplyr::select("ID")
  expect_equal(job1, ref1a)
  expect_equal(job1, ref1b)

  ############

  ### TEST 2: When ID is specified, return only these individuals
  job2a <- create_id_starting.table(ID = c("A-080", "L-094"))
  #No matter what else is specified!!
  job2b <- create_id_starting.table(ID = c("A-080", "L-094"), lifestage = "cub",
                                    from = "1995-01-01")
  ref2 <- structure(list(ID = c("A-080", "L-094")),
                    row.names = c(NA, -2L),
                    class = c("tbl_df", "tbl", "data.frame"))
  expect_equal(job2a, ref2)
  expect_equal(job2b, ref2)

  ############

  ### TEST 3: When only clan.birth is provided, return all individuals born into this clan
  job3  <- create_id_starting.table(clan.birth = "A")
  ref3a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                 "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                 "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
                                 "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
                                 "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
                                 "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
                                 "A-099", "A-100", "A-113", "A-114")),
                     row.names = c(NA, -51L),
                     class = c("tbl_df", "tbl", "data.frame"))
  ref3b <- extract_database_table("hyenas") %>%
    dplyr::filter(.data$birthclan == "A") %>%
    dplyr::select("ID")
  expect_equal(job3, ref3a)
  expect_equal(job3, ref3b)
})

test_that("create_id_starting.table works when lifestage/clan.overlap are both 'always'", {
  ############

  ### TEST 4: When at date provided, return all individuals alive at that date
  #Check expected outcome (ref4/5a) and raw data (ref4/5b)
  job4  <- create_id_starting.table(at = "1996-04-12")
  ref4a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                 "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                 "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                 "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                 "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
                                 "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
                                 "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
                                 "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
                                 "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
                                 "L-083", "L-088", "L-089", "M-004", "M-047", "M-051", "M-053",
                                 "N-043", "S-002", "S-043")),
                     row.names = c(NA, -78L), class = c("tbl_df", "tbl", "data.frame"))
  ref4b <- extract_database_table("hyenas") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-04-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job4, ref4a)
  expect_equal(job4, ref4b)

  ############

  ### TEST 5: When from/to date provided, return all individuals alive at any point between those dates
  job5  <- create_id_starting.table(from = "1996-04-12", to = "1996-05-12")
  ref5a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                 "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                 "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                 "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                 "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
                                 "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
                                 "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
                                 "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
                                 "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
                                 "L-083", "L-084", "L-085", "L-088", "L-089", "M-004", "M-047",
                                 "M-051", "M-053", "N-043", "S-002", "S-043")),
                     row.names = c(NA, -80L), class = c("tbl_df", "tbl", "data.frame"))
  ref5b <- extract_database_table("hyenas") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-05-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job5, ref5a)
  expect_equal(job5, ref5b)

  ############

  ### TEST 6: When clan, lifestage, and at date are provided will return all individuals of that lifestage, in this clan on that date
  job6 <- create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
  ref6a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-009", "A-013", "A-014", "A-015", "A-016", "A-017",
                                 "A-020", "L-001", "L-002", "L-003", "L-004", "L-005", "L-006",
                                 "L-007", "L-008", "L-009", "L-011", "L-012", "L-014")),
                     row.names = c(NA, -25L), class = c("tbl_df", "tbl", "data.frame"))
  ref6b <- create_id_life.history.table() %>%
    dplyr::filter(clan %in% c("A", "L") & life_stage == "philopatric" & starting_date <= "1996-04-12" & ending_date >= "1996-04-12") %>%
    dplyr::select("ID")
  expect_equal(job6, ref6a)
  expect_equal(job6, ref6b)

  ############

  ### TEST 7: When clan, lifestage, and from/to date are provided, return all individuals that were of that lifestage and clan at any point during the time span.
  #i.e. the intervals overlap
  job7 <- create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", from = "1996-04-12", to = "1996-08-31")
  ref7a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-013", "A-014", "A-015", "A-016",
                                 "A-017", "A-020", "A-040", "L-001", "L-002", "L-003", "L-004",
                                 "L-005", "L-006", "L-007", "L-008", "L-009", "L-010", "L-011",
                                 "L-012", "L-013", "L-014", "L-015")),
                     row.names = c(NA, -30L), class = c("tbl_df", "tbl", "data.frame"))
  test_interval <- lubridate::interval(start = "1996-04-12",
                                       end = "1996-08-31")
  ref7b <- create_id_life.history.table() %>%
    dplyr::filter(clan %in% c("A", "L") & life_stage == "philopatric") %>%
    dplyr::mutate(interval = lubridate::interval(start = starting_date,
                                                 end = ending_date)) %>%
    dplyr::filter(lubridate::int_overlaps(test_interval, interval)) %>%
    dplyr::select("ID")

  expect_equal(job7, ref7a)
  expect_equal(job7, ref7b)
})

test_that("create_id_starting.table works with different values of clan.overlap", {
  ############

  ### TEST 8: When clan.overlap = "start" w/ from/to, return all individuals that started being in the clan at this point
  #This may be cubs born or dispersers
  job8 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start")
  ref8a <- structure(list(ID = c("A-011", "A-042", "A-044", "A-045", "A-047",
                                 "A-048", "A-050", "A-051", "A-055", "A-080", "A-081", "A-086",
                                 "A-087", "A-088", "A-089", "A-090", "A-091", "A-092", "A-093",
                                 "A-094", "A-095", "A-096", "A-097", "A-098", "A-099", "A-100",
                                 "A-114", "M-051", "M-053", "S-043")),
                     row.names = c(NA, -30L), class = c("tbl_df", "tbl", "data.frame"))

  ref8b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job8, ref8a)
  expect_equal(job8, ref8b)

  ############

  ### TEST 9: When clan.overlap = "end" w/ from/to, return all individuals that ended being in the clan at this point
  #This may be cubs born or dispersers
  job9 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "end")
  ref9a <- structure(list(ID = c("A-007", "A-043", "A-044", "A-049", "A-058", "A-082")),
                     row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame"))

  ref9b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job9, ref9a)
  expect_equal(job9, ref9b)

  ############

  ### TEST 10: When clan.overlap = "always" w/ from/to, return all individuals that were always in the clan during this period
  job10 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "always")
  ref10a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                  "A-008", "A-009", "A-010", "A-011", "A-013", "A-014", "A-015",
                                  "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                  "A-042", "A-045", "A-046", "A-047", "A-048", "A-050", "A-051",
                                  "A-052", "A-053", "A-054", "A-056", "A-057", "A-083", "A-084",
                                  "A-085", "A-113", "M-053")),
                      row.names = c(NA, -36L), class = c("tbl_df", "tbl", "data.frame"))

  ref10b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date),
                     .groups = "drop") %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job10, ref10a)
  expect_equal(job10, ref10b)

  ############

  ### TEST 11: When clan.overlap = "within" w/ from/to, return all individuals that were always in the clan during this period
  job11 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "within")
  ref11a <- structure(list(ID = c("A-044")),
                      row.names = c(NA, -1L), class = c("tbl_df", "tbl", "data.frame"))

  ref11b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date),
                     .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job11, ref11a)
  expect_equal(job11, ref11b)

  ############

  ### TEST 12: When we give clan and clan.birth w/ from/to, return all individuals that were alive at any point between from/to AND were born in focal clan
  job12 <- create_id_starting.table(clan = "A", clan.birth = "A", from = "1996-04-12", to = "1997-12-30")
  ref12a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                  "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                  "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                  "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
                                  "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
                                  "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
                                  "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
                                  "A-099", "A-100", "A-113", "A-114")),
                      row.names = c(NA, -51L), class = c("tbl_df", "tbl", "data.frame"))

  ref12b <- extract_database_table("hyenas") %>%
    filter(birthclan == "A") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1997-12-30") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job12, ref12a)
  expect_equal(job12, ref12b)

  ############

  ### TEST 13: When we provide both clan.birth, clan and lifestage is given w/ from/to, return all individuals that were in this lifestage at any point between from/to AND were born in focal clan
  job13 <- create_id_starting.table(clan.birth = "A", clan = "L", from = "1997-01-01", to = "1997-12-31",
                                    lifestage = "disperser", lifestage.overlap = "any")
  ref13a <- structure(list(ID = "A-049"), row.names = c(NA, -1L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref13b <- create_id_life.history.table() %>%
    dplyr::filter(clan == "L" & life_stage == "disperser" & fetch_id_clan.birth(ID) == "A") %>%
    dplyr::filter(.data$starting_date <= "1997-12-31" & .data$ending_date >= "1997-01-01") %>%
    dplyr::select("ID")
  expect_equal(job13, ref13a)
  expect_equal(job13, ref13b)
})

test_that("create_id_starting.table works with lifestage.overlap 'start'", {
  ############

  ### TEST 14: When lifestage.overlap = "start"  w/ from/to, return all individuals that started being in this lifestage in all clans at this point
  job14 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref14a <- structure(list(ID = c("A-040", "A-041", "A-046", "A-049", "A-054",
                                  "A-056", "A-084", "A-085", "A-113", "L-046", "L-082", "L-083",
                                  "L-089")),
                      row.names = c(NA, -13L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref14b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date >= "1996-04-12" & .data$starting_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job14, ref14a)
  expect_equal(job14, ref14b)

  ############

  ### TEST 15: When lifestage.overlap = "start" and we use multiple lifestages w/ from/to, return all individuals that started being in any of these lifestages in all clans at this point
  job15 <- create_id_starting.table(lifestage = c("subadult", "natal"),
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref15a <- structure(list(ID = c("A-054", "A-058", "A-080", "A-081", "A-083",
                                  "A-084", "A-085", "A-086", "A-087", "A-088", "A-089", "A-092",
                                  "A-093", "A-095", "A-113", "L-080", "L-081", "L-082", "L-083",
                                  "L-084", "L-085", "L-086", "L-087", "L-088", "L-089", "L-090",
                                  "L-093")),
                      row.names = c(NA, -27L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref15b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job15, ref15a)
  expect_equal(job15, ref15b)

  ############

  ### TEST 16: When lifestage.overlap = "start" and we use multiple lifestages w/ from/to, return all individuals that started being in any of these lifestages in all clans at this point
  job16 <- create_id_starting.table(lifestage = "adult",
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref16a <- structure(list(ID = c("A-008", "A-010", "A-018", "A-019", "A-040",
                                  "A-041", "A-046", "A-049", "A-054", "A-056", "A-084", "A-085",
                                  "A-113", "L-010", "L-013", "L-015", "L-046", "L-082", "L-083",
                                  "L-088", "L-089")),
                      row.names = c(NA, -21L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref16b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("disperser",
                                                    "foreigner",
                                                    "natal",
                                                    "unknown",
                                                    "philopatric",
                                                    "selector_2",
                                                    "selector_3",
                                                    "selector_4",
                                                    "selector_5",
                                                    "transient",
                                                    "founder_male",
                                                    "foreigner_2",
                                                    "foreigner_3",
                                                    "foreigner_4",
                                                    "foreigner_5")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job16, ref16a)
  expect_equal(job16, ref16b)
})

test_that("create_id_starting.table works with lifestage.overlap 'end'", {
  ############

  ### TEST 17: When lifestage.overlap = "end"  w/ from/to, return all individuals that ended being in this lifestage in all clans at this point
  job17 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end")
  ref17a <- structure(list(ID = c("A-040", "A-043", "A-049", "M-047", "M-051",
                                  "N-043", "S-043")),
                      row.names = c(NA, -7L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref17b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$ending_date >= "1996-04-12" & .data$ending_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job17, ref17a)
  expect_equal(job17, ref17b)

  ############

  ### TEST 18: When lifestage.overlap = "end" and we use multiple lifestage w/ from/to, return all individuals that ended being in any of these lifestages in all clans at this point
  job18 <- create_id_starting.table(lifestage = c("subadult", "natal"),
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end")
  ref18a <- structure(list(ID = c("A-008", "A-010", "A-018", "A-019", "A-040",
                                  "A-043", "A-049", "A-058", "L-010", "L-013", "L-015",
                                  "L-049", "L-088", "M-047", "M-051", "N-043", "S-043")),
                      row.names = c(NA, -17L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref18b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job18, ref18a)
  expect_equal(job18, ref18b)

  ############

  ### TEST 19: When lifestage.overlap = "end" and we use meta-lifestage w/ from/to, return all individuals that ended being in any of these lifestages in all clans at this point
  job19 <- create_id_starting.table(lifestage = "adult",
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end")
  ref19a <- structure(list(ID = c("A-007", "A-043", "A-044", "L-006", "L-007",
                                  "L-043", "S-002")),
                      row.names = c(NA, -7L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref19b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("disperser",
                                                    "foreigner",
                                                    "natal",
                                                    "philopatric",
                                                    "selector_2",
                                                    "selector_3",
                                                    "selector_4",
                                                    "selector_5",
                                                    "transient",
                                                    "founder_male",
                                                    "foreigner_2",
                                                    "foreigner_3",
                                                    "foreigner_4",
                                                    "foreigner_5")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job19, ref19a)
  expect_equal(job19, ref19b)
})

test_that("create_id_starting.table works with lifestage.overlap 'always'", {
  ############

  ### TEST 20: When lifestage.overlap = "always"  w/ from/to, return all individuals that were always in this lifestage in all clans at this point
  job20 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always")
  ref20a <- structure(list(ID = c("A-052", "A-053", "A-057", "L-044", "L-045")),
                      row.names = c(NA, -5L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref20b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date <= "1996-04-12" & .data$ending_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job20, ref20a)
  expect_equal(job20, ref20b)

  ############

  ### TEST 21: When lifestage.overlap = "always" and we use multiple lifestage w/ from/to, return all individuals that were always in one of these lifestages in all clans at this point
  job21 <- create_id_starting.table(lifestage = c("subadult", "natal"),
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always")
  ref21a <- structure(list(ID = c("A-041", "A-046", "A-052", "A-053", "A-056",
                                  "A-057", "L-044", "L-045", "L-046")),
                      row.names = c(NA, -9L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref21b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job21, ref21a)
  expect_equal(job21, ref21b)

  ############

  ### TEST 22: When lifestage.overlap = "always" and we use meta-lifestage w/ from/to, return all individuals that were always in one of these lifestages in all clans at this point
  job22 <- create_id_starting.table(lifestage = "adult",
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always")
  ref22a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                  "A-009", "A-011", "A-013", "A-014", "A-015", "A-016", "A-017",
                                  "A-020", "A-040", "A-042", "A-045", "A-047", "A-048", "A-050",
                                  "A-051", "A-052", "A-053", "A-055", "A-057", "L-001", "L-002", "L-003",
                                  "L-004", "L-005", "L-008", "L-009", "L-011", "L-012", "L-014",
                                  "L-040", "L-041", "L-042", "L-044", "L-045", "L-047", "L-048",
                                  "M-004", "M-047", "M-051", "M-053", "N-043", "S-043")),
                      row.names = c(NA, -47L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref22b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("disperser",
                                                    "foreigner",
                                                    "natal",
                                                    "unknown",
                                                    "philopatric",
                                                    "selector_2",
                                                    "selector_3",
                                                    "selector_4",
                                                    "selector_5",
                                                    "transient",
                                                    "founder_male",
                                                    "foreigner_2",
                                                    "foreigner_3",
                                                    "foreigner_4",
                                                    "foreigner_5")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job22, ref22a)
  expect_equal(job22, ref22b)
})

test_that("create_id_starting.table works with lifestage.overlap 'within'", {
  ############

  ### TEST 23: When lifestage.overlap = "within"  w/ from/to, return all individuals that started and ended in this lifestage in all clans at this point
  job23 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within")
  ref23a <- structure(list(ID = c("A-040", "A-049")),
                      row.names = c(NA, -2L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref23b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date >= "1996-04-12" & .data$ending_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job23, ref23a)
  expect_equal(job23, ref23b)

  ############

  ### TEST 24: When lifestage.overlap = "within" and we use multiple lifestage w/ from/to, return all individuals that started and ended in all of these lifestages in all clans at this point
  job24 <- create_id_starting.table(lifestage = c("subadult", "natal"),
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within")
  ref24a <- structure(list(ID = c("A-058", "L-088")),
                      row.names = c(NA, -2L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref24b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job24, ref24a)
  expect_equal(job24, ref24b)

  ############

  ### TEST 25: When lifestage.overlap = "within" and we use meta-lifestage w/ from/to, return all individuals that started and ended in all of these lifestages in all clans at this point
  job25 <- create_id_starting.table(lifestage = "adult",
                                    from = "1992-01-01", to = "1997-12-30", lifestage.overlap = "within")
  ref25a <- structure(list(ID = c("A-043", "L-006", "L-043")),
                      row.names = c(NA, -3L),
                      class = c("tbl_df", "tbl", "data.frame"))

  ref25b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("disperser",
                                                    "foreigner",
                                                    "natal",
                                                    "unknown",
                                                    "philopatric",
                                                    "selector_2",
                                                    "selector_3",
                                                    "selector_4",
                                                    "selector_5",
                                                    "transient",
                                                    "founder_male",
                                                    "foreigner_2",
                                                    "foreigner_3",
                                                    "foreigner_4",
                                                    "foreigner_5")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date),
                     last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1992-01-01" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job25, ref25a)
  expect_equal(job25, ref25b)
})

test_that("create_id_starting.table deals properly with sex and death", {

  ############

  ### TEST 26: When sex is specified same output but sex is filtered.
  job26a <- create_id_starting.table(lifestage = c("subadult", "natal"),
                                    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within",
                                    sex = "male")
  #Take ref24a as our starting point
  ref26a <- structure(list(ID = c("A-058", "L-088")),
                      row.names = c(NA, -2L),
                      class = c("tbl_df", "tbl", "data.frame")) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = .data$ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::select("ID")
  expect_equal(job26a, ref26a)

  job26b <- create_id_starting.table(clan.birth = "A", sex = "male")
  #Take ref3a as our starting point (create_id_starting.table(clan.birth = "A"))
  ref26b <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                  "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                  "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                  "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
                                  "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
                                  "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
                                  "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
                                  "A-099", "A-100", "A-113", "A-114")),
                      row.names = c(NA, -51L),
                      class = c("tbl_df", "tbl", "data.frame")) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = .data$ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::select("ID")
  expect_equal(job26b, ref26b)

  ############

  ### TEST 27: When lifestage = "dead" with at, will return all individuals that have died in this clan up to and including this date.
  job27 <- create_id_starting.table(lifestage = "dead", at = "1997-01-01")
  ref27a <- structure(list(ID = c("A-007", "A-043", "A-044", "A-058", "A-082",
                                  "L-006", "L-007", "L-043", "L-049", "L-091", "L-092", "S-002")),
                     row.names = c(NA, -12L), class = c("tbl_df", "tbl", "data.frame"))
  ref27b <- extract_database_table("deaths") %>%
    dplyr::filter(.data$deathdate <= "1997-01-01") %>%
    dplyr::select("ID")
  expect_identical(job27, ref27a)
  expect_identical(job27, ref27b)

  ############

  ### TEST 28: Lifestage "!dead" is the same as when lifestage is not specified.
  job28a <- create_id_starting.table(lifestage = "!dead", at = "1997-01-01")
  job28b <- create_id_starting.table(at = "1997-01-01")
  expect_equal(job28a, job28b)

  ############

  ### TEST 29: Lifestage "!dead" is the same as when lifestage is not specified.
  job29a <- create_id_starting.table(lifestage = "all", at = "1997-01-01") %>%
    dplyr::arrange(.data$ID)
  ref29 <- dplyr::bind_rows(job27, job28a) %>%
    dplyr::arrange(.data$ID)
  expect_equal(job29a, ref29)

  ############

  ### TEST 30: No args or providing from = first birth, to = last sighting should be identical
  job30a <- create_id_starting.table()
  ref30 <- create_id_starting.table(from = find_pop_date.birth.first(),
                                    to = find_pop_date.observation.last())
  expect_equal(job30a, ref30)

  ############

  ### TEST 31: Providing clan with or without default from/to is identical
  job31a <- create_id_starting.table(clan = "A")
  ref31 <- create_id_starting.table(clan = "A",
                                    from = find_pop_date.birth.first(),
                                    to = find_pop_date.observation.last())
  expect_equal(job31a, ref31)

})

test_that("create_offspring_litterID.from.father works as intended", {
  ref <- structure(list(parentID = c("A-011", "A-011", "A-011", "A-040"),
                        offspringID = c("A-054", "A-080", "A-092", NA),
                        birthdate = structure(c(9487, 9658, 9798, NA), class = "Date"),
                        filiation = c("father","father", "father", NA),
                        litterID = c(NA, "A-002_001", "A-016_002",NA)),
                   row.names = c(NA, -4L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_offspring_litterID.from.father(parentID = c("A-011", "A-040"))
  expect_equal(ref, job)
})


test_that("create_offspring_litterID.from.mother works as intended", {
  ref <- structure(list(parentID = c("A-001", "A-001", "A-001", "A-001","A-001", "A-001", "A-058"),
                        offspringID = c("A-010", "A-018", "A-046","A-084", "A-088", "A-089", NA),
                        filiation = c("mother_social_genetic","mother_social_genetic", "mother_social_genetic", "mother_social_genetic",
                                      "mother_social_genetic", "mother_social_genetic", NA),
                        litterID = c("A-001_001","A-001_001", "A-001_001", "A-001_002", "A-001_003", "A-001_003",NA),
                        birthdate = structure(c(9029, 9029, 9029, 9411, 9842, 9842,NA), class = "Date")),
                   row.names = c(NA, -7L),
                   class = c("tbl_df","tbl", "data.frame"))
  job <- create_offspring_litterID.from.mother(parentID = c("A-001", "A-058"))
  expect_equal(ref, job)
})


test_that("create_id_offspring.table works as intended", {
  ref <- structure(list(parentID = c("A-001", "A-001", "A-001", "L-003",
                                     "A-100", "A-011", "A-058"),
                        offspringID = c("A-010", "A-018",
                                        "A-046", NA, NA, NA, NA),
                        birthdate = structure(c(9029, 9029, 9029, NA, NA, NA, NA), class = "Date"),
                        filiation = c("mother_social_genetic",
                                      "mother_social_genetic", "mother_social_genetic", NA, NA, NA, NA)),
                   row.names = c(NA, -7L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_id_offspring.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
                                   from = "1994-01-01", to = "1995-01-01")
  expect_equal(ref, job)
})


test_that("create_litter_offspring.table returns output as intended", {
  ref <- structure(list(litterID = c("A-001_003", "A-001_003", "A-001_002"),
                        parentID = c("A-001", "A-001", "A-001"),
                        offspringID = c("A-088", "A-089", "A-084"),
                        filiation = c("mother_social_genetic","mother_social_genetic",
                                      "mother_social_genetic"),
                        birthdate = structure(c(9842, 9842, 9411), class = "Date")),
                   row.names = c(NA,-3L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_litter_offspring.table(litterID = c("A-001_003", "A-001_002"))
  expect_equal(ref, job)

})


test_that("create_id_offspring.count returns output as intended", {
  ref <- structure(
    list(
      parentID = c("A-001", "A-008"),
      n_females = c(3L,
                    NA),
      n_males = c(3L, NA),
      n_unknown = c(0L, NA)
    ),
    row.names = 1:2,
    class = c("tbl_df",
              "tbl", "data.frame")
  )
  job <- create_id_offspring.count(ID = c("A-001", "A-008"))
  expect_equal(ref, job)
})

test_that("create_litter_offspring.count returns output as intended", {
  ref <-
    structure(
      list(
        litterID = "A-001_003",
        female = 1L,
        male = 1L,
        unknown = 0L,
        social.female = 0L,
        social.male = 0L,
        social.unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- create_litter_offspring.count("A-001_003")
  expect_equal(ref, job)
})

test_that("create_litter_starting.table return the expected output", {
  ref <- structure(list(parentID = c(rep("A-001",3), "L-003", "A-098"),
                        litterID = c("A-001_001", "A-001_002", "A-001_003", "L-003_001", NA_character_)),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -5L))
  job <- create_litter_starting.table(c("A-001", "L-003", "A-098"))
  expect_equal(ref,job)
})


test_that("create_id_mate.conception.table returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "A-001", "A-001", "A-001", "A-098", "L-003"),
      mate = c("A-045", NA, NA, NA, NA, "L-043"),
      date = structure(c(8919, 8919, 9301, 9732, NA, 9240), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -6L)
  )
  job <- create_id_mate.conception.table(c("A-001", "L-003", "A-098"))
  expect_identical(ref, job)
})

test_that("create_id_selection.history returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "L-094"),
      clan = c("A", "L"),
      starting_date = structure(c(6715, 9896), class = "Date"),
      ending_date = structure(c(10226, 10226), class = "Date")
    ),
    class = c("tbl_df","tbl", "data.frame"),
    row.names = c(NA,-2L)
  )
  job <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = TRUE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "L-094"),
        clan = c("A", "L"),
        starting_date = structure(c(6715, 9896), class = "Date"),
        ending_date = structure(c(NA_real_, NA_real_), class = "Date")
      ),
      class = c("tbl_df",
                "tbl", "data.frame"),
      row.names = c(NA,-2L)
    )

  job2 <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = FALSE)
  expect_identical(ref2, job2)
})

test_that("create_id_life.transition.table returns the correct output", {
  ref <- structure(list(ID = c("A-001", "A-001", "A-008", "A-008", "A-044", "A-044"),
                        origin = c("W", "A", "W", "A", "W", "X"),
                        destination = c("A", "A", "A", "A", "X", "A"),
                        date = structure(c(6715, 7445, 8906, 9636, 5254, 9598), class = "Date")),
                   row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame"))
  job <- create_id_life.transition.table(c("A-001", "A-008", "A-044"))
  expect_identical(ref, job)
})

test_that("create_sighting_starting.table returns output as intended", {

  ref <- structure(list(ID = c("A-001", "A-002", "A-002"),
                        sighting_time = structure(c(857977740, 857977740, 857979360),
                                                  class = c("POSIXct", "POSIXt"),
                                                  tzone = "Africa/Dar_es_Salaam"),
                        latitude = c(-3.14017, -3.14017, -3.1415),
                        longitude = c(35.50417, 35.50417, 35.50333),
                        sighting_clan = c("A", "A", "A")),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -3L))
  job <- create_sighting_starting.table(ID = c("A-001", "A-002"), from = "1997-03-01", to = "1997-03-10")
  expect_equal(ref, job)

  #Check that time zone is dealt with correctly
  ref <- recode_x_date("1997-09-19")

  job <- create_sighting_starting.table(ID = "L-004", to = "1997-09-19") %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::pull(sighting_time) %>%
    recode_x_date()

  expect_true(job <= ref)

})

test_that("'include.conceptions' works as expected in create_sighting_starting.table", {

  default <- structure(list(ID = c("A-013", "A-013"),
                            sighting_time = structure(c(868953600, 869978940),
                                                      tzone = "Africa/Dar_es_Salaam",
                                                      class = c("POSIXct", "POSIXt")),
                            latitude = c(-3.13867, -3.16267),
                            longitude = c(35.5065, 35.49317),
                            sighting_clan = c("A", "A")),
                       row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame"))

  conception_included <- structure(list(ID = c("A-013", "A-013", "A-013"),
                                        sighting_time = structure(c(862779600, 868953600, 869978940),
                                                                  tzone = "Africa/Dar_es_Salaam",
                                                                  class = c("POSIXct", "POSIXt")),
                                        latitude = c(NA, -3.13867, -3.16267),
                                        longitude = c(NA, 35.5065, 35.49317),
                                        sighting_clan = c("A", "A", "A")),
                                   row.names = c(NA, -3L), class = c("tbl_df", "tbl", "data.frame"))

  job1 <- create_sighting_starting.table(ID = "A-013", from = "1997-05-01", to = "1997-08-01")
  job2 <- create_sighting_starting.table(ID = "A-013", from = "1997-05-01", to = "1997-08-01", include.conception = TRUE)

  expect_equal(default, job1)
  expect_equal(conception_included, job2)

})

test_that("create_sample_starting.table works with dates provided", {

  ref <- structure(list(ID = c("L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043"),
                        sampleID = c("N0001", "N0002a",
                                     "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a", "N0005",
                                     "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c", "N0008d",
                                     "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011", "N0012",
                                     "N0013", "N0014"),
                        collection_time = structure(c(838744200, 838736640, 838744200, 838737000, 838744200,
                                                      838740600, 838744200, 838740600, 838744200, 838740600, 838744200,
                                                      838738800, 838749600, 838746000, 838746000, 838746000, 838749600,
                                                      838749600, 838749600, 838749600, 838749600, 838751400, 838739700,
                                                      838745100, 838735200), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
                        type = c("testicle", "liver", "liver",
                                 "spleen", "spleen", "salivary gland", "salivary gland", "lymph node",
                                 "lymph node", "tonsil", "tonsil", "voice box", "muscle",
                                 "muscle", "muscle", "muscle", "brain", "brain", "brain",
                                 "blood", "CSF", "eye", "tongue", "gland", "penis"),
                        treatment = c("liq N", "10% Form", "liq N", "10% Form", "liq N",
                                      "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                      "10% Form", "liq N", "Ethanol", "Ethanol", "10% Form", "glycerol",
                                      "glycerol", "liq N", "liq N", "liq N", "10% Form", "10% Form",
                                      "10% Form", "10% Form")), class = c("tbl_df", "tbl", "data.frame"
                                      ), row.names = c(NA, -25L))

  job <- create_sample_starting.table(from = "1996-07-01",
                                      to = "1996-08-01", verbose = FALSE)

  ref2 <- structure(list(ID = c("L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043"),
                         sampleID = c("N0001",
                                      "N0002a", "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a",
                                      "N0005", "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c",
                                      "N0008d", "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011",
                                      "N0012", "N0013", "N0014"),
                         collection_time = structure(c(838744200,
                                                       838736640, 838744200, 838737000, 838744200, 838740600, 838744200,
                                                       838740600, 838744200, 838740600, 838744200, 838738800, 838749600,
                                                       838746000, 838746000, 838746000, 838749600, 838749600, 838749600,
                                                       838749600, 838749600, 838751400, 838739700, 838745100, 838735200), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
                         type = c("testicle",
                                  "liver", "liver", "spleen", "spleen", "salivary gland", "salivary gland",
                                  "lymph node", "lymph node", "tonsil", "tonsil", "voice box",
                                  "muscle", "muscle", "muscle", "muscle", "brain", "brain", "brain",
                                  "blood", "CSF", "eye", "tongue", "gland", "penis"),
                         treatment = c("liq N",
                                       "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                       "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                       "Ethanol", "Ethanol", "10% Form", "glycerol", "glycerol", "liq N",
                                       "liq N", "liq N", "10% Form", "10% Form", "10% Form", "10% Form")),
                    class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -25L))

  job2 <- create_sample_starting.table(ID = "L-043", verbose = FALSE)

  expect_equal(ref, job)
  expect_equal(ref2, job2)

})

test_that("create_clan_obsv.effort.table returns the correct output", {

  expect_equal(class(create_clan_obsv.effort.table(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  ref <- structure(list(clan = c("A", "L"),
                        from = structure(c(10074, 10074), class = "Date"),
                        to = structure(c(10105, 10105), class = "Date"),
                        effort_adult = c(11/29, 21/25),
                        effort_cub = c(10/23, 16/20),
                        effort_all = c(21/52, 37/45)),
                   row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame"))

  #We keep the new argument just to make sure we can compare new & and old method
  job <- create_clan_obsv.effort.table(clan = c("A", "L"), from = "1997-08-01", to = "1997-09-01")
  expect_equal(ref, job)

})

test_that("create_cervus_input works as intended",{

  # Works with standard and multiple individuals
  ref <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      sex = c(
        "female",
        "female",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male"
      ),
      motherID = c(
        "A-015",
        NA,
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014"
      ),
      birthdate = structure(
        c(
          8906,
          6715,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797
        ),
        class = "Date"
      ),
      clan.conception = c("A",
                          NA, "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      ),
      genotyped = c(
        NA,
        NA,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE,
        FALSE,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE
      ),
      index.candidate = c(
        "candidate1",
        "candidate1",
        "candidate1",
        "candidate2",
        "candidate3",
        "candidate4",
        "candidate5",
        "candidate6",
        "candidate7",
        "candidate8",
        "candidate9",
        "candidate10",
        "candidate11"
      ),
      N.typed = c(NA, NA, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L,
                  8L),
      N.potential = c(NA, NA, 11L, 11L, 11L, 11L, 11L, 11L, 11L,
                      11L, 11L, 11L, 11L),
      prop.typed = c(
        NA,
        NA,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727
      )
    ),
    row.names = c(NA,-13L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_cervus_input(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref, job)

  # Works with individuals conceived before the birthdate of the first founder in the dataset
  expect_warning(create_cervus_input("L-003"))
})


test_that("create_offspring_father.candidate.table works as intended", {

  #Works with standard and multiple individuals
  ref1 <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      )
    ),
    row.names = c(NA,-13L),
    class = c("tbl_df",
              "tbl", "data.frame")
  )
  job1 <- create_offspring_father.candidate.table(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref1, job1)

  # Returns warning when input contains at least one individual conceived before the birthdate of the first founder
  expect_warning(create_offspring_father.candidate.table("L-003"))
  expect_warning(create_offspring_father.candidate.table(c("L-003", "L-004")))
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(list(ID = c("A-001", "A-084", "A-010", "A-018", "A-046",
                               "A-003", "A-015", "A-008", "A-013", "A-016", "A-019", "A-020",
                               "A-041", "A-049", "A-081", "A-057", "A-085", "A-002", "A-004",
                               "A-006", "A-007", "A-009", "A-014", "A-017", "A-040", "A-043",
                               "A-052", "A-053", "A-056", "A-058", "A-080", "A-054", "A-083",
                               "A-113", "A-011", "A-042", "A-044", "A-045", "A-047", "A-048",
                               "A-050", "A-051", "M-053"),
                        rank = c(1, 2, 3, 3, 3, 6, 6, 8,
                                 8, 8, 11, 11, 11, 11, 11, 16, 16, 18, 18, 18, 18, 18, 18, 18,
                                 18, 18, 18, 18, 18, 18, 18, 32, 32, 32, 35, 35, 35, 35, 35, 35,
                                 35, 35, 35)),
                   row.names = c(NA, -43L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_clan_rank.social("A", "1996-07-30")
  expect_equal(ref, job)
})

test_that("create_id_table.ancestors return a list column with ancestors", {
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30")$ancestors), "list")
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(
    list(ID.1 = c("A-084"),
         ID.2 = c("A-001"),
         date = as.Date(c("1997-04-01")),
         ID.1_is_migrant = c(FALSE),
         ID.2_is_migrant = c(FALSE),
         mrcaID = c("A-001"),
         type = c("native_related")),
    row.names = c(NA,-1L),
    class = c("tbl_df", "tbl", "data.frame"))
  job <- create_dyad_interaction.type(ID.1 = "A-084", ID.2 = "A-001", "1997-04-01")
  expect_equal(ref, job)
})

test_that("create_id_overlap.table works as intended", {

  #Dummy data to filter
  input <- structure(list(ID = c("A", "A", "B", "C"),
                          starting_date = c("1996-01-01", "1997-01-01", "1997-01-01", "1996-05-01"),
                          ending_date = c("1996-12-31", "1997-02-01", "1997-03-01", "1997-04-05")),
                     row.names = c(NA, -4L), class = c("tbl_df", "tbl", "data.frame"))

  job1 <- create_id_overlap.table(input, from = "1996-11-01", to = "1997-11-01", overlap = "start")

  ref1 <- structure(list(ID = c("A", "B"),
                         starting_date = structure(c(9862, 9862), class = "Date"),
                         ending_date = structure(c(9893, 9921), class = "Date")),
                    row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame"))

  expect_equal(job1, ref1)

})

test_that("Weather data check throws expected warning/error for single and multiple files", {

  #Should get warning because location is outside crater
  expect_warning(load_data_weatherstation.file(system.file("extdata/test_weather_Mlima_fail",
                                                           "weather_data_test1.xlsx",
                                                           package = "hyenaR")))
  warning_message <- tryCatch(load_data_weatherstation.file(system.file("extdata/test_weather_Mlima_fail",
                                                                        "weather_data_test1.xlsx",
                                                                        package = "hyenaR")),
                              warning = function(w){

                                return(w)

                              })
  expect_equal(warning_message$message, "Weather station location is outside the crater!")

  #Should get error because stations are in different locations to one another!!
  #Make verbose = FALSE to hide warnings already tested above
  expect_error(load_data_weatherstation.all(system.file("extdata/test_weather_Mlima_fail", package = "hyenaR"), verbose = FALSE))
  error_message <- tryCatch(load_data_weatherstation.all(system.file("extdata/test_weather_Mlima_fail",
                                                                     package = "hyenaR"),
                                                         verbose = FALSE),
                            error = function(e){

                              return(e)

                            })
  expect_equal(error_message$message, "Different weather station files are from different locations! Check file meta-data.")


})

test_that("We can get meta-data from weather stations data for single file", {

  #File with warning
  ref <- structure(list(metadata_category = c("configuration", "software",
                                              "location", "cellular", "cellular_hardware", "sensors", "errors"),
                        data = list(structure(list(info = c("device_name", "site_name",
                                                            "serial_number", "device_type", "firmware_version", "hardware_version",
                                                            "measurement_interval"),
                                                   value = c("jua", "ngoitokitok", "z6-08626",
                                                             "zl6", "2.07.3", "3", "30_minutes"),
                                                   error = c(FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -7L)),
                                    structure(list(info = "software_version", value = "1.23.7",
                                                   error = FALSE, message = NA_character_),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -1L)),
                                    structure(list(info = c("latitude", "longitude", "logger_time", "time_zone",
                                                            "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                            "altitude"),
                                                   value = c("52.5057091", "13.5214943", "11/30/21_12:00:50",
                                                             "utc+03", "12", "5", "1096", "1759.987"),
                                                   error = c(TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c("Weather station location is outside the crater!",
                                                               "Weather station location is outside the crater!", NA, NA,
                                                               NA, NA, NA, NA)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -8L)),
                                    structure(list(info = c("uploading",
                                                            "12:00-12:59_am", "1:00-1:59_am", "2:00-2:59_am", "3:00-3:59_am",
                                                            "4:00-4:59_am", "5:00-5:59_am", "6:00-6:59_am", "7:00-7:59_am",
                                                            "8:00-8:59_am", "9:00-9:59_am", "10:00-10:59_am", "11:00-11:59_am",
                                                            "12:00-12:59_pm", "1:00-1:59_pm", "2:00-2:59_pm", "3:00-3:59_pm",
                                                            "4:00-4:59_pm", "5:00-5:59_pm", "6:00-6:59_pm", "7:00-7:59_pm",
                                                            "8:00-8:59_pm", "9:00-9:59_pm", "10:00-10:59_pm", "11:00-11:59_pm",
                                                            "upload_frequency"),
                                                   value = c("false", "true", "false", "false",
                                                             "false", "true", "true", "true", "true", "true", "true", "true",
                                                             "true", "true", "true", "true", "true", "true", "true", "true",
                                                             "true", "true", "true", "true", "false", "do_not_upload_data"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df",
                                                        "tbl", "data.frame"),
                                              row.names = c(NA, -26L)),
                                    structure(list(info = c("sim_number", "modem_firmware_version", "modem_type"),
                                                   value = c("8944500502190551847", "2341", "3"),
                                                   error = c(FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -3L)),
                                    structure(list(info = c("port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version", "port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version", "port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version", "port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version", "port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version", "port_#", "name", "serial_num",
                                                            "meta", "value", "status", "version"),
                                                   value = c("1", "none_selected",
                                                             NA, "0", "0", "0", "0", "2", "none_selected", NA, "0", "0", "0",
                                                             "0", "3", "atmos_14_humidity/temp/barometer", "16422-04-709",
                                                             "0", "0", "1", "104", "4", "ecrn-100_precipitation", NA, "0",
                                                             "0", "0", "0", "5", "none_selected", NA, "0", "0", "0", "0",
                                                             "6", "none_selected", NA, "0", "0", "0", "0"),
                                                   error = c(FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -42L)),
                                    structure(list(info = c("ereset:", "ememory:", "eclock:",
                                                            "eradio:", "exfer:", "ecommand:", "ebattery:", "ctestbtn:", "emeasurement:",
                                                            "esensor[1]:", "esensor[2]:", "esensor[3]:", "esensor[4]:", "esensor[5]:",
                                                            "esensor[6]:", "esensor[7]:", "esensor[8]:", "egps:", "eble:",
                                                            "ecellinit:", "esim:", "eattachcell:", "eip:", "last_updated"),
                                                   value = c("0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "11/30/21_00:23:47"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -24L))),
                        any_error = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE,
                                      FALSE),
                        messages = list(NA_character_, NA_character_, "Weather station location is outside the crater!",
                                        NA_character_, NA_character_, NA_character_, NA_character_)),
                   row.names = c(NA, -7L), class = c("tbl_df", "tbl", "data.frame"))

  #Use file that 'fails' (i.e. has a warning) to make sure it is being passed to meta-data
  job <- create_tbl_metadata(load_data_weatherstation.file(system.file("extdata/test_weather_Mlima_fail",
                                                                       "weather_data_test1.xlsx",
                                                                       package = "hyenaR"), verbose = FALSE))

  expect_equal(job, ref)

})

test_that("We can get meta-data from weather stations data for multiple files", {

  #File without warning (otherwise it will fail!)
  ref <- structure(list(file_number = c(1L, 1L, 1L, 1L, 1L, 1L, 1L, 2L,
                                        2L, 2L, 2L, 2L, 2L, 2L),
                        metadata_category = c("configuration",
                                              "software", "location", "cellular", "cellular_hardware", "sensors",
                                              "errors", "configuration", "software", "location", "cellular",
                                              "cellular_hardware", "sensors", "errors"),
                        data = list(structure(list(info = c("device_name", "site_name", "serial_number", "device_type",
                                                            "firmware_version", "hardware_version", "measurement_interval"),
                                                   value = c("jua", "ngoitokitok", "z6-08626", "zl6", "2.07.3",
                                                             "3", "30_minutes"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -7L)),
                                    structure(list(info = "software_version",
                                                   value = "1.23.7",
                                                   error = FALSE,
                                                   message = NA_character_),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -1L)),
                                    structure(list(info = c("latitude", "longitude", "logger_time", "time_zone",
                                                            "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                            "altitude"),
                                                   value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                             "utc+03", "12", "5", "1096", "1759.987"),
                                                   error = c(FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df",
                                                        "tbl", "data.frame"),
                                              row.names = c(NA, -8L)),
                                    structure(list(info = c("uploading", "12:00-12:59_am", "1:00-1:59_am", "2:00-2:59_am",
                                                            "3:00-3:59_am", "4:00-4:59_am", "5:00-5:59_am", "6:00-6:59_am",
                                                            "7:00-7:59_am", "8:00-8:59_am", "9:00-9:59_am", "10:00-10:59_am",
                                                            "11:00-11:59_am", "12:00-12:59_pm", "1:00-1:59_pm", "2:00-2:59_pm",
                                                            "3:00-3:59_pm", "4:00-4:59_pm", "5:00-5:59_pm", "6:00-6:59_pm",
                                                            "7:00-7:59_pm", "8:00-8:59_pm", "9:00-9:59_pm", "10:00-10:59_pm",
                                                            "11:00-11:59_pm", "upload_frequency"),
                                                   value = c("false",
                                                             "true", "false", "false", "false", "true", "true", "true",
                                                             "true", "true", "true", "true", "true", "true", "true", "true",
                                                             "true", "true", "true", "true", "true", "true", "true", "true",
                                                             "false", "do_not_upload_data"),
                                                   error = c(FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -26L)),
                                    structure(list(info = c("sim_number", "modem_firmware_version",
                                                            "modem_type"),
                                                   value = c("8944500502190551847", "2341", "3"),
                                                   error = c(FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl",
                                                        "data.frame"),
                                              row.names = c(NA, -3L)),
                                    structure(list(info = c("port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version"),
                                                   value = c("1", "none_selected", NA, "0", "0", "0", "0", "2",
                                                             "none_selected", NA, "0", "0", "0", "0", "3", "atmos_14_humidity/temp/barometer",
                                                             "16422-04-709", "0", "0", "1", "104", "4", "ecrn-100_precipitation",
                                                             NA, "0", "0", "0", "0", "5", "none_selected", NA, "0", "0",
                                                             "0", "0", "6", "none_selected", NA, "0", "0", "0", "0"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df",
                                                        "tbl", "data.frame"),
                                              row.names = c(NA, -42L)),
                                    structure(list(info = c("ereset:", "ememory:", "eclock:", "eradio:", "exfer:",
                                                            "ecommand:", "ebattery:", "ctestbtn:", "emeasurement:", "esensor[1]:",
                                                            "esensor[2]:", "esensor[3]:", "esensor[4]:", "esensor[5]:",
                                                            "esensor[6]:", "esensor[7]:", "esensor[8]:", "egps:", "eble:",
                                                            "ecellinit:", "esim:", "eattachcell:", "eip:", "last_updated"),
                                                   value = c("0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "0", "0", "11/30/21_00:23:47"),
                                                   error = c(FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl",
                                                        "data.frame"),
                                              row.names = c(NA, -24L)),
                                    structure(list(info = c("device_name",
                                                            "site_name", "serial_number", "device_type", "firmware_version",
                                                            "hardware_version", "measurement_interval"),
                                                   value = c("jua",
                                                             "ngoitokitok", "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -7L)),
                                    structure(list(info = "software_version",
                                                   value = "1.23.7",
                                                   error = FALSE,
                                                   message = NA_character_),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -1L)),
                                    structure(list(info = c("latitude", "longitude", "logger_time", "time_zone",
                                                            "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                            "altitude"),
                                                   value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                             "utc+03", "12", "5", "1096", "1759.987"),
                                                   error = c(FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df",
                                                        "tbl", "data.frame"),
                                              row.names = c(NA, -8L)),
                                    structure(list(info = c("uploading", "12:00-12:59_am", "1:00-1:59_am", "2:00-2:59_am",
                                                            "3:00-3:59_am", "4:00-4:59_am", "5:00-5:59_am", "6:00-6:59_am",
                                                            "7:00-7:59_am", "8:00-8:59_am", "9:00-9:59_am", "10:00-10:59_am",
                                                            "11:00-11:59_am", "12:00-12:59_pm", "1:00-1:59_pm", "2:00-2:59_pm",
                                                            "3:00-3:59_pm", "4:00-4:59_pm", "5:00-5:59_pm", "6:00-6:59_pm",
                                                            "7:00-7:59_pm", "8:00-8:59_pm", "9:00-9:59_pm", "10:00-10:59_pm",
                                                            "11:00-11:59_pm", "upload_frequency"),
                                                   value = c("false",
                                                             "true", "false", "false", "false", "true", "true", "true",
                                                             "true", "true", "true", "true", "true", "true", "true", "true",
                                                             "true", "true", "true", "true", "true", "true", "true", "true",
                                                             "false", "do_not_upload_data"),
                                                   error = c(FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_)),
                                              class = c("tbl_df", "tbl", "data.frame"),
                                              row.names = c(NA, -26L)),
                                    structure(list(info = c("sim_number", "modem_firmware_version",
                                                            "modem_type"),
                                                   value = c("8944500502190551847", "2341", "3"),
                                                   error = c(FALSE, FALSE, FALSE),
                                                   message = c(NA_character_,
                                                               NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl",
                                                        "data.frame"), row.names = c(NA, -3L)),
                                    structure(list(info = c("port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version", "port_#",
                                                            "name", "serial_num", "meta", "value", "status", "version"),
                                                   value = c("1", "none_selected", NA, "0", "0", "0", "0", "2",
                                                             "none_selected", NA, "0", "0", "0", "0", "3", "atmos_14_humidity/temp/barometer",
                                                             "16422-04-709", "0", "0", "1", "104", "4", "ecrn-100_precipitation",
                                                             NA, "0", "0", "0", "0", "5", "none_selected", NA, "0", "0",
                                                             "0", "0", "6", "none_selected", NA, "0", "0", "0", "0"),
                                                   error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_)),
                                              class = c("tbl_df",
                                                        "tbl", "data.frame"),
                                              row.names = c(NA, -42L)),
                                    structure(list(info = c("ereset:", "ememory:", "eclock:", "eradio:", "exfer:",
                                                            "ecommand:", "ebattery:", "ctestbtn:", "emeasurement:", "esensor[1]:",
                                                            "esensor[2]:", "esensor[3]:", "esensor[4]:", "esensor[5]:",
                                                            "esensor[6]:", "esensor[7]:", "esensor[8]:", "egps:", "eble:",
                                                            "ecellinit:", "esim:", "eattachcell:", "eip:", "last_updated"),
                                                   value = c("0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                             "0", "0", "11/30/21_00:23:47"),
                                                   error = c(FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                             FALSE, FALSE, FALSE),
                                                   message = c(NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_, NA_character_, NA_character_,
                                                               NA_character_, NA_character_)),
                                              class = c("tbl_df", "tbl",
                                                        "data.frame"),
                                              row.names = c(NA, -24L))),
                        any_error = c(FALSE,
                                      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                      FALSE, FALSE, FALSE, FALSE),
                        messages = list(NA_character_, NA_character_,
                                        NA_character_, NA_character_, NA_character_, NA_character_,
                                        NA_character_, NA_character_, NA_character_, NA_character_,
                                        NA_character_, NA_character_, NA_character_, NA_character_)),
                   row.names = c(NA, -14L), class = c("tbl_df", "tbl", "data.frame"))

  job <- create_tbl_metadata(load_data_weatherstation.all(system.file("extdata/weather_Mlima",
                                                                      package = "hyenaR")))

  expect_equal(job, ref)

})


test_that("We can create weather db with create_weather_starting.table", {

  ref <- structure(list(station_name = c("jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua"),
                        site_name = c("ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok"),
                        date_time = structure(c(1633035600,
                                                1633037400, 1633039200, 1633041000, 1633042800, 1633044600, 1633046400,
                                                1633048200, 1633050000, 1633051800, 1633053600, 1633055400, 1633057200,
                                                1633059000, 1633060800, 1633062600, 1633064400, 1633066200, 1633068000,
                                                1633069800, 1633071600, 1633073400, 1633075200, 1633077000, 1633078800,
                                                1633080600, 1633082400, 1633084200, 1633086000, 1633087800, 1633089600,
                                                1633091400, 1633093200, 1633095000, 1633096800, 1633098600, 1633100400,
                                                1633102200, 1633104000, 1633105800, 1633107600, 1633109400, 1633111200,
                                                1633113000, 1633114800, 1633116600, 1633118400, 1633120200, 1633122000,
                                                1633123800, 1633125600, 1633127400, 1633129200, 1633131000, 1633132800,
                                                1633134600, 1633136400, 1633138200, 1633140000, 1633141800, 1633143600,
                                                1633145400, 1633147200, 1633149000, 1633150800, 1633152600, 1633154400,
                                                1633156200, 1633158000, 1633159800, 1633161600, 1633163400, 1633165200,
                                                1633167000, 1633168800, 1633170600, 1633172400, 1633174200, 1633176000,
                                                1633177800, 1633179600, 1633181400, 1633183200, 1633185000, 1633186800,
                                                1633188600, 1633190400, 1633192200, 1633194000, 1633195800, 1633197600,
                                                1633199400, 1633201200, 1633203000, 1633204800, 1633206600),
                                              tzone = "Africa/Dar_es_Salaam",
                                              class = c("POSIXct", "POSIXt")),
                        latitude = c(-3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856),
                        longitude = c(35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366),
                        air_temp = c(18.48, 17.86, 17.04, 16.58, 16.23, 16.01, 15.89,
                                     15.78, 15.98, 15.78, 15.45, 15.21, 15.04, 14.9, 14.91, 15.55,
                                     17.31, 18.12, 18.61, 19.22, 19.86, 20.87, 21.34, 22.12, 22.84,
                                     23.33, 23.76, 24.82, 24.94, 25.29, 25.43, 25.71, 24.88, 24.65,
                                     24.1, 23.94, 23.2, 22.17, 20.49, 18.75, 16.3, 16.31, 14.93,
                                     15.38, 15.6, 16.31, 15.58, 15.71, 15.71, 15.88, 16.64, 16.15,
                                     15.08, 15.03, 14.84, 15.17, 14.69, 13.44, 13.08, 13.23, 11.41,
                                     9.68, 10.06, 12.02, 14.63, 17.33, 18.71, 19.83, 20.79, 21.66,
                                     23.29, 24.26, 24.58, 24.81, 25.26, 25.14, 25.24, 26.16, 26.47,
                                     26.31, 25.95, 25.07, 24.66, 23.84, 22.89, 22.29, 21.21, 18.29,
                                     16.04, 15.27, 15.42, 15.6, 14.9, 13.59, 14.12, 13.36)),
                   row.names = c(NA, -96L), class = c("tbl_df", "tbl", "data.frame"))
  job <- create_weather_starting.table(from = "2021-10-01", to = "2021-10-02", variable = "temp", station = "jua")

  expect_equal(job, ref)

})

test_that("`create_weather_starting.table` deals with dates as expected", {

  #Ref here should be the same for both jobs because station and location are the same
  ref <- structure(list(station_name = c("jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua"),
                        site_name = c("ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok"),
                        date_time = structure(c(1633035600,
                                                1633037400, 1633039200, 1633041000, 1633042800, 1633044600, 1633046400,
                                                1633048200, 1633050000, 1633051800, 1633053600, 1633055400, 1633057200,
                                                1633059000, 1633060800, 1633062600, 1633064400, 1633066200, 1633068000,
                                                1633069800, 1633071600, 1633073400, 1633075200, 1633077000, 1633078800,
                                                1633080600, 1633082400, 1633084200, 1633086000, 1633087800, 1633089600,
                                                1633091400, 1633093200, 1633095000, 1633096800, 1633098600, 1633100400,
                                                1633102200, 1633104000, 1633105800, 1633107600, 1633109400, 1633111200,
                                                1633113000, 1633114800, 1633116600, 1633118400, 1633120200),
                                              tzone = "Africa/Dar_es_Salaam",
                                              class = c("POSIXct", "POSIXt")),
                        latitude = c(-3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856, -3.2094856,
                                     -3.2094856, -3.2094856, -3.2094856),
                        longitude = c(35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366,
                                      35.6006366, 35.6006366, 35.6006366, 35.6006366, 35.6006366),
                        air_temp = c(18.48, 17.86, 17.04, 16.58, 16.23, 16.01, 15.89,
                                     15.78, 15.98, 15.78, 15.45, 15.21, 15.04, 14.9, 14.91, 15.55,
                                     17.31, 18.12, 18.61, 19.22, 19.86, 20.87, 21.34, 22.12, 22.84,
                                     23.33, 23.76, 24.82, 24.94, 25.29, 25.43, 25.71, 24.88, 24.65,
                                     24.1, 23.94, 23.2, 22.17, 20.49, 18.75, 16.3, 16.31, 14.93,
                                     15.38, 15.6, 16.31, 15.58, 15.71)),
                   row.names = c(NA, -48L), class = c("tbl_df", "tbl", "data.frame"))

  #Throws warning if dates are outside period in which station was active (but still returns expected output)
  expect_warning(job1 <- create_weather_starting.table(from = "2021-09-01", to = "2021-10-01", variable = "temp", station = "jua"))

  #Same if we use location
  expect_warning(job2 <- create_weather_starting.table(from = "2021-09-01", to = "2021-10-01", variable = "temp", location = "ngoitokitok"))

  expect_equal(job1, ref)
  expect_equal(job2, ref)

})
