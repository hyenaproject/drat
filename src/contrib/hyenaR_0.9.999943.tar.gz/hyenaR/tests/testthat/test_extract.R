context("Test extract_xxx functions")

test_that("all extract functions return tibble(s)", {
  expect_equal(class(create_id_rank.table(ID = c("A-080", "A-001"), at = c("1997-01-01", "1997-01-01")))
               [1], "tbl_df")
  expect_equal(class(extract_database_row(ID = c("A-080", "A-001"))[[1]])[1], "tbl_df")
  expect_equal(class(extract_id_summary(ID = "A-011")), "list")
})


test_that("extract_id_summary works as intended", {
  ref <- list(
    hyena = structure(
      list(
        ID = "A-001",
        sex = "female",
        dna = TRUE,
        birthclan = "A",
        gen.mum = NA_character_,
        soc.mum = NA_character_,
        father = NA_character_,
        clan.last.sighting = "A"
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    dates = structure(
      list(
        ID = "A-001",
        birthdate = structure(6715, class = "Date"),
        first.sighting = structure(8919, class = "Date"),
        last.sighting = structure(10147, class = "Date"),
        deathdate = structure(NA_real_, class = "Date")
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    rank = structure(
      list(
        ID = c("A-001", "A-001", "A-001"),
        date = structure(c(6715,
                           7445, 10147), class = "Date"),
        surv.x = c(TRUE, TRUE, TRUE),
        surv.y = c(TRUE, TRUE, TRUE),
        clan = c(
          clan1 = NA,
          clan2 = NA,
          clan3 = "A"
        ),
        clantotal = c(
          clantotal1 = NA,
          clantotal2 = NA,
          clantotal3 = 57L
        ),
        clanadults = c(
          clanadults1 = NA,
          clanadults2 = NA,
          clanadults3 = 35L
        ),
        rank = c(NA, NA, 1L),
        rank_std = c(NA,
                     NA, 1),
        gender_rank = c(NA, NA, 1L),
        gender_rank_std = c(NA,
                            NA, 1),
        nat_rank = c(NA, NA, 1L),
        nat_rank_std = c(NA, NA,
                         1),
        adnat_rank = c(NA, NA, 1L),
        adnat_rank_std = c(NA, NA,
                           1),
        sel_rank = c(NA_integer_, NA_integer_, NA_integer_),
        sel_rank_std = c(NA_real_, NA_real_, NA_real_)
      ),
      row.names = c(NA,-3L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    conceptions = structure(
      list(
        ID = c("A-001",
               "A-001", "A-001", "A-001"),
        mate = c("A-045",
                 NA, NA, NA),
        date = structure(c(8919, 8919, 9301, 9732), class = "Date")
      ),
      row.names = c(NA,-4L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    offspring = structure(
      list(
        parentID = c("A-001", "A-001", "A-001", "A-001", "A-001", "A-001"),
        offspringID = c("A-010", "A-018", "A-046", "A-084", "A-088",
                        "A-089"),
        birthdate = structure(c(9029, 9029, 9029, 9411, 9842, 9842), class = "Date"),
        filiation = c(
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic"
        ),
        litterID = c(
          "A-001_001",
          "A-001_001",
          "A-001_001",
          "A-001_002",
          "A-001_003",
          "A-001_003"
        )
      ),
      row.names = c(NA,-6L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    life.history = structure(
      list(
        ID = c("A-001", "A-001", "A-001"),
        clan = c("A", "A", "A"),
        life_stage = c("cub", "subadult", "philopatric"),
        starting_date = structure(c(6715,
                                    7080, 7445), class = "Date"),
        ending_date = structure(c(7079,
                                  7444, Inf), class = "Date"),
        isrightcensored = c(FALSE, FALSE,
                            TRUE),
        isleftcensored = c(TRUE, TRUE, TRUE)
      ),
      row.names = c(NA,-3L),
      class = c("tbl_df", "tbl", "data.frame")
    ),
    sightings = structure(list(ID = c("A-001", "A-001", "A-001", "A-001", "A-001",
                                      "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001",
                                      "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001",
                                      "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001",
                                      "A-001", "A-001", "A-001", "A-001"),
                               date_time = structure(c(770590800,
                                                       803595600, 832678140, 835513440, 837839700, 837843000, 838894140,
                                                       840346260, 840834000, 842075400, 853563000, 857977740, 858582120,
                                                       860654160, 861947340, 862039320, 864829800, 864829800, 865026000,
                                                       865090500, 866754000, 866840400, 866840400, 866979000, 867013200,
                                                       867099600, 867162300, 869981820, 872574900, 876717120),
                                                     tzone = "Africa/Dar_es_Salaam", class = c("POSIXct", "POSIXt")),
                               latitude = c(NA, NA, -3.16533, -3.1525, -3.16833,
                                            -3.14017, -3.13917, -3.18033, NA, -3.15817, -3.14017, -3.14017,
                                            -3.17117, -3.13867, -3.155, -3.14933, -3.14017, -3.14017, -3.14017,
                                            -3.14233, -3.14017, -3.14017, -3.14017, -3.14017, -3.14017, -3.14017,
                                            -3.14017, -3.14033, -3.14117, -3.15217),
                               longitude = c(NA, NA,
                                             35.53633, 35.52633, 35.499, 35.50417, 35.50533, 35.50917, NA,
                                             35.51367, 35.50417, 35.50417, 35.54417, 35.5065, 35.512, 35.52067,
                                             35.50417, 35.50417, 35.50417, 35.5025, 35.50417, 35.50417, 35.50417,
                                             35.50417, 35.50417, 35.50417, 35.50417, 35.50217, 35.50233, 35.52367),
                               age = c("ad", "ad", NA, NA, NA, NA, NA, NA, "ad", NA, NA,
                                       NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
                                       NA, NA, NA),
                               sex = c("female", "female", NA, NA, NA, NA, NA,
                                       NA, "female", NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
                                       NA, NA, NA, NA, NA, NA, NA, NA, NA),
                               remarks = c("Estimated from conception",
                                           "Estimated from conception", NA, NA, NA, NA, NA, NA, "Estimated from conception",
                                           NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
                                           NA, NA, NA, NA, NA),
                               clanID = c("A", "A", "A", "A", "A", "A",
                                          "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A",
                                          "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"),
                               denstop = c(NA,
                                           NA, NA, NA, NA, "10:11", NA, NA, NA, NA, "9:05", "10:30", NA,
                                           "12:10", NA, NA, "23:59", "23:59", "9:53", NA, "23:59", "23:59",
                                           "23:59", "23:59", "23:59", "10:10", "17:53", NA, "10:06", NA),
                               prey = c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 1L, 1L,
                                        NA, 2L, NA, NA, 1L, 1L, 1L, NA, 1L, 1L, 1L, 1L, 1L, 1L, 1L,
                                        NA, 1L, NA),
                               obsstart = c(NA, NA, NA, NA, NA, NA, NA, NA,
                                            NA, NA, "7:50", "10:09", NA, "9:36", NA, NA, "17:30", "18:47",
                                            "6:15", NA, "21:30", "0:00", "1:28", "21:33", "18:41", "0:00",
                                            "17:25", NA, "8:55", NA),
                               obsstop = c(NA, NA, NA, NA, NA,
                                           NA, NA, NA, NA, NA, "9:05", "10:30", NA, "12:10", NA, NA,
                                           "18:37", "19:00", "6:43", NA, "23:59", "0:50", "1:51", "21:53",
                                           "23:59", "10:10", "17:53", NA, "10:06", NA)),
                          row.names = c(NA, -30L),
                          class = c("tbl_df", "tbl", "data.frame")),
    interactions = NULL
  )
  job <- extract_id_summary("A-001")
  expect_equal(ref, job)
})
