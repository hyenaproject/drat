#' Determine clan members in a specific clan at a specific time.
#'
#' @param date Date of clan membership in format "YYYY-MM-DD"
#' @param clan Clan in which you want to determine membership.
#' @param min_age The min_age above which clan members should be included. Default at age 0.
#'
#' @return Returns a 3 column data frame with names of all individuals in the clan at the time.
#' @export
#'
#' @examples
#'
#' # Load data (use dummy dataset)
#' load_database()
#'
#' get_clan_members(date = "1997-08-16", clan = "L", min_age = 0)
#'
get_clan_members <- function(date, clan, min_age = 0) {
  ID <- origin <- destination <- birthdate <- deathdate <- birthclan <- NULL
  currentclan <- native <- NULL

  event_date <- lubridate::ymd(date)

  hyena_data <- extract_database(tables = "hyenas") %>%
    dplyr::left_join(extract_database(tables = "deaths"), by = "ID")

  # select the selection date and clan for the last selection before the
  # event_date. Only if the clan is different
  selection_data2 <- extract_database(tables = "selections") %>%
    dplyr::filter(date <= event_date & !is.na(ID) & origin != destination) %>%
    dplyr::group_by(ID) %>%
    dplyr::slice(n()) %>%
    dplyr::select(ID, destination)

  # if not in the selections_data2, add the birthclan as current clan.
  hyena_data %>%
    dplyr::filter(birthdate <= event_date & (deathdate > event_date | is.na(deathdate))) %>%
    dplyr::select(ID, birthclan, birthdate) %>%
    dplyr::left_join(selection_data2, by = "ID") %>%
    dplyr::mutate(currentclan = ifelse(is.na(destination), birthclan, destination)) %>%
    dplyr::filter(currentclan == clan & (birthdate <= event_date - lubridate::duration(min_age, units = "years"))) %>%
    dplyr::mutate(native = currentclan == birthclan) %>%
    dplyr::select(ID, currentclan, native)
}
#################################################################################


#' Determine clan members in a specific clan at a specific time.
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' Filter the hyenas table to return all the members of a clan at a given time.
#' All internal function start with the prefix "in_". They are not designed to be
#' used directly by the users and are very specific in their behavior which make
#' sense only in the frame of the general, user-oriented function. Internal
#' functions are not exported.
#'
#' @param date Date of clan membership in format "YYYY-MM-DD"
#' @param clan Clan in which you want to determine membership.
#' @param min_age he age above which clan members should be included. Default at age 2.
#' @param hyenas hyenas table including deathdate
#' @param selections selections table
#'
#' @return a 6 columns data frame (ID, currentclan, native, destination, birthclan and date)
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#'  hyenas = hyenas, selections = selections)
#' }

in_get_clan_members <- function(date, clan, min_age = 2, hyenas, selections){

  event_date <- as.Date(date, format = "%Y-%m-%d")

  # select the selection date and clan for the last selection before the
  # event_date. Only if the clan is different
  selections2 <- selections[selections$origin != selections$destination & selections$date <= event_date & !is.na(selections$ID) , c("ID", "destination")]
  selections2 <- selections2[cumsum(tabulate(as.factor(selections2$ID))), ]
  migrants_name <- selections2$ID

  # if not in the selections_data2, add the birthclan as current clan.
  out <- hyenas[hyenas$birthdate < event_date & (hyenas$deathdate > event_date | is.na(hyenas$deathdate)), c("ID", "birthclan", "birthdate")]
  out <- dplyr::left_join(out, selections2, by = "ID")

  out$currentclan <- ifelse(is.na(out$destination), out$birthclan, out$destination)
  out$native <- out$currentclan == out$birthclan & is.na(out$destination)

  out <- out[out$currentclan == clan & (as.Date(out$birthdate, format = "%Y-%m-%d") < event_date - (min_age*365)), c("ID", "currentclan", "native", "destination", "birthclan")]
  out$date <- date
  return(out)
}
#################################################################################


#' expand the clan_members table by adding the ancestors of all clan members
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' Pull the ancestors of the hyena table to the clan members table.
#' Create as many col as the max. number of ancestor. non-limited in terms of numbers of generation.
#'
#' @param clan_members Output table from \code{\link{in_get_clan_members}}
#' @param hyenas The hyenas table
#'
#' @return a data frame of X column: clan_members table with additional column for ancestors
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A",
#'  min_age = 2, hyenas = hyenas, selections = selections)
#'
#' in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'}
in_add_ancestors <- function(clan_members, hyenas) {
  hyenas <- hyenas[,c("ID", "mothersocial")]
  d <- list(hyenas[match(clan_members$ID, hyenas$ID), "mothersocial"])
  i <- 1
  while(sum(!is.na(d[[i]]$mothersocial)) > 0) {
    i <- i + 1
    d[[i]] <- hyenas[match(d[[i-1]]$mothersocial, hyenas$ID), "mothersocial"]
  }
  d[[i]] <- NULL
  d <- as.data.frame(d)
  if(ncol(d) == 0) {
    d <- data.frame(G1 = rep(NA, nrow(clan_members)))
    xx <- dplyr::bind_cols(clan_members, d)
  } else {

    colnames(d) <- paste0("G",rep(1:(i-1)))
    xx <- dplyr::bind_cols(clan_members, d)
  }
  RM <- xx$ID[!is.na(xx$destination) & xx$birthclan == xx$destination] ## returning males
  G_columns2 <- grepl(pattern = "G", x = colnames(xx))
  xx[xx$ID %in% RM, G_columns2] <- NA
  return(xx)
}
#################################################################################


#' Pull the ancestors line of an indv. from the ancestors table
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION
#'
#' @param ancestors output of \code{\link{in_add_ancestors}}
#' @param indv focal individual
#' @param generation number of generation at which to go back
#'
#' @return a vector of character with the indv and its maternal ancestors
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#'  hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv <- ancestors$ID[2]
#'
#' in_extract_line(ancestors, indv = indv, generation = 4)
#' }

in_extract_line <- function(ancestors, indv, generation = 4){
  # print(indv)
  x <- generation + 6
  if(x > ncol(ancestors)) {
    x <- ncol(ancestors)
  }
  out <- ancestors[ancestors$ID == indv, c(1, 7:x)]

  if(length(as.vector(!is.na(out))) == 0) {
    indv
  } else {
    as.character(out[, as.vector(!is.na(out))])
  }
}
#################################################################################


#' find common ancestor between indv_A and indv_B
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' look for the first common ID between the ancestor of indv_A and indv_B. Thus finding
#' the most recent common ancestor.
#'
#' @param line_A ancestors of indv_A (output of \code{\link{in_extract_line}})
#' @param line_B ancestors of indv_B (output of \code{\link{in_extract_line}})
#'
#' @return a character string
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#'  hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' line_A <- in_extract_line(ancestors, indv = ancestors$ID[2], generation = 6)
#' line_B <- in_extract_line(ancestors, indv = ancestors$ID[3], generation = 6)
#'
#' in_find_common_ancestor(line_A, line_B)
#' }
in_find_common_ancestor <- function(line_A, line_B){
  if(any(line_A %in% line_B)) as.character(line_A[which(line_A %in% line_B)][1]) else NA
}
################################################################################


#' indv_A, indv_B, their ancestors and their relationship
#'
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' create a list with information about indv_A, indv_B and their relationship, theirs
#' common ancestor, the individual supported by the common ancestor (winner), the
#' loser, loser_line, the loser descendant and the older sisters of the loser
#' descendant.
#'
#' @param ancestors output of \code{\link{in_add_ancestors}}
#' @param hyenas hyenas table
#' @param indv_A indv A
#' @param indv_B indv B
#' @param generation numbers of generations to get back
#'
#' @return Returns a list with indv_A, indv_B, line_A, line_B, common_ancestor,
#' winner, loser, loser_line, loser_descendant, older_sister of loser_descendant
#' @examples
#' \dontrun{
#'  rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#'  hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv_A <- as.character(ancestors$ID[1])
#' indv_B <- as.character(ancestors$ID[3])
#'
#' x <- in_get_interaction_info(indv_A, indv_B, ancestors, hyenas, generation = 5)
#' }

in_get_interaction_info <- function(indv_A, indv_B, ancestors,  hyenas, generation = 6){
birthdate <- threshold <- ID <- NULL
  line_A <- in_extract_line(ancestors, indv_A, generation = generation)
  line_B <- in_extract_line(ancestors, indv_B, generation = generation)
  common_ancestor <- in_find_common_ancestor(line_A, line_B)

  if (length(common_ancestor) == 0 | is.na(common_ancestor)) {
    out <- list( indv_A = indv_A,
                 indv_B = indv_B,
                 line_A = line_A,
                 line_B = line_B,
                 common_ancestor = NA,
                 winner = NA,
                 loser  = NA,
                 loser_line  = NA,
                 loser_descendant = NA,
                 older_sister = NA)
  } else {

    out <- in_get_common_ancestor_choice(line_A, line_B, common_ancestor, hyenas)

    loser_descendant <- hyenas[hyenas$mothersocial %in% out$loser_line, ]

    out$older_sister <- hyenas[hyenas$ID %in% out$loser_line, c("mothersocial", "birthdate")] %>%
      dplyr::rename(threshold = birthdate) %>%
      dplyr::right_join(loser_descendant, by = "mothersocial") %>%
      dplyr::filter(birthdate <= threshold) %>%
      dplyr::pull(ID)
  }

  out$type_of_interaction <- paste(ancestors$native[ancestors$ID == indv_A],
                                   ancestors$native[ancestors$ID == indv_B], sep = "_") ## TRUE = native, false = migrant, first = indv_A, second = indv_B


  return(out)

}
################################################################################


#' decision for the common ancestor
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' get the individual that would have been/is supported by the common ancestor
#'
#' @param line_A ancestors of indv_A
#' @param line_B ancestors of indv_B
#' @param common_ancestor common ancestor
#' @param hyenas hyenas table
#'
#' @return a list with indv_A, indv_B, line_A, line_B, common ancestor,
#' winner, loser, loser_line
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#' hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv_A <- as.character(ancestors$ID[1])
#' indv_B <- as.character(ancestors$ID[3])
#'
#' line_A <- in_extract_line(ancestors, indv_A)
#' line_B <- in_extract_line(ancestors, indv_B)
#'
#' common_ancestor <- in_find_common_ancestor(line_A, line_B)
#'
#' in_get_common_ancestor_choice(line_A, line_B, common_ancestor, hyenas)
#' }


in_get_common_ancestor_choice <- function(line_A, line_B, common_ancestor, hyenas = hyenas){
  . <- NULL

  if (is.na(common_ancestor)) { ## born at the same time
    Winner <- NA
    Loser <- NA
    Loser_line <- NA
  } else {

    common_ancestor_offspring <- hyenas[hyenas$mothersocial %in% common_ancestor , c("ID", "birthdate")]
    indv_A <- line_A[[1]]
    indv_B <- line_B[[1]]

    A_ancestor_date <-common_ancestor_offspring[common_ancestor_offspring$ID %in% line_A, "birthdate"] %>%
      .$birthdate
    B_ancestor_date <-common_ancestor_offspring[common_ancestor_offspring$ID %in% line_B, "birthdate"] %>%
      .$birthdate

    if (indv_A %in% line_B) {
      Winner <- indv_A
      Loser <- indv_B
      Loser_line <- line_B
    } else if (indv_B %in% line_A) {
      Winner <- indv_B
      Loser <- indv_A
      Loser_line <- line_A
      #Otherwise
    } else {
      if (A_ancestor_date == B_ancestor_date) { ## born at the same time
        Winner <- NA
        Loser <- NA
        Loser_line <- NA
      } else {
        Winner <- if (A_ancestor_date > B_ancestor_date)  indv_A else indv_B
        Loser <- if (Winner == indv_A) indv_B else indv_A
        Loser_line <- if(Winner == indv_A) line_B else line_A
      }
    }
  }
  out <- list(indv_A = indv_A,
              indv_B = indv_B,
              line_A = line_A,
              line_B = line_B,
              common_ancestor = common_ancestor,
              winner = Winner,
              loser = Loser,
              loser_line = Loser_line)
  return(out)
}
################################################################################


#' get the spectators (bystanders)
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION: create a tibble with all potential supporters
#' and their relatedness (binomial, related or not-related) with both interacting
#' parties
#'
#'
#' @param ancestors  output of \code{\link{in_add_ancestors}}
#' @param interaction_info output of \code{\link{in_get_interaction_info}}
#' @param generation_b number of generation to comes back between spectactors
#' and interacting parties
#'
#' @return a tibble
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#'  hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv_A <- as.character(ancestors$ID[1])
#' indv_B <- as.character(ancestors$ID[3])
#'
#' interaction_info <- in_get_interaction_info(indv_A, indv_B,ancestors, hyenas)
#'
#' in_get_spectators(ancestors, interaction_info)
#' }

in_get_spectators <- function(ancestors, interaction_info, generation_b = 3) {

  indv_A <- interaction_info$indv_A
  indv_B <- interaction_info$indv_B

  ##### add the generations
  x <- generation_b + 6
  if(x > ncol(ancestors)) {
    x <- ncol(ancestors)
  }

  spectators <- ancestors[!(ancestors$ID %in% c(indv_A, indv_B)), 1:x]

  RM <- ancestors$ID[!is.na(ancestors$destination) & ancestors$birthclan == ancestors$destination] ## added line for the returning males

  G_columns <- grepl(pattern = "G", x = colnames(spectators))
  ancestors  <- spectators[, G_columns]
  rest <- spectators[, !G_columns]
  rest$ancestor_A <- apply(ancestors, 1, function(row) any(row %in% interaction_info$line_A))
  rest$ancestor_B <- apply(ancestors, 1, function(row) any(row %in% interaction_info$line_B))
  test_var <- 1 + (rest$ancestor_A*2) + rest$ancestor_B
  rest$type <- c("non_relatives", "B_relative", "A_relative", "both_relatives")[test_var]
  xx <- bind_cols(rest, ancestors)
  xx$type[xx$ID %in% RM] <- "non_relatives"
  G_columns2 <- grepl(pattern = "G", x = colnames(xx))
  xx[xx$ID %in% RM, G_columns2] <- NA
  return(xx)
}
################################################################################


#' find the individuals (not) following the rules
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION: find the individuals following the rules
#' in the spectators related to both interacting parties. i.e. tag the descendant
#' of the loser (according to the common ancestor choice) and the individuals
#' whose daughter of the common ancestor with the loser is older than the one of
#' the loser. In other words, all descendant of an older sister of a descendant
#' of the loser.
#'
#' @param DF subset of individuals related to both interacting parties
#' @param interaction_info output of \code{\link{in_get_interaction_info}}
#' @param hyenas  hyenas table
#'
#' @return a tibble

in_transform_both_related <- function(DF, interaction_info, hyenas) {
  do_not_follow <- ascendant_of_L <- daughter_common_LB <- descendant_of_L <- common_LB <- NULL

  G_columns <- grepl(pattern = "G", x = colnames(DF))
  test <- DF[, G_columns]
  R <- DF[, !G_columns] ## R for rest

  loser_line <- as.character(interaction_info$loser_line)
  loser <- loser_line[1]

  R$descendant_of_L <- apply(test, 1, function(row) any(loser %in% row))
  R$ascendant_of_L <- purrr::map_lgl(R$ID, ~ .x %in% loser_line)

  test$common_LB <- apply(test, 1,function(row) loser_line[loser_line %in% row][1]) ## common loser_bystander

  test2 <- dplyr::bind_cols(R[, "ID"], test)

  test2$daughter_common_LB <- apply(test2, 1, function(row) row[which(row == row[length(row)])[1] -1]) ## give the daughter of the common ancestor between spectator_loser

  test2 <- test2 %>%
    dplyr::inner_join(R, by= "ID") %>%
    dplyr::mutate(do_not_follow = !ascendant_of_L & daughter_common_LB %in% interaction_info$ID_older_sister | descendant_of_L) %>%
    dplyr::select(-common_LB, -daughter_common_LB)

  return(test2)
}
################################################################################


#' crate table of supporters
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION create a table with all potential partners,
#' their relatedness status with indv_A and indv_B, and the different rules, indicating
#' which one, each potential supporters follows if any, and which indv it supports.
#'
#' @param interaction_info output of \code{\link{in_get_interaction_info}}
#' @param ancestors output of \code{\link{in_add_ancestors}}
#' @param hyenas  hyenas table
#' @param generation_b number of generation to comes back between spectactors
#' and interacting parties
#'
#' @return a tibble
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A",
#' min_age = 2, hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv_A <- as.character(ancestors$ID[1])
#' indv_B <- as.character(ancestors$ID[3])
#'
#' interaction_info <- in_get_interaction_info(indv_A, indv_B, ancestors, hyenas)
#'
#' in_create_support_table(interaction_info, ancestors, hyenas)
#' }
in_create_support_table <- function(interaction_info, ancestors, hyenas, generation_b = 3) {
  descendant_of_L <- ascendant_of_L <- do_not_follow <- type <- NULL
  type_A_B <- native <- indv_A <- indv_B <- R1_native <- common_ancestor_choice <- NULL


  specatators <- in_get_spectators(ancestors, interaction_info, generation_b)

  ##### transform both  related
  if(is.na(interaction_info$winner)) {
    out <- specatators %>%
      dplyr::mutate(descendant_of_L = NA,
                    ascendant_of_L = NA,
                    do_not_follow = NA)

  } else {
    both_related <- specatators %>% filter(type == "both_relatives")
    rest <- specatators %>%
      dplyr::filter(type != "both_relatives") %>%
      dplyr::mutate(descendant_of_L = NA,
                    ascendant_of_L = NA,
                    do_not_follow = NA)

    if (nrow(both_related) > 0) {
      out <- in_transform_both_related(both_related, interaction_info, hyenas) %>%
        dplyr::bind_rows(rest)
    } else {
      out <- rest
    }
  }

  #### rules
  out3 <- out %>%
    dplyr::mutate(
      indv_A = as.character(interaction_info$indv_A),
      indv_B = as.character(interaction_info$indv_B),
      type_A_B = as.character(interaction_info$type),
      common_ancestor_A_B = interaction_info$common_ancestor,
      common_ancestor_choice = as.character(interaction_info$winner),
      R1_native = ifelse(type_A_B == "TRUE_FALSE" & native, as.character(indv_A), ifelse(type_A_B == "FALSE_TRUE" & native, as.character(indv_B), NA)), ### first rule ## native vs migrant
      R2_relat = ifelse(!is.na(R1_native), NA, ifelse(type == "A_relative", as.character(indv_A), ifelse(type == "B_relative", as.character(indv_B), NA))), ### second rule ## relativeness
      R3_common_ancestor = ifelse(do_not_follow, NA, as.character(common_ancestor_choice)) ### third rule ## common ancestor
    )

  return(out3)
}
################################################################################


#' summarize table
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' summarize the table created by in_create_support_table
#' to just keep the numbers of followers of each rules and the total numbers of supporter
#' for each indv
#'
#' @param table_out output of \code{\link{in_create_support_table}}
#'
#' @return a tibble

in_summarize_table <- function(table_out){
  indv_A <- indv_B <- R2_relat <- R1_native <- R3_common_ancestor <- do_not_follow <- NULL
  summary <- table_out %>% dplyr::summarize(
    indv_A = sum(R1_native == indv_A, na.rm =T) + sum(R2_relat == indv_A, na.rm = T) + sum(R3_common_ancestor == indv_A, na.rm =T),
    indv_B = sum(R1_native == indv_B, na.rm =T) + sum(R2_relat == indv_B, na.rm = T) + sum(R3_common_ancestor == indv_B, na.rm =T),
    R1 = sum(!is.na(R1_native)),
    R2 = sum(!is.na(R2_relat)),
    R3 = sum(do_not_follow == FALSE, na.rm = T),
    R4 = sum(do_not_follow == TRUE, na.rm = T))
  return(summary)
}
################################################################################


#' compute the social support for interaction
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION:
#' compute the social support for both parties in an interaction.
#'
#' @param indv_A indv A
#' @param indv_B indv B
#' @param date date of the interaction
#' @param clan clan of the interaction
#' @param min_age threshold to clan_members
#' @param hyenas hyena table
#' @param selections selection table
#' @param generation generation between indv_A and indv_B
#' @param generation_b generation between spectators and indv
#' @param table logical if TRUE return full table
#'
#' @return a tibble
#' @examples
#' \dontrun{
#' rm(list = ls())
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "1997-01-01", clan = "A", min_age = 2,
#' hyenas = hyenas, selections = selections)
#'
#' ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)
#'
#' indv_A <- as.character(ancestors$ID[1])
#' indv_B <- as.character(ancestors$ID[3])
#' date <- as.character(ancestors$date[1])
#' clan <- as.character(ancestors$currentclan[1])
#'
#' in_compute_support(indv_A, indv_B, date, clan, min_age = 1,
#' hyenas, selections, generation = 5, generation_b = 2, table = TRUE)
#'}


in_compute_support <- function(indv_A, indv_B, date, clan, min_age, hyenas, selections, generation = 6, generation_b = 3, table = FALSE){

  clan_members <- in_get_clan_members(date = date, clan = clan, min_age = min_age, hyenas = hyenas, selections = selections)
  ancestors <-  in_add_ancestors(clan_members, hyenas)
  interaction_info <- in_get_interaction_info(indv_A = indv_A, indv_B = indv_B, generation = generation, ancestors = ancestors, hyenas = hyenas)
  table2 <- in_create_support_table(interaction_info, ancestors, hyenas, generation_b = generation_b)

  if (table) {
    out <- table2
  } else {
    out <- in_summarize_table(table2)
  }
  return(out)
}
################################################################################

#' compute the social support for interctions for same clan
#'
#' SOCIAL SUPPORT INTERNAL FUNCTION
#' Same function as the compute_support just designed to speed up iterations.
#' clan_members are given as argument and thus doesn't have to be
#' recalculated several times. This function is to be used for calculating rank
#' based on social support, for which we make every individual of a clan
#' interact with each other.
#'
#' @param ancestors output of \code{\link{in_add_ancestors}}
#' @param indv_A indv A
#' @param indv_B indv B
#' @param clan_members  output of \code{\link{in_get_clan_members}}
#' @param hyenas hyena table
#' @param table logical if TRUE return full table
#' @param generation between indv_A and indv_B
#' @param generation_b between spectators and indv
#'
#' @return a tibble
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "2010-01-01", clan = "L", min_age = 2,
#' hyenas = hyenas, selections = selections)
#'
#' interactions <- in_expand_clan(clan_members)
#'
#' indv_A <- interactions$focal[6]
#' indv_B <- interactions$other[6]
#' date <- interactions$date[6]
#' clan <- interactions$clan[6]
#' min_age <- 2
#'
#' clan_members <- in_get_clan_members(clan = clan, date = date, min_age = 2,
#'  hyenas = hyenas, selections = selections)
#'
#' ancestors <-  in_add_ancestors(clan_members, hyenas)
#'
#' test <- in_compute_support_same_clan(indv_A, indv_B, clan_members,
#' hyenas, ancestors, table = FALSE, generation = 5, generation_b = 2)
#' }
#'
in_compute_support_same_clan <- function(indv_A, indv_B, clan_members, hyenas,
                                         ancestors, table = FALSE, generation = 6, generation_b = 3){

  interaction_info <- in_get_interaction_info(indv_A = indv_A, indv_B = indv_B,
                                              generation = generation, ancestors = ancestors, hyenas = hyenas)
  table2 <- in_create_support_table(interaction_info, ancestors, hyenas, generation_b)

  if (table) {
    out <- table2
  } else {
    out <- in_summarize_table(table2)
  }
  return(out)
}
################################################################################


#' compute the social support for interctions tables
#'
#' User level function to get the social support of an interaction table. This function works
#' for both interaction within only one or many clans.
#'
#' @param interaction interaction df with date, clan, focal and other column
#' @param min_age threshold to clan_members
#' @param table logical to return a full table of all supporters or not
#' @param generation between indv_A and indv_B
#' @param generation_b between spectators and indv
#'
#' @export
#' @return  a tibble with number of supporter for indv_A and indv_B and which
#'  rules have been followed. OR a tibble with all supporters and the rules they followed
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' clan_members <- in_get_clan_members(date = "2010-01-01", clan = "A", min_age = 2,
#' hyenas = hyenas, selections = selections)
#'
#' interactions <- in_expand_clan(clan_members)
#'
#' x <- calculate_support(interactions, min_age = 2, table = TRUE)
#' }


calculate_support <- function(interaction, min_age, table = TRUE, generation = 6, generation_b = 3){
  mothersocial <- NULL

  hyenas <- extract_database(tables = "hyenas") %>%
    dplyr::group_by(mothersocial) %>%
    dplyr::left_join(extract_database(tables = "deaths"), by = "ID")

  selections <- extract_database(tables = "selections")

  if(length(unique(interaction$clan)) <2 & length(unique(interaction$date)) <2 ) ## carful with the clan and not clan

  {
    clan_members <- in_get_clan_members(date = interaction$date[1], clan = interaction$clan[1], min_age = min_age, hyenas = hyenas, selections = selections)
    ancestors <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)

    out2 <- purrr::pmap_df(list(indv_A = interaction$focal, indv_B = interaction$other), in_compute_support_same_clan,
                           hyenas = hyenas, clan_members = clan_members, ancestors = ancestors, table = table, generation = generation, generation_b = generation_b)

  } else {

    out2 <- purrr::pmap_df(list(indv_A = interaction$focal, indv_B = interaction$other, date = interaction$date, clan = interaction$clan), in_compute_support,
                           hyenas = hyenas, selections = selections, min_age = min_age, generation = generation, generation_b = generation_b, table = table)
  }

  if (table == FALSE) {
    out <- dplyr::bind_cols(interaction, out2)
  } else {
    out <- out2
  }
  return(out)
}




################################################################################


#' create all possible interaction for a given clan / use internally to compute
#'
#' INTERNAL SOCIAL SUPPORT FUNCTION RANK:
#'
#' @param clan_members output of \code{\link{in_get_clan_members}}
#' @return  a tibble
#'
in_expand_clan <- function(clan_members) {
  focal <- other <- NULL
  zz <- gtools::combinations(nrow(clan_members), 2, clan_members$ID)
  tibble::tibble(focal = zz[, 1],
                 other = zz[, 2],
                 date = clan_members$date[1],
                 clan = clan_members$currentclan[1]) %>%
    dplyr::filter(focal != other)
}
################################################################################

#' compute the support for all possible interaction in a given clan at a given time
#'
#' INTERNAL SOCIAL SUPPORT FUNCTION RANK:
#' Wrapper arround the get_social_support function. It is designed to compute
#' a rank within a clan based on the social support
#'
#' @param migrant logical if migrant are included or not
#' @param clans a vector of clan
#' @param dates a vector of date
#' @param hyenas hyenas
#' @param selections selections
#' @param min_age age cutoff
#' @param generation generation between indv_A and indv_B
#' @param generation_b generation between spectators and indv
#' @param table logical to return a table or a summary
#'
#' @return a list of list of df
#' @examples
#' \dontrun{
#' rm(list = ls())
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' dates <- seq(from = as.Date("2004-01-01"), to = as.Date("2006-01-01"), by = "6 month")
#' clans <- c("A", "E", "F", "L", "M", "N", "S", "T")
#' min_age <- 2
#'
#' xx <- in_compute_support_all_interactions(clans = clans, dates = dates, min_age = 2,
#'  table = FALSE, migrant = TRUE, generation = 2, generation_b = 5, hyenas = hyenas,
#'  selections = selections)
#'
#'  }
in_compute_support_all_interactions <- function(clans, dates,
                                            hyenas = hyenas, selections = selections,
                                            min_age = 2, table = FALSE, migrant = TRUE, generation = 6, generation_b = 3){

  native <- NULL

  L_dates <- length(dates)
  out <- list()
  for(c in 1:length(clans)) {

    clan <- rep(clans[c], L_dates)

    list_M <- purrr::map2(dates, clan, in_get_clan_members, min_age = min_age, hyenas = hyenas, selections = selections)
    list_M <- purrr::map2(list_M, dates, ~  .x %>% dplyr::mutate(date = lubridate::ymd(.y)))


    if (migrant) {
      list_M <- purrr::map(list_M, ~ .x %>% dplyr::filter(native == T))
    }

    expanded_list_clan2 <- purrr::map(list_M, in_expand_clan)
    out[[c]] <- purrr::map(expanded_list_clan2, calculate_support, min_age = min_age, table = table, generation = generation, generation_b = generation_b)

  }
  return(out)
}
################################################################################


#' compute rank from interactions support table
#'
#' INTERNAL FUNCTION SOCIAL SUPPORT RANK:
#'
#' @param DF a DF created by \code{\link{in_compute_support_all_interactions}}
#'
#' @return a tibble
#' @export
in_transform_support_rank <- function(DF) {
  winner <- focal <- other <- indv_A <- indv_B <- other <- loser <- NULL
  delta_A <- delta_B <- date <- clan <- delta <- name <- wins <- total <- NULL

  DF2 <-  DF %>% mutate(winner = ifelse(indv_A > indv_B, focal, ifelse(indv_B > indv_A, other, "ties"))) %>%
    mutate(loser = ifelse(winner == focal, other, ifelse(winner == other, focal, "ties")),
           delta_A = indv_A - indv_B,
           delta_B = indv_B - indv_A)

  tttt <- bind_rows(DF2 %>% select(focal, other, winner, loser, indv_A, delta_A, date, clan) %>%
                      rename(name = focal, opponent = other, support = indv_A, delta = delta_A),
                    DF2 %>% select(other, focal, winner, loser, indv_B, delta_B, date, clan) %>%
                      rename(name = other, opponent = focal, support = indv_B, delta = delta_B)) %>%
    group_by(name) %>%
    summarise(wins = sum(winner == name, na.rm = T),
              lose = sum(loser == name, na.rm = T),
              ties = sum(winner == "ties" | loser == "ties"),
              raw_sup = sum(delta, na.rm = T),
              total = wins,
              date = date[1],
              clan = clan[1]) %>% arrange(desc(total)) %>%
    mutate(rank_sup = rank(- total, ties.method = "average"))
  return(tttt)
}
################################################################################


#'compute rank based on social support for a given date and within a given clan
#'
#' @param clans a vector of clan
#' @param dates a vector of date
#' @param min_age age at which to consider supporters
#' @param generation generation between indv_A and indv_B
#' @param generation_b generation between spectators and indv
#' @param migrant logical to include migrant or not
#'
#' @return a list of list of df the column total indicates the numbers of winning
#' interaction (the higher the better) the rank
#' @export
#' @examples
#' \dontrun{
#' rm(list = ls())
#'
#' load_database(
#' "/home/colin/Documents/hyenaR_old/hyenaR_old/source_data/Fisidata.sqlite")
#'
#' hyenas <- extract_database(tables = "hyenas") %>%
#'   group_by(mothersocial) %>%
#'   left_join(extract_database(tables = "deaths"), by = "ID")
#'
#' selections <- extract_database(tables = "selections")
#'
#' dates <- seq(from = as.Date("2004-01-01"), to = as.Date("2006-01-01"),
#' by = "6 month")
#'
#' clans <- c("A", "E", "F", "L", "M", "N", "S", "T")
#'
#' min_age <- 2
#'
#' tt <- calculate_support_rank(clans, dates, migrant = TRUE, min_age = 2,
#' generation = 6, generation_b = 5)
#' }
calculate_support_rank <- function(clans, dates, migrant = TRUE,
                             min_age = 2, generation = 6, generation_b = 3) {

  mothersocial <- NULL
  hyenas <- extract_database(tables = "hyenas") %>%
    dplyr::group_by(mothersocial) %>%
    dplyr::left_join(extract_database(tables = "deaths"), by = "ID")

  selections <- extract_database(tables = "selections")

  oo <- in_compute_support_all_interactions(clans = clans, dates = dates, hyenas = hyenas, selections = selections, table = FALSE, migrant = migrant,
                                        min_age = min_age, generation = generation, generation_b = generation_b)

  out <- list()
  for(c in 1:length(oo)){
    xx <- oo[[c]]
    out[[c]] <- map(xx, in_transform_support_rank)

  }
  return(out)

}







