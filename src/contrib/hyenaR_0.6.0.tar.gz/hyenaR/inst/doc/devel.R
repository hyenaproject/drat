## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE-------------------------------------------------------
#  if (foo) {
#    bar
#  }

## ---- eval = FALSE-------------------------------------------------------
#    attr(.database, "dummy") <- FALSE ## nb: will change below if dummy

## ---- eval = FALSE-------------------------------------------------------
#    ## store the database and its path in the hidden environment:
#    assign(x = "database", value = database, envir = .database)
#    assign(x = "db", value = db, envir = .database)

