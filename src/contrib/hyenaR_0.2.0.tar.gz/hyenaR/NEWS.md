# hyenaR 0.2.0

## New functionalities

### For users
* Add this `NEWS.md` file to track changes to the package on GitHub.
* Add a large set of functions called `fetch_xxx_yyy`, see `?fetch_family` for details.
* Add a main help page for the package (see `?hyenaR`).
* A few functions from the `tidyverse` are now re-exported (e.g. you can use pipes without having to load explicitly `dplyr`).

## For developpers only
* Add one function to test arguments (see `check_args.R`); we should do more of those.

## Minor changes
* Small polishing along the way.

