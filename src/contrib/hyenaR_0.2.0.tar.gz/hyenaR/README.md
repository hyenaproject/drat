# hyenaR

The goal of hyenaR is to provide a toolkit to work with the data of the [hyena project](https://hyena-project.com/).

## Installation

Installation from the current GitHub page is not recommended for this project.

Users should instead install the package for the [drat page](https://github.com/hyenaproject/drat) and __NOT__ from here.

Developpers should clone the repos and work in their local clone.


## Usage

See https://github.com/hyenaproject/hyenaR/wiki for some help on how to use this package.

