context("Test indv_summary function")

test_that("indv_summary works when no date is provided", {

  load_db()
  output_summary <- indv_summary(indv = "N-006")

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("indv_summary works only date provided", {

  load_db()
  output_summary <- indv_summary(start_date = "2016-01-01")

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))

  output_summary <- indv_summary(end_date = "1999-01-01")

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))

  output_summary <- indv_summary(start_date = "1999-01-01", end_date = "2000-01-01")

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("indv_summary works when no arguments are provided", {

  load_db()
  output_summary <- indv_summary()

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Reproductive information is as expected.", {

  #Test for a known female...
  load_db()
  output_summary <- indv_summary(indv = "F-066")

  hyena <- extract_db(tables = "hyenas")

  expect_equal(output_summary$RS, nrow(subset(hyena, mothergenetic == "F-066")))
  expect_true(output_summary$repro)
  expect_false(output_summary$twin)

  #Test for a known period
  output_summary <- indv_summary(start_date = "2012-01-01", end_date = "2014-12-31") %>%
    filter(name == "F-066")

  expect_equal(output_summary$RS, nrow(subset(hyena, mothergenetic == "F-066" &
                                                birthdate >= as.Date("2012-01-01", format = "%Y-%m-%d") &
                                                birthdate < as.Date("2014-12-31", format = "%Y-%m-%d"))))
  expect_true(output_summary$repro)
  expect_false(output_summary$twin)

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Survival information is as expected.", {

  #Test for a known female...
  load_db()
  output_summary <- indv_summary(indv = "F-066")

  hyena <- extract_db(tables = "hyenas")

  expect_equal(output_summary$RS, nrow(subset(hyena, mothergenetic == "F-066")))
  expect_true(output_summary$repro)
  expect_false(output_summary$twin)

  #Test for a known male...
  output_summary <- indv_summary(indv = "E-004")

  expect_equal(output_summary$RS, nrow(subset(hyena, mothergenetic == "E-004")))
  expect_true(output_summary$repro)
  expect_true(output_summary$twin)

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Dispersal information is as expected.", {

  #Test one case where dispersal has occurred...
  load_db()
  output_summary <- indv_summary(indv = "A-009")

  selections <- extract_db(tables = "selections") %>%
    filter(name == "A-009")

  expect_equal(selections$origin, output_summary$start_clan)
  expect_equal(selections$destination, output_summary$current_clan)
  expect_true(output_summary$dispersal)

  #Test the same individual before they dispersed...
  output_summary <- indv_summary(start_date = "2016-06-01", end_date = "2016-12-01") %>%
    filter(name == "A-009")

  expect_equal(output_summary$birthclan, output_summary$start_clan)
  expect_equal("F", output_summary$current_clan)
  expect_true(output_summary$dispersal)

  rm(list = c("database", "db"), envir = .GlobalEnv)

})
