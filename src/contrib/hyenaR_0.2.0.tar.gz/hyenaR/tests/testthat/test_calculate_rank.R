context("Test calculate_rank behaviour")

test_that("calculate_rank returns a tibble with data frame, tibble and named list input", {

  load_db()

  output <- calculate_rank(input = data.frame(name = "N-006", date = "2006-01-01"))

  expect_equal(class(output)[1], "tbl_df")
  expect_equal(class(output)[1], "tbl_df")
  expect_equal(class(output)[1], "tbl_df")

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Providing a matrix or vector returns an error", {

  load_db()

  input <- matrix(nrow = 2, ncol = 2, data = c("N-006", "L-020", "2005-01-01", "2006-01-01"))
  colnames(input) <- c("name", "date")

  expect_error(calculate_rank(input = z))
  expect_error(calculate_rank(input = c("N-006", "L-020", "2005-01-01", "2006-01-01")))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})


test_that("Providing a wrong name and/or date returns an error", {

  load_db()

  expect_error(calculate_rank(input = data.frame(name = "A-AAA", date = "1997-01-01")))
  expect_error(calculate_rank(input = data.frame(name = "A-001", date = "0001-01-01")))
  expect_error(calculate_rank(input = data.frame(name = "A-AAA", date = "0001-01-01")))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})
