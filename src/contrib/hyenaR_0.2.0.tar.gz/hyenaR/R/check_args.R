#' Functions checking arguments
#'
#' These functions check that the input arguments are correct, correct them if
#' possible, and throw an error otherwise.
#'
#' More functions to come...
#'
#' @note Developers should add more functions here to check more arguments.
#'
#' @param unit The unit argument for functions working with durations.
#'
#' @return The corrected arguments.
#' @export
#'
#' @examples
#' check_arg_unit(c("day", "days", "week", "weeks"))
#'
check_arg_unit <- function(unit) {
  unit %>% purrr::map_chr(~ case_when(.x == 'days' ~ 'day',
                                      .x == 'weeks' ~ 'week',
                                      .x == 'months' ~ 'month',
                                      .x == 'years' ~ 'year',
                                      TRUE ~ .x)) -> unit

  if (!all(unit %in% c('day', 'week', 'month', 'year')))
    stop("The argument(s) unit must be 'day', 'week', 'month', or 'year'!")
  unit
}
