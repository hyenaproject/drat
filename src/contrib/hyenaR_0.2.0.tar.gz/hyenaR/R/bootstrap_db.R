#' Build hyena database
#'
#' @param dbname Name of new database to create
#' @param path Location of .csv files used for building database
#'
#' @return Creates an sqlite database.
#' @export
#' @importFrom utils read.csv
#' @import purrr
#'
#' @examples
#'
#' \dontrun{
#' get_source_csvs(destfolder = "~/Downloads/CSV")
#' bootstrap_db(path = "~/Downloads/CSV")
#' }
bootstrap_db <- function(dbname = "Fisidata", path = "."){

  #Assign NULL to prevent global variables note
  hyenas <- sightings <- selections <- clans <- dens <- injuries <- rainfall <- NULL
  interactions <- observationtime <- samples <- sucklings <- videos <- weighing <- NULL
  menu <- total <- year <- Month <- Year <- NULL

  data(old_snapshots)

  #Fix the path (e.g. remove trailing "/")
  path <- normalizePath(path, mustWork = FALSE)

  #Build full path for database
  db_path <- paste(path, paste0(dbname, ".sqlite"), sep = "/")
  if (file.exists(db_path)) {
    #stop(paste("The database", db_path, "already exists. Delete the file if you want to create a new one."))
    #If the file already exists, allow the user to either: a) overwrite the file b) create a new file (with custom name based on current date).
    user_response <- menu(choices = c("Overwrite the original file", "Create a new database file"),
                          title = "A database with the same name already exists. What do you want to do?")

    #If they want to overwrite the file, delete the original and continue.
    #(Not ideal because the delete takes time, actual overwrite would be better but SQL problems)
    if(user_response == 1){

      file.remove(db_path)

    #Otherwise, create a new file that has todays date
    } else {

      #In case somebody tries to do this twice on the same day (creating another file path clash)
      #Add a version number after the date
      version_number <- 0

      #Aslong as the file path clashes, increase the version number.
      while(file.exists(db_path)){

        db_path <- paste(path, paste0(paste(dbname, Sys.Date(), version_number, sep = "_"), ".sqlite"), sep = "/")

        version_number <- version_number + 1

      }

    }

  }

  #Create SQLite db for hyenas
  db_new <- DBI::dbConnect(RSQLite::SQLite(), dbname = db_path)

  #Load all csv files
  files <- list.files(path = path, pattern = ".csv", full.names = TRUE)
  pwalk(.l = list(file_path = files), .f = function(file_path){

    file_name <- strsplit(file_path, "/")[[1]][length(strsplit(file_path, "/")[[1]])]
    file_name <- substr(file_name, start = 1, stop = nchar(file_name) - 7)

    X <- read.csv(file = file_path, header = T, sep = ",", stringsAsFactors = FALSE, na.strings = c("", " ", "NA"))

    #Remove any empty columns? Do we want to do this?
    is_empty <- function(x) !all(is.na(x))
    X <- X %>%
      select_if(is_empty) %>%
      #Trim all character columns (i.e. remove trailing/leading whitespace)
      mutate_if(.predicate = is.character, .funs = trimws) %>%
      #Make any 'clan' column uppercase
      mutate_at(vars(contains("clan"), contains("origin"), contains("destination")), toupper)

    assign(as.character(file_name), X, envir = parent.env(environment()))

  })

  #Before building the database run a number of data checks.
  #These checks are specified in check_db.R
  full_record_check(hyenas = hyenas, selections = selections, sightings = sightings)

  #Our raw rainfall data needs to be re-structured to use in the database.
  rainfall <- rainfall %>%
    #Filter any NA records
    filter(!is.na(location)) %>%
    #Remove the TOTAL column (this can be calculated easily)
    select(-total) %>%
    #Gather data so that there are columns year, month and rainfall.
    tidyr::gather(key = "Month", value = "Rainfall", -year, -location) %>%
    #Change month to be a numeric
    mutate(Month = lubridate::month(lubridate::parse_date_time(Month, orders = "b"))) %>%
    rename(Year = year, Location = location) %>%
    #Arrange chronologically
    arrange(Year, Month)

    #List tables to be added to the database
    tables_to_do <- c("hyenas", "raw_sightings", "clans", "dens", "injuries",
                      "interactions", "observationtime", "samples", "selections",
                      "sucklings", "videos", "weighing", "rainfall", "snapshots",
                      "rankchanges")

    #Fix the non-matching names between name and value
    raw_sightings <- sightings

    #Don't add these for now because I'm not sure how they inter-relate.
    #DBI::dbWriteTable(conn = db_new, name = "other_carnivores_sightings", value = carnivores, row.names = "id")
    #DBI::dbWriteTable(conn = db_new, name = "other_carnivore_demo", value = Demo_other, row.names = "id")

    #Add tables to the database
    for (table in tables_to_do) {
      if (table %in% ls() && !is.null(get(table))) {
        DBI::dbWriteTable(conn = db_new, name = table, value = get(table), row.names = "id")
      } else {
        #If the issue is with snapshots, we still create a file using the default stored with the package
        #This is necessary because we need snapshots for the python code
        if(table == "snapshots"){

          warning("You haven't provided a new snapshot file. Using an old snapshot from 1996-4-12 instead")

          DBI::dbWriteTable(conn = db_new, name = table, value = old_snapshots, row.names = "id")

        } else {

          warning(paste("The table", table, "has not been created. The CSV may be missing!"))

        }

      }
    }

  #Create adults view
  Query1 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW adults AS SELECT hyenas.name, hyenas.sex, date(birthdate, '+2 years') AS dateadult, date(MAX(sightings.date), '+1 day') AS deathdate, mothergenetic, mothersocial, DNA FROM hyenas JOIN sightings ON (hyenas.name == sightings.name) GROUP BY hyenas.name HAVING deathdate > dateadult")
  DBI::dbClearResult(Query1)

  #Full_sightings view that also contains contraception views (i.e. 110 days before the birthdate of cubs where parentage is known)
  #Seems that UNION doesn't work with SELECT *?? for now I spell out all...
  Query2 <- DBI::dbSendQuery(conn = db_new,
                             "CREATE VIEW sightings AS SELECT date(birthdate, '-110 days') AS date, NULL AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 1 AS sex, 'Estimated from conception' as remarks, father AS name, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM hyenas WHERE father <> '' UNION
                    SELECT birthdate AS date, NULL AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 2 AS sex, 'Estimated from conception' as remarks, mothergenetic AS name, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM hyenas WHERE mothergenetic <> '' UNION
                    SELECT date, time, latitude, longitude, denname, age, sex, remarks, name, name2, clanID, denstop, prey, obsstart, obsstop, sucklingID, denhole, injuryID, earR, earL, altitude, waypoint, observer FROM raw_sightings")
  DBI::dbClearResult(Query2)

  #Create deaths view
  #We now build this from the previous 'all_sightings' view because we want to account for conception date when estimating death
  #i.e. we need to consider that if an individual is known to have conceived of a cub it must have been alive!!
  Query3 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW deaths AS SELECT name, date(max(date), '+1 day') as deathdate FROM sightings GROUP BY name HAVING deathdate < date('now', '-1 years')")
  DBI::dbClearResult(Query3)

  #First litter view
  Query4 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW firstlitter AS SELECT father AS male, MIN(date(birthdate, '-110 days')) AS date_first_litter FROM hyenas WHERE father > 0 GROUP BY father")
  DBI::dbClearResult(Query4)

  DBI::dbDisconnect(db_new)

}



#' Download the source CSV files
#'
#' Bear in mind that the token
#' is hardcoded for now, so anyone with access to the package is able to
#' download the data (and more)! This will have to be changed if we distribute
#' the package. The function downloads the CSV files that contains the data from
#' a GitHub repository.
#'
#' By default the function puts the downloaded CSVs in a folder called
#' "source_data" that is created (if not existing) in your working directory.
#'
#' The authentification to GitHub is done using a Personal Access Token (PAT)
#' that would work for any private repos in hyenaproject. Besides, for the token
#' to work, it is necessary to activate the scope "repo" in GitHub, which grants
#' over rights than just reading. Perhaps there would be a better way to handle
#' that.
#'
#' @param repos Name of the GitHub repository (default:
#'   "hyenaproject/data")
#' @param destfolder Name of the folder in which the data are put into (default:
#'   "source_data")
#'
#' @return Nothing
#' @export
#'
#' @examples
#' \dontrun{
#'
#' get_source_csvs(destfolder = "~/Downloads/CSV")
#'
#' }
get_source_csvs <- function(repos = "hyenaproject/data", destfolder = "source_data") {
  repos <- gh::gh(paste0("GET /repos/", repos, "/contents"),
                  .token = "22c472e986ed852bea0dcbcb3d87fce768d3403f")
  urls  <- unlist(lapply(repos, function(file) ifelse(is.null(file$download_url), NA, file$download_url)))
  files <- unlist(lapply(repos, function(file) file$name))
  index_for_download <- grepl("*.csv", files) ## need xlsx too?
  files_to_download <- files[index_for_download]
  url_to_download   <- urls[index_for_download]
  if (!dir.exists(destfolder)) {
    dir.create(destfolder, recursive = TRUE)
  }
  if (length(url_to_download) > 0) {
    path_destination <- normalizePath(destfolder, mustWork = FALSE)
    sapply(1:length(url_to_download), function(i) {
      if (!is.na(url_to_download[i])) {
        utils::download.file(url_to_download[i],
                             destfile = paste0(path_destination, "/", files_to_download[i]))
      }
    })
    message(paste0("the downloaded files are in the folder ", normalizePath(destfolder)))
  } else {
    warning("no file to download")
  }
  return(invisible(NULL))
}
