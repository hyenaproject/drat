#' Fetch information for a vector of hyenas
#'
#' These functions allows for the extraction of individual-level information
#' that remain constant for a hyena or that varies with time. Use ```fetch```
#' when information is constant, and either ```fetch_xxx_at``` or
#' ```fetch_xxx_on``` when information varies with time. ```fetch_xxx_at```
#' provide the information at a given age and ```fetch_xxx_on``` provide them on
#' a given date. All ```fetch_xxx```, ```fetch_xxx_at``` and ```fetch_xxx_on```
#' functions have not been designed to be particularly efficient, so they should
#' not be used by an intensive procedures (e.g. simulations). Instead they have
#' been designed to be particularly robust so that they can be safely used
#' directly by users.
#'
#' These functions can be used with inputs of length 1 or using vector. They
#' produce simple tables of the format [tibble][dplyr::tibble()] containing the
#' name of the hyena(s) and the outputs of the function. Such tables can easily
#' be merged to other tables using e.g. [dplyr::full_join()] (see example).
#'
#' @param name The name of hyena(s).
#' @param focal_date The date(s) using the format "YYYY-MM-DD".
#' @param focal_age The age(s) of the hyena(s).
#' @param unit The unit for the age(s) of the hyena(s): "day", "week", "month"
#'   or "year" (default).
#' @param trim A ```logical``` indicating if additional columns needed for the
#'   computation should be dropped.
#' @name fetch_family
#' @aliases fetch_family fetch
#' @examples
#' ## Load the dummy dataset:
#' load_db()
#'
NULL


#' @describeIn fetch_family fetch the rank of a given hyena at its birth.
#' @import dplyr
#' @export
#' @examples
#' ## Birth clan of two individuals:
#' fetch_rank_at_birth(name = c("N-006", "E-004"))
#'
fetch_rank_at_birth <- function(name, trim = TRUE) {

  name_arg <- name
  name <- enquo(name)

  .GlobalEnv$database$data$hyenas %>%
    filter(name %in% !!name) %>%
    mutate(birth_date = lubridate::ymd(birthdate)) %>%
    select(birth_date) %>% pull() -> birth_date

  fetch_rank_on(name = name_arg, focal_date = birth_date, trim = trim) -> output

  birthdate <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the lifespan of a given hyena at its death.
#' @import dplyr
#' @export
#' @examples
#' ## Lifespan of two individuals:
#' fetch_lifespan(name = c("N-006", "E-004"))
#'
#' ## Add lifespan to hyena table:
#' lifespan_table <- fetch_lifespan(name = database$data$hyenas$name)
#' hyena_table <- database$data$hyenas
#' hyena_table_with_lifespan <- hyena_table %>% left_join(lifespan_table)
#' hist(hyena_table_with_lifespan$lifespan)
#'
fetch_lifespan <- function(name, unit = "year", trim = TRUE) {
  name <- enquo(name)

  .GlobalEnv$database$data$hyenas %>%
    select(name, birthdate) %>%
    filter(name %in% !!name) -> alive

  .GlobalEnv$database$data$deaths %>%
    select(name, deathdate) %>%
    filter(name %in% !!name) -> dead

  alive %>%
    left_join(dead) %>%
    mutate(birth_date = lubridate::ymd(birthdate),
           death_date = lubridate::ymd(deathdate),
           lifespan = purrr::pmap_dbl(list(birth_date, death_date, check_arg_unit(unit)),
                                      ~ lubridate::interval(..1, ..2)/lubridate::duration(1, units = ..3))) -> output

  #utils::globalVariables(c("birthdate", "birth_date", "deathdate", "death_date"), add = FALSE)

  if (trim) output %>% select(name, lifespan) -> output

  birthdate <- deathdate <- birth_date <- death_date <- lifespan <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the age of a hyena on a given day.
#'
#' Note that if the hyena is dead, the age will be ```NA```.
#' @export
#' @import dplyr
#' @examples
#' ## Age of 2 individuals at 2 dates:
#' fetch_age_on(name = c("N-006", "E-004"), focal_date = c("2004-10-04", "2005-10-04"))
#'
#' ## Age of 1 individual at 2 dates:
#' fetch_age_on(name = "N-006", focal_date = c("2004-10-04", "2005-10-04"))
#'
#' ## Age of 2 individuals at 1 date:
#' fetch_age_on(name = c("N-006", "E-004"), focal_date = "2004-10-04")
#'
fetch_age_on <- function(name, focal_date, unit = "year", trim = TRUE) {

  input <- clean_input_fetch_xxx_on(name = name, focal_date = focal_date)

  .GlobalEnv$database$data$hyenas %>%
    select(name, birthdate) %>%
    right_join(input) %>%
    left_join(.GlobalEnv$database$data$deaths) %>%
    mutate(
      birth_date = lubridate::ymd(birthdate),
      death_date = lubridate::ymd(deathdate),
      focal_age = purrr::pmap(list(birth_date, focal_date, check_arg_unit(unit)),
                              ~ lubridate::interval(..1, ..2)/lubridate::duration(1, units = ..3)))  %>%
    tidyr::unnest(focal_age) %>%
    mutate(focal_age = case_when( ## give no focal age if dead!
      focal_date < death_date ~ focal_age,
      focal_date >= death_date ~ NA_real_)) -> output
  ## Note: I cannot find a neat way to pmap so to directly obtain a vector...

  if (trim) output %>% select(name, focal_date, focal_age) -> output

  birthdate <- birth_date <- deathdate <- death_date <- focal_date <- focal_age <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the date at which a given hyena has reached
#' a given age.
#'
#' Note that if the hyena is dead, the date will be ```NA```.
#' @export
#' @import dplyr
fetch_date_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  input <- clean_input_fetch_xxx_at(name = name,
                                    focal_age = focal_age,
                                    unit = check_arg_unit(unit))

  .GlobalEnv$database$data$hyenas %>%
    select(name, birthdate) %>%
    right_join(input) %>%
    left_join(.GlobalEnv$database$data$deaths) %>%
    mutate(
      birth_date = lubridate::ymd(birthdate),
      death_date = lubridate::ymd(deathdate),
      focal_date = purrr::pmap(list(birth_date, focal_age, unit),
                               ~ as.Date(..1 + lubridate::duration(..2, units = ..3)))) %>%
    ## Note 1: I cannot find a neat way to pmap so to directly obtain a
    ## vector...
    ## Note 2: as.Date() smooths things out if there are both discrete
    ## and continuous time by rounding to the day
    tidyr::unnest(focal_date) %>% ## nb: unnest not working within mutate!
    mutate(focal_date = case_when( ## give no focal date if dead!
      focal_date < death_date ~ focal_date,
      focal_date >= death_date ~ as.Date(NA))) -> output

  if (trim) output %>% select(name, focal_age, focal_date) -> output

  birthdate <- birth_date <- deathdate <- death_date <- focal_date <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch if individuals could have been observed at on
#'   a given date.
#'
#'   The functions simply check if a given date falls between the first and the
#'   last sighting. It does not consider any other complexity, such as if
#'   someone was actually in the field at this particular date.
#' @export
#' @import dplyr
fetch_obs_on <- function(name, focal_date, trim = TRUE) {

  input <- clean_input_fetch_xxx_on(name = name, focal_date = focal_date)

  .GlobalEnv$database$data$sightings %>%
    filter(name %in% input$name) %>%
    select(name, date) %>%
    group_by(name) %>%
    summarise(firstobsdate = min(lubridate::ymd(date)),
              lastobsdate = max(lubridate::ymd(date))) %>%
    ungroup() %>%
    right_join(input) -> sightings_per_id

  sightings_per_id %>%
    mutate(obs = purrr::pmap_lgl(
      list(focal_date = input$focal_date, firstobsdate, lastobsdate), ~ between(..1, ..2, ..3))) -> output

  if (trim) output %>% select(name, focal_date, obs) -> output

  firstobsdate <- lastobsdate <- obs <- NULL ## to please R CMD check

  return(output)
}

#' @describeIn fetch_family fetch if individuals could have been  observed at at
#'   a given age.
#'
#'   The functions simply check if a given date falls between the first and the
#'   last sighting. It does not consider any other complexity, such as if
#'   someone was actually in the field at this particular date.
#' @export
#' @import dplyr
fetch_obs_at <- function(name, focal_age, unit = "year", trim = TRUE) {
  input <- fetch_date_at(name, focal_age, unit = unit, trim = trim)
  input %>%
    left_join(fetch_obs_on(name = input$name, focal_date = input$focal_date, trim = trim)) -> output

  if (trim) output %>% select(name, focal_age, obs) -> output

  return(output)
}


#' @describeIn fetch_family fetch if a given individual was alive on a given
#'   date.
#'
#'   The functions simply check if a given date falls before or after the
#'   ```deathdate``` from the ```death``` table. It does not consider any other
#'   complexity.
#' @export
#' @import dplyr
fetch_surv_on <- function(name, focal_date, trim = TRUE) {

  input <- clean_input_fetch_xxx_on(name = name, focal_date = focal_date)

  .GlobalEnv$database$data$deaths %>%
    filter(name %in% input$name) %>%
    right_join(input) %>%
    mutate(surv = deathdate > focal_date) -> output

  if (trim) output %>% select(name, focal_date, surv) -> output

  deathdate <- surv <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch if a given individual was alive at a given
#'   age.
#'
#'   The functions simply check if a given date falls before or after the
#'   ```deathdate``` from the ```death``` table. It does not consider any other
#'   complexity.
#' @export
#' @import dplyr
fetch_surv_at <- function(name, focal_age, unit = "year", trim = TRUE) {
  input <- fetch_date_at(name, focal_age, unit = unit, trim = trim)
  input %>%
    left_join(fetch_surv_on(name = input$name, focal_date = input$focal_date, trim = trim)) -> output

  if (trim) output %>% select(name, focal_age, surv) -> output

  surv <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the social rank of a given individual on a
#'   given date.
#' @export
#' @import dplyr
fetch_rank_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$rank))) output %>% mutate(rank = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, rank) -> output

  name <- focal_date <- rank <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the social rank of a given individual at a
#'   given age.
#' @export
#' @import dplyr
fetch_rank_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$rank))) output %>% mutate(rank = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, rank) -> output

  name <- focal_age <- rank <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on
#'   a given date.
#' @export
#' @import dplyr
fetch_rankstd_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$rank_std))) output %>% mutate(rank_std = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, rank_std) -> output

  name <- focal_date <- rank_std <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual at
#'   a given age.
#' @export
#' @import dplyr
fetch_rankstd_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$rank_std))) output %>% mutate(rank_std = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, rank_std) -> output

  name <- focal_age <- rank_std <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the social rank within sex of a given individual on a
#'   given date.
#' @export
#' @import dplyr
fetch_genderrank_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$gender_rank))) output %>% mutate(gender_rank = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, gender_rank) -> output

  name <- focal_date <- gender_rank <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the social rank within sex of a given individual at a
#'   given age.
#' @export
#' @import dplyr
fetch_genderrank_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$gender_rank))) output %>% mutate(gender_rank = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, gender_rank) -> output

  name <- focal_age <- gender_rank <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the standardized social rank within sex of a given
#'   individual on a given date.
#' @export
#' @import dplyr
fetch_genderrankstd_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$gender_rank_std))) output %>% mutate(gender_rank_std = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, gender_rank_std) -> output

  name <- focal_date <- gender_rank_std <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the standardized social rank within sex of a given
#'   individual at a given age.
#' @export
#' @import dplyr
fetch_genderrankstd_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$gender_rank_std))) output %>% mutate(gender_rank_std = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, gender_rank_std) -> output

  name <- focal_age <- gender_rank_std <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the clan a given individual at a given age.
#' @export
#' @import dplyr
fetch_clan_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$clan))) output %>% mutate(clan = NA_character_) -> output

  if (trim) output %>% select(name, focal_date, clan) -> output

  name <- focal_date <- clan <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the clan a given individual on a given date.
#' @export
#' @import dplyr
fetch_clan_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$clan))) output %>% mutate(clan = NA_character_) -> output

  if (trim) output %>% select(name, focal_age, clan) -> output

  name <- focal_age <- clan <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the clan size a given individual on a given
#'   date.
#' @import dplyr
#' @export
fetch_clansize_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$clantotal))) output %>% mutate(clantotal = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, clantotal) -> output

  output %>% rename(clan_size = clantotal) -> output

  name <- focal_date <- clantotal <- clan_size <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the clan size a given individual at a given
#'   age.
#' @import dplyr
#' @export
fetch_clansize_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit, trim = trim)

  if (suppressWarnings(is.null(output$clantotal))) output %>% mutate(clantotal = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, clantotal) -> output

  output %>% rename(clan_size = clantotal) -> output

  name <- focal_age <- clantotal <- clan_size  <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the number of adults in the clan of a given
#'   individual on a given date.
#' @import dplyr
#' @export
fetch_clansizeadults_on <- function(name, focal_date, trim = TRUE) {

  output <- fetch_allrankinfo_on(name = name, focal_date = focal_date)

  if (suppressWarnings(is.null(output$clanadults))) output %>% mutate(clanadults = NA_real_) -> output

  if (trim) output %>% select(name, focal_date, clanadults) -> output

  output %>% rename(clan_size_adults = clanadults) -> output

  name <- focal_date <- clanadults <- clan_size_adults <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family fetch the number of adults in the clan of a given
#'   individual at a given age.
#' @import dplyr
#' @export
fetch_clansizeadults_at <- function(name, focal_age, unit = "year", trim = TRUE) {

  output <- fetch_allrankinfo_at(name = name, focal_age = focal_age, unit = unit)

  if (suppressWarnings(is.null(output$clanadults))) output %>% mutate(clanadults = NA_real_) -> output

  if (trim) output %>% select(name, focal_age, clanadults) -> output

  output %>% rename(clan_size_adults = clanadults) -> output

  name <- focal_age <- clanadults <- clan_size_adults <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family companion function for all the ```fetch_xxx_on``` calls that
#'   are internally rely on a call to [calculate_rank()].
#'
#' This function should not be directly used by the user.
#' @import dplyr
fetch_allrankinfo_on <- function(name, focal_date) {

  input <- clean_input_fetch_xxx_on(name = name, focal_date = focal_date)

  surv <- fetch_surv_on(name = input$name, focal_date = input$focal_date)$surv

  if (nrow(input) != length(surv)) stop("Dimension problem... that should not happen, so please contact the developpers!")

  input_alive <- input[surv & !is.na(surv), ] ## drop dead individuals

  input_alive %>%
    rename(date = focal_date) -> input_alive

  message(paste("Extracting info for", nrow(input_alive), "(alive) cases..."))

  info <- tryCatch(expr = calculate_rank(input = input_alive),
                   error = function(cond) {
                     message("Some Python error(s) imply to run the extraction case-by-case (very slow)...")
                     info <- purrr::pmap(input_alive, ~ tryCatch(expr = calculate_rank(tibble(name = ..1, date = ..2)),
                                                                 error = function(cond) {
                                                                   warning(paste("Error(s) happened in the Python code:\n",
                                                                                 cond))
                                                                   return(NA)
                                                                 }))
                     return(info)
                   })

  ## the following could be prettier if calculate_rank would not convert floats
  ## into chars
  if ("list" %in% class(info)) {
    info <- info[!is.na(info)]
    if (length(info) > 0) {
      purrr::map_df(info, ~ .x %>%
                      select(-clan, -name, -date) %>%
                      mutate_if(is.character, as.numeric) %>%
                      bind_cols(.x %>% select(clan, name, date))) %>%
        right_join(input) -> output
    } else {
      input -> output
    }
  } else {
    info %>%
      select(-clan, -name, -date) %>%
      mutate_if(is.character, as.numeric) %>%
      bind_cols(info %>% select(clan, name, date)) %>%
      right_join(input) -> output
  }

  clan <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn fetch_family companion function for all the ```fetch_xxx_at``` calls
#'   that are internally rely on a call to [calculate_rank()].
#'
#' This function should not be directly used by the user.
#' @import dplyr
fetch_allrankinfo_at <- function(name, focal_age, unit = "year", trim = TRUE) {
  input <- fetch_date_at(name, focal_age, unit = unit, trim = trim)
  input %>%
    left_join(fetch_allrankinfo_on(name = input$name, focal_date = input$focal_date))
}


#' @describeIn fetch_family companion function to fetch clean the input of the
#'   fetch_xxx_on functions and reformat it as a [tibble][dplyr::tibble()].
#'
#' This function should not be directly used by the user.
#' @import dplyr
clean_input_fetch_xxx_on <- function(name, focal_date) {
  if (!class(focal_date) == "Date") focal_date <- lubridate::ymd(focal_date)
  tibble(name = name, focal_date = focal_date)[!is.na(name), ]
}


#' @describeIn fetch_family companion function to fetch clean the input of the
#'   fetch_xxx_at functions and reformat it as a [tibble][dplyr::tibble()].
#'
#' This function should not be directly used by the user.
#' @import dplyr
clean_input_fetch_xxx_at <- function(name, focal_age, unit) {
  tibble(name = name, focal_age = focal_age, unit = check_arg_unit(unit))[!is.na(name), ]
}
