#' Welcome to the R package hyenaR
#'
#' The goal of this package is to ease the manipulation of the data of the Ngorongoro hyena
#' project (https://hyena-project.com/). See https://github.com/hyenaproject/hyenaR/wiki for a
#' short introduction on how to use this package. The wiki is hosted in a private GitHub
#' repository so if you do not have access to it, please contact alexandre.courtiol@gmail.com
#'
#' @name hyenaR-package
#' @aliases hyenaR-package hyenaR
#' @docType package
#'
#' @keywords package
#' @examples
#' # Examples will come
NULL
