# rm(list = ls())
# library(gridExtra)
# library(profvis)
# library(microbenchmark)
# library(bench)
# library(data.table)
# library(hyenaR)
# library(dplyr)
# library(purrr)
# library(gtools)
# load_db(db = "/home/colin/Downloads/Fisidata_03_12_18_BOOTSTRAP_DATABASE.sqlite")
#
#
#  hyenas_DF <- database$data$hyenas %>%
#    group_by(mothersocial) %>%
#    left_join(.GlobalEnv$database$data$deaths, by = "name")
#  sel_DF <- .GlobalEnv$database$data$selections
#  dates <- seq(from = as.Date("2018-01-01"), to = as.Date("2018-01-01"), by = "1 year")
#  clans <- c("A")
#
# out <- list()
#
# for(i in 1:1){
# system.time(xx <- get_social_support_clan_all_interactions(clans = clans, dates = dates, age = 2, table = FALSE, migrant = TRUE, generation = i, generation_b = 5,
# hyenas_DF = hyenas_DF, sel_DF = sel_DF))
#
#
#  xx2 <- map(xx, ~ bind_rows(.x))
#  xx_full <- bind_rows(xx2) %>%
#  mutate(winner = ifelse(indv_A > indv_B, focal, ifelse(indv_B > indv_A, other, "ties"))) %>%
#      mutate(loser = ifelse(winner == focal, other, ifelse(winner == other, focal, "ties")),
#             delta_A = indv_A - indv_B,
#             delta_B = indv_B - indv_A)
#
#  tttt <- bind_rows(xx_full %>% select(date, clan, focal, other, winner, loser, indv_A, delta_A) %>%
#                     rename(name = focal, opponent = other, support = indv_A, delta = delta_A),
#                   xx_full %>% select(date, clan, other, focal, winner, loser, indv_B, delta_B) %>%
#                     rename(name = other, opponent = focal, support = indv_B, delta = delta_B)) %>%
#   group_by(name, date, clan) %>%
#   summarise(wins = sum(winner == name, na.rm = T),
#             lose = sum(loser == name, na.rm = T),
#             ties = sum(winner == "ties" | loser == "ties"),
#             raw_sup = sum(delta, na.rm = T),
#             total = wins) %>% arrange(desc(total)) %>%
#    ungroup() %>%
#    group_by(date, clan) %>%
#   mutate(rank_sup = rank(total, ties.method = "average")) %>%
#    ungroup()
#
#
#  #
#  real_rank <- tttt %>%
#    select(name, date) %>%
#    calculate_rank() %>%
#    select(name, rank_std, rank, date) %>%
#    arrange(rank)
#
# pl <- inner_join(real_rank, tttt) %>%
#   mutate(sex = map_int(name, ~ ifelse(.x %in% hyenas_DF$name, hyenas_DF$sex[hyenas_DF$name == .x], NA)))
#
# cor <- pl %>% group_by(clan, date) %>%
#   summarize(cor = cor(as.numeric(rank_std), rank_sup, method = "spearman"))
# cor$n <- i
# out[[i]] <- inner_join(pl, cor) %>%
#   mutate(cor = as.character(round(cor, 2)))
# }
#
# tt <- out[1]
# #########################
# map(out, ~ ggplot(.x, aes(y =  as.numeric(rank_sup), x = as.numeric(rank_std))) +
#       geom_point(aes(col = sex)) +
#       guides(col = FALSE) +
#       geom_text(aes(x = 1, y = 0, label = cor), check_overlap = T) +
#       facet_grid(clan ~ date , scale = "free"))
#
# out_3 <- map_df(out, ~ .x %>%
#          group_by(clan, date, n) %>%
#   summarize(cor = cor[1]))
#
# out_3 %>% ungroup() %>% group_by(n) %>% summarise(mean = mean(as.numeric(cor), na.rm = T))
#
# ggplot(pl, aes(y =  as.numeric(rank_sup), x = as.numeric(rank_std))) +
#   geom_point(aes(col = sex)) +
#   guides(col = FALSE) +
#   geom_text(aes(x = 1, y = 0, label = cor), check_overlap = T) +
#   facet_grid(clan ~ date , scale = "free")
#
#
#
# mean(cor$cor)^2
