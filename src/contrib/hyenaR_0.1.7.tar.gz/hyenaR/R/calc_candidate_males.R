#' Determine all candidate males for a female
#'
#' Extract candidate males (adult males in the clan)
#' on a given date.
#'
#' @param female Focal female
#' @param focal_date Date at which to estimate candidate males (YYYY-MM-DD)
#'
#' @return A tibble with male names and age
#' @export
#'
#' @examples
#'
#' #Load dummy data
#' load_db()
#'
#' #Estimate males
#' calc_candidate_males("N-006", focal_date = "2006-01-01")
#'

calc_candidate_males <- function(female, focal_date){

  birthdate <- deathdate <- name <- destination <- sex <- . <- name <- current_clan <- age <- adult <- NULL

  format <- "%Y-%m-%d"

  hyenas     <- .GlobalEnv$database$data$hyenas %>%
    mutate(birthdate = as.Date(birthdate, format = format))
  selections <- .GlobalEnv$database$data$selections %>%
    mutate(date = as.Date(date, format = format))
  deaths     <- .GlobalEnv$database$data$deaths %>%
    mutate(deathdate = as.Date(deathdate, format = format))
  focal_date <- as.Date(focal_date, format = format)

  #Check the female was alive on this date!
  if(hyenas[["birthdate"]][which(hyenas$name == female)] > focal_date | deaths[["deathdate"]][which(deaths$name == female)] <= focal_date){

    stop(paste0("The focal female was not alive on ", focal_date))

  }

  #Firstly, we determine the clan of the female.
  #Check that she never moved (rare but it happens!)
  if(!female %in% selections$name){

    fem_clan <- hyenas[["birthclan"]][which(hyenas$name == female)]

  } else {

    fem_clan <- selections[["destination"]][which(selections$name == female & date < focal_date)]

  }

  #Check that the female isn't somewhere outside of the main clans
  if(!fem_clan %in% c("A", "E", "F", "L", "M", "N", "S", "T")){

    stop("The focal female was outside one of the main clans on this date")

  }

  #Determine dispersals of all individuals before the focal date (to determine current clan)
  disp_clan <- selections %>%
    filter(date < focal_date) %>%
    group_by(name) %>%
    slice(n()) %>%
    summarise(current_clan = destination)

  #Determine the current clan of all MALES (we don't care about females now)
  clan_summary <- hyenas %>%
    left_join(deaths, by = "name") %>%
    filter(sex == 1 &
             birthdate < focal_date &
             (is.na(deathdate) | deathdate > focal_date)) %>%
    #Determine the current clan of each individual
    mutate(current_clan = pmap_chr(.l = list(focal = .$name,
                                             birthclan = .$birthclan),
                                   .f = function(focal, birthclan, disp_clan){

                                     if(focal %in% disp_clan$name){

                                       return(filter(disp_clan, name == focal) %>%
                                                pull(current_clan))

                                     } else {

                                       return(birthclan)

                                     }

                                   }, disp_clan = disp_clan)) %>%
    #Filter only those individuals in the females clan
    filter(current_clan == fem_clan) %>%
    #Calculate age of all individuals
    mutate(age = pmap_dbl(.l = list(birthdate = .$birthdate,
                                    deathdate = .$deathdate),
                          .f = calc_age, age_units = "months", end_date = focal_date),
           adult = age >= 24) %>%
    #Let's just exclude non-adult males
    filter(adult)

  return(clan_summary[, c("name", "age")])

}
