#' Load all database tables for use in functions.
#'
#' This is different to extract_db, which can still be used for extracting single tables (is being depracated).
#'
#' @param db Location of database. If unspecified, will use dummy database file for examples.
#' @param unpack Logical. Should the database be loaded as a single (tibble) object or multiple data frames?
#' N.B. For running functions, unpack must equal TRUE
#' (i.e. there must be an object in the global environment called 'database').
#'
#' @return A tibble of tables and table names in the global environment
#' @export
#'
#' @examples
#' load_db()

load_db <- function(db = NULL, unpack = FALSE){

  if(is.null(db)){

    message("No database path specified. Using the dummy dataset!")

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  all_data <- extract_db(db = db)

  #If the use wants the function to be unpacked, use list2env to output all tables as individual objects
  if(unpack){

    list2env(all_data, envir = .GlobalEnv)

    invisible(NULL)

  } else {

    database <- tibble(table_name = names(all_data),
                                  data = all_data
                                  # ,last_date = pmap_dfr(.l = list(output_tibble$data),
                                  #                      .f = function(table){
                                  #
                                  #                        table %>%
                                  #                          mutate_at(vars(contains("date")), lubridate::ymd) %>%
                                  #                          summarise_at(vars(contains("date")), max)
                                  #
                                  #                      })
    )

    assign(x = "database", value = database, envir = .GlobalEnv)
    assign(x = "db", value = db, envir = .GlobalEnv)

  }

}
