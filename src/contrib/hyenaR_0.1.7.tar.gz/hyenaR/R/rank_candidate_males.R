
#' Determine all candidate males for a birth
#'
#' Extract candidate males (sexually active males in the clan) and compute
#' theirs ranks.
#'
#' @param cub_ID ID of the cub
#' @return A tibble with male names rank and other info about the cub
#' @export
#' @import lubridate
#' @import dpylr

get_candidate_males_rank <- function(cub_ID){

  ###########
  # load data

  hyenas  <- .GlobalEnv$database$data$hyenas %>%
    mutate(birthdate = ymd(birthdate))

  selections <- .GlobalEnv$database$data$selections %>%
    mutate(date = ymd(date))

  deaths <- .GlobalEnv$database$data$deaths %>%
    mutate(deathdate = ymd(deathdate))

  #######################################
  # retrieve cub´s information from hyenas

  ID_info <- hyenas[hyenas$name == cub_ID, ]

  mother_genetic <- female <- ID_info$mothergenetic
  father <- ID_info$father
  sex <- ifelse(ID_info$sex == 1, "male", "female")
  focal_date <- ID_info$birthdate - days(110)
  birth_date <- ID_info$birthdate
  clan <- fem_clan <- ID_info$birthclan
  date_range <- c(focal_date - days(90), focal_date + days(90))

  #############
  #get mom rank

  mom_input <- data.frame(name = mother_genetic,
                          date = focal_date)

  mom_rank <- calculate_rank(mom_input)[,c("gender_rank", "gender_rank_std")]


  ##########################
  # retrieve candidate males

  disp_clan3 <- retrieve_candidate_males(cub_ID, hyenas, selections, deaths)


  #########################################
  #change date for the deaths or dispersers

  input <- disp_clan3 %>%
    mutate(date = ymd(ifelse(deathdate <= focal_date & !is.na(deathdate), as.character(deathdate - days(1)),
                             ifelse(out_date <= focal_date, as.character(out_date - days(1)),
                                    ifelse(date >= focal_date , as.character(date + days(1)), as.character(focal_date)))))) %>%
    select(name, date)


  ##################
  # compute the rank

  rank <- calculate_rank(input = input)[,c("name", "sel_rank", "sel_rank_std", "date")] %>%
    rename(candidate_date_rank = date)

  ##################
  # merge everything

  disp_clan4 <- left_join(disp_clan3, rank, by = "name") %>%
    select(name, sel_rank, sel_rank_std, candidate_date_rank) %>%
    mutate(cub_ID = cub_ID,
           cub_mother_genetic = mother_genetic,
           cub_father = father,
           cub_conception_date = focal_date,
           cub_birth_date = birth_date,
           cub_sex = sex,
           mom_gender_rank = as.numeric(mom_rank[1,"gender_rank"]),
           mom_gender_rank_std = as.numeric(mom_rank[1, "gender_rank_std"])) %>%
    rename(candidate_male = name,
           candidate_sel_rank = sel_rank,
           candidate_sel_rank_std = sel_rank_std)
  return(disp_clan4)
}


################################################################################

#' return all candidate males for a given cub (used internally)
#'
#' Extract candidate males (sexually active males in the clan) and compute.
#' @name retrieve_candidate_males
#' @param cub_ID ID of the cub
#' @param hyenas hyenas table from the database
#' @param selections selections table from the database
#' @param deaths deaths table from the database
#' @return A tibble with hyenas info about the candidate males
#' @import lubridate
#' @import dpylr



retrieve_candidate_males <- function(cub_ID, hyenas, selections, deaths){
  #######################################
  # retrieve cub´s information from hyenas

  ID_info <- hyenas[hyenas$name == cub_ID, ]
  mother_genetic <- female <- ID_info$mothergenetic
  focal_date <- ID_info$birthdate - days(110)
  clan <- fem_clan <- ID_info$birthclan
  date_range <- c(focal_date - days(90), focal_date + days(90))


  ##############################################################################
  # get males that have been in the clan at least once befor the conception + 90

  chose_clan <- selections %>%
    filter(destination == fem_clan) %>% ## keep the one that have been in the clan at least once
    filter(date <= date_range[2]) %>% pull(name)

  been_in_clan <- selections %>% filter(name %in% chose_clan) %>% group_by(name) %>%
    mutate(out_date = lead(date, default = today())) %>% ungroup() %>%
    filter(destination == fem_clan)

  been_in_clan2 <- been_in_clan %>%
    filter(date <= date_range[2] & out_date > date_range[1])


  ####################################################
  # join the information about birthdate and deathdate

  disp_clan2 <- left_join(been_in_clan2, hyenas, by= "name") %>%
    left_join(deaths, by = "name")

  disp_clan3 <- disp_clan2 %>% filter(is.na(deathconfirmed) | ymd(deathconfirmed) > focal_date) %>%
    filter(is.na(deathdate) | ymd(deathdate) > date_range[1])

  return(disp_clan3)

}


################################################################################

#' return all candidate males for a list of cubs
#'
#' Extract candidate males (sexually active males in the clan) and put them in a
#' dataframe.
#'
#' @name get_candidate_males_horizontal
#' @param cub_ID_df a dataframe with 1 col (name)
#' @return A tibble with hyenas info about the candidate males
#' @import lubridate
#' @import dpylr
#' @import purrr
#' @export

get_candidate_males_horizontal <- function(cub_ID_df){

  hyenas  <- .GlobalEnv$database$data$hyenas %>%
    mutate(birthdate = ymd(birthdate))

  selections <- .GlobalEnv$database$data$selections %>%
    mutate(date = ymd(date))

  deaths <- .GlobalEnv$database$data$deaths %>%
    mutate(deathdate = ymd(deathdate))


  x <- map(cub_ID_df$name, ~ retrieve_candidate_males(cub_ID = .x, hyenas = hyenas,
                            selections = selections, deaths = deaths)[,"name"])

  ncol <- max(map_dbl(x, ~ length(.x[[1]])))

  out <- as.data.frame(matrix(NA, nrow = nrow(cub_ID_df), ncol = ncol))
  colnames(out) <- c(paste0("ID", 1:ncol))

  for(i in 1:nrow(cub_ID_df)){
    for(j in 1:ncol(out)){
      out[i, j ] <- x[[i]][[1]][j]
    }
  }
  row <- out[1, ]
  out$n_candidate <- apply(out, 1, function(row) sum(!is.na(row)))
  out$n_typed_candidate <- apply(out, 1, function(row) sum(hyenas$DNA[hyenas$name %in% row] == "yes"))
  out$proportion_typed <- out$n_typed_candidate / out$n_candidate
  out$cub_name <- cub_ID_df$name


  ### get additional information about the cub

  infos <- hyenas %>%
    filter(name %in% out$cub_name) %>%
    select(mothergenetic, sex, birthdate, name) %>%
    mutate(sex = ifelse(sex == 1, "M", ifelse(sex == 2, "F", NA)))

  out2 <- out %>% left_join(infos, by = c("cub_name" = "name")) %>%
    select(cub_name, mothergenetic, sex, birthdate, n_typed_candidate, n_candidate, proportion_typed, everything())

  return(out2)
  }
