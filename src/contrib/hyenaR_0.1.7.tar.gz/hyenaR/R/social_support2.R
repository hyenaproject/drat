#'get the clan members at a given date and clan
#'@param date, a date in "character string"
#'@param clan a clan name
#'@param age age limit to exclude individuals
#'@param hyenas_DF hyena DF from the database including deathdate
#'@param sel_DF selection DF from the database
#'@export
#'@import dplyr
#'@examples
#'library(dplyr)
#'#Load data (use dummy dataset)
#'load_db()
#'hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' get_clan_members2(date = "2017-08-16", clan = "F", age = 1, hyenas_DF = hyena_data, sel_DF = sel)

get_clan_members2 <- function(date, clan, age = 1, hyenas_DF, sel_DF){

event_date <- as.Date(date, format = "%Y-%m-%d")

# select the selection date and clan for the last selection before the
# event_date. Only if the clan is different
selection_data2 <- sel_DF[sel_DF$origin != sel_DF$destination & sel_DF$date <= event_date & !is.na(sel_DF$name) , c("name", "destination")]
selection_data2 <- selection_data2[cumsum(tabulate(as.factor(selection_data2$name))), ]
migrants_name <- selection_data2$name

# if not in the selections_data2, add the birthclan as current clan.
out <- hyenas_DF[hyenas_DF$birthdate < event_date & (hyenas_DF$deathdate > event_date | is.na(hyenas_DF$deathdate)), c("name", "birthclan", "birthdate")]
out <- left_join(out, selection_data2, by = "name")

out$currentclan <- ifelse(is.na(out$destination), out$birthclan, out$destination)
out$native <- out$currentclan == out$birthclan & is.na(out$destination)

out[out$currentclan == clan & (as.Date(out$birthdate, format = "%Y-%m-%d") < event_date - (age*365)), c("name", "currentclan", "native", "destination", "birthclan")]

}

################################################################################
#' Determine the ancestry of all individuals in a clan at a given time, non-limited in terms of numbers of generation
#' @param clan_members Clan members at a give time. Output from \code{\link{get_clan_members}}
#' @param hyenas_DF hyenas_DF from the database.
#' @return Returns a tibble with the maternal ancestry of every individual
#' @export
#' @import dplyr
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' clan_members <- get_clan_members2(date = "2017-08-16", clan = "F", age = 1,
#' hyenas_DF = hyena_data, sel_DF = sel)
#' get_ancestry3(clan_members = clan_members, hyenas_DF = hyena_data)

get_ancestry3 <- function(clan_members, hyenas_DF) {
  hyenas <- hyenas_DF[,c("name", "mothersocial")]
  d <- list(hyenas[match(clan_members$name, hyenas$name), "mothersocial"])
  i <- 1
  while(sum(!is.na(d[[i]]$mothersocial)) > 0) {
    i <- i + 1
    d[[i]] <- hyenas[match(d[[i-1]]$mothersocial, hyenas$name), "mothersocial"]
  }
  d[[i]] <- NULL

  d <- as.data.frame(d)
  colnames(d) <- paste0("G",rep(1:(i-1)))
  xx <- dplyr::bind_cols(clan_members, d)

  RM <- xx$name[!is.na(xx$destination) & xx$birthclan == xx$destination]
  G_columns2 <- grepl(pattern = "G", x = colnames(xx))
  xx[xx$name %in% RM, G_columns2] <- NA
  return(xx)
}



################################################################################
#' extract the lines of indv // used internally in get_ancestor_A_B_C
#' @param ancestry_df the output of get_ancestry2 or get_ancestry3
#' @param indv focal individual
#' @return Returns a tibble with the maternal ancestry of every individual
#' @export
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' clan_members <- get_clan_members2(date = "2017-08-16", clan = "F",
#' age = 1, hyenas_DF = hyena_data, sel_DF = sel)
#' ancestry_DF <- get_ancestry3(clan_members = clan_members, hyenas_DF = hyena_data)
#' extract_line(ancestry_DF, indv = ancestry_DF$name[2])

extract_line <- function(ancestry_df, indv){
  out <- ancestry_df[ancestry_df$name == indv, c(1, 6:ncol(ancestry_df))]
  out[, as.vector(!is.na(out))]
    # dplyr::select_if(out, .predicate =  ~ !is.na(.))
}

################################################################################
#' extract information about A B C ancestors // used internally in get_ancestor_A_B_C
#' @param C_ancestor common_ancestor
#' @param A_ancestor ancestor_line of A
#' @param B_ancestor ancestor_line of B
#' @param hyenas_DF hyena data table
#' @return Returns a tibble with the maternal ancestry of every individual
#' @import dplyr
#'
get_common_ancestor_offspring_and_date <- function(A_ancestor, B_ancestor, C_ancestor, hyenas_DF) {

  #Prevent global binding NOTE in checks
  . <- NULL

  if (is.na(C_ancestor)){
    common_ancestor_offspring <- NA
    A_ancestor_date <- NA
    B_ancestor_date <- NA

  } else {

    common_ancestor_offspring <- hyenas_DF[hyenas_DF$mothersocial %in% C_ancestor , c("name", "birthdate")]

    A_ancestor_date <-common_ancestor_offspring[common_ancestor_offspring$name %in% A_ancestor, "birthdate"] %>%
      .$birthdate

    B_ancestor_date <-common_ancestor_offspring[common_ancestor_offspring$name %in% B_ancestor, "birthdate"] %>%
      .$birthdate
  }
  return(list(common_ancestor_offspring = common_ancestor_offspring,
              A_ancestor_date = A_ancestor_date,
              B_ancestor_date = B_ancestor_date))
}


################################################################################
#' pack all information about A B C into a list
#' @param ancestry_DF ancestry DF
#' @param hyenas_DF hyenas DF
#' @param indv_A indv A
#' @param indv_B indv B
#' @return Returns a list with information about common ancestors and co.
#' @export
#' @import dplyr
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' clan_members <- get_clan_members2(date = "2017-08-16", clan = "F", age = 1,
#' hyenas_DF = hyena_data, sel_DF = sel)
#' ancestry_DF <- get_ancestry3(clan_members = clan_members, hyenas_DF = hyena_data)
#' indv_A <- ancestry_DF$name[10]
#' indv_B <- ancestry_DF$name[15]
#' get_ancestors_A_B_C(ancestry_DF, indv_A, indv_B, hyenas_DF = hyena_data)

get_ancestors_A_B_C <- function(ancestry_DF, indv_A, indv_B, hyenas_DF){
  A_ancestors <- extract_line(ancestry_DF, indv_A)
  B_ancestors <- extract_line(ancestry_DF, indv_B)

  common_ancestor <- if(any(A_ancestors %in% B_ancestors)) as.character(A_ancestors[which(A_ancestors %in% B_ancestors)][1]) else NA

  #### additional chunk to remove the cases when the common ancestor not in clan is anymore

  # common_ancestor_N <- if(common_ancestor %in% ancestry_DF$name) as.character(common_ancestor) else NA
  # common_ancestor_death_date <- hyena_data$deathdate[hyena_data$name == common_ancestor]
  # if (is.na(common_ancestor_N) & !(is.na(common_ancestor))) {
  #   A_i <- which(as.character(A_ancestors[1, ]) == common_ancestor)
  #   B_i <- which(as.character(B_ancestors[1, ]) == common_ancestor)
  #   A_ancestors <- A_ancestors[1, 1:(A_i -1)]
  #   B_ancestors <- B_ancestors[1, 1:(B_i -1)]
  #   common_ancestor <- NA
  # }

  ## chunk to get at least one that knows the common ancestor in clan.
  ## get the deathdate of the commonancestor
  # if (is.na(common_ancestor_N) & !(is.na(common_ancestor))) {
  #
  # A_ancestors_in_clan <- A_ancestors[1, as.character(A_ancestors[1,]) %in% ancestry_DF$name]
  # B_ancestors_in_clan <- B_ancestors[1, as.character(B_ancestors[1,]) %in% ancestry_DF$name]
  #
  # birth_A <- any(na.omit(hyena_data$birthdate[hyena_data$name %in% as.character(A_ancestors_in_clan[1, ])]) < common_ancestor_death_date)
  # birth_B <- any(na.omit(hyena_data$birthdate[hyena_data$name %in% as.character(B_ancestors_in_clan[1, ])]) < common_ancestor_death_date)
  #
  # if ((!birth_A & !birth_B) | is.na(common_ancestor_death_date)) {
  #   A_i <- which(as.character(A_ancestors[1, ]) == common_ancestor)
  #   B_i <- which(as.character(B_ancestors[1, ]) == common_ancestor)
  #   A_ancestors <- A_ancestors[1, 1:(A_i -1)]
  #   B_ancestors <- B_ancestors[1, 1:(B_i -1)]
  #   common_ancestor <- NA
  # }
  # }

  offsprings <- get_common_ancestor_offspring_and_date(A_ancestors, B_ancestors, common_ancestor, hyenas_DF)

  return(list(common_ancestor = common_ancestor,
              A_ancestors = A_ancestors,
              B_ancestors = B_ancestors,
              common_ancestor_offspring = offsprings$common_ancestor_offspring,
              A_ancestor_date = offsprings$A_ancestor_date,
              B_ancestor_date = offsprings$B_ancestor_date))
}



################################################################################
#' decision rule for the common ancestor
#' @param ancestors_list outcome of the function
#' @param indv_A indv A
#' @param indv_B indv B
#' @return the individual that is supported by the common ancestor.
#' @export
#' @import dplyr
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' clan_members <- get_clan_members2(date = "2017-08-16", clan = "F", age = 1,
#' hyenas_DF = hyena_data, sel_DF = sel)
#' ancestry_DF <- get_ancestry3(clan_members = clan_members, hyenas_DF = hyena_data)
#' indv_A <- ancestry_DF$name[1]
#' indv_B <- ancestry_DF$name[2]
#' ancestors_list <-  get_ancestors_A_B_C(ancestry_DF, indv_A, indv_B, hyenas_DF = hyena_data)
#' relative_fight_outcome2(indv_A, indv_B, ancestors_list = ancestors_list)


relative_fight_outcome2 <- function(indv_A, indv_B, ancestors_list){
  if (length(ancestors_list$common_ancestor) == 0 | is.na(ancestors_list$common_ancestor)){
    Winner <- NA
  } else if (indv_A %in% ancestors_list$B_ancestors) {
    Winner <- indv_A
  } else if (indv_B %in% ancestors_list$A_ancestors) {
    Winner <- indv_B
    #Otherwise
  } else {
    if (ancestors_list$A_ancestor_date == ancestors_list$B_ancestor_date) { ## born at the same time
      Winner <- NA
    } else {
      Winner <- if (ancestors_list$A_ancestor_date > ancestors_list$B_ancestor_date)  indv_A else indv_B
    }
  }
  return(Winner)
}



################################################################################
#' get the spectators
#' @param ancestry_DF Loser ancestry line
#' @param indv_A indv A
#' @param indv_B indv B
#' @param ancestors_list list of info about ancestors
#' @return somethin
#' @export
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#'
#' clan_members <- get_clan_members2(date = "2017-08-16", clan = "F", age = 1,
#' hyenas_DF = hyena_data, sel_DF = sel)
#' ancestry_DF <- get_ancestry3(clan_members = clan_members, hyenas_DF = hyena_data)
#' indv_A <- ancestry_DF$name[1]
#' indv_B <- ancestry_DF$name[2]
#' ancestors_list <-  get_ancestors_A_B_C(ancestry_DF, indv_A, indv_B, hyenas_DF = hyena_data)
#' get_spectators2(ancestry_DF, indv_A, indv_B, ancestors_list)

get_spectators2 <- function(ancestry_DF, indv_A, indv_B, ancestors_list) {
  spectators <- ancestry_DF[ancestry_DF$name != indv_A & ancestry_DF$name != indv_B, ]
  RM <- ancestry_DF$name[!is.na(ancestry_DF$destination) & ancestry_DF$birthclan == ancestry_DF$destination] ## added line for the returning males

  G_columns <- grepl(pattern = "G", x = colnames(spectators))
  ancestors  <- spectators[, G_columns]
  rest <- spectators[, !G_columns]
  rest$ancestor_A <- apply(ancestors, 1, function(row) any(row %in% ancestors_list$A_ancestors))
  rest$ancestor_B <- apply(ancestors, 1, function(row) any(row %in% ancestors_list$B_ancestors))
  test_var <- 1 + (rest$ancestor_A*2) + rest$ancestor_B
  rest$type <- c("non_relatives", "B_relative", "A_relative", "both_relatives")[test_var]
  xx <- bind_cols(rest, ancestors)
  xx$type[xx$name %in% RM] <- "non_relatives"
  G_columns2 <- grepl(pattern = "G", x = colnames(xx))
  xx[xx$name %in% RM, G_columns2] <- NA
  return(xx)
}

################################################################################
#' apply the different rules
#' @param ancestry_DF ancestry df
#' @param indv_A indv A
#' @param indv_B indv B
#' @param ancestors_list list with ancestors info
#' @param hyenas_DF hyena df
#' @param spectators_DF spectators
#' @param contest_winner contest winner
#' @return A DF with number of supporter for indv_A and indv_B
#' @import dplyr
#' @import purrr

apply_choice <- function(indv_A, indv_B, ancestry_DF, spectators_DF, contest_winner, hyenas_DF, ancestors_list){

  #Remove global bindings NOTE in checks
  . <- name <- ansestor_L_S <- ansestor_L_S_offspring <- L_S_offspring_birth <- threshold <- NULL

    if ((!ancestry_DF[ancestry_DF$name == indv_A, "native", drop = TRUE]) && ancestry_DF[ancestry_DF$name == indv_B, "native", drop = TRUE]) { ### rule 3
      supporters <- dplyr::bind_cols(support_A = sum(spectators_DF$type == "A_relative"), support_B = sum(spectators_DF$native))

      #If the rival is an immigrant
    } else if (!ancestry_DF[ancestry_DF$name == indv_B, "native", drop = TRUE] && ancestry_DF[ancestry_DF$name == indv_A, "native", drop = TRUE]) { ### rule 3
      supporters <- dplyr::bind_cols(support_A = sum(spectators_DF$native), support_B = sum(spectators_DF$type == "B_relative"))
      # two natives
    } else if (is.na(contest_winner)) {  ### rule 2
      supporters <- dplyr::bind_cols(support_A =  sum(spectators_DF$type == "A_relative"), support_B =  sum(spectators_DF$type == "B_relative"))

      #However, if there is a clear winner by ancestory and both are native...
    } else {  ### rule 4

      Loser_ancestors <- as.character(if(contest_winner == indv_A) ancestors_list$B_ancestors else ancestors_list$A_ancestors)  ##### need to be done
      Loser <- Loser_ancestors[1]

      ## define relationship with loser

      #Determine if the losing individual appears in the maternal ancestery of any clan members
      spectators_DF <- spectators_DF %>%
        mutate(S_L_desc = apply(. , 1, function(row) length(dplyr::intersect(row[-1], Loser)) > 0),
               ## direct descendant of the Loser // loser (L) in the line of the Spectator (S)
               S_L_anc = name %in% Loser_ancestors, ## S in the direct line of L
               ansestor_L_S = apply(. , 1, function(row) as.character(Loser_ancestors[Loser_ancestors %in% row[-1]])[1]))

      spectators_DF <- spectators_DF %>%
        mutate(ansestor_L_S_offspring = apply(spectators_DF %>% select(name, colnames(spectators_DF)[stringr::str_detect(colnames(spectators_DF), "G")], ansestor_L_S), 1,
                                              function(row) as.character(row[which(row == as.character(row[length(row)]))[1] -1])),
               L_S_offspring_birth = map_chr(ansestor_L_S_offspring, ~ ifelse(is.na(.x), NA, hyenas_DF$birthdate[hyenas_DF$name == .x])),
               threshold = map_chr(ansestor_L_S, ~ ifelse(is.na(.x), NA, hyenas_DF$birthdate[hyenas_DF$name == (Loser_ancestors[which(Loser_ancestors == .x) -1])])),
               pass_threshold = L_S_offspring_birth > threshold) ### rule 5

      n_sup <- sum(spectators_DF$pass_threshold[spectators_DF$type == "both_relatives"] == T, na.rm = T) + sum(spectators_DF$S_L_anc ==T, na.rm = T)
      supporters <- dplyr::bind_cols(support_A = ifelse(indv_A == Loser, 0, n_sup), support_B = ifelse(indv_B == Loser, 0, n_sup))

    }
   return(supporters)

}


################################################################################
#' compute the social support for interctions
#' @param indv_A indv A
#' @param indv_B indv B
#' @param date date of the interaction
#' @param clan clan of the interaction
#' @param hyenas_DF hyena table
#' @param sel_DF selection table
#' @export
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#'
#' interactions <- data.frame(date = c("2007-08-16", "2007-08-16"), clan_f = c("N", "N"),
#' focal = c("N-006", "N-064"), other = c("N-064", "N-006"), stringsAsFactors = FALSE)
#' get_supporters2(
#'  indv_A = interactions$focal[1],
#'  indv_B = interactions$other[1],
#'  date = interactions$date[1],
#'  clan = interactions$clan[1], hyenas_DF = hyena_data, sel_DF = sel)

get_supporters2 <- function(indv_A, indv_B, date, clan, hyenas_DF, sel_DF){

  clan_members <- get_clan_members2(date = date, clan = clan, age =2, hyenas_DF = hyenas_DF, sel_DF = sel_DF)
  ancestry_DF <- get_ancestry3(clan_members = clan_members, hyenas_DF = hyenas_DF)
  ancestors_list <- get_ancestors_A_B_C(ancestry_DF, indv_A, indv_B, hyenas_DF)
  contest_winner <- relative_fight_outcome2(indv_A, indv_B, ancestors_list)
  spectators_DF <- get_spectators2(ancestry_DF, indv_A, indv_B, ancestors_list)
  out <- apply_choice(indv_A = indv_A,
                      indv_B = indv_B,
                      ancestry_DF = ancestry_DF,
                      spectators_DF = spectators_DF,
                      contest_winner = contest_winner,
                      hyenas_DF = hyenas_DF,
                      ancestors_list = ancestors_list)
  return(out)
}


################################################################################
#' compute the social support for interctions
#' @param indv_A indv A
#' @param indv_B indv B
#' @param date date of the interaction
#' @param clan clan of the interaction
#' @param hyenas_DF hyena table
#' @param clan_members_DF clan members df computed outside
#' @param sel_DF selection table
#' @export

get_supporters2_same_clan <- function(indv_A, indv_B, date, clan, hyenas_DF, sel_DF, clan_members_DF){

  clan_members_DF <- clan_members_DF
  ancestry_DF <- get_ancestry3(clan_members_DF, hyenas_DF = hyenas_DF)
  ancestors_list <- get_ancestors_A_B_C(ancestry_DF, indv_A, indv_B, hyenas_DF)
  contest_winner <- relative_fight_outcome2(indv_A, indv_B, ancestors_list)
  spectators_DF <- get_spectators2(ancestry_DF, indv_A, indv_B, ancestors_list)
  out <- apply_choice(indv_A = indv_A,
                      indv_B = indv_B,
                      ancestry_DF = ancestry_DF,
                      spectators_DF = spectators_DF,
                      contest_winner = contest_winner,
                      hyenas_DF = hyenas_DF,
                      ancestors_list = ancestors_list)
  return(out)
}
################################################################################
#' compute the social support for interctions
#' @param interaction interaction df
#' @export
#' @import purrr
#' @import dplyr
#' @examples
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#'
#' interactions <- data.frame(date = c("2018-01-01", "2007-08-16"), clan_f = c("A", "N"),
#' focal = c("A-128", "N-064"), other = c("A-142", "N-006"), stringsAsFactors = FALSE)
#' wrapper_social_support2(interactions)

wrapper_social_support2 <- function(interaction){

  #Prevent global bindings NOTE in checks
  mothersocial <- NULL

# browser()
  hyena_data <- .GlobalEnv$database$data$hyenas %>%
    group_by(mothersocial) %>%
    left_join(.GlobalEnv$database$data$deaths, by = "name")

  sel <- .GlobalEnv$database$data$selections

  if(length(unique(interaction$clan_f)) <2 & length(unique(interaction$date)) <2 ) ## carful with the clan_f and not clan

  {
    clan_members <- get_clan_members2(date = interaction$date[1], clan = interaction$clan_f[1], age = 2, hyenas_DF = hyena_data, sel_DF = sel)

    pmap_df(list(indv_A = interaction$focal, indv_B = interaction$other, date = interaction$date, clan = interaction$clan_f), get_supporters2_same_clan,
            hyenas_DF = hyena_data, sel_DF = sel, clan_members_DF = clan_members)

  } else {


  pmap_df(list(indv_A = interaction$focal, indv_B = interaction$other, date = interaction$date, clan = interaction$clan_f), get_supporters2,
          hyenas_DF = hyena_data, sel_DF = sel)
  }
}

################################################################################
#' create all possible interaction for a given clan / use internally to compute
#' rank based on social support
#' @param clan_members_DF output of get_clan_members2
#' @param date date
#' @import dplyr
expand_clans2 <- function(clan_members_DF, date) {

  #Bind to NULL to avoid global bindings note in checks
  focal <- other <- NULL

  zz <- gtools::combinations(nrow(clan_members_DF), 2, clan_members_DF$name)
  tibble(focal = zz[, 1],
         other = zz[, 2],
         date = paste(date),
         clan_f = clan_members_DF$currentclan[1]) %>%
    filter(focal != other)
}
################################################################################
#' compute the supporter for all possible interaction in a given clan at a given time
#' @param clans a vector of clan
#' @param dates a vector of date
#' @param age age at which to consider supporters
#' @param hyenas_DF hyenas_DF from the database
#' @param sel_DF sel_DF from the database
#' @import purrr
#' @export
#' @examples \dontrun{
#' ## examples doesn't work with fake database.
#' library(dplyr)
#' load_db()
#' hyena_data <- database$data$hyenas %>%
#'   group_by(mothersocial) %>%
#'   left_join(.GlobalEnv$database$data$deaths, by = "name")
#' sel <- .GlobalEnv$database$data$selections
#' dates <- seq(from = as.Date("201-01-01"), to = as.Date("2018-01-01"), by = "1 year")
#' clans <- c("A")
#' age <- 1
#' get_social_support_clan_all_interactions(clans = clans, dates = dates, age = 2,
#' hyenas_DF = hyena_data, sel_DF = sel)
#' }

get_social_support_clan_all_interactions <- function(clans, dates, age, hyenas_DF, sel_DF){
# browser()
  L_dates <- length(dates)

for(c in 1:length(clans)) {


  clan <- rep(clans[c], L_dates)

  list_M <- map2(dates, clan, get_clan_members2, age = age, hyenas_DF = hyenas_DF, sel_DF = sel_DF)
  list_M <- map(list_M, ~ .x %>% filter(native == T))

  expanded_list_clan2 <- map2(list_M, dates, expand_clans2)
  map(expanded_list_clan2, wrapper_social_support2)
}
}
