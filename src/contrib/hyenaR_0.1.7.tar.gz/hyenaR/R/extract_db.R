#' Load data frames from the hyena database.
#'
#' @param db Location of database. If unspecified, will use dummy database file for examples.
#' @param tables Which tables you wish to load.
#' Can be "hyena", "adults", "deaths", "firstlitter",
#' "samples", "selections", "sightings", "snapshots",
#' "youngest_age". All tables are loaded by default.
#'
#' @return If only one table is requested, will return a single tibble.
#' If multiple tables are requested, will return a list of tibbles.
#' @export
#' @import DBI
#' @import dplyr
#' @import RSQLite
#'
#' @examples
#'
#'  #Load a single table from the database
#'  data <- extract_db(tables = "hyenas")
#'
#'  #Load multiple tables from the database
#'  data <- extract_db(tables = c("hyenas", "deaths"))

extract_db <- function(db = NULL, tables = NULL){

  if(is.null(db)){

    message("No database path specified. Using the dummy dataset!")

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  db <- path.expand(db)

  #Establish connection with .sqlite database
  connection <- dbConnect(SQLite(), db)

  if(is.null(tables)){

    tables <- DBI::dbListTables(connection)

  }

  #Check that requested table name exists in the database
  if(!all(tables %in% dbListTables(connection))){

    wrong_tables <- tables[which(!tables %in% dbListTables(connection))]

    #Disconnect from database file
    dbDisconnect(connection)

    stop(paste("These table names are not in the database:", paste(wrong_tables, collapse = ", "), "\n Please check your spelling and try again."))

  }

  #If only one table is requested...
  if(length(tables) == 1){

    #Create a single tibble object
    return_obj <- tbl(connection, tables) %>%
      collect()

  #Otherwise...
  } else {

    #Create a list, where each list item is a tibble
    return_obj <- list()

    for(i in 1:length(tables)){

      return_obj[[i]] <- tbl(connection, tables[i]) %>%
        collect()

    }

    #Make it a named list
    names(return_obj) <- tables

  }

  #Disconnect from database file
  dbDisconnect(connection)

  #Return tibble/list object
  return(return_obj)

}
