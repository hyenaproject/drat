#' Check that sightings, selections and hyena are all consistent
#'
#' Use to check database tables before database is built.
#' Run withint \code{\link{bootstrap_db}}.
#' @param hyenas Hyenas data table.
#' @param sightings Sightings data table.
#' @param selections Selections data table.
#'
#' @return Prints a message if all checks are met.
#' @importFrom glue glue
#' @importFrom stringr str_trim

full_record_check <- function(hyenas, sightings, selections){

  #Assing NULL to avoid global binding NOTE
  name <- NULL

  print("Check that all individuals have full records in hyenas, sightings and selections...")

  names_selections <- stringr::str_trim(unique(selections$name)[!is.na(unique(selections$name)) & unique(selections$name) != ""])
  names_sightings  <- stringr::str_trim(unique(sightings$name)[!is.na(unique(sightings$name)) & unique(sightings$name) != ""])
  names_hyenas     <- stringr::str_trim(unique(hyenas$name)[!is.na(unique(hyenas$name)) & unique(hyenas$name) != ""])

  #Check that any time there is a recorded selection that the individual must have a hyena and sightings record
  correct_selections_hyena <- names_selections %in% names_hyenas
  correct_selections_sightings <- names_selections %in% names_sightings

  #Check that any time there is a recorded sighting that the individual must have a hyena record.
  correct_sightings <- names_sightings %in% names_hyenas

  #Check that anything in hyenas is also in sightings
  correct_hyenas <- names_hyenas %in% names_sightings

  if(all(correct_selections_hyena) & all(correct_selections_sightings) & all(correct_sightings)){

    print("All individuals have full records!")

  } else {

    bad_records <- bind_rows(data_frame(name = names_selections[!correct_selections_hyena], table1 = "selections", table2 = "hyenas"),
              data_frame(name = names_selections[!correct_selections_sightings], table1 = "selections", table2 = "sightings"),
              data_frame(name = names_sightings[!correct_sightings], table1 = "sightings", table2 = "hyenas"),
              data_frame(name = names_hyenas[!correct_sightings], table1 = "hyenas", table2 = "sightings")) %>%
      filter(!is.na(name))


    pwalk(.l = list(name = bad_records$name, table1 = bad_records$table1, table2 = bad_records$table2),
          .f = function(name, table1, table2){

            print(glue::glue('{name} has a record in {table1} but not in {table2}!'))

          })

    stop("Please check the above records before building the database.")

    }

}
