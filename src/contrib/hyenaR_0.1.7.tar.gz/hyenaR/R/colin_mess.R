# rm(list = ls())
# library(gridExtra)
# library(profvis)
# library(microbenchmark)
# library(bench)
# library(data.table)
# library(hyenaR)
# library(dplyr)
# library(purrr)
# library(gtools)
#
#  load_db(db = "/home/colin/Downloads/Fisidata_03_12_18_BOOTSTRAP_DATABASE.sqlite")
# #
# # hyena_data <- database$data$hyenas %>%
# #   group_by(mothersocial) %>%
# #   left_join(.GlobalEnv$database$data$deaths, by = "name")
# # sel <- .GlobalEnv$database$data$selections
# #
# # expand_clans2 <- function(x,y ) {
# #
# #   zz <- combinations(nrow(x), 2, x$name)
# #   tibble(focal = zz[, 1],
# #          other = zz[, 2],
# #          date = paste(y),
# #          clan_f = x$currentclan[1], stringsAsFactors = F) %>%
# #     filter(focal != other)
# # }
# #
# #
# plot_xx <- function(x, y, plot){
#
#   out <-  bind_cols(x, y) %>%
#     mutate(winner = ifelse(support_A > support_B, focal, ifelse(support_B > support_A, other, "ties"))) %>%
#     mutate(loser = ifelse(winner == focal, other, ifelse(winner == other, focal, "ties")),
#            delta_A = support_A - support_B,
#            delta_B = support_B - support_A)
#
#
#
#
#   tttt <- bind_rows(out %>% select(focal, other, winner, loser, support_A, delta_A) %>%
#                       rename(name = focal, opponent = other, support = support_A, delta = delta_A),
#                     out %>% select(other, focal, winner, loser, support_B, delta_B) %>%
#                       rename(name = other, opponent = focal, support = support_B, delta = delta_B)) %>%
#     group_by(name) %>%
#     summarise(wins = sum(winner == name, na.rm = T),
#               lose = sum(loser == name, na.rm = T),
#               ties = sum(winner == "ties" | loser == "ties"),
#               raw_sup = sum(delta, na.rm = T),
#               total = wins) %>% arrange(desc(total)) %>%
#     mutate(rank_sup = rank(total, ties.method = "average"))
#
#
#   x22 <- calculate_rank(data.frame(name = unique(c(y$focal, y$other)), date = paste(y$date[1])))
#   x22 <- x22 %>% select(name, rank_std, rank) %>% arrange(rank)
#   x22$date <- paste(y$date[1])
#
#   pl <- inner_join(x22, tttt, by = "name") %>%
#     mutate(sex = map_int(name, ~ ifelse(.x %in% hyena_data$name, hyena_data$sex[hyena_data$name == .x], NA)))
#
#   pl2 <- list(pl = pl, out = out)
#   out1 <- ggplot(pl, aes(x = - as.numeric(rank_sup), y = - rank)) +
#     geom_point(aes(col = name)) +
#     guides(col = FALSE) +
#     ggtitle(paste(y$date[1]))
#
#   if(plot == T) {
#     return(out1)
#   } else {
#     return(pl)
#   }
# }



# Clans_v <- c("A", "E", "F", "L", "M", "N", "S", "T")
# # Clans_v <- "M"
# OutOut <- list()
#
# # i <- 1
# for(c in 1:length(Clans_v)) {
#
# dates <- seq(from = as.Date("2010-01-01"), to = as.Date("2018-01-01"), by = "1 year")
# clan <- rep(Clans_v[c], 9)
#
# list_M <- map2(dates, clan, get_clan_members2, age = 2, hyena = hyena_data, sel = sel)
# list_M <- map(list_M, ~ .x %>% filter(native == T))
#
# expanded_list_clan2 <- map2(list_M, dates, expand_clans2)
# system.time(test <- map(expanded_list_clan2, wrapper_social_support2))
#
# OutOut[[c]] <- map2_df(test, expanded_list_clan2, plot_xx, plot = F)
# OutOut[[c]]$clan <- Clans_v[c]
# }
#

#
#
#
# ######################## check for Munge 2018
# clan_members <- get_clan_members2(date = "2018-01-01", clan = "M", age = 2, hyena = hyena_data, sel = sel)
#
#
#
#
# ancestry <- get_ancestry3(clan_members)
# ancestors_info <- get_ancestors_A_B_C(ancestry, "M-287", "M-295", hyena_df)
# contest_winner <- relative_fight_outcome2("M-287", "M-295", ancestors_info)
# spectators <- get_spectators2(ancestry,"M-287", "M-295", ancestors_info)
#
# ancestors_info
#
# M287 <- spectators %>% filter(type == "A_relative")
# M295 <- spectators %>% filter(type == "B_relative")
# write.csv(M287, file = "M287.csv")
# write.csv(M295, file = "M295.csv")
#
# out <- apply_choice("M-287", "M-295",ancestry, Loser_ancestors, spectators, contest_winner,  hyena_df, ancestors_info)
#
#
#
# x <- bind_rows(OutOut[[1]][[1]]$out)
#
# x_M287 <- x %>% filter(focal == "M-287" | other == "M-287") %>% filter(winner == "M-287")
# x_M295 <- x %>% filter(focal == "M-295" | other == "M-295") %>% filter(winner == "M-295")
#
#
# x <- bind_rows(OutOut[[1]][[1]]$pl) %>% arrange(total)
#
#
# x$clan <- OutOut[[1]][[2]]
#
# x <- bind_rows(OutOut)
# ggplot(x, aes(y = as.numeric(total), x = -as.numeric(rank))) +
#   geom_text(aes(label = name), size = 0.7, angle = -45)+
#   guides(col = FALSE) +
#   facet_grid(clan ~ date, scales = "free")
#
# cor <- x %>% group_by(clan, date) %>%
#   summarize(cor = cor(rank, total, method = "spearman"))
# mean(cor$cor)^2

# ?geom_label()
#
#
# out_test <- out_test %>% arrange(date, desc(total)) %>%
#   group_by(date) %>%
#   mutate(rank_sup = order(total, decreasing = T),
#          rank_raw = order(raw_sup, decreasing = T))
#
# out_test <- out_test %>% mutate(top_ranking = rank_std < 0.8,
#                                 gap = rank-rank_sup)
#
# ggplot(out_test, aes(as.Date(date), gap, top_ranking)) +
#   geom_line(aes(col = rank_std, group = name)) +
#   guides(color = FALSE)
#
# ggplot(out_test, aes(as.Date(date), - rank_sup)) +
#   geom_line(aes(col = rank, group = name))
#
# ggplot(out_test, aes(as.Date(date), - rank_sup)) +
#   geom_line(aes(col = name, group = name))
