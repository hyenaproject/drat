context("Test the functions associated with social_support")

test_that("get_clan_members returns a list of clan members", {

  load_db()
  output_summary <- get_clan_members(date = "2017-08-16", clan = "F")

  #Test that a tibble is returned
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that it has more 0 rows (i.e. it actually returned clan members)
  expect_true(nrow(output_summary) > 0)
  #Test type of all columns is correct
  expect_true(is.character(output_summary$name) &
                is.character(output_summary$currentclan) &
                is.logical(output_summary$native))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("get_ancestry returns a list of ancestors", {

  load_db()
  clan_members <- get_clan_members(date = "2017-08-16", clan = "F")
  output_summary <- get_ancestry(clan_members = clan_members)

  #Test that a tibble is returned
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that it has more 0 rows (i.e. it actually returned clan members)
  expect_true(nrow(output_summary) > 0)
  #Test type of all columns is correct
  expect_true(is.character(output_summary$name) &
                is.character(output_summary$currentclan) &
                is.logical(output_summary$native) &
                is.character(output_summary$M))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("wrapper function calc_social_support returns a expected values", {

  load_db()
  interactions <- data.frame(date = c("2007-08-16", "2007-08-16"), clan_f = c("N", "N"),
  focal = c("N-006", "N-064"), other = c("N-064", "N-006"), stringsAsFactors = FALSE)
  output_summary <- calc_social_support(interactions = interactions)

  #Test that it has 2 rows as expected
  expect_equal(nrow(output_summary), 2)
  #Test that relative support values are as expected
  expect_equal(output_summary$relative_support, c(-2, 2))
  #Test that absolute number of supporters is also as expected.
  expect_equal(output_summary$support_A, c(0, 2))
  expect_equal(output_summary$support_B, c(2, 0))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

