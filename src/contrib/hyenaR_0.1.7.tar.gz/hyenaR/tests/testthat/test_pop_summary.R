context("Test pop_summary function")

test_that("Returns a complete summary when no date provided", {

  load_db()
  output_summary <- pop_summary()

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$date), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$pop_size)
              & is.numeric(output_summary$active_clans)
              & is.numeric(output_summary$average_size))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Returns a summary when multiple dates provided", {

  load_db()
  output_summary <- pop_summary(date = c("1998-01-01", "2016-01-01"))

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$date), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$pop_size)
              & is.numeric(output_summary$active_clans)
              & is.numeric(output_summary$average_size))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Returns a message when a too recent date is provided", {

  load_db()
  expect_message(pop_summary(date = c("2019-01-01")))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})
