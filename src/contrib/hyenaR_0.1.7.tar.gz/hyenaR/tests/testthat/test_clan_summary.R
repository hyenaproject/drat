context("Test clan_summary function")

test_that("Function works when no date is provided", {

  load_db()
  test_summary <- clan_summary(clan = "A")

  #Test that a tibble is returned
  expect_equal(class(test_summary)[1], "tbl_df")
  #Test that clan is a character
  expect_equal(class(test_summary$clan), "character")
  #Test that all other columns are numeric
  expect_true(all(apply(test_summary[, -(1:2)], 2, is.numeric)))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Function works when no clan is provided", {

  load_db()
  test_summary <- clan_summary(date = "1998-01-01")

  #Test that a tibble is returned
  expect_equal(class(test_summary)[1], "tbl_df")
  #Test that clan is a character
  expect_equal(class(test_summary$clan), "character")
  #Test that all other columns are numeric
  expect_true(all(apply(test_summary[, -(1:2)], 2, is.numeric)))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})

test_that("Function works with no clan or date", {

  load_db()
  test_summary <- clan_summary()

  #Test that a tibble is returned
  expect_equal(class(test_summary)[1], "tbl_df")
  #Test that clan is a character
  expect_equal(class(test_summary$clan), "character")
  #Test that all other columns are numeric
  expect_true(all(apply(test_summary[, -(1:2)], 2, is.numeric)))

  rm(list = c("database", "db"), envir = .GlobalEnv)

})
