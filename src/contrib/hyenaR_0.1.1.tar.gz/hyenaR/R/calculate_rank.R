#' Determine the rank of given hyena(s) on a given date
#'
#' Uses python functions written by Ilja to determine
#' the rank and standardised rank of given individuals
#' at a given date.
#'
#' @param db Location of database file (.sqlite). If unspecified, will use dummy database file for examples.
#' @param input Can take a dataframe/tibble or named list.
#' Input should have two columns/list items called `name` (name of hyenas) and `date` ("YYYY-MM-DD").
#' @param python_loc Location of python on the computer. If unspecified,
#' will search in PATH.
#'
#' @return Will return a tibble with ranks calculated for each individual
#' @export
#' @import reticulate
#' @import dplyr
#' @import purrr
#'
#' @examples
#'
#'#Run with internal dataframe
#'input_file <- data.frame(name = c("N-006", "N-064"), date = c("2007-01-01", "2007-01-01"))
#'calculate_rank(input = input_file)

calculate_rank <- function(db = NULL, input, python_loc = NA){

  #Check the input file is in the correct format
  if(class(input)[1] == "matrix" | (is.vector(input) & !class(input)[1] == "list")){

    stop("input variable must be either a dataframe, tibble or named list")

  }

  if(class(input$date) == "Date"){

    input$date <- as.character(input$date)

  }

  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Assign main to prevent global variable check issue
  main <- NULL

  #Specify location of python on your system
  use_python(python_loc)

  #Run python code to include my extra functions AND Ilya's function library
  py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))
  py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))

  #Run the main_R function to get ranks of all individuals
  #Before we can do this, we need to input our data in a different format.
  #Instead of being a dataframe, it should be a list, with each item being another list with name and date.
  #Map over the dataframe using df_to_list() function.
  input <- map2(.x = input$name, .y = input$date, .f = df_to_list)

  #Use this file in the python function designed for R...
  output_file = py$main_R(db, input)

  #This is now a dictionary.
  #Essentially, this behaves like a dataframe (you get extract a column with dataframe$x)
  #However, it doesn't display and can't be indexed!
  #Therefore, we map across this whole dictionary with dict_to_df. This outputs an unnamed list.
  output_R <- map(.x = names(output_file), .f = dict_to_df, output_file)
  #we then assign list names from the original file
  names(output_R) <- names(output_file)
  #And finally, we use bind_rows to convert it into a dataframe
  #Python provides None when data is missing...R translates this into NULL rather than NA.
  #For cases where no rank could be determined, we need to map through and replace these with NAs.
  return(map_df(output_R, .f = function(x){

    if(is.list(x)){

      return(map(x, .f = function(y){

        if(is.null(y)){
          return(NA)
        } else {
          return(y)
        }

      }))

    } else {

      return(x)

    }

  }) %>%
    mutate_if(is.list, as.numeric))

}
