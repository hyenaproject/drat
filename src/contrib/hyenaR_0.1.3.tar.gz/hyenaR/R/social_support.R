#' Determine clan members in a specific clan at a specific time.
#'
#' @param db Location of database. If unspecified, will use dummy database for examples
#' @param date Date of clan membership in format "YYYY-MM-DD"
#' @param clan Clan in which you want to determine membership.
#' @param age The age above which clan members should be included. Default at age 1.
#'
#' @return Returns a 3 column data frame with names of all individuals in the clan at the time.
#' @export
#' @import DBI
#' @import RSQLite
#' @import dplyr
#' @import purrr
#' @importFrom lubridate years
#'
#' @examples
#'
#'get_clan_members(date = "2017-08-16", clan = "F")
#'
#'

################################################################################################

get_clan_members <- function(db = NULL, date, clan, age = 1){

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  hyena_data <- extract_db(db = db, "hyenas") %>%
    left_join(extract_db(db = db, "deaths"), by = "name")
  selection_data <- extract_db(db = db, "selections")

  #Create a datetime object
  event_date <- as.Date(date, format = "%Y-%m-%d")

  #Create a vector of all male names?
  male_selections <- selection_data$name

  #Create a subset of all hyenas where:
  # - Individual was born before the interaction occured
  # - Individual died after the interaction occured (or has not died)
  #Extract their name, birthclan and birthdate.
  subset <- hyena_data[hyena_data$birthdate < event_date & (hyena_data$deathdate > event_date | is.na(hyena_data$deathdate)), c("name", "birthclan", "birthdate")]

  #Determine the current clan of every individual in the above subset
  subset$currentclan <- map_chr(subset$name, function(focal_name) {
    #For a given individual
    #If the individual is not found in the list of hyena names that have changed clan
    if (!(focal_name %in% male_selections)) {
      #Save its birthclan (i.e. it didn't move clans from birth)
      return(subset$birthclan[subset$name == focal_name])
      #If the individual is found in the list of names (i.e. it dispersed)
    } else {
      #Extract the dispersal decisions this individual made BEFORE the interaction occured
      dispersal <- selection_data[selection_data$name == focal_name & selection_data$date <= event_date, c("name", "destination")]
      #If there was no dispersal before the interaction...
      if (nrow(dispersal) == 0) {
        #Then save the birth clan
        #i.e. did dispersed at some point, but that was after the interaction occured
        return(subset$birthclan[subset$name == focal_name])
      } else {
        #If it occured afterwards, then take the value of the LAST clan that the individual dispersed to.
        return(as.character(dispersal[nrow(dispersal), "destination"]))
      }
    }
  })

  #Reduce the list of individuals that were alive during the interaction to only include those that were ALSO in the clan at the time.
  subset <- subset[subset$currentclan == clan, ]
  #Subset so their birthdate was more than a year before the interaction (i.e. we are only dealing with individuals >1yo)
  subset <- subset[subset$birthdate < event_date - years(age), ]
  #Create an output that includes the names, birthclan and current clan of all potential individuals around during the interaction.
  subset$native <- map2_lgl(.x = subset$birthclan, .y = subset$currentclan, .f = ~.x == .y)
  subset <- subset[, c("name", "currentclan", "native")]

    # #Reduce the list of individuals that were alive during the interaction to only include those that were ALSO in the clan at the time.
    # #Subset so their birthdate was more than a year before the interaction (i.e. we are only dealing with individuals >1yo)
    # subset <- subset %>%
    #   filter(currentclan == clan, birthdate < event_date - years(1)) %>%
    #   #If current clan is different to birthclan then make a column native == FALSE
    #   mutate(native = map2_lgl(.x = birthclan, .y = currentclan, .f = ~.x == .y)) %>%
    #   #Subset to only include name, birthclan, current clan and native %>%
    #   select(name, currentclan, native)

  return(subset)

  # if(is.null(db)){
  #
  #   db = system.file("extdata", "Fisidata_28_06_18.sqlite", package = "hyenaR", mustWork = TRUE)
  #
  # }
  #
  # #Establish a connection with the database
  # connection <- dbConnect(SQLite(), db)
  #
  # #Generate state of clans on each date
  # raw_clan_summary <- get_rawclan_summary(db = db, clan = clan, date = date, python_loc = python_loc)
  #
  # date <- lubridate::ymd(date)
  #
  # #Just extract those individuals that were >1yo at the time of the interaction
  # map_df(.x = raw_clan_summary$indv_summary[[1]][clan], .f = function(x){
  #
  #   if(x['birthdate'] < (date - lubridate::years(age))){data.frame(name = x['name'], currentclan = clan, native = x['native'], stringsAsFactors = FALSE)}
  #
  # })

}

#############################################################################

#' Determine the ancestry of all individuals in a clan at a given time.
#' @param db Location of database. If unspecified, will use database file pre 28-06-18
#' @param clan_members Clan members at a give time. Output from \code{\link{get_clan_members}}
#'
#' @return Returns a tibble with the maternal ancestry (6 generations) of every individual
#' @export
#' @import dplyr
#'
#' @examples
#'
#' #Extract clan members on a given date
#' clan_members <- get_clan_members(date = "2017-08-16", clan = "F")
#'
#' #Determine the ancestry of all these clan members.
#' get_ancestry(clan_members = clan_members)
#'

get_ancestry <- function(clan_members, db = NULL){

  #Assign NULL to variable names to avoid binding NOTE in R CHECKS
  M <- GM <- GGM <- GGGM <- GGGGM <- GGGGGM <- . <- name <- NULL

  hyenas <- extract_db(db = db, tables = "hyenas")

  #Extract 6 generations with map
  clan_members <- clan_members %>%
    mutate(M = purrr::map_chr(.x = name, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]),
           GM = purrr::map_chr(.x = M, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]),
           GGM = purrr::map_chr(.x = GM, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]),
           GGGM = purrr::map_chr(.x = GGM, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]),
           GGGGM = purrr::map_chr(.x = GGGM, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]),
           GGGGGM = purrr::map_chr(.x = GGGGM, .f = ~ if (is.na(.x)) NA else hyenas$mothersocial[hyenas$name == .x]))

  #Return list with all individuals and their maternal ancestry
  return(clan_members)

}

##############################################################################################

#' Determine supporters of two individuals during an interaction.
#'
#' @param indv_A Name of focal individual.
#' @param indv_B Name of opponent.
#' @param ancestry Ancestry of clan members from \code{\link{get_ancestry}}.
#' @param db Location of database. If unspecified, will use dummy database for examples.
#' @param hyena_data Hyena database table including birth rank.
#'
#' @return Returns a tibbel with number of supporters for each individual.
#' @export
#' @import dplyr
#' @import purrr
#'
#' @examples
#'
#' library(dplyr)
#' hyena_data <- extract_db(table = "hyenas") %>%
#' group_by(mothersocial) %>%
#' do(., mutate(., birth_rank = rank(as.Date(.$birthdate), ties.method = "average"))) %>%
#' ungroup()
#'
#' #Extract clan members on a given date
#' clan_members <- get_clan_members(date = "2007-08-16", clan = "N")
#'
#' #Determine the ancestry of all these clan members.
#' ancestry <- get_ancestry(clan_members = clan_members)
#'
#' get_supporters(indv_A = "N-006", indv_B = "N-064", ancestry = ancestry, hyena_data = hyena_data)
#'

get_supporters <- function(indv_A, indv_B, ancestry, hyena_data, db = NULL){

  #Assign NULL to variable names to avoid binding NOTE in R CHECKS
  ancestor_A <- ancestor_B <- choice <- loser_desc <- loser_anc <- NULL
  M <- GM <- GGM <- GGGM <- GGGGM <- GGGGGM <- NULL
  name <- . <- currentclan <- native <- mothersocial <- birth_rank <- NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Extract residence information for each individual
  resid_A <- ancestry %>% filter(name == indv_A) %>% .$native
  resid_B <- ancestry %>% filter(name == indv_B) %>% .$native

  #Return all the known maternal ancestors for both the focal and rival individual
  A_ancestors <- ancestry %>%
                 filter(name == indv_A) %>%
                 select(-currentclan:-native) %>%
                 select_if(.predicate = ~ !is.na(.))

  B_ancestors <- ancestry %>%
                 filter(name == indv_B) %>%
                 select(-currentclan:-native) %>%
                 select_if(.predicate = ~ !is.na(.))

  #If there is at least one individual shared in the maternal ancestry.
  #Return the first common ancestor
  common_ancestor <- if(any(A_ancestors %in% B_ancestors)) as.character(A_ancestors[which(A_ancestors %in% B_ancestors)][1]) else NA

  #For the common ancestor, determine all her offspring and their rank (by age)
  common_ancestor_offspring <- hyena_data %>%
    filter(mothersocial == common_ancestor) %>%
    select(name, birth_rank)

  #Determine the rank of offspring of the common ancestor which belongs to the maternal lineage of each focal individual
  #e.g. if they share a grandma, but they have different mothers. What was the rank of each mother (based on birth order)
  A_ancestor_rank <- common_ancestor_offspring %>%
                     filter(name %in% A_ancestors) %>%
                     .$birth_rank

  #Do the same for the rival
  B_ancestor_rank <- common_ancestor_offspring %>%
                     filter(name %in% B_ancestors) %>%
                     .$birth_rank

  #Determine what relatives should do in a contest between individuals A and B if they are both related
  contest_outcome <- relative_fight_outcome(indv_A, indv_B, A_ancestors, B_ancestors, A_ancestor_rank, B_ancestor_rank, common_ancestor)
  #Save the winning individual
  Winner <- contest_outcome[[1]]
  #Save the losing individual
  Loser  <- contest_outcome[[2]]
  #Save the lineage of the loser
  Loser_ancestors <- contest_outcome[[3]]
  #Save the ranking (i.e. A>B, B=A)
  Ranking <- contest_outcome[[4]]

  #### Now, use all this information to get the choice of C
  #Create a new list of individuals in the clan that are not involved in the fight
  spectators <- ancestry %>%
                filter(name != indv_A & name != indv_B)

  #Logical variable to determine if any of the maternal ancestors of a given spectator falls within the matriline of either of the competing individuals
  #N.B. This means that the individual could be either the ancestor OR desendant (or in the same generation) as one of the individuals.
  #We just checked to see if their mum/grandma etc. fell SOMEWHERE in the matriline.
  #For the offspring of individual A, their grandma would be in the matriline of A as the mum.
  spectators <- spectators %>%
    mutate(ancestor_A = purrr::pmap_lgl(.l = list(M, GM, GGM, GGGM, GGGGM, GGGGGM), .f = function(M, GM, GGM, GGGM, GGGGM, GGGGGM){

      return(any(c(M, GM, GGM, GGGM, GGGGM, GGGGGM) %in% A_ancestors))

    }),
    ancestor_B = purrr::pmap_lgl(.l = list(M, GM, GGM, GGGM, GGGGM, GGGGGM), .f = function(M, GM, GGM, GGGM, GGGGM, GGGGGM){

      return(any(c(M, GM, GGM, GGGM, GGGGM, GGGGGM) %in% B_ancestors))

    }))

  #Find individuals that were related to ONLY one of the interacting pair
  single_relative <- spectators %>%
    filter(xor(ancestor_A, ancestor_B)) %>%
    #For these individuals, they always choose their relative
    mutate(choice = purrr::map(.x = ancestor_A, .f = ~ifelse(.x, indv_A, indv_B)))

  #Create a subset for all the other individuals that shared a common ancestor with both competing individuals
  #N.B. This is cases where they are a common ancestor NOT where they ARE the common ancestor of A and B.
  both_relatives <- spectators %>%
    filter(ancestor_A & ancestor_B)

  #Now determine the number of supporters each individual should get.
  #If the focal individual has immigrated...
  if (!resid_A) {

    #the only individuals that would support the focal will be those related to it and not the opponent
    #The rival gets the support of all the natives

    #Count all natives
    natives          <- sum(spectators$native)
    #Count all individuals that are only related to indv_A
    A_only_relatives <- single_relative %>% filter(choice == indv_A) %>% nrow()

    supporters <- dplyr::bind_cols(support_A = A_only_relatives, support_B = natives)

    #If the rival is an immigrant
  } else if (!resid_B) {

    #the only individuals that would support the rival will be those related to it and not the opponent
    #The focal gets the support of all the natives

    #Count all natives
    natives          <- sum(spectators$native)
    #Count all individuals that are only related to indv_B
    B_only_relatives <- single_relative %>% filter(choice == indv_B) %>% nrow()

    supporters <- dplyr::bind_cols(support_A =  natives, support_B = B_only_relatives)

    #Otherwise, if there is no clear reason for support via ancestory
    #Either they are unrelated OR their is a twin conflict
    #Then the supporters of each individual are just the ones that are completely unrelated to the other.
    #We assume every other individual abstains because the choice is unclear.
  } else if (is.na(Winner)) {

    A_only_relatives <- single_relative %>% filter(choice == indv_A) %>% nrow()
    B_only_relatives <- single_relative %>% filter(choice == indv_B) %>% nrow()

    supporters <- dplyr::bind_cols(support_A = A_only_relatives, support_B = B_only_relatives)

    #However, if there is a clear winner by ancestory and both are native...
  } else {

    #Determine if the losing individual appears in the maternal ancestery of any clan members
    #i.e. is a spectator the offspring of the loser
    both_relatives <- both_relatives %>%
      mutate(loser_desc = purrr::pmap_lgl(.l = list(M, GM, GGM, GGGM, GGGGM, GGGGGM),
                                           .f = function(M, GM, GGM, GGGM, GGGGM, GGGGGM){
                                             return(any(c(M, GM, GGM, GGGM, GGGGM, GGGGGM) %in% Loser))
                                             }),
             #Also determine if the spectator is a direct ancestor of the loser
             loser_anc = name %in% Loser_ancestors)

    #Create a subset for those individuals that are not direct descendents or ancestors of the losing individual.
    #These individuals will need to pick a side...
    not_direct <- both_relatives %>% filter(!(loser_desc | loser_anc)) %>%
    #Of those individuals determine the closest common ancestor to the loser
                  mutate(common_ancestor = purrr::pmap_chr(.l = list(M, GM, GGM, GGGM, GGGGM, GGGGGM),
                                                       .f = function(M, GM, GGM, GGGM, GGGGM, GGGGGM){
                                                         return(as.character(Loser_ancestors[, which(Loser_ancestors %in% c(M, GM, GGM, GGGM, GGGGM, GGGGGM))][1]))
                                                         }))

    #Determine all offspring of this most recent common ancestor with the loser.
    common_ancestor_offspring <- not_direct %>%
      group_by(common_ancestor) %>%
      do(., hyena_data[hyena_data$mothersocial %in% .$common_ancestor, c('name', 'birth_rank')])

    #Determine the rank of the offspring that is in the lineage of the loser...
    threshold <- common_ancestor_offspring %>%
                 group_by(common_ancestor) %>%
                 summarise(threshold = birth_rank[name %in% Loser_ancestors],
                          name = name[name %in% Loser_ancestors]) %>%
                 ungroup()

    #...then determine whether the rank of the offspring in the lineage of the spectator is higher or lower rank than...
    #that of the loser's ancestory determined above
    not_direct <- not_direct %>%
      mutate(passed_threshold = purrr::pmap_lgl(.l = list(common_ancestor,
                                                         name, M, GM, GGM, GGGM, GGGGM, GGGGGM),
                                               .f = ~filter(common_ancestor_offspring, common_ancestor %in% ..1 & name %in% c(..2, ..3, ..4, ..5, ..6, ..7, ..8)) %>% .$birth_rank
                                               > filter(threshold, common_ancestor == .x) %>% .$threshold))


    #Create a subset for those individuals that are direct ancestors of the subordinate.
    ancestors  <- filter(both_relatives, loser_anc)
    ancestors$choice <- ifelse(ancestors$loser_anc == T, Winner)

    ## count the results:
    #If an individual has no direct connection to the loser and their maternal ancestor was lower rank than the losers paternal ancestor...
    #Then this individual will support the regular winner...otherwise it will abstain.
    not_direct$choice <- ifelse(not_direct$passed_threshold, Winner, NA)

    supporters <- c(single_relative$choice, ancestors$choice, not_direct$choice)

    supporters <- dplyr::bind_cols(support_A = sum(supporters %in% indv_A, na.rm = T),
                      support_B = sum(supporters %in% indv_B, na.rm = T))
  }

  return(dplyr::bind_cols(supporters, Ranking = Ranking))

}

#########################################################################################

#' Determines the ranking of two competing relatives in a clan.
#'
#' Determines the ranking of two competing relatives in a clan use within \code{\link{get_supporters}}.
#' @param indv_A Name of focal individual.
#' @param indv_B Name of opponent.
#' @param A_ancestors Ancestors of focal individual.
#' @param B_ancestors Ancestors of opponent.
#' @param A_ancestor_rank Birth rank of most recent common ancestor with focal individual.
#' @param B_ancestor_rank Birth rank of most recent common ancestor with opponent.
#' @param common_ancestor Name of common ancestor between interacting individuals.
#'
#' @import dplyr

relative_fight_outcome <- function(indv_A, indv_B, A_ancestors, B_ancestors, A_ancestor_rank, B_ancestor_rank, common_ancestor){

  #If they don't have a common ancestor
  if (length(common_ancestor) == 0 | is.na(common_ancestor)){
    #Then state they are unrelated
    #The winner cannot be determined
    Winner <- NA
    Ranking <- "Unrelated"
    #Otherwise, if A is a maternal ancestor of B
  } else if (indv_A %in% B_ancestors) {
    #Then A is superior to B
    Winner <- indv_A
    Ranking <- "A_>>_B"
    #Otherwise, if B is a maternal ancestor of A
  } else if (indv_B %in% A_ancestors) {
    #Then B is superior to A
    Winner <- indv_B
    Ranking <- "B_>>_A"
    #Otherwise
  } else {
    #If the rank of the divergent ancestor of the focal and rival individuals is equal (i.e. they were twins)
    if (A_ancestor_rank == B_ancestor_rank) {
      #Then they cannot be distinguished.
      #The winner cannot be determined
      Winner <- NA
      Ranking <- "A0_==_B0"
      #If they are NOT twins
    } else {
      #The individual with the higher ranked ancestor is superior.
      #### DON'T UNDERSTAND THIS PART!!! WHAT IS GOING ON HERE!!
      #IF A0 > B0 then shouldn't A0 > B0 in the A_B object output????
      Winner <- if (A_ancestor_rank > B_ancestor_rank)  indv_A else indv_B
      Ranking <- if(A_ancestor_rank > B_ancestor_rank) "A0_<_BO" else "B0_<_A0"
    }
  }

  Loser <- ifelse(is.na(Winner), NA, ifelse(Winner == indv_B, indv_A, indv_B))
  Loser_ancestors <- if (is.na(Loser)) {
    NA
  } else if (Loser %in% indv_A) {
    A_ancestors
  } else {
    B_ancestors
  }
  #Create a list with the superior individual (GR)
  #The inferior individual (xx)
  #The lineage of the inferior individual (xx_line)
  #And the outcome of the comparison (i.e. was A>B, B<A, A=B)
  #Return this object
  list(Winner, Loser, Loser_ancestors, Ranking)
}

#########################################################################################

#' Determine social support of interacting individuals.
#'
#' @param interactions Data frame/tibble with information on date of interaction (YYYY-MM-DD), clan of interaction, focal individuals, and opponents.
#' @param db Location of database. If unspecified, will use dummy database for examples.
#'
#' @return Returns a dataframe with number of supporters for each individual in all provided contests.
#' @export
#' @import dplyr
#' @import purrr
#'
#' @examples
#' interactions <- data.frame(date = c("2007-08-16", "2007-08-16"), clan_f = c("N", "N"),
#' focal = c("N-006", "N-064"), other = c("N-064", "N-006"), stringsAsFactors = FALSE)
#' output_summary <- calc_social_support(interactions = interactions)

calc_social_support <- function(interactions, db = NULL){

  #Assign NULL to variable names to avoid binding NOTE in R CHECKS
  mothersocial <- . <- support_A <- support_B <- NULL

  clan_members_list <- purrr::map2(.x = as.character(interactions$date), .y = interactions$clan_f, get_clan_members, db = db)

  ancestry_list     <- purrr::map(clan_members_list, get_ancestry, db = db)

  #In the list of all hyenas.
  #Group them by social mother
  #Then rank them by their birthdate (i.e. determine for each mother which are her offspring oldest to youngest.)
  #Then rank them, so that oldest are 1 and youngest are N (number of offspring). Twins are given the same rank.
  hyenas <- extract_db(db = db, tables = "hyenas") %>%
    group_by(mothersocial) %>%
    do(., mutate(., birth_rank = rank(as.Date(.$birthdate), ties.method = "average"))) %>%
    ungroup()

  supporters_list   <- purrr::pmap_df(.l = list(indv_A = interactions$focal, indv_B = interactions$other, ancestry = ancestry_list), get_supporters, hyena_dat = hyenas, db = db)

  output <- bind_cols(interactions, supporters_list) %>%
    mutate(relative_support = support_A - support_B)

  return(output)

}
