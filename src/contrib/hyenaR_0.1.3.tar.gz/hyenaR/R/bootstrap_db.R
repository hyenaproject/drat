#' Build hyena database
#'
#' @param dbname Name of new database to create
#' @param path Location of .csv files used for building database
#'
#' @return Creates an sqlite database.
#' @export
#' @importFrom utils read.csv
#' @import purrr

bootstrap_db <- function(dbname = "Fisidata", path = "."){

  #Assign NULL to prevent global variables note
  hyenas <- sightings <- selections <- clans <- dens <- injuries <- rainfall <- NULL
  interactions <- observationtime <- samples <- sucklings <- videos <- weighing <- NULL

  #Create SQLite db for hyenas
  db_new <- DBI::dbConnect(RSQLite::SQLite(), dbname = paste(path, paste0(dbname, ".sqlite"), sep = "/"))

  #Load all csv files
  files <- list.files(path = path, pattern = ".csv", full.names = TRUE)
  pwalk(.l = list(file_path = files), .f = function(file_path){

    file_name <- strsplit(file_path, "/")[[1]][length(strsplit(file_path, "/")[[1]])]
    file_name <- substr(file_name, start = 1, stop = nchar(file_name) - 7)

    X <- read.csv(file = file_path, header = T, sep = ",", stringsAsFactors = FALSE, na.strings = c("", " ", "NA"))

    #Remove any empty columns? Do we want to do this?
    is_empty <- function(x) !all(is.na(x))
    X <- X %>%
      select_if(is_empty) %>%
      #Trim all character columns (i.e. remove trailing/leading whitespace)
      mutate_if(.predicate = is.character, .funs = trimws) %>%
      #Make any 'clan' column uppercase
      mutate_at(vars(contains("clan"), contains("origin"), contains("destination")), toupper)

    assign(as.character(file_name), X, envir = parent.env(environment()))

  })

  #Before building the database run a number of data checks.
  #These checks are specified in check_db.R
  full_record_check(hyenas = hyenas, selections = selections, sightings = sightings)

  #Our raw rainfall data needs to be re-structured to use in the database.
  rainfall <- rainfall %>%
    #Filter any NA records
    filter(!is.na(location)) %>%
    #Remove the TOTAL column (this can be calculated easily)
    select(-total) %>%
    #Gather data so that there are columns year, month and rainfall.
    tidyr::gather(key = "Month", value = "Rainfall", -year, -location) %>%
    #Change month to be a numeric
    mutate(Month = lubridate::month(lubridate::parse_date_time(Month, orders = "b"))) %>%
    rename(Year = year, Location = location) %>%
    #Arrange chronologically
    arrange(Year, Month)

  DBI::dbWriteTable(conn = db_new, name = "hyenas", value = hyenas, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "sightings", value = sightings, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "clans", value = clans, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "dens", value = dens, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "injuries", value = injuries, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "interactions", value = interactions, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "observationtime", value = observationtime, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "samples", value = samples, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "selections", value = selections, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "sucklings", value = sucklings, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "videos", value = videos, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "weighing", value = weighing, row.names = "id")
  DBI::dbWriteTable(conn = db_new, name = "rainfall", value = rainfall, row.names = "id")

  #Don't add these for now because I'm not sure how they inter-relate.
  #DBI::dbWriteTable(conn = db_new, name = "other_carnivores_sightings", value = carnivores, row.names = "id")
  #DBI::dbWriteTable(conn = db_new, name = "other_carnivore_demo", value = Demo_other, row.names = "id")

  #Create adults view
  Query1 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW adults AS SELECT hyenas.name, hyenas.sex, date(birthdate, '+2 years') AS dateadult, date(MAX(sightings.date), '+1 day') AS deathdate, mothergenetic, mothersocial, DNA FROM hyenas JOIN sightings ON (hyenas.name == sightings.name) GROUP BY hyenas.name HAVING deathdate > dateadult")
  DBI::dbClearResult(Query1)

  #Full_sightings view that also contains contraception views (i.e. 110 days before the birthdate of cubs where parentage is known)
  #Seems that UNION doesn't work with SELECT *?? for now I spell out all...
  Query2 <- DBI::dbSendQuery(conn = db_new,
                             "CREATE VIEW all_sightings AS SELECT date(birthdate, '-110 days') AS date, NULL AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 1 AS sex, 'Estimated from conception' as remarks, father AS name, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM hyenas WHERE father <> '' UNION
                    SELECT date(birthdate, '-110 days') AS date, NULL AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 2 AS sex, 'Estimated from conception' as remarks, mothergenetic AS name, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM hyenas WHERE mothergenetic <> '' UNION
                    SELECT date, time, latitude, longitude, denname, age, sex, remarks, name, name2, clanID, denstop, prey, obsstart, obsstop, sucklingID, denhole, injuryID, earR, earL, altitude, waypoint, observer FROM sightings")
  DBI::dbClearResult(Query2)

  #Create deaths view
  #We now build this from the previous 'all_sightings' view because we want to account for conception date when estimating death
  #i.e. we need to consider that if an individual is known to have conceived of a cub it must have been alive!!
  Query3 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW deaths AS SELECT name, date(max(date), '+1 day') as deathdate FROM all_sightings GROUP BY name HAVING deathdate < date('now', '-1 years')")
  DBI::dbClearResult(Query3)

  #First litter view
  Query4 <- DBI::dbSendQuery(conn = db_new,
                   "CREATE VIEW firstlitter AS SELECT father AS male, MIN(date(birthdate, '-110 days')) AS date_first_litter FROM hyenas WHERE father > 0 GROUP BY father")
  DBI::dbClearResult(Query4)

  DBI::dbDisconnect(db_new)

}
