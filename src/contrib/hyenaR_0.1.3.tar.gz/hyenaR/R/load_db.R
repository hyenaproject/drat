#' Load all database tables for use in functions.
#'
#' This is different to extract_db, which can still be used for extracting single tables (is being depracated).
#' @param db Location of database. If unspecified, will use dummy database file for examples.
#'
#' @return A tibble of tables and table names in the global environment
#' @export
#'
#' @examples
#' load_db()

load_db <- function(db = NULL){

  all_data <- extract_db(db = db)

  .GlobalEnv$database <- tibble(table_name = names(all_data),
                          data = all_data
                          # ,last_date = pmap_dfr(.l = list(output_tibble$data),
                          #                      .f = function(table){
                          #
                          #                        table %>%
                          #                          mutate_at(vars(contains("date")), lubridate::ymd) %>%
                          #                          summarise_at(vars(contains("date")), max)
                          #
                          #                      })
                          )

}
