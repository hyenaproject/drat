#' Calculate observation effort for hyena clans
#'
#' Calculate the observation effort for a given clan over a given date range.
#' Observation effort is proportion of known individuals observed on a given date.
#' N.B. This assumes that number of individuals sighted is related to observer effort.
#'
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param daily Should observation effort be calculated once over the focal period or each day?
#' If FALSE (default), the proportion of individuals sighted over the whole focal period will be calculated.
#' If TRUE, the proportion of individuals on each day of the focal period will be calculated.
#' N.B. When daily == FALSE, dispersing males are only counted in their clan of origin.
#' @param clans Name of clan(s) of interest.
#' If left blank will return a summary of all clans in the specified database.
#'
#' @return A data frame with observation effort for chosen clans over given dates.
#' @export
#'
#' @examples
#'
#' \dontrun{
#'
#' #Estimate observer effort on each day clan A
#' calc_obsveffort(clans = "A", start_date = "2003-01-01", end_date = "2003-12-01", )
#'
#' #Estimate monthly observer effort for all clans in all years
#' possible_dates <- expand.grid(year = seq(1996, 2018, 1),
#' month = seq(1, 12, 1), day = 1) %>%
#' #Create a date object using the above years and months
#' mutate(dates = lubridate::ymd(paste(year, month, day, sep = "-"))) %>%
#' #Filter out any dates that fall outside the range of the database
#' filter(dates >= lubridate::ymd("1996-05-01") & dates <= lubridate::ymd("2018-10-01")) %>%
#' #Order chronologically
#' arrange(dates) %>%
#' #Extract the dates
#' .$dates
#'
#' #Create the start dates and end dates from the above possible dates
#' start_dates <- possible_dates[1:(length(possible_dates)-1)]
#' end_dates <- possible_dates[2:length(possible_dates)]
#'
#' pb <- progress_estimated(n = length(start_dates))
#'
#' total_effort <- pmap_df(.l = list(start_date = as.character(start_dates),
#'                                   end_date = as.character(end_dates)),
#'                         .f = function(start_date, end_date){
#'
#'                             pb$print()$tick()
#'
#'                             return(calc_obsveffort(start_date = start_date,
#'                                                    end_date = end_date))
#'
#'                         })
#'
#'}

calc_obsveffort <- function(clans = NA, start_date = -Inf, end_date = Inf, daily = FALSE){

  #Assign NULL to avoid global variable NOTE
  clanID <- name <- dateadult <- clan <- nr_adults <- nr_cubs <- NULL
  birthdate <- adult <- adult_sightings <- cub_sightings <- age <- start_clan <- NULL

  #Convert start and end_date to date objects
  if(!is.infinite(start_date)){

    start_date <- lubridate::ymd(start_date)

  } else {

    start_date <- lubridate::ymd("1995-01-05")

  }

  if(!is.infinite(end_date)){

    end_date <- lubridate::ymd(end_date)

  } else {

    end_date <- lubridate::ymd(.GlobalEnv$database$data$sightings %>% summarise(latest_date = max(date, na.rm = T)) %>% collect())
    # end_date <- lubridate::ymd(tbl(connection, "sightings") %>% summarise(latest_date = max(date, na.rm = T)) %>% collect())


  }

  #If clans is NA, assume we're wanting observer effort for all clans
  if(all(is.na(clans))){

    clans <- c("A", "E", "F", "L", "M", "N", "S", "T")

  }

  #Load sightings and hyenas table
  #From this we know which individual was observed on each date AND when their age class
  sightings <- .GlobalEnv$database$data$sightings
  hyenas <- .GlobalEnv$database$data$hyenas
  # sightings <- tbl(connection, "sightings")
  # hyenas    <- tbl(connection, "hyenas")

  #If you want observer effort calculated at a daily time scale (i.e. % of individuals seen on any day)
  #then we want to subset our data by both clan and date.

  if(daily){

    #Extract sightings data and subset to just cover the start and end date
    total_sightings <- sightings %>%
      #Filter to only include the specified clans
      filter(date >= start_date & date <= end_date & clanID %in% clans & !is.na(name)) %>%
      #Subset just to variables we want
      select(date, name, clanID) %>%
      #left join in hyena table to include birth date so we know if they were an adult or cub.
      left_join(select(hyenas, name, birthdate), by = "name") %>%
      collect() %>%
      #Specify whether an individual was an adult on the day of observation.
      mutate(adult = lubridate::ymd(date) >= (lubridate::ymd(birthdate) + lubridate::years(2))) %>%
      #Determine total number of sightings of cubs and adults for each clan on each date.
      group_by(date, clanID) %>%
      summarise(total_sightings = n_distinct(name),
                adult_sightings = length(unique(name[adult == 1])),
                cub_sightings = length(unique(name[adult == 0]))) %>%
      ungroup() %>%
      arrange(date, clanID)

    #Determine which clans were observed on each date
    sightings_perdate <- total_sightings %>%
      group_by(date) %>%
      summarise(clanID = list(clanID))

    #For every date where sightings were taken, determine the number of hyenas in the clans sighted at that time
    pb <- dplyr::progress_estimated(n = nrow(sightings_perdate))

    clan_size <- pmap_df(.l = list(date = sightings_perdate$date, clan = sightings_perdate$clanID),
                         .f = function(date, clan){

                           pb$tick()$print()

                           clan_summary(date = date, clan = clan)

                         })

    #For every day between the specified start and end date and for the chosen clans determine the observer effort as number sightings/clan size.
    #When no sightings were made on a given date we assume the clan was not observed
    #N.B. This could be a problem if they look for a clan and couldn't find them...but for now we are assuming that a clan could be found if it was being focused on.
    #An alternative is to use observation time table...need to consider more later.
    obsv_effort <- expand.grid(date = seq(start_date, end_date, by = "days"), clanID = clans, stringsAsFactors = FALSE) %>%
      left_join(total_sightings %>% mutate(date = lubridate::ymd(date)), by = c("date", "clanID")) %>%
      left_join(select(clan_size, date, clanID = clan, nr_adults, nr_cubs, clan_size), by = c("date", "clanID")) %>%
      transmute(date = date, clanID = clanID, obsv_effort_adult = round(pmap_dbl(.l = list(adult_sightings = adult_sightings, nr_adults = nr_adults),
                                                                                 .f = function(adult_sightings, nr_adults){

                                                                                   if(is.na(adult_sightings)){

                                                                                     return(0)

                                                                                   } else {

                                                                                     return(adult_sightings/nr_adults)

                                                                                   }

                                                                                 }), digits = 3),
                obsv_effort_cub = round(pmap_dbl(.l = list(cub_sightings = cub_sightings, nr_cubs = nr_cubs),
                                                 .f = function(cub_sightings, nr_cubs){

                                                   if(is.na(cub_sightings)){

                                                     return(0)

                                                   } else {

                                                     return(cub_sightings/nr_cubs)

                                                   }

                                                 }), digits = 3),
                obsv_effort_all = round(pmap_dbl(.l = list(total_sightings = total_sightings, clan_size = clan_size),
                                                 .f = function(total_sightings, clan_size){

                                                   if(is.na(total_sightings)){

                                                     return(0)

                                                   } else {

                                                     return(total_sightings/clan_size)

                                                   }

                                                 }), digits = 3))

  #Otherwise, if we just want to observer effort calculated across the full time period...
  } else {

    #Extract sightings data and subset to just cover the start and end date
    total_sightings <- sightings %>%
      #Filter to only include the specified clans and the given date range
      filter(date >= start_date & date <= end_date & clanID %in% clans & !is.na(name)) %>%
      #Subset just to variables we want
      select(date, name, clanID) %>%
      #left join in hyena table to include birth date so we know if they were an adult or cub.
      left_join(select(hyenas, name, birthdate), by = "name") %>%
      collect() %>%
      #Specify whether an individual was an adult by the last day of our observation period.
      mutate(age = interval(birthdate, end_date)%/%months(1),
             adult = age > 24) %>%
      #Determine total number of sightings of cubs and adults for each clan over all dates.
      group_by(clanID) %>%
      summarise(total_sightings = n_distinct(name),
                adult_sightings = length(unique(name[adult == 1])),
                cub_sightings = length(unique(name[adult == 0]))) %>%
      ungroup() %>%
      #Include a date column so that it is structurally the same as the other data
      #Just make this date column equal to end_date
      mutate(date = start_date) %>%
      arrange(clanID)

    #Determine who was in each clan over the study period.
    clan_size <- indv_summary(start_date = start_date, end_date = end_date) %>%
      filter(start_clan %in% clans) %>%
      mutate(adult = age > 24) %>%
      group_by(start_clan) %>%
      summarise(date = start_date,
                clan_size = n_distinct(name),
                nr_adults = length(unique(name[adult == 1])),
                nr_cubs = length(unique(name[adult == 0])))

    #In our given period determine the observer effort as number sightings/clan size.
    #When no sightings were made on a given date we assume the clan was not observed
    obsv_effort <- expand.grid(date = start_date, clanID = clans, stringsAsFactors = FALSE) %>%
      left_join(total_sightings %>% mutate(date = lubridate::ymd(date)), by = c("date", "clanID")) %>%
      left_join(select(clan_size, date, clanID = start_clan, nr_adults, nr_cubs, clan_size), by = c("date", "clanID")) %>%
      transmute(date = date, clanID = clanID, obsv_effort_adult = round(pmap_dbl(.l = list(adult_sightings = adult_sightings, nr_adults = nr_adults),
                                                                                 .f = function(adult_sightings, nr_adults){

                                                                                   if(is.na(adult_sightings)){

                                                                                     return(0)

                                                                                   } else {

                                                                                     return(adult_sightings/nr_adults)

                                                                                   }

                                                                                 }), digits = 3),
                obsv_effort_cub = round(pmap_dbl(.l = list(cub_sightings = cub_sightings, nr_cubs = nr_cubs),
                                                 .f = function(cub_sightings, nr_cubs){

                                                   if(is.na(cub_sightings)){

                                                     return(0)

                                                   } else {

                                                     return(cub_sightings/nr_cubs)

                                                   }

                                                 }), digits = 3),
                obsv_effort_all = round(pmap_dbl(.l = list(total_sightings = total_sightings, clan_size = clan_size),
                                                 .f = function(total_sightings, clan_size){

                                                   if(is.na(total_sightings)){

                                                     return(0)

                                                   } else {

                                                     return(total_sightings/clan_size)

                                                   }

                                                 }), digits = 3))



  }

  return(obsv_effort)

}
