#' Test for errors in the database
#'
#' Tests for integrity in the data/missing information including:
#' - All individuals die after being born
#' - All individuals give birth after 1yo
#' - All mothers/fathers are female/male
#' - All individuals have a known sex
#'
#' @param db Location of database. If unspecified, will use dummy database for example.
#' @param verbose Should results be printed as messages?
#'
#' @return Will return a tibble showing number of integrity issues and the data where the issues occur.
#' @export
#' @importFrom lubridate interval
#' @examples
#' \dontrun{
#'
#' ###NOT RUN DUE TO COMPUTATIONAL TIME###
#' #Test integrity on stored database
#' #test_integrity()
#'
#' }

test_integrity <- function(db = NULL, verbose = TRUE){

  #Assign variables as NULL to prevent global binding NOTE in R CMD Check
  birthdate <- last_sighting <- mothergenetic <- motherIsF <- father <- fatherIsM <- NULL
  sex <- alive <- NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Extract all records for every existing individual
  #Do this first so it only needs to be done once.
  all_indv <- indv_summary()

  #################################
  # TEST1: Individuals have a sex #
  #################################

  unk_sex <- all_indv %>%
    filter(is.na(sex) | (sex != "Female" & sex != "Male"))

  number_unk_sex <- unk_sex %>%
    nrow()

  ################################
  # TEST2: Birth is before death #
  ################################

  #Test to see if all individuals have a death date after their birth date
  #Use the function indv_summary.R to get the summary of all dead individuals in the whole population.
  flawed_deaths <- all_indv %>%
    #Filter only those where birthdate < deathdate
    filter(!alive & ymd(birthdate) > ymd(last_sighting))

  number_flawed_deaths <- flawed_deaths %>%
    nrow()

  ###################################
  # TEST3: Parents have correct sex #
  ###################################

  #Extract all individuals with a known mother
  flawed_maternity <- all_indv %>%
    filter(!is.na(mothergenetic)) %>%
    #Check that mother is female
    mutate(motherIsF = map2_lgl(.x = mothergenetic, .y = "Female",
                               .f = ~ifelse(is.na(filter(all_indv, name == .x) %>% .$sex), NA, filter(all_indv, name == .x) %>% .$sex == .y))) %>%
    filter(!motherIsF)

  number_flawed_maternity <- flawed_maternity %>%
    nrow()

  #Extract all individuals with a known father
  flawed_paternity <- all_indv %>%
    filter(!is.na(father)) %>%
    #Check that mother is female
    mutate(fatherIsM = map2_lgl(.x = father, .y = "Male",
                                .f = ~ifelse(is.na(filter(all_indv, name == .x) %>% .$sex), NA, filter(all_indv, name == .x) %>% .$sex == .y))) %>%
    filter(!fatherIsM)

  number_flawed_paternity <- flawed_paternity %>%
    nrow()

  ################################
  # OUTPUT ALL INTEGRITY RESULTS #
  ################################

  if(verbose){

    message(paste("Individuals with unknown sex:", number_unk_sex))
    message(paste("Individuals with death before birth:", number_flawed_deaths))
    message(paste("Males assigned as mothers:", number_flawed_maternity))
    message(paste("Females assigned as mothers:", number_flawed_paternity))
    message("See output for more details.")

  }

  dbDisconnect(connection)

  data_frame(integrity_issue = c("Unk_sex", "Flawed_death", "Flawed_maternity", "Flawed_paternity"),
             total_number = c(number_unk_sex, number_flawed_deaths, number_flawed_maternity, number_flawed_paternity),
             details = list(unk_sex, flawed_deaths, flawed_maternity, flawed_paternity))

}
