context("Test that the load functions for database and other files work properly")

test_that("load_package_database.dummy() creates a hidden global object and returns a message when loading dummy data", {

  # Message saying we are using the dummy database
  expect_message(load_package_database.dummy())
  expect_true(exists(".database"))

})

test_that("deathdate correctly accounts for deathconfirmed information", {

  #Confirmed deaths
  all_deaths <- extract_database_table("hyenas") %>%
    dplyr::left_join(extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(!is.na(deathdate)) %>%
    dplyr::mutate(lastobsv = fetch_id_date.observation.last(ID = ID),
                  deathconfirmed = as.Date(.data$deathconfirmed)) %>% ## FIXME: deathconfirmed is chr because first value is NA
    ## therefore when we writetable to database it coerces to string
    ## May not be a major issue because we want to replace the database
    dplyr::select(ID, deathconfirmed, lastobsv, deathdate)

  confirmed <- all_deaths %>%
    dplyr::filter(!is.na(deathconfirmed))

  #Check that there is a confirmed deaths that is <1yr from last observation
  #These are needed to check the SQL code
  #Want to provide this warning in case we change how the dummy data is calculated
  if (all(find_pop_date.observation.last() - confirmed$deathconfirmed > 365)) {

    warning("No individuals with recent deathconfirmed (<365 days since last observation) in the dummy database.
            We cannot fully test death dates.")

  }

  unconfirmed <- all_deaths %>%
    dplyr::filter(is.na(deathconfirmed))

  #When death is confirmed, deathdate should be exactly the same as deathconfirmed
  expect_true(all(confirmed$deathconfirmed == confirmed$deathdate))

  #When death is unconfirmed, deathdate should be one day after the last observation
  expect_true(all(unconfirmed$deathdate == unconfirmed$lastobsv + 1))

})

test_that("Data with missing time data is loaded", {

  #Injuries L-092 record should exist
  output <- extract_database_table("injuries") %>%
    dplyr::filter(.data$ID == "L-092")

  expect_true(nrow(output) > 0L)
  expect_equal(nrow(output), 1L)
  expect_equal(lubridate::hour(output$date_time), 0L)

})

test_that("we can load a multisheet excel file", {

  #Example data collected from IZW is stored with the package for example
  ref <- load_data_excel(system.file("extdata/weather_Mlima", "weather_data_test1.xlsx", package = "hyenaR"))

  #Expect a list output containing 3 tibbles
  expect_equal(class(ref), "list")
  expect_equal(length(ref), 3L)
  expect_true(all(sapply(lapply(ref, class), function(x){

    "data.frame" %in% x

  })))

})

test_that("load_data_weatherstation.file correctly recodes weather station data", {

  ref <- structure(list(station_name = c("jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
                                         "jua", "jua", "jua", "jua", "jua", "jua", "jua"),
                        site_name = c("ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
                                      "ngoitokitok", "ngoitokitok"),
                        date_time = structure(c(1633039200,
                                                1633041000, 1633042800, 1633044600, 1633046400, 1633048200, 1633050000,
                                                1633051800, 1633053600, 1633055400, 1633057200, 1633059000, 1633060800,
                                                1633062600, 1633064400, 1633066200, 1633068000, 1633069800, 1633071600,
                                                1633073400, 1633075200, 1633077000, 1633078800, 1633080600, 1633082400,
                                                1633084200, 1633086000, 1633087800, 1633089600, 1633091400, 1633093200,
                                                1633095000, 1633096800, 1633098600, 1633100400, 1633102200, 1633104000,
                                                1633105800, 1633107600, 1633109400, 1633111200, 1633113000, 1633114800,
                                                1633116600, 1633118400, 1633120200, 1633122000, 1633123800),
                                              class = c("POSIXct",
                                                        "POSIXt"), tzone = "Africa/Dar_es_Salaam"),
                        latitude = c(52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091, 52.5057091,
                                     52.5057091, 52.5057091, 52.5057091, 52.5057091),
                        longitude = c(13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943,
                                      13.5214943, 13.5214943, 13.5214943, 13.5214943, 13.5214943),
                        air_temp = c(18.48, 17.86, 17.04, 16.58, 16.23, 16.01, 15.89,
                                     15.78, 15.98, 15.78, 15.45, 15.21, 15.04, 14.9, 14.91, 15.55,
                                     17.31, 18.12, 18.61, 19.22, 19.86, 20.87, 21.34, 22.12, 22.84,
                                     23.33, 23.76, 24.82, 24.94, 25.29, 25.43, 25.71, 24.88, 24.65,
                                     24.1, 23.94, 23.2, 22.17, 20.49, 18.75, 16.3, 16.31, 14.93,
                                     15.38, 15.6, 16.31, 15.58, 15.71),
                        atmospheric_pressure = c(82.7,
                                                 82.72, 82.68, 82.66, 82.67, 82.7, 82.69, 82.68, 82.7, 82.74,
                                                 82.75, 82.77, 82.8, 82.83, 82.84, 82.87, 82.9, 82.92, 82.96,
                                                 82.98, 82.97, 82.95, 82.93, 82.9, 82.86, 82.79, 82.75, 82.7,
                                                 82.64, 82.6, 82.56, 82.54, 82.53, 82.54, 82.55, 82.55, 82.55,
                                                 82.57, 82.58, 82.6, 82.62, 82.66, 82.69, 82.71, 82.73, 82.76,
                                                 82.79, 82.78),
                        relative_humidity = c(0.660576873826198, 0.704416182646831,
                                              0.775342799005621, 0.803617108420954, 0.826607175907493,
                                              0.842143284958125, 0.840864848223909, 0.842335149047108,
                                              0.828878354174753, 0.840102318963485, 0.848928881242678,
                                              0.850531302007649, 0.849929308324724, 0.857034283779824,
                                              0.858843474548927, 0.832739858100878, 0.766258018642565,
                                              0.722828687067864, 0.690688860967215, 0.672062650500209,
                                              0.635064561232434, 0.592203463191583, 0.582844205733391,
                                              0.533544620338299, 0.509625853642058, 0.486363325027701,
                                              0.470517076213227, 0.425908229561272, 0.41526145662836, 0.396448489533969,
                                              0.383002077301439, 0.378808053497084, 0.381756253476725,
                                              0.37607045766428, 0.38533318823834, 0.379293984999927, 0.394480604370654,
                                              0.425912127085715, 0.485814626156182, 0.53200418788865, 0.617195563176197,
                                              0.618960968477435, 0.675579088741605, 0.659750303173205,
                                              0.635262262428236, 0.615723160447039, 0.658692908650608,
                                              0.651549338889926),
                        precip = c(0, 0, 0, 0, 0, 0, 0, 0, 0,
                                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                   0),
                        precip_max_hourly = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                        battery_percent = c(100,
                                            100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
                                            100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
                                            100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
                                            100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100)),
                   row.names = c(NA, -48L), class = c("tbl_df", "tbl", "data.frame"),
                   metadata = structure(list(metadata_category = c("configuration", "software", "location",
                                                                   "cellular", "cellular_hardware", "sensors", "errors"),
                                             data = list(structure(list(info = c("device_name", "site_name", "serial_number",
                                                                                 "device_type", "firmware_version", "hardware_version",
                                                                                 "measurement_interval"),
                                                                        value = c("jua", "ngoitokitok",
                                                                                  "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                                        error = c(FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                                        message = c(NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_)),
                                                                   class = c("tbl_df", "tbl",
                                                                             "data.frame"),
                                                                   row.names = c(NA, -7L)),
                                                         structure(list(info = "software_version",
                                                                        value = "1.23.7",
                                                                        error = FALSE,
                                                                        message = NA_character_),
                                                                   class = c("tbl_df", "tbl",
                                                                             "data.frame"),
                                                                   row.names = c(NA, -1L)),
                                                         structure(list(info = c("latitude", "longitude", "logger_time",
                                                                                 "time_zone", "satellite_vehicles", "gps_fix_status",
                                                                                 "horizontal_accuracy", "altitude"),
                                                                        value = c("52.5057091",
                                                                                  "13.5214943", "11/30/21_12:00:50", "utc+03", "12",
                                                                                  "5", "1096", "1759.987"),
                                                                        error = c(TRUE, TRUE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE),
                                                                        message = c("Weather station location is outside the crater!",
                                                                                    "Weather station location is outside the crater!",
                                                                                    NA, NA, NA, NA, NA, NA)),
                                                                   class = c("tbl_df", "tbl",
                                                                             "data.frame"),
                                                                   row.names = c(NA, -8L)),
                                                         structure(list(info = c("uploading", "12:00-12:59_am", "1:00-1:59_am",
                                                                                 "2:00-2:59_am", "3:00-3:59_am", "4:00-4:59_am", "5:00-5:59_am",
                                                                                 "6:00-6:59_am", "7:00-7:59_am", "8:00-8:59_am", "9:00-9:59_am",
                                                                                 "10:00-10:59_am", "11:00-11:59_am", "12:00-12:59_pm",
                                                                                 "1:00-1:59_pm", "2:00-2:59_pm", "3:00-3:59_pm", "4:00-4:59_pm",
                                                                                 "5:00-5:59_pm", "6:00-6:59_pm", "7:00-7:59_pm", "8:00-8:59_pm",
                                                                                 "9:00-9:59_pm", "10:00-10:59_pm", "11:00-11:59_pm",
                                                                                 "upload_frequency"),
                                                                        value = c("false", "true", "false",
                                                                                  "false", "false", "true", "true", "true", "true",
                                                                                  "true", "true", "true", "true", "true", "true", "true",
                                                                                  "true", "true", "true", "true", "true", "true", "true",
                                                                                  "true", "false", "do_not_upload_data"),
                                                                        error = c(FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE),
                                                                        message = c(NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_)),
                                                                   class = c("tbl_df", "tbl", "data.frame"
                                                                   ),
                                                                   row.names = c(NA, -26L)),
                                                         structure(list(info = c("sim_number",
                                                                                 "modem_firmware_version", "modem_type"),
                                                                        value = c("8944500502190551847",
                                                                                  "2341", "3"),
                                                                        error = c(FALSE, FALSE, FALSE),
                                                                        message = c(NA_character_,
                                                                                    NA_character_, NA_character_)),
                                                                   class = c("tbl_df", "tbl",
                                                                             "data.frame"),
                                                                   row.names = c(NA, -3L)),
                                                         structure(list(info = c("port_#", "name", "serial_num", "meta",
                                                                                 "value", "status", "version", "port_#", "name", "serial_num",
                                                                                 "meta", "value", "status", "version", "port_#", "name",
                                                                                 "serial_num", "meta", "value", "status", "version",
                                                                                 "port_#", "name", "serial_num", "meta", "value",
                                                                                 "status", "version", "port_#", "name", "serial_num",
                                                                                 "meta", "value", "status", "version", "port_#", "name",
                                                                                 "serial_num", "meta", "value", "status", "version"),
                                                                        value = c("1", "none_selected", NA, "0", "0",
                                                                                  "0", "0", "2", "none_selected", NA, "0", "0", "0",
                                                                                  "0", "3", "atmos_14_humidity/temp/barometer", "16422-04-709",
                                                                                  "0", "0", "1", "104", "4", "ecrn-100_precipitation",
                                                                                  NA, "0", "0", "0", "0", "5", "none_selected", NA,
                                                                                  "0", "0", "0", "0", "6", "none_selected", NA, "0",
                                                                                  "0", "0", "0"),
                                                                        error = c(FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE),
                                                                        message = c(NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_)),
                                                                   class = c("tbl_df", "tbl", "data.frame"),
                                                                   row.names = c(NA, -42L)),
                                                         structure(list(info = c("ereset:",
                                                                                 "ememory:", "eclock:", "eradio:", "exfer:", "ecommand:",
                                                                                 "ebattery:", "ctestbtn:", "emeasurement:", "esensor[1]:",
                                                                                 "esensor[2]:", "esensor[3]:", "esensor[4]:", "esensor[5]:",
                                                                                 "esensor[6]:", "esensor[7]:", "esensor[8]:", "egps:",
                                                                                 "eble:", "ecellinit:", "esim:", "eattachcell:", "eip:",
                                                                                 "last_updated"),
                                                                        value = c("0", "0", "0", "0", "0", "0",
                                                                                  "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                                                                  "0", "0", "0", "0", "0", "0", "11/30/21_00:23:47"),
                                                                        error = c(FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                  FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                                        message = c(NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_, NA_character_,
                                                                                    NA_character_, NA_character_, NA_character_)),
                                                                   class = c("tbl_df", "tbl", "data.frame"),
                                                                   row.names = c(NA, -24L))),
                                             any_error = c(FALSE,
                                                           FALSE, TRUE, FALSE, FALSE, FALSE, FALSE),
                                             messages = list(
                                               NA_character_, NA_character_, "Weather station location is outside the crater!",
                                               NA_character_, NA_character_, NA_character_, NA_character_)),
                                        row.names = c(NA, -7L),
                                        class = c("tbl_df", "tbl", "data.frame")))

  #Use data that throws warning to check that this is being passed to meta-data
  job <- load_data_weatherstation.file(system.file("extdata/test_weather_Mlima_fail",
                                                   "weather_data_test1.xlsx",
                                                   package = "hyenaR"), verbose = FALSE)

  #Check output list is correct
  #expect_equal(ref, job) ## COMMENTED BECAUSE CREATE ISSUES ON SOME COMPUTERS

})
