#' Create tidy tables with hyena(s)
#'
#' These functions are used to create tidy tables. Each row correspond to an
#' individual hyena (but see the exception of `create_tbl_metadata()` in Details).
#' Depending on the function, individuals can be repeated or not. All functions from the
#' create family, provide at least a column with the ID of the hyena, and possibly other columns
#' depending on the function and the defined arguments. The produced tables are always of format
#' [tibble::tibble] and can be used as the basic structure around which you can add additional
#' columns using the functions from the [fetch_family].
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' The exception to the general rules of create functions is `create_tbl_metadata()`. This
#' function takes a table and return a tidy table of meta-data information where each row
#' corresponds to a meta-data category.
#'
#' @inheritParams arguments
#' @return A tidy table
#'
#' @name create_family
#' @aliases create_family create
#'
#' @examples
#'
#'
#' ### Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL


#' @describeIn create_family create a tidy table with individuals, their mates, and estimated mating date.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_id_mate.conception.table usage:
#' create_id_mate.conception.table(c("A-001", "L-003", "A-098"))
#'
create_id_mate.conception.table <- function(ID){

  ID <- check_function_arg.ID(ID)

  input <- tibble::tibble(ID = ID)

  create_id_offspring.table(ID) %>%
    dplyr::filter(.data$filiation != "mother_social" | is.na(.data$filiation)) %>%
    dplyr::rename(ID = .data$parentID) %>%
    dplyr::mutate(
      focal_sex = fetch_id_sex(.data$ID),
      offspring_birthdate = fetch_id_date.birth(.data$offspringID),
      mate = dplyr::case_when(
        focal_sex == "male" ~ fetch_id_id.mother.genetic(.data$offspringID),
        focal_sex == "female" ~ fetch_id_id.father(.data$offspringID),
        TRUE ~ NA_character_
      ),
      date = .data$offspring_birthdate - 110
    ) %>%
    dplyr::select(.data$ID, .data$mate, .data$date) %>%
    dplyr::distinct() %>%
    dplyr::left_join(x = input, y = ., by = "ID") %>%
    dplyr::arrange(.data$ID, .data$date) -> output

  output
}


#' @describeIn create_family create a tidy table with individuals, their
#' offspring, and the offspring-parent relationship (mother_genetic, mother_social,
#' mother_social_genetic, father) which is called 'filiation'.
#'
#' @export
#' @returns A data frame with all parent/offspring relationships.
#' @examples
#' #### Simple example of create_id_offspring.table usage:
#' ## If 'first.event' is 'birthdate' (default), the function will retrieve
#' ## all offspring born from the given IDs in their entire life.
#' create_id_offspring.table(ID = "A-001")
#' create_id_offspring.table(ID = "A-011")
#' create_id_offspring.table(ID = "A-058")
#' create_id_offspring.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
#'                                             from = "1994-01-01", to = "1995-01-01")
#' create_id_offspring.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
#'                                                                  at = "1995-01-01")
#'
#' ## If 'first.event' is 'observation', the function will retrieve the offspring
#' ## born from the given ID within the first and last observation.
#' create_id_offspring.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
#'                                                          first.event = "observation")

create_id_offspring.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                      fill = TRUE, first.event = "birthdate", debug = FALSE) {

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ## check and process argument:
  ID <- check_function_arg.ID(ID, fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date,
                                                 arg.max.length = 1L)
  from       <- date_range$from
  to         <- date_range$to

  ## All offspring
  extract_database_table(tbl.names = "hyenas") %>%
    dplyr::select(offspringID = .data$ID, .data$birthdate, .data$mothergenetic,
                  .data$mothersocial, .data$father) %>%
    tidyr::pivot_longer(cols = c(.data$mothergenetic:.data$father),
                        names_to = "filiation", values_to = "parentID",
                        values_drop_na = TRUE, values_transform = list(parentID = as.character)) %>%
    dplyr::filter(.data$parentID %in% !!ID) %>%
    dplyr::group_by(.data$parentID, .data$offspringID) %>%
    dplyr::summarise(filiation = dplyr::case_when(dplyr::n() > 1 ~ "mother_social_genetic",
                                                  .data$filiation[1] == "mothergenetic" ~ "mother_genetic",
                                                  .data$filiation[1] == "mothersocial" ~ "mother_social",
                                                  TRUE ~ .data$filiation[1]), .groups = "drop",
                     birthdate = dplyr::first(.data$birthdate)) -> all_offspring

  #Filter by birthdate
  all_offspring %>%
    dplyr::filter(.data$birthdate >= from, .data$birthdate <= to) %>%
    dplyr::select(.data$parentID, .data$offspringID, .data$birthdate, .data$filiation) -> df_offspring_from_parents

  check_function_output(input.tbl = tibble::tibble(parentID = ID), output.tbl = df_offspring_from_parents, join.by = "parentID",
                        duplicates = "output", debug = debug)

}


#' @describeIn create_family create a tidy table with mothers, their offspring and the litter ID. This is an internal function and
#' should be used only by developers.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_offspring_litterID.from.mother usage:
#' create_offspring_litterID.from.mother(parentID = c("A-001", "A-058"))
#' create_offspring_litterID.from.mother(parentID = "A-058")
#'
create_offspring_litterID.from.mother <- function(parentID = NULL, debug = FALSE) {

  #If no parent is given, use all non-male IDs (i.e. we also include NAs)
  if (is.null(parentID)) {

    parentID <- find_pop_id(sex = c("female", NA))

  } else {

    parentID <- check_function_arg.ID(parentID, argument.name = 'parentID')

  }

  parent <- tibble::tibble(parentID = parentID)
  ## Check the sex of the given ID
  sex <- fetch_id_sex(parent$parentID)
  if (any(!is.na(sex) & sex == "male")) stop("The function works only with females")

  ## Fetch the birthdate to calculate whether to include social cubs or not in the litter.
  create_id_offspring.table(ID = parent$parentID) %>%
    dplyr::mutate(birth_offspringID = fetch_id_date.birth(.data$offspringID)) -> offspring.with.birthdate

  offspring.with.birthdate %>%
    dplyr::group_by(.data$parentID) %>%
    ## One row for each litter/birthdate to calculate differences in days among birthdates of different litters
    dplyr::distinct(.data$birth_offspringID, .data$filiation) %>%
    dplyr::arrange(.data$birth_offspringID, .by_group = TRUE) %>%
    ## Social cubs are included in the social mother's genetic litters if born 90 days
    ## Backwards or afterwards the birthdate of the litter:
    dplyr::mutate(previous_birthdate = dplyr::lag(.data$birth_offspringID),
                  next_birthdate = dplyr::lead(.data$birth_offspringID)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(diff_prev = .data$birth_offspringID - .data$previous_birthdate,
                  diff_next = .data$next_birthdate - .data$birth_offspringID,
                  inclusion_birthdate = dplyr::case_when(.data$filiation == "mother_genetic" | .data$filiation == "mother_social_genetic" ~ .data$birth_offspringID,
                                                         .data$filiation == "mother_social" & .data$diff_next <= 90 ~ .data$next_birthdate,
                                                         .data$filiation == "mother_social" & .data$diff_prev <= 90 ~ .data$previous_birthdate,
                                                         TRUE ~ .data$birth_offspringID)) %>%
    dplyr::select(.data$parentID, .data$birth_offspringID, .data$inclusion_birthdate) -> offspring_from_females_with_inclusion_birthdate

  ## Birthdates within each mother are duplicated for each offspring born at the same date
  ## By that, each offspring born from the same mother at the same date will be assigned the same litter:
  dplyr::full_join(offspring.with.birthdate, offspring_from_females_with_inclusion_birthdate, by = c("parentID",  "birth_offspringID")) %>%
    dplyr::select(.data$parentID, .data$offspringID, .data$filiation, .data$inclusion_birthdate) -> offspring_from_females

  ## litterID will be "mothercode-00+litterorder", if parent didn't have offspring will be NA:
  offspring_from_females %>%
    dplyr::group_by(.data$parentID) %>%
    dplyr::mutate(litter_order = dplyr::dense_rank(.data$inclusion_birthdate),
                  litterID = dplyr::if_else(is.na(.data$offspringID), NA_character_,
                                            paste(.data$parentID, formatC(.data$litter_order, width = 3, flag = "0"), sep = "_"))) %>%
    dplyr::ungroup() %>%
    dplyr::select(-.data$litter_order, -.data$inclusion_birthdate) %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(.data$offspringID)) %>%
    dplyr::distinct() -> littersID_females

  check_function_output(input.tbl = parent, output.tbl = littersID_females, join.by = "parentID",
                        duplicates = "output", debug = debug)
}

#' @describeIn create_family create a tidy table with fathers, their offspring and the litter ID. This is an internal function and
#' should be used only by developers.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_offspring_litterID.from.father usage:
#' create_offspring_litterID.from.father(parentID = c("A-011", "A-040"))
#' create_offspring_litterID.from.father(parentID = "A-058")
#'
create_offspring_litterID.from.father <- function(parentID = NULL, debug = FALSE) {

  #If no parent is given, use all non-male IDs (i.e. we also include NAs)
  if (is.null(parentID)) {

    parentID <- find_pop_id(sex = c("male", NA))

  } else {

    parentID <- check_function_arg.ID(parentID, argument.name = 'parentID')

  }

  parent <- tibble::tibble(parentID = parentID)
  sex <- fetch_id_sex(parent$parentID)
  ## Check the sex of the given IDs
  if (any(!is.na(sex) & sex == "female")) stop("The function works only with males")

  create_id_offspring.table(ID = parent$parentID) %>%
    ## Fetch the litterID from the genetic mother of father's offspring.
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID, filiation = "mother_genetic"),
                  birthdate = fetch_id_date.birth(.data$offspringID)) -> litters.father

  check_function_output(input.tbl = parent, output.tbl = litters.father, join.by = "parentID",
                        duplicates = "output", debug = debug)
}

#' @describeIn create_family create a tidy table with fathers and/or mothers, their offspring and the litter ID.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_offspring_litterID.from.mother usage:
#' create_offspring_litterID.from.all(parentID = c("A-001", "A-040"))
#' create_offspring_litterID.from.all(parentID = c("A-011", "A-058"))
#' create_offspring_litterID.from.all(parentID = "A-058")
#'
create_offspring_litterID.from.all <- function(parentID = NULL, debug = FALSE) {
  parentID <- check_function_arg.ID(parentID, fill = TRUE, argument.name = 'parentID')
  all <- tibble::tibble(parentID = parentID)
  ## We fetch the sex to separate individuals in two different tibbles
  all %>%
    dplyr::mutate(sex = fetch_id_sex(.data$parentID)) -> all.sex

  all.sex %>%
    dplyr::filter(.data$sex == "female") %>%
    dplyr::select(.data$parentID) -> females

  all.sex %>%
    dplyr::filter(.data$sex == "male" | is.na(.data$sex)) %>%
    dplyr::select(.data$parentID) -> males

  if (nrow(females) > 0 && nrow(males) > 0) {
    create_offspring_litterID.from.mother(females$parentID) -> litterID_females
    create_offspring_litterID.from.father(males$parentID) -> litterID_males
    ## LitterIDs for mothers and fathers are combined.
    dplyr::full_join(litterID_females, litterID_males,
                     by = c("parentID", "offspringID", "filiation", "litterID", "birthdate")) %>%
      dplyr::distinct()  -> litterID_all
  } else if (nrow(females) > 0 && nrow(males) == 0) {
    create_offspring_litterID.from.mother(females$parentID) -> litterID_all
  } else if (nrow(females) == 0 && nrow(males) > 0 ) {
    create_offspring_litterID.from.father(males$parentID) -> litterID_all
  }
  ## The output is arranged to make it equal to the one obtained with the old function.
  litterID_all %>%
    dplyr::arrange(.data$parentID, .data$litterID) -> litterID_all

  check_function_output(input.tbl = all, output.tbl = litterID_all, join.by = "parentID",
                        duplicates = "output", debug = debug)
}


#' @describeIn create_family create a table of the life history of focal individual(s)
#'
#' @export
#' @examples
#'
#'  #### Simple example of create_life_history usage:
#'  create_id_life.history.table(c("A-001", "L-003", "A-098"))
#'
create_id_life.history.table <- function(ID = NULL, censored.to.last.sighting = FALSE, verbose = TRUE, .cache = TRUE) {

  ## Check that the user did not set .cache to FALSE (only the Recall should modify this argument!)
  stack <- sys.calls()
  if (!.cache && (length(stack) == 1 || (length(stack) > 1 && as.character(stack[[length(stack) - 1]][[1]]) != "Recall"))) {
    warning("create_id_life.history.table() has been called with .cache = FALSE by the user, make sure you know what you are doing.")
  }

  check_database_is.loaded() ## Check .database exists before checking for caching
  messages <- vector()

  input <- tibble::tibble(ID = check_function_arg.ID(ID, fill = TRUE)) ## TODO: USE GLOBAL VERBOSE ARGUMENT TO PRINT MESSAGE

  if (.cache && "life_history" %in% .database$database$table_name){

    lastsighting  <- find_pop_date.observation.last()

    extract_database_table("life_history") %>%
      dplyr::filter(.data$ID %in% input$ID) -> output

  } else {

    if (.cache) { ##TODO: Make a global option for future caching behaviour in create

      #messages <- append(messages, "Caching life history table (only happen the first time the function is being called, for speed up in future calls). \n")
      message("Caching life history table (only happens the first time the function is being called, for speed up in future calls. Be patient)...") ## Display msg straight away in this case!

      full_output <- Recall(ID = check_function_arg.ID(fill = TRUE), .cache = FALSE) ## Recursive call to the function

      build_package_database.append.table(tbl = full_output, tbl.name = "life_history")

      full_output %>%
        dplyr::filter(.data$ID %in% input$ID) -> output

    } else {

      create_id_life.transition.table(input$ID) %>%
        dplyr::select(-.data$origin) %>%
        dplyr::rename(clan = .data$destination) -> selections

      ## Life history before selection: splitting first row in the selection table
      selections %>%
        dplyr::group_by(.data$ID) %>%
        dplyr::arrange(date, .by_group = TRUE) %>% ## in case data are not ordered
        dplyr::mutate(sec_tran_date = dplyr::lead(.data$date)) %>% # adding the date when the second life transition happened
        dplyr::slice(1) %>%
        dplyr::ungroup() %>%
        dplyr::mutate(
          sex = fetch_id_sex(.data$ID),
          date_first_selection = fetch_id_date.selection.first(.data$ID),
          date_age_1 = fetch_id_date.at.age(.data$ID, 1),
          date_age_2 = fetch_id_date.at.age(.data$ID, 2),
          cub = .data$date,
          subadult = dplyr::if_else(fetch_id_is.alive(.data$ID, .data$date_age_1) &
                                      (is.na(.data$sec_tran_date) | .data$sec_tran_date > .data$date_age_1), .data$date_age_1, as.Date(NA)), # remove subadult stage if first selection happened before 1 year old
          ## Individuals from clan X cannot be classified as 'natal' because we don't know the exact date of first selection
          natal = dplyr::if_else(.data$clan != "X" & ((is.na(.data$sex) | .data$sex == "male") & (is.na(.data$date_first_selection) | .data$date_age_2 < .data$date_first_selection)) & fetch_id_is.alive(.data$ID, .data$date_age_2), .data$date_age_2, as.Date(NA)),
          # dead = fetch_id_date.death(.data$ID)
        ) -> life_history_before_selection_wide

      life_history_before_selection_wide %>%
        dplyr::select(-.data$date, -.data$date_age_1, -.data$date_age_2, -.data$sex) %>%
        tidyr::pivot_longer(cols = c("cub", "subadult", "natal"),
                            names_to = "life_stage",
                            values_to = "starting_date") %>%
        dplyr::filter(!is.na(.data$starting_date)) -> life_history_before_selection

      main.clans <- find_clan_name.all()

      ## Life history after selection
      selections %>%
        dplyr::mutate(is_transient = .data$clan == "Y",
                      is_founder = fetch_id_is.founder(.data$ID),
                      birth_clan = fetch_id_clan.birth(.data$ID),
                      sex = fetch_id_sex(.data$ID)) %>%
        dplyr::group_by(.data$ID) %>%
        dplyr::arrange(date, .by_group = TRUE) %>%  ## in case data are not ordered
        dplyr::slice(-1) %>%
        dplyr::mutate(selection_times = dplyr::dense_rank(.data$date),
                      life_stage = dplyr::case_when(
                        #All founder males (i.e. born before start of study) that have either unknown birth clan ("X") or
                        #birth clan outside of the crater (non-main clans) are given life_stage 'founder_male'
                        #This is a special case where both disperser status (disperser, philopatric) and number of previous selections
                        #is unknown.
                        #Note: males that were cub/subadult/natal at the start of the study
                        #are assumed to be in their birth clan at the start of study, because it is *very likely* that they haven't previously dispersed.
                        #Therefore, they will not be given status 'founder_male'
                        .data$selection_times == 1 & .data$sex == "male" & .data$is_founder & !.data$birth_clan %in% main.clans ~ "founder_male",
                        ## Individuals that have either unknown birth clan ("X") or
                        ## birth clan outside of the crater (non-main clans) but are NOT founders are given life_stage 'foreigner_1'
                        ## on their first observed selection.
                        ## Unlike 'founder_male' we know these individuals must have dispersed from their birth clan (because we monitor all crater clans)
                        ## however, we still do NOT know the number of previous selections.
                        ## Individuals that have either unknown birth clan ("X") or birth clan outside of the crater (non-main clans)
                        ## are called foreigner_X for every selection following their first (excluding periods of transience)
                        ## In this case, we know they have made clan selections a *minimum* of X times
                        ## This includes individuals classified as both 'founder_male' and 'foreigner_1' on their first selection.
                        .data$selection_times > 1 & !.data$birth_clan %in% main.clans ~ paste0("foreigner_", .data$selection_times - cumsum(.data$is_transient)),
                        #For all other sexually active individuals, life stage is either philopatric or disperser
                        #depending on whether they stay in birth clan or not on their first selection.
                        .data$selection_times == 1 & .data$clan == .data$birth_clan ~ "philopatric",
                        .data$selection_times == 1 & .data$clan != .data$birth_clan ~ "disperser",
                        #Transient if in clan Y
                        is_transient ~  "transient",
                        ## All other individuals are made 'selector_X' for each subsequent selection (excluding periods of transience)
                        ## In this case, we know they have made clan selections *exactly* X times
                        TRUE ~ paste0("selector_", .data$selection_times - cumsum(.data$is_transient))
                      )
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(.data$ID, .data$clan, starting_date = .data$date, .data$life_stage) -> life_history_after_selection

      dplyr::bind_rows(life_history_before_selection, life_history_after_selection) %>%
        dplyr::arrange(.data$ID, .data$starting_date) -> all_lifestages

      all_lifestages %>%
        dplyr::group_by(.data$ID) %>%
        dplyr::summarise(clan = .data$clan[dplyr::n()],
                         life_stage = "dead",
                         starting_date = fetch_id_date.death(.data$ID[1])) %>%
        dplyr::ungroup() %>%
        dplyr::filter(!is.na(.data$starting_date)) -> deaths

      #lastsighting  <- find_pop_date.observation.last()
      firstsighting <- find_pop_date.observation.first()

      # Merge stages together and calculate the ending date of each stage by creating a column of dislocated starting date
      dplyr::bind_rows(all_lifestages, deaths) %>%
        dplyr::arrange(.data$ID, .data$starting_date) %>%
        dplyr::group_by(.data$ID) %>%
        dplyr::mutate(ending_date = tidyr::replace_na(dplyr::lead(.data$starting_date) - 1, as.Date(Inf, origin = "1970-01-01"))) %>%
        dplyr::filter(!is.infinite(.data$starting_date) | !is.infinite(.data$ending_date)) %>%
        dplyr::ungroup() %>%
        dplyr::mutate(
          isrightcensored = is.infinite(.data$ending_date),
          isleftcensored  = .data$starting_date < !!firstsighting,
          ending_date_na_as_na = .data$ending_date,
          ending_date_na_as_last_sighting = dplyr::case_when(is.infinite(.data$ending_date) & life_stage != "dead" ~ fetch_id_date.observation.last(.data$ID),
                                                             TRUE ~ .data$ending_date)

        ) %>%
        dplyr::select(.data$ID, .data$clan, .data$life_stage, .data$starting_date, .data$ending_date_na_as_na, .data$ending_date_na_as_last_sighting, .data$isrightcensored,  .data$isleftcensored) -> output

    }
  }

  ## When using the cache, we need to select what to use as ending date, since both alternatives are present in the cached version:
  if (.cache) {
    if(!censored.to.last.sighting) {
      output %>%
        dplyr::rename(ending_date = .data$ending_date_na_as_na) %>%
        dplyr::select(- .data$ending_date_na_as_last_sighting) -> output
    } else {
      output %>%
        dplyr::rename(ending_date = .data$ending_date_na_as_last_sighting) %>%
        dplyr::select(- .data$ending_date_na_as_na) -> output
    }
  }

  output <- check_function_output(input.tbl = input,
                                  output.tbl = output,
                                  join.by = "ID",
                                  duplicates = "output")


  if (verbose && length(messages) > 0) { ## TODO: USE GLOBAL VERBOSE ARGUMENT

    message(messages, appendLF = FALSE)

  }

  output

}

#' @describeIn create_family create a tidy table with individuals and their selection events.
#'
#' @export
#'
#' @examples
#' #### Simple examples of create_id_life.transition.table usage:
#' create_id_life.transition.table(c("A-001", "L-003", "A-098"))
#'
create_id_life.transition.table <- function(ID = NULL) {

  ID <- check_function_arg.ID(ID, fill = TRUE)

  input <- tibble::tibble(ID = ID)

  lastsighting <- find_pop_date.observation.last()

  ## Extract selection event from selection table
  selections <- extract_database_table("selections")
  focal_selections_no_young_females <- selections[selections$ID %in% input$ID, ]

  ## Extract the first event in selection table for each ID, so there will be not repetition when doing left join later
  focal_selections_no_young_females %>%

    dplyr::arrange(ID, date) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::select(.data$ID, .data$date) %>%
    dplyr::rename(selection_date = .data$date) -> first_selection

  ## Add female philopatry in the selection event
  input %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID),
                  date_age_2 = fetch_id_date.at.age(.data$ID, 2),
                  first_conception_date = fetch_id_date.conception.first(.data$ID)) %>%
    dplyr::filter(.data$sex == "female" & fetch_id_is.alive(.data$ID, .data$date_age_2) & .data$date_age_2 < !!lastsighting) %>%
    dplyr::mutate(origin = fetch_id_clan.birth(.data$ID),
                  destination = .data$origin,
                  date = dplyr::if_else(.data$date_age_2 < .data$first_conception_date | is.na(.data$first_conception_date), .data$date_age_2, .data$first_conception_date)) %>%
    # If a female dispersed before 2 year old she would not become philopatric
    dplyr::left_join(x = ., y = first_selection, by = "ID") %>%
    dplyr::filter(is.na(.data$selection_date) | .data$selection_date > .data$date) %>%
    dplyr::select(.data$ID, .data$origin, .data$destination, .data$date) -> female_philopatry

  focal_selections <- dplyr::bind_rows(focal_selections_no_young_females, female_philopatry)

  # Add birth as selection event
  input %>%
    dplyr::mutate(origin = "W", # origin of birth events will be marked as W (womb)
                  destination = fetch_id_clan.birth(ID = .data$ID),
                  date = fetch_id_date.birth(ID = .data$ID)) %>%
    dplyr::full_join(focal_selections, by = c("ID", "date", "origin","destination")) %>%
    dplyr::arrange(.data$ID, .data$date) -> transition_full ## restore empty rows but does not conserve ID ranking

  dplyr::left_join(input, transition_full, by = "ID") -> output

  output

}


#' @describeIn create_family create a tidy table with individuals and their litters.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_litter_starting.table usage:
#' create_litter_starting.table(c("A-001", "L-003", "A-098"))
#'
create_litter_starting.table <- function(parentID = NULL) {
  parentID <- check_function_arg.ID(parentID, fill = TRUE, argument.name = 'parentID')

  ## Reading the full table and keeping only one row for each litterID:
  create_offspring_litterID.from.all(parentID = parentID) %>%
    dplyr::select(.data$parentID, .data$litterID) %>%
    dplyr::distinct() %>%
    dplyr::ungroup() -> litters

  litters
}


#' @describeIn create_family create a tidy table with all litters for each ID and the corresponding number of daughters, sons and cubs with unknown sex.
#'
#' @export
#' @examples
#' ### Simple example of usage of create_litter_offspring.count ###
#' create_litter_offspring.count("A-001_003")
#'
create_litter_offspring.count <- function(litterID = NULL) {
  litterID <- check_function_arg.litter.ID(litterID, fill = TRUE)
  litter.df <- tibble::tibble(litterID = litterID)
  parentID <- substr(litterID, 1, 5)

  create_offspring_litterID.from.all(unique(parentID)) %>%
    dplyr::mutate(sex_offspring = ifelse(.data$filiation == "mother_social",
                                         paste("social", fetch_id_sex(.data$offspringID), sep = "."),
                                         fetch_id_sex(.data$offspringID))) -> input

  input$sex_offspring[!is.na(input$offspringID) & is.na(input$sex_offspring) & (input$filiation == "mother_genetic" | input$filiation == "father" | input$filiation == "mother_social_genetic")] <- "unknown"
  input$sex_offspring[!is.na(input$offspringID) & is.na(input$sex_offspring) & input$filiation == "mother_social"] <- "social.unknown"

  input %>%
    dplyr::mutate(sex_offspring = factor(.data$sex_offspring,
                                         levels = c("female",
                                                    "male",
                                                    "unknown",
                                                    "social.female",
                                                    "social.male",
                                                    "social.unknown"))) -> input

  ## Each row becomes a litter:
  suppressWarnings( ## to prevent spurious warnings from old dplyr:
    ## Factor `sex_offspring` contains implicit NA, consider using `forcats::fct_explicit_na`
    input %>%
      dplyr::count(.data$parentID, .data$litterID, .data$sex_offspring, .drop = FALSE) -> litters
  )
  tidyr::pivot_wider(litters, names_from = .data$sex_offspring, values_from = .data$n, values_fill = list(n = 0)) -> litters

  litter.df %>%
    dplyr::left_join(litters, by = "litterID") %>%
    dplyr::select(-(.data$parentID)) -> output

  output

}



#' @describeIn create_family create a tidy table with all daughters, sons, and cubs with unknown sex that a mother gave birth to in her life.
#' @export
#' @examples
#'
#' ### Simple example of usage of create_id_offspring.count ###
#' create_id_offspring.count(ID = c("A-001", "A-008"))
#'
create_id_offspring.count <- function(ID, filiation = c("mother_genetic", "mother_social_genetic", "father")) {

  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation)
  ID_test <- tibble::tibble(ID = ID) ## tibble format to join easily

  create_id_offspring.table(ID) %>%
    dplyr::mutate(sex_offspring = fetch_id_sex(.data$offspringID)) %>%
    dplyr::filter(.data$filiation %in% !!filiation | is.na(.data$filiation)) -> offspring  ## drop the IDs of non-matching filiation

  offspring$sex_offspring[is.na(offspring$sex_offspring) & !is.na(offspring$offspringID)] <- "unknown"

  offspring %>%
    dplyr::group_by(.data$parentID) %>%
    dplyr::summarise(n_females = sum(.data$sex_offspring == "female"),
                     n_males = sum(.data$sex_offspring == "male"),
                     n_unknown = sum(.data$sex_offspring == "unknown")) -> output


  output <- dplyr::left_join(ID_test, output, by = c( "ID" = "parentID")) %>%
    dplyr::rename(parentID = .data$ID)
  return(output)
}



#' @describeIn create_family create a table that documents the starting and ending time of each clan the focal individual(s) stayed.
#' @export
#' @examples
#'
#' #### Simple example of create_selection_history usage:
#' create_id_selection.history(c("A-001","A-080"))
#'
create_id_selection.history <- function(ID, censored.to.last.sighting = FALSE) {

  input <- check_function_arg.ID(ID)
  lastsighting <- find_pop_date.observation.last()

  create_id_life.transition.table(input) %>%
    dplyr::select(-.data$origin) %>%
    dplyr::rename(clan = .data$destination) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::mutate(
      clan_after = dplyr::lead(.data$clan, 1),
      date_after_1 = dplyr::lead(.data$date, 1) - 1,
      date_after_2 = dplyr::lead(.data$date, 2) - 1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(deathdate = fetch_id_date.death(.data$ID),
                  ending_date = dplyr::case_when(!is.na(.data$clan_after) & .data$clan != .data$clan_after ~ .data$date_after_1,
                                                 is.na(.data$deathdate) & is.na(.data$date_after_2) & !!censored.to.last.sighting ~ !!lastsighting,
                                                 is.na(.data$deathdate) & is.na(.data$date_after_2) & !(!!censored.to.last.sighting) ~ as.Date(NA),
                                                 is.na(.data$date_after_2) ~ .data$deathdate,
                                                 TRUE ~ .data$date_after_2)) %>%
    dplyr::rename(starting_date = .data$date) %>%
    dplyr::select(.data$ID, .data$clan, .data$starting_date, .data$ending_date) %>%
    dplyr::group_by(.data$ID, .data$ending_date, .data$clan) %>%
    dplyr::slice(1) %>% ## first row of groups with the same ending date do not correspond to a selection event but to a age development
    dplyr::ungroup() -> output

  output
}


#' @describeIn create_family create a tidy table with all informations about the given litterID.
#'
#' @export
#' @examples
#' ### Simple example of usage of create_litter_offspring.count ###
#' create_litter_offspring.table(litterID = c("A-001_003", "A-001_002"))
#'
create_litter_offspring.table <- function(litterID = NULL) {
  litterID <- check_function_arg.litter.ID(litterID, fill = TRUE)
  litter.table <- tibble::tibble(litterID = litterID)

  offspring.litter.table <- create_offspring_litterID.from.all(
    parentID = unique(substring(litterID, first = 1, last = 5)))

  litter.table %>%
    dplyr::left_join(offspring.litter.table, by = "litterID") -> output

  output

}

#' @describeIn create_family create a table that documents all sightings for focal individuals in a given date range
#' @export
#' @examples
#'
#' #### Simple example of create_selection_history usage:
#' create_sighting_starting.table(c("A-001","A-080"))

create_sighting_starting.table <- function(ID, from = NULL, to = NULL, at = NULL,
                                           fill = TRUE, first.event = "observation",
                                           include.conception = FALSE,
                                           include.na = TRUE){

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  input      <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at, arg.max.length = 1,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  extract_database_table("sightings") %>%
    dplyr::filter(.data$ID %in% input & lubridate::as_date(.data$date_time) >= !!from & lubridate::as_date(.data$date_time) <= !!to) %>%
    {if(!include.na) dplyr::filter(., !is.na(.data$latitude) & !is.na(.data$longitude)) else .} %>%
    dplyr::arrange(.data$ID, .data$date_time) %>%
    #If we are excluding conception sightings then apply a filter...
    {if (!include.conception) {
      dplyr::filter(., is.na(.data$remarks) | .data$remarks != "Estimated from conception")
      #Otherwise just return unchanged data
    } else {
      .
    }} %>%
    dplyr::select(.data$ID, sighting_time = .data$date_time, .data$latitude, .data$longitude, sighting_clan = .data$clanID) -> output

  output

}

#' @describeIn create_family Create a table that documents all biological samples collected in a focal period
#'
#' @export
#' @examples
#' # A simple example
#' create_sample_starting.table(from = "1996-05-01", to = "1996-12-31")
#'
#' # A more complex example to recreate defunct [create_sample_summary.table]
#' create_sample_starting.table(from = "1996-05-01", to = "1996-12-31") %>%
#'     dplyr::mutate(deathdate = fetch_id_date.death(ID),
#'            birthdate = fetch_id_date.birth(ID),
#'            age = fetch_id_age(ID, collection_time),
#'            sex = fetch_id_sex(ID),
#'            clan = fetch_id_clan.current(ID, collection_time),
#'            lifestage = fetch_id_lifestage(ID, collection_time),
#'            rank_std = fetch_id_rank.std(ID = ID, at = lubridate::ymd_hm("1997-01-01 10:30")))

create_sample_starting.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                         fill = TRUE, first.event = "observation", verbose = TRUE){

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  messages   <- vector() ## Create an empty vector to which messages are appended. Print at end if verbose.

  if (all(is.null(ID), missing(from), missing(to), missing(at))) {

    messages <- append(messages, "Returning all recorded hyena sightings. \n")

  } else if (is.null(ID)) {

    messages <- append(messages, "Returning sightings for all individuals in focal date range. \n")

  } else if (all(missing(from), missing(to), missing(at))) {

    messages <- append(messages, "Returning all sightings of focal individuals. \n")

  }

  ID         <- check_function_arg.ID(ID, fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to, at, arg.max.length = 1,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  extract_database_table(tbl.names = "samples") %>%
    dplyr::filter(.data$species == "hy" & .data$collectiondate >= !!from & .data$collectiondate <= !!to & .data$ID %in% !!ID) %>%
    dplyr::mutate(collection_time = lubridate::ymd_hm(paste(.data$collectiondate, .data$stored1))) %>%
    dplyr::select(.data$ID, .data$sampleID, .data$collection_time, .data$type, .data$treatment) -> output

  if (verbose && length(messages) > 0) { # If verbose print all relevant messages

    message(messages, appendLF = FALSE)

  }

  output

}

#' @describeIn create_family Create a table with 3 different measures of observer effort of a clan
#' during the focal period: proportion of known adults sighted at least once, proportion of known cubs sighted
#' at least once, and proportion of all known individuals sighted at least once.
#' NOTE: This assumes that number of individuals sighted is related to observer effort.
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_clan_obsv.effort.table
#'
#' # Multiple clans over a date range
#' create_clan_obsv.effort.table(clan = c("A", "L"),
#'                               from = c("1997-01-01", "1997-02-01"),
#'                               to = c("1997-02-01", "1997-03-01"))
#'
#' # Multiple clans on a single date
#' create_clan_obsv.effort.table(clan = c("A", "L"),
#'                               at = c("1997-01-01", "1997-02-01"))

create_clan_obsv.effort.table <- function(clan = NULL, from = NULL, to = NULL, at = NULL,
                                          fill = TRUE, first.event = "observation", debug = FALSE,
                                          CPUcores = NULL, .parallel.min = 200){

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  # Used to join back at the end to maintain input order
  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         from = from, to = to)

  ## Create a nested list of all clans at each date
  ## This greatly speeds up the loop by iterating over unique dates
  ## Not unique clan/date combinations
  unique_input <- input %>%
    dplyr::distinct() %>%
    dplyr::group_by(.data$from, .data$to) %>%
    dplyr::summarise(all_clans = list(.data$clan))

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(unique_input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if (is.null(CPUcores)) {
    CPUcores <- 1
  }

  if (CPUcores > 1 && nrow(unique_input) >= .parallel.min) {
    debug_output <- furrr::future_pmap_dfr(.l = unique_input,
                                           .f = function(all_clans, from, to, basetable){

                                             create_id_starting.table(clan = all_clans, from = from, to = to, lifestage = "!dead") %>%
                                               dplyr::filter(!.data$ID %in% create_id_starting.table(clan = all_clans, from = from, to = to, lifestage = "disperser",
                                                                                                     lifestage.overlap = "start")$ID) %>%
                                               dplyr::mutate(from = from, to = to,
                                                             birthclan = fetch_id_clan.birth(.data$ID), fromclan = fetch_id_clan.current(.data$ID, at = .data$from),
                                                             clan = ifelse(is.na(.data$fromclan), .data$birthclan, .data$fromclan),
                                                             hassighting = fetch_id_has.sighting(ID = .data$ID,
                                                                                                 from = .data$from, to = .data$to,
                                                                                                 #Make removal of conceptions explicit
                                                                                                 include.conception = FALSE),
                                                             deathdate = fetch_id_date.death(.data$ID),
                                                             lastdate = dplyr::if_else(is.na(.data$deathdate), .data$to, .data$deathdate), ## Use dplyr if_else so it doesn't coerce dates
                                                             isadult = fetch_id_is.adult(ID = .data$ID, at = .data$lastdate - 1))

                                           }, .progress = TRUE,
                                           .options = furrr::furrr_options(globals = ".database"))
  } else {
    if (CPUcores > 1 && (nrow(unique_input) < .parallel.min)){
      message(paste0("Argument CPUcores ignored as less than", .parallel.min, "cases to compute."))
    }
    debug_output <- purrr::pmap_df(.l = unique_input,
                                   .f = function(all_clans, from, to, basetable){

                                     create_id_starting.table(clan = all_clans, from = from, to = to, lifestage = "!dead") %>%
                                       dplyr::filter(!.data$ID %in% create_id_starting.table(clan = all_clans, from = from, to = to, lifestage = "disperser",
                                                                                             lifestage.overlap = "start")$ID) %>%
                                       dplyr::mutate(from = from, to = to,
                                                     birthclan = fetch_id_clan.birth(.data$ID), fromclan = fetch_id_clan.current(.data$ID, at = .data$from),
                                                     clan = ifelse(is.na(.data$fromclan), .data$birthclan, .data$fromclan),
                                                     hassighting = fetch_id_has.sighting(ID = .data$ID,
                                                                                         from = .data$from, to = .data$to,
                                                                                         #Make removal of conceptions explicit
                                                                                         include.conception = FALSE),
                                                     deathdate = fetch_id_date.death(.data$ID),
                                                     lastdate = dplyr::if_else(is.na(.data$deathdate), .data$to, .data$deathdate), ## Use dplyr if_else so it doesn't coerce dates
                                                     isadult = fetch_id_is.adult(ID = .data$ID, at = .data$lastdate - 1))

                                   })
  }

  if (debug) {

    return(debug_output)

  }

  # Determine observation effort stats for every clan/date combination
  debug_output %>%
    dplyr::group_by(.data$clan, .data$from, .data$to) %>%
    dplyr::summarise(effort_adult = sum(.data$isadult & .data$hassighting) / sum(.data$isadult),
                     effort_cub = sum(!.data$isadult & .data$hassighting) / sum(!.data$isadult),
                     effort_all = sum(.data$hassighting)/dplyr::n()) %>%
    dplyr::ungroup() %>%
    dplyr::mutate_at(dplyr::vars(dplyr::contains("effort")),
                     ~ replace(., is.na(.), 0)
    ) %>%
    dplyr::mutate(from = from, to = to) %>%
    check_function_output(input, ., join.by = c("clan", "from", "to")) -> output

  output

}


#' @describeIn create_family creates a table with all selectors in the clan at the conception date of the given offspring
#' @export
#' @examples
#' #### Simple examples of create_offspring_father.candidate.table:
#' ## No one has a selector candidate:
#' create_offspring_father.candidate.table(offspringID = "A-008")
#' ## No one has a mother:
#' create_offspring_father.candidate.table(offspringID = "A-001")
#' ## Combination of both cases:
#' create_offspring_father.candidate.table(offspringID = c("A-008", "A-001"))
#' ## One offspring has candidates:
#' create_offspring_father.candidate.table(offspringID = c("A-008", "A-001", "A-086"))
#' ## Both have candidates:
#' create_offspring_father.candidate.table(offspringID = c("A-086", "A-087"))
create_offspring_father.candidate.table <- function(offspringID, error.margin.selection = "90 days",
                                                    error.margin.alive = "90 days", debug = FALSE){

  error.margin.alive <- check_function_arg.period(error.margin.alive)
  error.margin.selection <- check_function_arg.period(error.margin.selection)
  input <- tibble::tibble(offspringID = check_function_arg.ID(offspringID, argument.name = 'offspringID'))

  input %>%
    dplyr::mutate(multifetch_id_birth.info(.data$offspringID)) %>%
    dplyr::select(-(.data$fatherID)) %>%
    dplyr::mutate(conception.date = .data$birthdate - 110) -> info.offspring.table

  # We exclude individuals conceived before the birth of the first founder because those who were around could not be in the dataset
  too_old <- info.offspring.table$conception.date < find_pop_date.birth.first()

  if (any(too_old)) {

    warning(paste("the following individuals were conceived before the birth date of the older founder of the dataset so we cannot know their potential fathers:", info.offspring.table$offspringID[too_old]))

    info.offspring.table %>%
      dplyr::filter(.data$conception.date >= find_pop_date.birth.first()) -> info.offspring.table
  }

  #If there are no individuals after removing those ones that are too old then just skip the next steps
  if (nrow(info.offspring.table) == 0) {

    output.tbl <- tibble::tibble(offspringID = offspringID,
                                 potential.fatherID = NA)

  } else {

    # Check whether mothers dispersed
    create_id_life.transition.table(unique(info.offspring.table$motherID[!is.na(info.offspring.table$motherID)])) %>%
      dplyr::mutate(life.stage = fetch_id_lifestage(.data$ID, at = .data$date)) %>%
      dplyr::filter(.data$life.stage %in% c("disperser", "selector_2", "selector_3", "selector_4", "selector_5")) -> female.dispersal

    # If the mother dispersed within error.margin.selection days after the conception, we will consider as father candidates the selectors present
    # in the origin clan and in the destination
    dplyr::left_join(info.offspring.table, female.dispersal, by = c("motherID" = "ID")) %>%
      dplyr::mutate(is.mother.disperser = ifelse(!is.na(.data$life.stage), TRUE, FALSE),
                    diff.mother.dispersion.conception = ifelse(.data$is.mother.disperser,
                                                               .data$date - .data$conception.date,
                                                               NA),
                    fathered.away = .data$is.mother.disperser & (.data$diff.mother.dispersion.conception <= !!error.margin.selection &
                                                                   .data$diff.mother.dispersion.conception > 0)) -> full.offspring.table

    full.offspring.table %>%
      dplyr::rowwise() %>%
      # If the conception.cla is NA (because the mother is unknown) and the birth.clan is not X (unknown),
      # we assume as conception clan the birth clan
      dplyr::mutate(potential.fatherID = dplyr::case_when(.data$clan.birth == "X" & is.na(.data$clan.conception) ~ list(NA_character_),
                                                          .data$clan.birth != "X" & is.na(.data$clan.conception) ~ list(find_clan_id(from = .data$conception.date - !!error.margin.selection,
                                                                                                                                     to = .data$conception.date + !!error.margin.selection,
                                                                                                                                     lifestage = c("disperser",
                                                                                                                                                   "philopatric",
                                                                                                                                                   "selector_2",
                                                                                                                                                   "selector_3",
                                                                                                                                                   "selector_4",
                                                                                                                                                   "selector_5"),
                                                                                                                                     sex = "male",
                                                                                                                                     clan = .data$clan.birth)),
                                                          .data$fathered.away ~ list(find_clan_id(from = .data$conception.date - !!error.margin.selection,
                                                                                                  to = .data$conception.date + !!error.margin.selection,
                                                                                                  lifestage = c("disperser",
                                                                                                                "philopatric",
                                                                                                                "selector_2",
                                                                                                                "selector_3",
                                                                                                                "selector_4",
                                                                                                                "selector_5",
                                                                                                                "founder_male",
                                                                                                                "foreigner",
                                                                                                                "foreigner_2",
                                                                                                                "foreigner_3",
                                                                                                                "foreigner_4",
                                                                                                                "foreigner_5"),
                                                                                                  clan = c(.data$origin, .data$destination),
                                                                                                  sex = "male")),
                                                          TRUE ~ list(find_clan_id(from = .data$conception.date - !!error.margin.selection,
                                                                                   to = .data$conception.date + !!error.margin.selection,
                                                                                   lifestage = c("disperser",
                                                                                                 "philopatric",
                                                                                                 "selector_2",
                                                                                                 "selector_3",
                                                                                                 "selector_4",
                                                                                                 "selector_5",
                                                                                                 "founder_male",
                                                                                                 "foreigner",
                                                                                                 "foreigner_2",
                                                                                                 "foreigner_3",
                                                                                                 "foreigner_4",
                                                                                                 "foreigner_5"),
                                                                                   clan = .data$clan.conception,
                                                                                   sex = "male")))) -> potential.father.table
    potential.father.table %>%
      tidyr::unnest_longer(.data$potential.fatherID) %>%
      dplyr::mutate(last.sighting = fetch_id_date.observation.last(.data$potential.fatherID),
                    diff.dates = abs(.data$conception.date - .data$last.sighting),
                    is.death.confirmed = fetch_id_is.death.confirmed(.data$potential.fatherID),
                    alive = fetch_id_is.alive(.data$potential.fatherID, at = .data$conception.date),
                    expandend.alive = ifelse(!.data$alive & !.data$is.death.confirmed & .data$diff.dates <= !!error.margin.alive,
                                             TRUE,
                                             .data$alive)) %>%
      dplyr::filter(.data$expandend.alive) %>%
      dplyr::select(.data$offspringID, .data$potential.fatherID) -> output.tbl

  }

  check_function_output(input.tbl = input, output.tbl = output.tbl,
                        join.by = "offspringID",
                        duplicates = "output",
                        output.IDcolumn = NULL, debug = debug)
}


#' @describeIn create_family creates a list of tables each of which contains all the given offsprings that had the same
#' proportion and number of typed potential fathers.
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_cervus_input:
#' ## No one has a selector candidate:
#' create_cervus_input(offspringID = "A-008")
#' ## No one has a mother:
#' create_cervus_input(offspringID = "A-001")
#' ## Combination of both cases:
#' create_cervus_input(offspringID = c("A-008", "A-001"))
#' create_cervus_input(offspringID = c("A-008", "A-001", "A-086"))
#'

create_cervus_input <- function(offspringID, debug = FALSE) {
  input <- tibble::tibble(offspringID = check_function_arg.ID(offspringID, argument.name = 'offspringID'))

  input %>%
    dplyr::mutate(multifetch_id_birth.info(.data$offspringID)) %>%
    dplyr::select(-(.data$fatherID), -(.data$clan.birth)) -> info.offspring.table

  create_offspring_father.candidate.table(input$offspringID) -> candidate.selectors

  dplyr::left_join(candidate.selectors, info.offspring.table, by = "offspringID") %>%
    dplyr::relocate(.data$potential.fatherID, .after = .data$clan.conception) %>%

    dplyr::mutate(genotyped = fetch_id_is.sampled.dna(.data$potential.fatherID)) %>%
    dplyr::group_by(.data$offspringID) %>%
    dplyr::mutate(index.candidate = paste0("candidate", 1:dplyr::n()),
                  N.typed = sum(.data$genotyped),
                  N.potential = ifelse(!is.na(.data$potential.fatherID), dplyr::n(), NA),
                  prop.typed = round(mean(.data$genotyped), 3)) %>%
    dplyr::ungroup() -> output

  check_function_output(input.tbl = input, output.tbl = output, join.by = "offspringID",
                        duplicates = "output",
                        output.IDcolumn = NULL,
                        debug = debug)
}

#' @describeIn create_family Create a table with a subset of observations within a focal period
#'
#' Requires columns 'starting_date' and 'ending_date' to specify the focal period.
#'
#' @return Tibble.
#' @export
#'
#' @examples
#' #Full life history data
#' input <- create_id_life.history.table(ID = c("A-001", "A-002", "A-058"))
#'
#' #Find only lifestages that start in 1995
#' create_id_overlap.table(input, from = "1995-01-01", to = "1995-12-01", overlap = "start")

create_id_overlap.table <- function(input.tbl, from = NULL, to = NULL, at = NULL, overlap = "any"){

  if (!all(c("starting_date", "ending_date") %in% colnames(input.tbl))) {

    stop("Input table must have columns starting_date and ending_date")

  }

  overlap <- check_function_arg.overlap(overlap)

  #Checking this twice is redundant, but allows the function to be used internally and stand alone
  date_range          <- check_function_arg.date.fromtoat(from = from, to = to, at = at, fill = TRUE,
                                                          max.date = find_pop_date.observation.last(),
                                                          min.date = find_pop_date.birth.first(), arg.max.length = 1)
  from                 <- date_range$from
  to                   <- date_range$to

  input.tbl %>%
    {
      ## start: the starting date of life stage falls in the focal period
      if (overlap == "start") {
        dplyr::filter(., .data$starting_date >= !!from & .data$starting_date <= !!to)
      }
      ## end: the ending date of life stage falls in the focal period
      else if (overlap == "end") {
        dplyr::filter(., .data$ending_date >= !!from & .data$ending_date <= !!to)
      }
      ## within: the interval of the life stage falls completely inside the focal period
      else if (overlap == "within") {
        dplyr::filter(., .data$starting_date >= !!from & .data$ending_date <= !!to)
      }
      ## always: the focal period falls completely inside the interval of the life stage
      else if (overlap == "always") {
        dplyr::filter(., .data$starting_date <= !!from &  .data$ending_date >= !!to)
      }
      ## any: any overlap between the focal period and interval of the life stage
      else {
        dplyr::filter(., (.data$starting_date >= !!from & .data$starting_date <= !!to) | (.data$ending_date >= !!from & .data$ending_date <= !!to) | (!!from >= .data$starting_date &  !!to <= .data$ending_date))
      }

    } -> output

  output

}

#' @describeIn create_family Create a table of the meta-data attribute of a dataframe.
#'
#' @return Tibble of meta-data information.
#' @export
#'
#' @examples
#' #Example weather data collected from IZW
#' test_data <- load_data_weatherstation.file(system.file("extdata/weather_Mlima",
#'                                           "weather_data_test1.xlsx",
#'                                           package = "hyenaR"))
#'
#' #Extract metadata
#' create_tbl_metadata(test_data)
create_tbl_metadata <- function(input.tbl){

  attributes(input.tbl)$metadata

}

#' @describeIn create_family Create a table of weather data in a given date range
#'
#' @return Tibble of weather data
#' @export
#'
#' @examples
#' #Get temp data from jua station
#' create_weather_starting.table(variable = "temp", station = "jua")
create_weather_starting.table <- function(from = NULL, to = NULL, at = NULL,
                                          variable = c("temp", "rain", "rainmax", "humidity", "pressure", "battery"),
                                          station = NULL,
                                          location = NULL){

  #Check station names or location are correct
  station   <- check_function_arg.station(station)
  location  <- check_function_arg.location.weather(location)

  #User must provide one of either station or location, not both
  if ((is.null(station) & is.null(location)) | (!is.null(station) & !is.null(location))) {

    stop("Please provide one of either `station` or `location`.")

  }

  #Check variables are correct
  variable <- check_function_arg.variable.weather(variable)

  #Extract advised dates for station (i.e. when the station was active)
  #or location (i.e. when a station was at this location)
  if (!is.null(location)) {

    #Fill dates are the start/end date at which stations was installed
    advised_dates <- sf_hyenaR$weather_stations %>%
      sf::st_drop_geometry() %>%
      #NOTE: We are assuming that each location only has a single record (i.e. no change of station)
      dplyr::filter(.data$location %in% !!location) %>%
      dplyr::mutate(end_date = dplyr::case_when(is.infinite(.data$end_date) ~ Sys.Date(),
                                                TRUE ~ .data$end_date) - lubridate::days(1),
                    start_date = .data$start_date + lubridate::days(1))

    purrr::pmap_df(.l = advised_dates,
                   .f = function(station_name, location, start_date, end_date){

                     ## check and process arguments:
                     date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                                    fill = TRUE,
                                                                    #We use the day *after* installation and day *before* removal
                                                                    #This way we are only returning data from a full day of use
                                                                    min.date = start_date,
                                                                    max.date = end_date,
                                                                    arg.max.length = 1L, data.type = "weather")
                     from_new       <- date_range$from
                     to_new         <- date_range$to

                     #If from/to were specified manually and they are before/after advised dates they are ignored and we throw warning
                     if (from_new < start_date) {

                       warning(paste0("Date requested is before weather station was active.\nStation ", station_name, " was active at ", location, " between: ", start_date, " - ", end_date, ". Data before this period has been ignored."))

                       from_new <- start_date

                     }

                     if (to_new > end_date) {

                       warning(paste0("Date requested is after weather station was active.\nStation ", station_name, " was active at ", location, " between: ", start_date, " - ", end_date, ". Data before this period has been ignored."))

                       to_new <- end_date

                     }

                     extract_database_table("weather") %>%
                       dplyr::filter(.data$station_name %in% !!station_name & lubridate::as_date(.data$date_time) >= from_new & lubridate::as_date(.data$date_time) <= to_new) %>%
                       dplyr::select(.data$station_name:.data$longitude, {{variable}})

                   }) -> output

  } else if (!is.null(station)) {

    #Fill dates are the start/end date at which stations was installed
    advised_dates <- sf_hyenaR$weather_stations %>%
      sf::st_drop_geometry() %>%
      #NOTE: We are currently only considering the 'official' locations for each station
      #May need to fix this if we consider e.g. when station was tested at the field house
      dplyr::filter(.data$station_name %in% !!station) %>%
      dplyr::mutate(end_date = dplyr::case_when(is.infinite(.data$end_date) ~ Sys.Date(),
                                                TRUE ~ .data$end_date) - lubridate::days(1),
                    start_date = .data$start_date + lubridate::days(1))

    purrr::pmap_df(.l = advised_dates,
                   .f = function(station_name, location, start_date, end_date){

                     ## check and process arguments:
                     date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                                    fill = TRUE,
                                                                    #We use the day *after* installation and day *before* removal
                                                                    #This way we are only returning data from a full day of use
                                                                    min.date = start_date,
                                                                    max.date = end_date,
                                                                    arg.max.length = 1L, data.type = "weather")
                     from_new       <- date_range$from
                     to_new         <- date_range$to

                     #If from/to were specified manually and they are before/after advised dates, throw a warning
                     if (from_new < start_date | to_new > end_date) {

                       warning(paste0("Station ", station_name, " was active in the Crater between ", start_date, " - ", end_date, "\nData outside this period should be treated with caution!"))

                     }

                     extract_database_table("weather") %>%
                       dplyr::filter(.data$station_name %in% !!station_name & lubridate::as_date(.data$date_time) >= from_new & lubridate::as_date(.data$date_time) <= to_new) %>%
                       dplyr::select(.data$station_name:.data$longitude, {{variable}})


                   }) -> output

  }

  output

}
