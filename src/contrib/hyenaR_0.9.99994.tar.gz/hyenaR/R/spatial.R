
#' @describeIn fetch_family fetch the tracks tables for individual(s) (used internally for any work with package {amt}, which handles home ranges)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_track.table usage:
#' fetch_id_track.table(c("A-001", "A-010"),
#'                      from = c("1996/10/01", "1996/01/01"),
#'                      to = c("1996/10/02", "1997/12/01"))
#'
fetch_id_track.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                 fill = TRUE, first.event = "observation",
                                 debug = FALSE) {

  ## temporary fix (not in Description since amt 0.1.5 is not on CRAN)
  if (utils::packageVersion("amt") < "0.1.5") {
    stop("Version of the package amt prior from 0.1.5 won't work; run remotes::install_github('jmsigner/amt') to install the latest version.")
  }

  #Check using legit CRS
  crs <- load_package_crs()

  sightings <- fetch_id_sighting.table(ID = ID, from = from, to = to, at = at,
                                       fill = fill, first.event = first.event, debug = debug,
                                       #amt necessarily can't deal with NAs, so this is always used
                                       include.na = FALSE)

  sightings <- purrr::map(sightings,
                            ~{
                              #If we have data with alternative crs...
                              if (nrow(.x) > 1 & crs != 4326) {
                                dplyr::bind_cols(.x, recode_df_sf(.x, crs = crs) %>%
                                                   sf::st_coordinates() %>%
                                                   dplyr::as_tibble())
                              #When crs is standard (or df is empty) just convert col names
                              } else {
                                .x %>%
                                  dplyr::rename(X = longitude, Y = latitude)
                              }

                            })

  ## to shut up verbose amt::mk_track
  quiet_mk_track <- function(...) {
    withCallingHandlers(amt::mk_track(...), message = function(m) invokeRestart("muffleMessage"))
  }

  tracks <- purrr::map(sightings, ~ quiet_mk_track(tbl = .x, .x = X, .y = Y, .t = sighting_time,
                                                   crs = crs,
                                                   all_cols = TRUE, order_by_ts = TRUE))

  ## replace empty sighting tables by empty tracking tables (with matching columns):
  for (i in seq_along(tracks)) {
    if (is.null(tracks[[i]])) {
      tracks[[i]] <-  tibble::tibble()
    }
  }

  tracks
}


#' @describeIn fetch_family fetch the tracks tables for clan(s) (used internally for any work with package {amt}, which handles home ranges)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_track.table usage:
#' fetch_clan_track.table(c("A", "L"),
#'                        from = c("1996/10/01", "1996/01/01"),
#'                        to = c("1996/10/02", "1997/12/01"))
#'
fetch_clan_track.table <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                   at = NULL, from = NULL, to = NULL,
                                   clan.overlap = "any", lifestage.overlap = "any",
                                   fill = TRUE, first.event = "observation",
                                   debug = FALSE) {

  ## temporary fix (not in Description since amt 0.1.5 is not on CRAN)
  if (utils::packageVersion("amt") < "0.1.5") {
    stop("Version of the package amt prior from 0.1.5 won't work; run remotes::install_github('jmsigner/amt') to install the latest version.")
  }

  #Check using legit CRS

  crs <- load_package_crs()

  sightings <- fetch_clan_sighting.table(clan = clan, sex = sex, lifestage = lifestage,
                                         at = at, from = from, to = to,
                                         clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                         fill = fill, first.event = first.event,
                                         #amt necessarily can't deal with NAs, so this is always used
                                         include.na = FALSE,
                                         debug = debug)

  sightings <- purrr::map(sightings,
                          ~{
                            #If we have data that is not WGS84 geographic CRS...
                            if (nrow(.x) > 1 & crs != sf::st_crs(4326)) {
                              dplyr::bind_cols(.x, recode_df_sf(.x, crs = crs) %>%
                                                 sf::st_coordinates() %>%
                                                 dplyr::as_tibble())
                              #When crs is standard (or df is empty) just convert col names
                            } else {
                              .x %>%
                                dplyr::rename(X = longitude, Y = latitude)
                            }

                          })

  ## to shut up verbose amt::mk_track
  quiet_mk_track <- function(...) {
    withCallingHandlers(amt::mk_track(...), message = function(m) invokeRestart("muffleMessage"))
  }

  tracks <- purrr::map(sightings, ~ quiet_mk_track(tbl = .x, .x = X, .y = Y, .t = sighting_time,
                                                   crs = crs,
                                                   all_cols = TRUE, order_by_ts = TRUE))

  ## replace empty sighting tables by empty tracking tables (with matching columns):
  for (i in seq_along(tracks)) {
    if (is.null(tracks[[i]])) {
      tracks[[i]] <-  tibble::tibble()
    }
  }

  tracks
}


#' @describeIn fetch_family fetch the home range for individual(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_homerange:
#' fetch_id_homerange(c("A-001", "A-010", "A-001"),
#'                    from = c("1996/10/01", "1996/01/01", "1996/01/01"),
#'                    to = c("1996/10/02", "1997/12/01", "1996/10/02"))
#'
fetch_id_homerange <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                               fill = TRUE, first.event = "observation", debug = FALSE,
                               hr.method = "mcp", hr.args = list(), hr.raw = FALSE) {

  #Check using legit CRS
  crs <- load_package_crs()

  hr.method <- check_function_arg.hr.method(hr.method)

  tracks <- fetch_id_track.table(ID = ID, from = from, to = to, at = at,
                                 fill = fill, first.event = first.event,
                                 debug = FALSE) ## debug must be FALSE here since we use debug here for hr.method

  hr_fn_text <- paste0("amt::hr_", hr.method)
  hr_fn <- eval(parse(text = hr_fn_text))

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug || grepl("package", x = e)) {if (grepl("package", x = e)) stop(e); message(e); cat("\n")}; list(list(geometry = sf::st_sfc(sf::st_polygon(),
                                                                                                                                                                          crs = crs)))}

  geom_list <- purrr::map(tracks, ~ tryCatch(do.call(hr_fn, c(list(x = add_noise_on_tracks(.x), keep.data = FALSE), hr.args)), error = err_fn(e)))

  if (!hr.raw) {
    geom_list <- purrr::map(geom_list, function(geom) geom[[1]]["geometry"][[1]])
    geom_list <- do.call(c, geom_list)
  }

  geom_list
}


#' @describeIn fetch_family fetch the home range for clan(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_homerange:
#' fetch_clan_homerange(c("A", "L", "A"),
#'                      from = c("1996/10/01", "1996/01/01", "1996/01/01"),
#'                      to = c("1996/10/02", "1997/12/01", "1996/10/02"))
#'
fetch_clan_homerange <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                 at = NULL, from = NULL, to = NULL,
                                 clan.overlap = "any", lifestage.overlap = "any",
                                 fill = TRUE, first.event = "observation",
                                 debug = FALSE,
                                 hr.method = "mcp", hr.args = list(), hr.raw = FALSE) {

  #Check using legit CRS
  crs <- load_package_crs()

  hr.method <- check_function_arg.hr.method(hr.method)

  tracks <- fetch_clan_track.table(clan = clan, sex = sex, lifestage = lifestage,
                                   at = at, from = from, to = to,
                                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                   fill = fill, first.event = first.event,
                                   debug = FALSE) ## debug must be FALSE here since we use debug here for hr.method

  hr_fn_text <- paste0("amt::hr_", hr.method)
  hr_fn <- eval(parse(text = hr_fn_text))

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; list(list(geometry = sf::st_sfc(sf::st_polygon(),
                                                                                                         crs = crs)))}

  ## TODO: make parallel?
  geom_list <- purrr::map(tracks, ~ tryCatch(do.call(hr_fn, c(list(x = add_noise_on_tracks(.x), keep.data = FALSE), hr.args)), error = err_fn(e)))

  if (!hr.raw) {
    geom_list <- purrr::map(geom_list, function(geom) geom[[1]]["geometry"][[1]])
    geom_list <- do.call(c, geom_list)
  }

  geom_list
}


#' @describeIn fetch_family fetch the home range area (in km^2) for individual(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_homerange.area usage:
#' fetch_id_homerange.area(c("A-001", "A-010"),
#'                         from = c("1996/10/01", "1996/01/01"),
#'                         to = c("1996/10/02", "1997/12/01"))
#'
fetch_id_homerange.area <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                    fill = TRUE, first.event = "observation", debug = FALSE,
                                    hr.method = "mcp", hr.args = list()) {

  geom_list <- fetch_id_homerange(ID = ID, from = from, to = to, at = at,
                                  fill = fill, first.event = first.event, debug = debug,
                                  hr.method = hr.method, hr.args = hr.args, hr.raw = TRUE)

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; NA}

  area <- purrr::map(geom_list, ~ tryCatch(amt::hr_area(x = .x)$area / 1e6, error = err_fn(e)))

  ## collapse as vector if possible (not possible e.g. when hr.method = "akde" since returns intervals):
  if (max(unlist(purrr::map(area, length))) < 2) {
    area <- unlist(area)
  }

  area
}


#' @describeIn fetch_family fetch the home range area (in km^2) for clan(s) (use debug = TRUE for diagnosing problems)
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_homerange.area usage:
#' fetch_clan_homerange.area(c("A", "L"),
#'                           from = c("1996/10/01", "1996/01/01"),
#'                           to = c("1996/10/02", "1997/12/01"))
#'
#' #### Advanced example of fetch_clan_homerange.area usage:
#'
#' tibble::tibble(clan = find_clan_name.all()) %>%
#'        dplyr::mutate(hr = fetch_clan_homerange(clan = clan,
#'                                         sex = "female",
#'                                         lifestage = "adult"),
#'               sightings = fetch_clan_sighting.point(clan = clan,
#'                                                     sex = "female",
#'                                                     lifestage = "adult")) -> tbl
#' tbl
#'
#' \dontrun{
#'   tbl %>%
#'       dplyr::mutate(centre = sf::st_centroid(hr)) %>%
#'       ggplot2::ggplot() +
#'         ggplot2::geom_sf(ggplot2::aes(geometry = hr, colour = clan), alpha = 0.5) +
#'         ggplot2::geom_sf(ggplot2::aes(geometry = centre, colour = clan),
#'                          shape = 3, size = 5) +
#'         ggplot2::geom_sf(ggplot2::aes(geometry = sightings, colour = clan),
#'                 alpha = 0.6, size = 1) +
#'         ggplot2::geom_sf(data = sf_hyenaR$rim_polygon, colour = "brown", fill = NA) +
#'         ## to avoid issues caused by rare wrong coordinates on full data:
#'         ggplot2::coord_sf(ylim = c(-3.26, -3.09), xlim = c(35.48, 35.67))
#' }
#'
fetch_clan_homerange.area <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                      at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      fill = TRUE, first.event = "observation",
                                      debug = FALSE,
                                      hr.method = "mcp", hr.args = list()) {

  geom_list <- fetch_clan_homerange(clan = clan, sex = sex, lifestage = lifestage,
                                    at = at, from = from, to = to,
                                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                    fill = fill, first.event = first.event, debug = debug,
                                    hr.method = hr.method, hr.args = hr.args, hr.raw = TRUE)

  ## function for handling errors in tryCatch calls
  err_fn <- function(e) function(e) {if (debug) {message(e); cat("\n")}; NA}

  area <- purrr::map(geom_list, ~ tryCatch(amt::hr_area(x = .x)$area / 1e6, error = err_fn(e)))

  ## collapse as vector if possible (not possible e.g. when hr.method = "akde" since returns intervals):
  if (max(unlist(purrr::map(area, length))) < 2) {
    area <- unlist(area)
  }

  area
}


#' @describeIn check_family Check arguments 'hr.method'.
#' @export
#' @examples
#'
#' check_function_arg.hr.method("mcp")
#'
check_function_arg.hr.method <- function(hr.method) {

  if (length(hr.method) != 1L) {
    stop("The argument 'hr.method' should be of length one.")
  }

  possible_args <- c('akde', 'kde', 'mcp', 'locoh')

  if (!is.character(hr.method)) {
    stop(paste0("The argument 'hr.method' should be a quotted string of characters such as: '", paste(possible_args, collapse = "', '"), "'"))
  }

  if (!hr.method %in% possible_args) {
    stop(paste0("Unknown argument 'hr.method'; it should be one of the following: '", paste(possible_args, collapse = "', '"), "'"))
  }

  hr.method
}


#' List of simple feature collections for hyenaR
#'
#' This object is a list of simple feature collections (sfc) for hyenaR.
#' This allows for you to plot various spatial objects such as the crater rim,
#' the roads, the rivers, the transects and more (see examples below).
#' You can also use these sfc to computate spatial metrics (e.g. area of the crater).
#'
#' @name sf_hyenaR
#' @docType data
#' @keywords sf
#'
#' @examples
#' ## Here is the list of everything you can use:
#' names(sf_hyenaR)
#'
#' ## Example of simple computation:
#' if (require("sf")) {
#'   area_crater <- st_area(sf_hyenaR$rim_polygon)
#'   units(area_crater) <- "km^2"
#'   area_crater
#' }
#'
#' ## Example of plot:
#' \dontrun{
#'  ggplot2::ggplot() +
#'  ggplot2::geom_sf(data = sf_hyenaR$rim_polygon, colour = "brown", fill = "lightgreen") +
#'    ggplot2::geom_sf(data = sf_hyenaR$roads_crater, colour = "black") +
#'    ggplot2::geom_sf(data = sf_hyenaR$waterbodies_lakes, fill = "blue", colour = NA) +
#'    ggplot2::geom_sf(data = sf_hyenaR$rivers_main, colour = "blue") +
#'    ggplot2::theme_classic()
#' }
NULL

#' Add random noise to tracks to prevent issues identical points
#'
#' This prevents issues with polygon errors due to overlapping points.
#' @param tracks Track data returned by `fetch_id_track.table`
add_noise_on_tracks <- function(tracks) {
  old <- .Random.seed
  on.exit( { .Random.seed <<- old } )
  set.seed(2) #Use same seed so that this is always reproducible
  tracks$x_ <- tracks$x_ + stats::runif(n = nrow(tracks), max = 1e-6)
  tracks$y_ <- tracks$y_ + stats::runif(n = nrow(tracks), max = 1e-6)
  return(tracks)
}

#' Brief guide to coordinate-reference systems (CRS)
#'
#' @description
#' When working with spatial data the choice of coordinate reference system (CRS) may
#' influence the results. When working in `hyenaR` the default CRS for
#' spatial data will often be suitable; however, there may be cases where transforming
#' data to an alternative CRS can be desirable. This document describes the basic of CRS
#' and when it may be useful to consider a non-standard CRS.
#'
#' @details
#' ## Basics of CRS
#' A CRS is made up of two important elements: a geographic coordinate system and projected coordinate system.
#'
#' ### Geographic coordinate system
#' The geographic coordinate system specifies where on the Earth's surface our spatial data can be found.
#' To do this, geographic coordinate systems make simplifying assumptions so that the Earth can be
#' represented as a sphere (in reality the Earth is not a perfect sphere!). Different geographic coordinate
#' systems make different assumptions when representing the Earth as a sphere and will do better
#' at representing certain areas on the Earth over others. This means that the same
#' coordinates will represent different locations on the Earth depending on which geographic coordinate system
#' they come from! Geographic coordinate systems typically use measurements in degrees (i.e. latitude/longitude).
#' A change in 1 unit of a geographic coordinate system (i.e. 1 degree) does not represent a standard distance
#' on the Earth's surface.
#'
#' ### Projected coordinate system
#' Once we know where our data are, we may want to take these positions from an (approximate) sphere
#' and represent them on a flat surface (e.g. a computer screen). It is impossible to perfectly represent
#' data from a sphere on a flat surface without some distortion occurring. Where this distortion occurs
#' and what metrics it affects will depend on the projected coordinate system we use.
#' It is important to use a projected coordinate system that minimizes distortion in the location where our
#' data are collected (Tanzania) and/or for the metrics we are interested in (e.g. area or distance).
#' This distortion will be determined both by the type of projection used and the parameters provided
#' to the projection system. Projected coordinate systems typically use measurements in meters so a
#' change in one unit represents a meter on the Earth's surface.
#'
#' ### Working with non-projected data
#' All CRS have a geographic coordinate system, but not all will have a projected coordinate system.
#' Projected coordinate systems are only needed if we want to represent our data on a map or make
#' measurements such as area or distance.
#'
#' ## Why use projected CRS?
#' What circumstances might require you to use a projected CRS?
#' \itemize{
#'  \item{"Obtain accurate estimates of distance"}{Geographic coordinate systems are not very good at measuring distances.
#'  We might want to measure distances if we create a buffer around a point or estimate distance between two locations.
#'  The `sf` package (used inside R) uses S2 geometry to estimate distances from latitude/longitude information
#'  (see [documentation here](https://r-spatial.github.io/sf/articles/sf7.html)),
#'  but using a CRS with a an appropriate projected coordinate system will be more accurate.
#'  Note, if you turn off S2 geometry (`sf::sf_use_s2(FALSE)`) without using a projection results will be
#'  even less accurate and this is not recommended when measuring distances.}
#'  \item{"Work with understable units"}{Projected CRS are in units of meters and so may be easier
#'  to interpret and understand.}
#'  \item{"Debugging"}{Some spatial
#'  functions in `hyenaR` may fail when using geographic coordinate systems.
#'  Working with a projected coordinate system may deal with some of these errors in spatial analysis.}
#' }
#'
#' ## Default CRS in `hyenaR` (WGS84 / UTM zone 36S; EPSG:32736)
#' By default, spatial functions in `hyenaR` such as [hyenaR::fetch_id_homerange()] or [hyenaR::fetch_clan_homerange.area()]
#' use the World Geodetic System (WGS 84) and the Transverse Mercator projection, specifically WGS84 / UTM zone 36S (EPSG:32736).
#' WGS84 is a geographic coordinate system that is designed to work equally well for most areas of the Earth,
#' and so it is the CRS used by GPS devices. `hyenaR` expects all raw spatial data to be stored in WGS84 (i.e. the same as the GPS output).
#' This data will then be projected internally.
#'
#' Transverse Mercator projection maintains most
#' metrics well as long as we are close to the central meridian of the CRS,
#' which is defined by the UTM zone. There are a number of zones that can represent Tanzania well;
#' however, zone 36S is closest to Ngorongoro Crater
#' so we should experience the least distortion with hyena data.
#'
#' ## Alternative CRS for Ngorongoro Crater
#'
#' ### Arc 1960 / UTM zone 36S (EPSG:21036)
#' This projected CRS uses Arc 1960 geographic coordinate system rather than WGS84.
#' Arc 1960 is a geographic coordinate system built specifically for E. Africa and you may
#' encounter this system when receiving spatial data from the region. Remember, it is important
#' when comparing spatial data they all data use the same CRS. Therefore, if you receive data
#' using Arc 1960, you can use this same system in `hyenaR` for comparability.
#' This CRS projects the coordinates from Arc 1960 using the same Transverse Mercator as described above.
#' We recommend using the same UTM zone (36S).
#'
#' ### WGS 84 (EPSG:4326)
#' WGS 84 geographic coordinate system does not include any projection, so it is not recommended
#' for many spatial analyses, such as measuring distances. This CRS can be useful if you want to
#' export data to a GPS device.
#'
#' ### Additional options
#' There are many different CRS available, some of which may also be effective for working with data
#' from Ngorongoro Crater. Users can visit https://epsg.io/ to investigate other CRS, but
#' we cannot guarantee the reliability of alternative CRS. We recommend reading more
#' in the book [Geocomputation in R](https://geocompr.robinlovelace.net/reproj-geo-data.html) before
#' deciding to use a CRS besides those listed here.
#'
#' ## How to change the CRS
#' The CRS that will be used in `hyenaR` is set as a package option. This ensures that the same CRS is being
#' used for different tasks. You can change the CRS by running `options(hyenaR_crs = NEW_CRS_HERE)`.
#' A CRS can be described in many different ways such as with a (numeric) EPSG code,
#' as a character string using the syntax 'AUTHORITY:CODE',
#' or as the CRS name (e.g. 'WGS84'). All these are possible values that can be used to change the package option
#' in `hyenaR`, but we would recommend the syntax 'AUTHORITY:CODE'. For example, WGS 84 / UTM zone 36S could
#' be used by providing the character string 'EPSG:32736'.
#'
#' @name hyenaR_projection
#' @docType data
#' @keywords sf
NULL
