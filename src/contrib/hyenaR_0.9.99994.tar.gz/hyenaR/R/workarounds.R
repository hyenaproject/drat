#' A wrapper around utils:::stack.default to solve limitations around factors
#'
#' @inheritParams utils::stack
#' @inheritParams base::data.frame
#'
#' @return a `data.frame`
#' @export
#'
#' @examples
#' str(stack_list_to_df(list(a = "a", b = "b")))
#' str(stack_list_to_df(list(a = "a", b = "b"), stringsAsFactors = FALSE))
#'
stack_list_to_df <- function(x, drop = FALSE, stringsAsFactors = TRUE, ...) { ## new argument stringsAsFactors
  ## workaround utils:::stack.default to solve limitations around factors.
  ## issue reported on BugZilla, so it may change in R itself in the future.
  x <- as.list(x)
  keep <- unlist(lapply(x, is.vector))
  if (!sum(keep))
    stop("at least one vector element is required")
  if (!all(keep))
    warning("non-vector elements will be ignored")
  x <- x[keep]
  #ind <- rep.int(factor(names(x), unique(names(x))), lengths(x))
  ind <- rep.int(names(x), lengths(x)) ## ALEX
  if (stringsAsFactors) ind <- as.factor(ind) ## ALEX
  if (drop) {
    ind <- droplevels(ind)
  }
  #data.frame(values = unlist(unname(x)), ind, stringsAsFactors = FALSE)
  data.frame(values = unlist(unname(x)), ind, stringsAsFactors = stringsAsFactors) ## ALEX
}


#' Compute the maximum without failing
#'
#' This function attempts to solve some limitations of [`max`] as shown in example.
#'
#' @inheritParams arguments
#'
#' @return a scalar
#' @export
#'
#' @examples
#' find_vector_max(c(NA, NA))
#' find_vector_max(c(1, 2))
#' find_vector_max(c(NA, 1, 2))
#' class(find_vector_max(as.Date(NA))) ## it keeps the class
#'
find_vector_max <- function(vec, keep.class = TRUE) {
  if (all(is.na(vec))) {
    output <- NA
    if(keep.class) class(output) <- class(vec)
    return(output)
  }
  max(vec, na.rm = TRUE)
}


#' Compute the minimum without failing
#'
#' This function attempts to solve some limitations of [`min`] as shown in example.
#'
#' @inheritParams arguments
#' @return a scalar
#' @export
#'
#' @examples
#' find_vector_min(c(NA, NA))
#' find_vector_min(c(1, 2))
#' find_vector_min(c(NA, 1, 2))
#' class(find_vector_min(as.Date(NA))) ## it keeps the class
#'
find_vector_min <- function(vec, keep.class = TRUE) {
  if (all(is.na(vec))) {
    output <- NA
    if(keep.class) class(output) <- class(vec)
    return(output)
  }
  min(vec, na.rm = TRUE)
}

#' Compute the length of a vector without the NAs
#'
#' This function attempts to solve some limitations of `length(NA)`.
#'
#' @inheritParams arguments
#' @return a scalar
#' @export
#'
#' @examples
#' find_vector_length.without.na(NA)
#' find_vector_length.without.na(1)
#' find_vector_length.without.na(c(1, NA))
#'
find_vector_length.without.na <- function(vec) {
  length(vec[!is.na(vec)])
}



#' Delete the cached tables
#'
#' This is a function aimed at developers for testing purposes only.
#' It allows for the deletion of the cached table from the database.
#'
#' @return Nothing (invisibly) since it works by creating a side effect.
#' @export
#'
#' @examples
#' load_package_database.dummy()
#' delete_package_cached.table()
#' create_id_life.history.table(c("A-001"))
#' delete_package_cached.table()
delete_package_cached.table <- function() {

  tables_to_remove <- find_package_cached.table()

  if (length(tables_to_remove) > 0) {
    index_for_removal <- which(.database$database$table_name %in% tables_to_remove)
    assign(x = "database", value = .database$database[-index_for_removal, ], envir = .database)
    message("Cached table(s) deleted")
  } else {
    message("No cached table detected")
  }
  invisible(NULL)
}


#' Delete the cached tables
#'
#' This is a function aimed at developers for testing purposes only.
#' It allows for the deletion of the cached table from the database.
#'
#' @return Nothing (invisibly) since it works by creating a side effect.
#' @export
#'
#' @examples
#' load_package_database.dummy()
#' find_package_cached.table()
#' create_id_life.history.table(c("A-001"))
#' find_package_cached.table()
find_package_cached.table <- function() {
  check_database_is.loaded()
  list_possibly_cached_tables <- c("life_history") ## TODO: add here other cached tables once we will have new ones.
  .database$database$table_name[.database$database$table_name %in% list_possibly_cached_tables]
}
