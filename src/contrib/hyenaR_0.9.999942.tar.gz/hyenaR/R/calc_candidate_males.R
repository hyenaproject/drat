#' Determine all candidate males for a female
#'
#' Extract candidate males (adult males in the clan)
#' on a given date.
#'
#' @inheritParams arguments
#' @return A tibble with male names and age
#' @export
#'
#' @examples
#'
#' # Load dummy data
#' load_package_database.dummy()
#'
#' # Estimate males
#' create_id_mate.candidate.table.oldfn("A-001", at = "1997-01-01")
create_id_mate.candidate.table.oldfn <- function(femaleID, at) {
  birthdate <- deathdate <- ID <- destination <- sex <- . <- current_clan <- age <- adult <- NULL

  hyenas <- extract_database_table(tbl.names = "hyenas")
  selections <- extract_database_table(tbl.names = "selections")
  deaths <- extract_database_table(tbl.names = "deaths")
  at <- as.Date(at, format = "%Y-%m-%d")

  # Check the female was alive on this date!
  if (hyenas[["birthdate"]][which(hyenas$ID == femaleID)] > at | (femaleID %in% deaths$ID &&
    deaths[["deathdate"]][which(deaths$ID == femaleID)] <= at)) {
    stop(paste0("The focal female was not alive on ", at))
  }

  # Firstly, we determine the clan of the female.
  # Check that she never moved (rare but it happens!)
  if (!femaleID %in% selections$ID) {
    fem_clan <- hyenas[["birthclan"]][which(hyenas$ID == femaleID)]
  } else {
    fem_clan <- selections[["destination"]][which(selections$ID == femaleID & date < at)]
  }

  # Check that the female isn't somewhere outside of the main clans
  if (!fem_clan %in% c("A", "E", "F", "L", "M", "N", "S", "T")) {
    stop("The focal female was outside one of the main clans on this date")
  }

  # Determine dispersals of all individuals before the focal date (to determine current clan)
  disp_clan <- selections %>%
    dplyr::filter(date < at) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::summarise(current_clan = destination)

  # Determine the current clan of all MALES (we don't care about females now)
  clan_summary <- hyenas %>%
    dplyr::left_join(multiple = "all", deaths, by = "ID") %>%
    dplyr::filter(sex == "male" &
      birthdate < at &
      (is.na(deathdate) | deathdate > at)) %>%
    # Determine the current clan of each individual
    dplyr::mutate(current_clan = purrr::pmap_chr(
      .l = list(
        focal = .$ID,
        birthclan = .$birthclan
      ),
      .f = function(focal, birthclan, disp_clan) {
        if (focal %in% disp_clan$ID) {
          return(dplyr::filter(disp_clan, ID == focal) %>%
            dplyr::pull(current_clan))
        } else {
          return(birthclan)
        }
      }, disp_clan = disp_clan
    )) %>%
    # Filter only those individuals in the females clan
    dplyr::filter(current_clan == fem_clan) %>%
    # Calculate age of all individuals
    dplyr::mutate(age = floor(fetch_id_age(ID = .data$ID, at = at, unit = "months")),
      adult = age >= 24
    ) %>%
    # Let's just exclude non-adult males
    dplyr::filter(adult)

  return(clan_summary[, c("ID", "age")])
}
