#' Internal functions for loading/unloading/attaching the package
#'
#' @inheritParams arguments
#' @name attach_load
#' @aliases attach_load, .onAttach, .onLoad, .onUnload
NULL


#' @describeIn attach_load Display welcome message
#'
#' This function should not be called by the user.
#' It displays a message when the package is being loaded.
#'
#' @export
#'
.onAttach <- function(libname, pkgname) {

  #Don't print onAttach message if hyenaR is being loaded non-interactively
  #e.g. for cron jobs
  if (!interactive()) return()

  packageStartupMessage( ## display message
    "\n",
    "Welcome to ", crayon::green("hyenaR"), " v", utils::packageDescription("hyenaR")$Version,
    "\n",
    .logo,
    "\n",
    "\n",
    "Run:",
    "\n",
    " - ", crayon::blue("build_vignette_news()"), " for news",
    "\n",
    " - ", crayon::blue("build_vignette_grammar()"), " for an organized list of all functions",
    "\n",
    " - ", crayon::blue("build_vignette_data.summary()"), " for summary statistics about the population",
    "\n",
    " - ", crayon::blue("build_vignette_errors()"), " for multiple checks on the raw data",
    "\n",
    " - ", crayon::blue("build_vignette_tutorial.ranks()"), " for an old (not so great) tutorial",
    "\n",
    " - ", crayon::blue("build_vignette_devel()"), " for developer tips & guidelines",
    "\n",
    " - ", crayon::blue("help(package = 'hyenaR')"), " to access all help files",
    "\n",
    "\n",
    find_package_tip()
  )
}


## Setting object storing package info
.hyenaR <- new.env(parent = emptyenv())


#' @describeIn attach_load Load the package
#'
#' This function should not be called by the user.
#' This function stores the global options of the R session before the load of the package,
#' so that such setting can be restored safely once the package is unloaded. Also set the default
#' setting for the general options in hyenaR.
#'
#' @seealso [`hyenaR_options`]
#'
#' @export
#'
.onLoad <- function(libname, pkgname) {

  ## define some flags for displaying messages only once per session:
  .hyenaR$flag_CPUcores <- FALSE

  ## backup original R options:
  .hyenaR$backup_options <- .Options

  ## add hyenaR option to .Options:
  options(
    list(
      hyenaR_CPUcores = 2,   ## define global option CPUcores
      hyenaR_verbose = TRUE, ## define global option verbose
      hyenaR_crs = 'EPSG:32736', ## define global option for projected CRS
      hyenaR_crs.msg = TRUE) ## Should message about default CRS be displayed? Will only be shown once per session.
  )
}


#' @describeIn attach_load Unload the package
#'
#' This function should not be called by the user.
#' This function restores the global options of the R session on the unload of the package.
#'
#' @export
#'
.onUnload <- function(libpath) {
  if (exists(".hyenaR")) {
    options(.hyenaR$backup_options)  ## reset R options to their backed up values
  }
}


#' Provide some basic information about the code of the package
#'
#' This is a function for development purpose only. This function provides the
#' number of functions and lines of code of the package. The results depend on
#' whether the function is called from the compiled or the raw package. When
#' called from the compiled package, the number of functions only gives the
#' number of exported functions, and the number of lines of code no longer
#' includes documentation and examples.
#'
#' @note This function does not work with `devtools::load_all(".")`.
#'
#' @export
#'
find_package_info <- function() {
  message(paste("Number of exported functions =", length(ls("package:hyenaR")) - 1)) ## remove one for the pipe
  if (requireNamespace("R.utils", quietly = TRUE)) {
    files <- dir(paste0(find.package(package = "hyenaR"), "/R/"))
    filenames_R <- paste0(find.package(package = "hyenaR"), "/R/", files)
    lines_code <- sum(sapply(filenames_R, function(file) R.utils::countLines(file)))
    message(paste("Number of lines of code =", lines_code, "\nNote: the numbers are only reliable if the package is loaded using library()\nand not via devtools!"))
  } else {
    message("Install the package R.utils for more info.")
  }
  return(invisible(NULL))
}


#' Display tips about how to use the package
#'
#' This function returns one tip about how to use the package.
#'
#' Note for developers: let's try to write many tips for hyenaR!
#'
#' @export
#'
#' @examples
#' find_package_tip()
#'
find_package_tip <- function() {
  alltips <- c("a call to rm(list = ls()) will remove all the R objects created in your R session, but not the loaded database. \n This is because the loaded database is hidden.",
               "knowing well how to use the tidyverse package {dplyr} will greatly help you to use 'hyenaR' efficiently. \n The best place to learn about it is probably https://r4ds.had.co.nz/transform.html",
               "it is good practice to update your R packages frequently using update.packages(ask = FALSE, checkBuild = TRUE) or similar.",
               "a call to find_pop_id() gives you all the IDs present in loaded database.",
               "a call to e.g. extract_database_row('A-001') will extract all the info known about this individual from the database.",
               "create_id_starting.table() is the best function to start most workflows. It is very flexible, so check its documentation to discover how to customize all its arguments!",
               "you can suggest developers many more tips you would like to see here.\n Fill in an issue on GitHub for that or just talk to the developers.")
  tip <- sample(alltips, size = 1)
  paste0("Tip:\n ", crayon::green(tip))
}


#' @describeIn attach_load The logo of the package
#'
#' @export
#'
.logo <-
  c("                                                         ", "\n",
    "                             .             &&#           ", "\n",
    "                          .&%/&%.    %   .&(//(&&        ", "\n",
    "                         (%/////%&.#&%/&%&#//////%%      ", "\n",
    "                         &%///&(////##//////&%////&(     ", "\n",
    "                         #&///&/////////////(#////&*     ", "\n",
    "                          *&#%////////////////&%&&       ", "\n",
    "                            %#&#/////&%%///////%&        ", "\n",
    "                            #%//////////////////%&       ", "\n",
    "           /(/              %&&&&%///////////////&(      ", "\n",
    "       .&&//%&               &(///////#%%////////(&      ", "\n",
    "   && %&///(&                   /(////////////////&(     ", "\n",
    "   &&&#////&&%/           /&&&&%#(////////////////&&     ", "\n",
    "   %%//////%&.       (&&%/////%&&%////////////////#&     ", "\n",
    "   .&#/////&,    .&&&&&////////////////////////////&     ", "\n",
    "     %&////%& .&&/%&&#/////////////////////////////&(    ", "\n",
    "       %&(//#&%/////////%&&////////////////////////%&    ", "\n",
    "          %&%/////#&&#////%////////////////////////#&    ", "\n",
    "           &%//////////////////////////////////////%&    ", "\n",
    "          (&&#/////////////////////////////////////&#    ", "\n",
    "          %&#//////////////////&&///////#/////////%&     ", "\n",
    "          %&////////////////&(/&&(/////#(////////%&      ", "\n",
    "          %&//////(%////////(&(////////&////////%%       ", "\n",
    "          &&#%#/////&&&//////#&////////&///////%&        ", "\n",
    "          &%///////#&,#&%&&&&&&&///////&//////(&         ", "\n",
    "          &(//////&%...&%/////(&(//////&/////(&          ", "\n",
    "         ,&%/////&(....&%/////&&&&&%(//%/////&*          ", "\n",
    "          *%&#//&,....(&/////#%.%#//////////&(           ", "\n")



#' Historic version of create_id_starting.table()
#'
#' May behave not as expected.
#'
#' @describeIn starting_data Create a table of unique hyenas based on their ID or clan, life stage, and time.
#'
#' @export
create_id_starting.table.historic <- function(ID = NULL, sex = NULL, clan = NULL, lifestage = NULL, from = NULL, to = NULL, at = NULL,
                                              clan.overlap = 'any', lifestage.overlap = 'any',
                                              verbose = TRUE) {

  warning("This is an old version of `create_id_starting.table()` from hyenaR v0.9.99994. This function will eventually be depracated, but is included for backwards compatibility.")

  messages <- vector()

  if (!is.null(ID)) {

    if (!(is.null(c(sex, clan, lifestage, from, to, at)) && clan.overlap == 'any' && lifestage.overlap == 'any')) {

      messages <- append(messages, "When ID is provided other arguments are ignored. \n")

    }

    tibble::tibble(ID = check_function_arg.ID(ID)) -> output

  } else {

    ## Check sex This will be needed in all circumstances
    sex <- check_function_arg.sex(sex, .fill = TRUE)
    # If no date information is given, simply return all individuals from in the focal clans
    clan_null <- is.null(clan)
    clan <- check_function_arg.clan(clan, .fill = TRUE, main.clans = FALSE)

    if (all(is.null(lifestage), is.null(from), is.null(to), is.null(at)) && clan.overlap == "any" && lifestage.overlap == "any") {

      ## Handles messages about the origin of individuals selected when dates are missing:
      if (!clan_null) {
        if (!identical(clan, find_clan_name.all(main.clans = FALSE))) {
          messages <- append(messages, "No date information provided. Returning only individuals born in the focal clans. \n")
        }
      } else {
        messages <- append(messages, "No date information provided. Returning only individuals born in the main clans. \n")
      }

      extract_database_table("hyenas") %>%
        dplyr::filter(.data$birthclan %in% !!clan & .data$sex %in% !!sex) -> output

      if (verbose) {
        message(messages, appendLF = FALSE)
      }

      output %>%
        dplyr::select("ID") %>%
        dplyr::arrange(.data$ID) -> output

      return(output)
    }

    #If date information is provided, other arguments are relevant
    lifestage           <- check_function_arg.lifestage(lifestage, .fill = TRUE)

    if ("dead" %in% lifestage) {

      messages <- append(messages, "lifestage dead will return all individuals that have died up until this point. If you want to return only individuals that died during this period use lifestage.overlap = 'start' \n")

    }

    clan.overlap        <- check_function_arg.overlap(clan.overlap)
    lifestage.overlap   <- check_function_arg.overlap(lifestage.overlap)
    date_range          <- check_function_arg.date.fromtoat(from = from, to = to, at = at, .fill = TRUE,
                                                            max.date = find_pop_date.observation.last(),
                                                            min.date = find_pop_date.birth.first(), arg.max.length = 1)
    from                 <- date_range$from
    to                   <- date_range$to

    #If users are searching for 'dead' lifestage, flag that not all overlap are suitable
    if ("dead" %in% lifestage & any(c("end", "within") %in% lifestage.overlap)) {

      messages <- append(messages, "lifestage.overlap 'end' and 'within' make no sense when searching for dead individuals. \n If you want to know if individuals died between 'from' and 'to', use 'lifestage.overlap = start' \n")

    }

    #All life history stages of individuals in our focal clan(s)
    #This is needed to determine clan overlap (i.e. we need to know when an individual started in a clan,
    #even if the lifestage when they started was not a focal lifestage)
    life_history_full <- create_id_life.history.table(censored.to.last.sighting = FALSE) %>%
      dplyr::mutate(sex = fetch_id_sex(.data$ID)) %>%
      dplyr::filter(.data$clan %in% !!clan & .data$sex %in% !!sex)

    #Filter only the relevant life stages
    #This is needed to determine lifestage overlap but cannot be used for clan overlap
    #because we filter out periods of occupancy within the clan that are non-focal lifestages
    life_history_full %>%
      dplyr::filter(.data$life_stage %in% !!lifestage) -> life_history

    #If at is provided (or from and to are the same) then we ignore the overlap arguments
    if (from == to && (lifestage.overlap != "any" || clan.overlap != "any")) {

      messages <- append(messages, "'clan.overlap' or 'lifestage.overlap' is ignored because 'at' is specified \n")

      lifestage.overlap <- "any"
      clan.overlap      <- "any"

    }

    ## filtering by the lifestage.overlap
    output_raw <- create_id_overlap.table(life_history, from = from, to = to,
                                          overlap = lifestage.overlap)

    if (nrow(output_raw) > 0) {

      ## filtering by the clan.overlap
      ## for all individuals that pass the lifestage overlap filter
      ## determine when they started in the focal clan(s) in ANY lifestage
      life_history_full %>%
        dplyr::filter(ID %in% unique(output_raw$ID)) %>%
        dplyr::group_by(.data$ID, .data$clan) %>%
        dplyr::summarise(
          starting_date = min(.data$starting_date),
          last_lifestage = .data$life_stage[dplyr::n()],
          max_end_date   = max(.data$ending_date)) %>%
        dplyr::ungroup() %>%
        dplyr::mutate(ending_date = dplyr::case_when(last_lifestage == "dead" ~ as.Date(Inf, origin = "1970-01-01"),
                                                     .default = .data$max_end_date)) %>%
        dplyr::arrange(.data$ID, .data$starting_date) %>%
        dplyr::ungroup() -> output_clan_summary

      output <- create_id_overlap.table(output_clan_summary, from = from, to = to,
                                        overlap = clan.overlap)

    } else {

      output <- output_raw

    }

  }

  if (verbose && length(messages) > 0) { message(messages, appendLF = FALSE) }

  output %>%
    dplyr::select("ID") %>%
    dplyr::arrange(.data$ID) %>%
    dplyr::distinct(.data$ID)

}


