context("Test find_xxx functions")

test_that("all find functions return the correct type", {
  expect_equal(class(find_IDs(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_IDs(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_IDs(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_IDs(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id.male(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.male(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_clan_id.male(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.male(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id.female(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.female(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_clan_id.female(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.female(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id.adult(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.adult(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.adult(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id.immigrant(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.immigrant(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.immigrant(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id.dead(from = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.dead(to = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.dead())[1], "character")

  expect_equal(class(find_clan_id.life.stage(clan = c("A", "L"), date = "1997/01/01", status = "philopatric"))[1], "character")
  expect_equal(class(find_clan_id.life.stage(clan = "A", date = "1997/01/01", status = "philopatric"))[1], "character")
  expect_equal(class(find_clan_id.life.stage(clan = NULL, date = "1997/01/01", status = "philopatric"))[1], "character")
})


test_that("find_clan_id.dead return the correct output", {
  job1 <- find_clan_id.dead(from = "1996/09/01")
  job2 <- find_clan_id.dead(to = "1997/12/30")
  job3 <- find_clan_id.dead(from = "1996/09/10", to = "1997/12/30")
  ref1 <- c("A-043", "L-007")
  ref2 <- c("A-007", "A-043", "A-044", "A-058", "A-082", "L-006", "L-007",
            "L-043", "L-049", "L-091", "L-092")
  ref3 <- "A-043"
  expect_equal(job1, ref1)
  expect_equal(job2, ref2)
  expect_equal(job3, ref3)
})
