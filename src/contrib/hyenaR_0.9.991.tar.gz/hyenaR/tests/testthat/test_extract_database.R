context("Test that we can extract data from the database using extract_database_table()")

test_that("extract_database_table returns a list of tibbles if given more than one table name", {

  tables <- c("hyenas", "deaths")
  output <- extract_database_table(tables = tables)

  # Test output is a list
  expect_equal(class(output), "list")
  # Test that all list items are tibbles
  expect_true(all(sapply(output, function(x) {
    class(x)[1] == "tbl_df"
  })))
  # Test that the number of items in the list corresponds to the number of tables
  # requested
  expect_equal(length(output), length(tables))
})

test_that("extract_database_table returns a tibble (not list) when given one table name", {

  # Test output is a tibble
  expect_equal(class(extract_database_table(tables = "hyenas"))[1], "tbl_df")

})

test_that("Providing incorrect table names throws an error", {

  expect_error(extract_database_table(tables = "WRONG!!"))

})

test_that("Not first using `load_package_database.dummy()` throws an error", {
  expect_error(extract_database_table(tables = "WRONG!!"))
})
