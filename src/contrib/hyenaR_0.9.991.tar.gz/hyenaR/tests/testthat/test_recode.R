context("Test recode_xxx functions")

test_that("recode_offspring.sex_litter.type returns an output of the correct class", {
  expect_equal(class(recode_offspring.sex_litter.type(1, 1, 1, 1, 1, 1)), "character")
})

test_that("recode_offspring.sex_litter.type returns the correct output", {
  ref <- list(female = 1, male = 1, unknown = 1, social_female = 1, social_male = 1, social_unknown = 1)
  job <- check_arg_litter.type(1, 1, 1, 1, 1, 1)
  expect_equal(ref, job)
})
