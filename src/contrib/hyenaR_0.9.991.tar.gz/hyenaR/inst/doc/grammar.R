## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  rows.print = 100
)
library(hyenaR)

## ----build, echo = FALSE------------------------------------------------------
build_list <- ls("package:hyenaR", pattern = "^build")
data.frame(functions = build_list)

## ----calculate, echo = FALSE--------------------------------------------------
calculate_list <- ls("package:hyenaR", pattern = "^calculate")
data.frame(functions = calculate_list)

## ----check, echo = FALSE------------------------------------------------------
check_list <- ls("package:hyenaR", pattern = "^check")
data.frame(functions = check_list)

## ----count, echo = FALSE------------------------------------------------------
count_list <- ls("package:hyenaR", pattern = "^count")
data.frame(functions = count_list)

## ----create, echo = FALSE-----------------------------------------------------
create_list <- ls("package:hyenaR", pattern = "^create")
data.frame(functions = create_list)

## ----extract, echo = FALSE----------------------------------------------------
extract_list <- ls("package:hyenaR", pattern = "^extract")
data.frame(functions = extract_list)

## ----fetch, echo = FALSE------------------------------------------------------
fetch_list <- ls("package:hyenaR", pattern = "^fetch")
data.frame(functions = fetch_list)

## ----find, echo = FALSE-------------------------------------------------------
find_list <- ls("package:hyenaR", pattern = "^find")
data.frame(functions = find_list)

## ----join, echo = FALSE-------------------------------------------------------
join_list <- ls("package:hyenaR", pattern = "^join")
data.frame(functions = join_list)

## ----plot, echo = FALSE-------------------------------------------------------
plot_list <- ls("package:hyenaR", pattern = "^plot")
data.frame(functions = plot_list)

## ----recode, echo = FALSE-----------------------------------------------------
recode_list <- ls("package:hyenaR", pattern = "^recode")
data.frame(functions = recode_list)

## ----stretch, echo = FALSE----------------------------------------------------
stretch_list <- ls("package:hyenaR", pattern = "^stretch")
data.frame(functions = stretch_list)

## ----other, echo = FALSE------------------------------------------------------
all_list <- ls("package:hyenaR")
exclude_list <- "%>%"
others_list <- setdiff(all_list, c(build_list, calculate_list, check_list,
                                   count_list, create_list, extract_list,
                                   fetch_list, plot_list, find_list, join_list,
                                   recode_list, stretch_list, exclude_list))

data.frame(functions = others_list)

