#' Create tidy tables with hyena(s)
#'
#' These functions allow for the creating a tidy table in which each row correspond to an
#' individual. Depending on the function, individuals can be repeated or not. All functions from the
#' create family, provide at least a column with the ID of the hyena, and possibly other columns
#' depending on the function and the defined arguments. The produced tables are always of format
#' [tibble::tibble] and can be used as the basic structure around which you can add additional
#' columns using the functions from the [fetch_family].
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @param ID The ID code of hyena(s).
#' @param clan The letter of the clan(s). If `NULL` (default), returns
#'   information for the whole population.
#' @param censored_replaced_by_last_sighting TRUE to replace the last life history date by the last sighting date, FALSE (default) otherwise.
#' @param date The date(s) using the format "YYYY-MM-DD". If `NULL` (default), the clan (if defined)
#'   will be interpreted as the birth clan.
#' @param parent The ID code of hyenas(s)..
#' @param lineage The type of lineage (e.g. "mothergenetic", "mothersocial", "father").
#' @param litter_ID Litter code of given litters.
#' @param filiation The type of parent-offspring relationship: "genetic_only",
#' "social_only", "social_and_genetic", or a combination.
#'
#' @return A tidy table
#'
#' @name create_family
#' @aliases create_family create
#'
#' @examples
#'
#'
#' ### Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL


#' @describeIn create_family create a table with hyenas.
#' @export
#' @examples
#'
#' #### Simple examples of create_basetable usage:
#'
#' ### create a table for all individuals:
#' create_basetable()
#'
#' ### create a table for all individuals born in clan A:
#' create_basetable(clan = "A")
#'
#' ### create a table for two clans at one date:
#' create_basetable(clan = c("A", "L"), date = "1997/01/01")
#'
#' ### create a table for two clans, with one date per clan:
#' create_basetable(clan = c("A", "L"), date = c("1997/01/01", "1997/01/02"))
#'
#' ### combining create_basetable and fetch functions to get sex and age of clan "A" on
#' ### christmas day 1997:
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#' create_basetable(clan = "A", date = "1997/12/25") %>%
#'   mutate(
#'     sex = fetch_id_sex(ID = ID),
#'     age = fetch_id_age(ID = ID, date = date)
#'   )
#'  }
create_basetable <- function(clan = NULL, date = NULL) {

  if (length(date) > 1 & length(clan) != length(date)) {
    stop("This function does not cope with a different number (>1) of dates and clans. If you think it would be useful, please inform the developers!")
  }

  if (!is.null(clan) & is.null(date)) {
    message(paste0("Since the argument date is NULL but clan is not, clan(s) are assumed to refer to the ", crayon::red$bold("birth clan(s)"), "!"))
  }

  ## If clan are not defined, all clans are considered:
  doclan <- ifelse(is.null(clan), FALSE, TRUE)
  clan <- check_arg_clan(clan, fill = TRUE)

  ## Deal with no date being defined:
  if (is.null(date)) {
    extract_database_table(tables = "hyenas") %>%
      dplyr::filter(birthclan %in% !!clan) %>%
      dplyr::select(ID, birthclan) -> output
    if (!doclan) {
      output %>%
        dplyr::select(-birthclan) -> output
    }
    return(output)
  }

  ## Deal with date being defined:
  date <- check_arg_date(date)

  input <- tibble::tibble(clan = clan, date = date)

  ## Create a list with one element per clan/date combination:
  clan_members <- purrr::pmap_df(input, ~ find_clan_id.all(date = ..2, clan = ..1, min_age = 0) %>%
    dplyr::mutate(date = ..2))

  clan_members %>%
    dplyr::rename(
      clan = currentclan
    ) %>%
    dplyr::select(-native) %>%
    dplyr::arrange(clan, date, ID) -> output

  birthclan <- ID <- currentclan <- native <- NULL ## to please R CMD check

  output
}


#' @describeIn create_family deprecated function! Use [create_basetable()] instead.
#'
#' @export
create_basetable_for_all <- function() .Deprecated("create_basetable")


#' @describeIn create_family create a table with hyenas based on their ID.
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_basetable usage:
#' create_id_starting.table(c("A-001", "L-003", "A-100"))
#'
create_id_starting.table <- function(ID) {
  tibble::tibble(ID = check_arg_ID(ID))
}


#' @describeIn create_family create a tidy table with individuals and their reproductive mates.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_matestable usage:
#' create_matestable(c("A-001", "L-003", "A-100"))
#'
create_matestable <- function(ID = NULL) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  mates_list <- calculate_mates(ID = ID)
  mates_df <- stack_list_to_df(mates_list, stringsAsFactors = FALSE)

  mates_df %>%
    tibble::as_tibble() %>%
    dplyr::transmute(ID = as.character(ind), mate = values) -> mates_tbl

  input %>%
    dplyr::left_join(mates_tbl, by = "ID") -> output

  ind <- values <- NULL ## to please R CMD check

  output
}


#' @describeIn create_family create a tidy table with individuals, their mates, and estimated mating date.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_dyad.mate_conception.table usage:
#' create_dyad.mate_conception.table(c("A-001", "L-003", "A-098"))
#'
create_dyad.mate_conception.table <- function(ID){

  ID <- check_arg_ID(ID)

  input <- tibble::tibble(ID = ID)

  create_dyad.offspring_starting.table(ID) %>%
    dplyr::filter(.data$filiation != "social_only" | is.na(.data$filiation)) %>%
    dplyr::rename(ID = .data$parent) %>%
    dplyr::mutate(
      focal_sex = fetch_id_sex(.data$ID),
      offspring_birthdate = fetch_id_date.birth(.data$offspring),
      mate = dplyr::case_when(
        focal_sex == "male" ~ fetch_id_id.mother.genetic(.data$offspring),
        focal_sex == "female" ~ fetch_id_id.father(.data$offspring),
        TRUE ~ NA_character_
      ),
      date = .data$offspring_birthdate - 110
    ) %>%
    dplyr::select(.data$ID, .data$mate, .data$date) %>%
    dplyr::distinct() %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output

  output
}


#' @describeIn create_family create a tidy table with individuals, their
#' offspring, and the offspring-parent relationship (genetic_only, social_only,
#' social_and_genetic) which is called 'filiation'.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_dyad.offspring_starting.table usage:
#' create_dyad.offspring_starting.table(ID = c("A-001", "L-003", "A-100"))
#'
create_dyad.offspring_starting.table <- function(ID = NULL) {

  ## check and process argument:
  ID <- check_arg_ID(ID, fill = TRUE)

  ## we extract all the data:
  hyenas <- extract_database_table(tables = "hyenas")

  ## we filter the data:
  hyenas_focus_mothers <- hyenas[hyenas$mothergenetic %in% ID | hyenas$mothersocial %in% ID, ]
  hyenas_focus_fathers <- hyenas[hyenas$father %in% ID, ]

  ## we list all offspring for each parent according to the type of the parent:
  list_offspring_from_mothers.genetic <- split(hyenas_focus_mothers$ID, hyenas_focus_mothers$mothergenetic)
  list_offspring_from_mothers.social <- split(hyenas_focus_mothers$ID, hyenas_focus_mothers$mothersocial)
  list_offspring_from_fathers <- split(hyenas_focus_fathers$ID, hyenas_focus_fathers$father)

  ## we turn the list into df where the parent is column 1, offspring column 2, and offspring type column 3:
  ## note: the [, 2:1] leads to data ordered by parents instead of by offspring
  df_offspring_blank <- data.frame(parent = NA_character_,
                                   offspring = NA_character_,
                                   filiation = NA_character_,
                                   stringsAsFactors = FALSE)
  df_offspring_from_mothers.genetic <- df_offspring_blank
  df_offspring_from_mothers.social  <- df_offspring_blank
  df_offspring_from_fathers         <- data.frame()

  if (length(list_offspring_from_mothers.genetic) > 0) {
    df_offspring_from_mothers.genetic <- cbind(stack_list_to_df(list_offspring_from_mothers.genetic,
                                                                stringsAsFactors = FALSE)[, 2:1],
                                               filiation = "genetic",
                                               stringsAsFactors = FALSE)
    colnames(df_offspring_from_mothers.genetic)[1:2] <- c("parent", "offspring")
  }

  if (length(list_offspring_from_mothers.social) > 0) {
    df_offspring_from_mothers.social <- cbind(stack_list_to_df(list_offspring_from_mothers.social,
                                                               stringsAsFactors = FALSE)[, 2:1],
                                              filiation = "social",
                                              stringsAsFactors = FALSE)
    colnames(df_offspring_from_mothers.social)[1:2] <- c("parent", "offspring")
  }

  if (length(list_offspring_from_fathers) > 0) {
    df_offspring_from_fathers <- cbind(stack_list_to_df(list_offspring_from_fathers,
                                                        stringsAsFactors = FALSE)[, 2:1],
                                       filiation = "genetic_only",
                                       stringsAsFactors = FALSE
                                       )
    colnames(df_offspring_from_fathers)[1:2] <- c("parent", "offspring")
  }

  ## we combine information from mothers:
  dplyr::anti_join(df_offspring_from_mothers.social[, -3],
                   df_offspring_from_mothers.genetic[, -3],
                   by = c("parent", "offspring")) -> df_social_only_offspring_from_mothers

  if (nrow(df_social_only_offspring_from_mothers) == 0  ||
      all(is.na(df_social_only_offspring_from_mothers))) {
    df_social_only_offspring_from_mothers <- data.frame()
  } else {
    df_social_only_offspring_from_mothers$filiation <- "social_only"
  }

  dplyr::anti_join(df_offspring_from_mothers.genetic[, -3],
                   df_offspring_from_mothers.social[, -3],
                   by = c("parent", "offspring")) -> df_genetic_only_offspring_from_mothers

  if (nrow(df_genetic_only_offspring_from_mothers) == 0 ||
      all(is.na(df_genetic_only_offspring_from_mothers))) {
    df_genetic_only_offspring_from_mothers <- data.frame()
  } else {
    df_genetic_only_offspring_from_mothers$filiation <- "genetic_only"
  }

  dplyr::inner_join(df_offspring_from_mothers.social[, -3],
                    df_offspring_from_mothers.genetic[, -3],
                    by = c("parent", "offspring")) -> df_social_and_genetic_offspring_from_mothers

  if (nrow(df_social_and_genetic_offspring_from_mothers) == 0 ||
      all(is.na(df_social_and_genetic_offspring_from_mothers))) {
    df_social_and_genetic_offspring_from_mothers <- data.frame()
  } else {
    df_social_and_genetic_offspring_from_mothers$filiation <- "social_and_genetic"
  }

  df_offspring_from_mothers <- rbind(df_social_only_offspring_from_mothers,
                                     df_genetic_only_offspring_from_mothers,
                                     df_social_and_genetic_offspring_from_mothers,
                                     stringsAsFactors = FALSE)

  ## we combine information of mothers and fathers:
  df_offspring_from_parents <- rbind(df_offspring_from_mothers,
                                     df_offspring_from_fathers,
                                     stringsAsFactors = FALSE)

  ## output:
  if (nrow(df_offspring_from_parents) == 0) {
    df_offspring_from_parents <- df_offspring_blank
  }
  dplyr::left_join(tibble::tibble(parent = ID), df_offspring_from_parents, by = "parent")
}


#' @describeIn create_family create a tidy table with individuals, their offspring and the litter ID.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_dyad.offspring_litter.table usage:
#' create_dyad.offspring_litter.table(parent = c("A-001", "A-008", "A-011",
#'                                                 "A-040", "A-058"))
#'
create_dyad.offspring_litter.table <- function(parent = NULL) {
  parent <- check_arg_ID(ID = parent, fill = TRUE)

  ## Parent's sex and Offspring's birthdate added to define litters afterwards:
  create_dyad.offspring_starting.table(parent) %>%
    dplyr::mutate(birth_offspring = fetch_id_date.birth(.data$offspring),
                  sex_parent = fetch_id_sex(.data$parent)) -> offsprings

  ## Males and females are separated since males take litterd_ID from genetic mothers:
  offsprings %>%
    dplyr::filter(.data$sex_parent == "male" | is.na(.data$sex_parent)) -> offspring_from_males ## also includes unknown sex

  offsprings %>%
    dplyr::filter(.data$sex_parent == "female") -> offspring_from_females


  ## Each litters is defined within the mother:
  offspring_from_females %>%
    dplyr::group_by(.data$parent) %>%
    ## One row for each litter/birthdate to calculate differences in days among birthdates of different litters
    dplyr::distinct(.data$birth_offspring, .data$sex_parent, .data$filiation) %>%
    dplyr::arrange(.data$birth_offspring, .by_group = TRUE) %>%
    ## Social cubs are included in the social mother's genetic litters if born 90 days
    ## Backwards or afterwards the birthdate of the litter:
    dplyr::mutate(previous_birthdate = dplyr::lag(.data$birth_offspring),
                  next_birthdate = dplyr::lead(.data$birth_offspring)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(diff_prev = .data$birth_offspring - .data$previous_birthdate,
                  diff_next = .data$next_birthdate - .data$birth_offspring,
                  inclusion_birthdate = dplyr::case_when(.data$filiation == "genetic_only" | .data$filiation == "social_and_genetic" ~ .data$birth_offspring,
                                                         .data$filiation == "social_only" & .data$diff_next <= 90 ~ .data$next_birthdate,
                                                         .data$filiation == "social_only" & .data$diff_prev <= 90 ~ .data$previous_birthdate,
                                                         TRUE ~ .data$birth_offspring)) %>%
    dplyr::select(.data$parent, .data$birth_offspring, .data$inclusion_birthdate) -> offspring_from_females_with_inclusion_birthdate


  ## Birthdates within each mother are duplicated for each offspring born at the same date
  ## By that, each offspring born from the same mother at the same date will be assigned the same litter:
  dplyr::full_join(offspring_from_females, offspring_from_females_with_inclusion_birthdate, by = c("parent",  "birth_offspring")) %>%
    select(.data$parent, .data$offspring, .data$filiation, .data$inclusion_birthdate) -> offspring_from_females

  ## litterID will be "mothercode-00+litterorder", if parent didn't have offspring will be NA:
  offspring_from_females %>%
    dplyr::group_by(.data$parent) %>%
    dplyr::mutate(litter_order = dplyr::dense_rank(.data$inclusion_birthdate),
                  litter_ID = dplyr::if_else(is.na(.data$offspring), NA_character_,
                                             paste(.data$parent, formatC(.data$litter_order, width = 3, flag = "0"), sep = "_"))) %>%
    dplyr::ungroup() %>%
    dplyr::select(-.data$litter_order) -> littersID_females
  ## Fathers will have the same litterID of their offspring's genetic mother
  littersID_females %>%
    dplyr::filter(.data$filiation != "social_only") -> genetic_littersID_females

  offspring_from_males %>%
    dplyr::left_join(genetic_littersID_females, by = "offspring") %>%
    dplyr::select(parent = .data$parent.x , .data$offspring, filiation = .data$filiation.x, .data$inclusion_birthdate, .data$litter_ID) -> littersID_males

  ## Litters ID of females and males are joined
  dplyr::full_join(littersID_females, littersID_males,
                   by = c("parent", "offspring", "filiation", "inclusion_birthdate", "litter_ID")) %>%
    dplyr::distinct() %>%
    dplyr::select(.data$parent, .data$offspring, .data$filiation, .data$litter_ID) %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(.data$offspring))  %>%
    dplyr::group_by(.data$parent) %>%
    dplyr::arrange(.data$litter_ID, .by_group = TRUE) %>%
    dplyr::ungroup() -> littersID_temp

  ## reorder output to have parents as input: TODO have this in all create functions.
  littersID_temp[order(match(littersID_temp$parent, parent)), ] -> litters_ID
  if (!identical(unique(litters_ID$parent), unique(parent))) {
    stop("some problem is happening inside the code of create_dyad.offspring_litter.table, please contact the devel team!")
  }
  litters_ID
}


#' @describeIn create_family create a table of the life history of focal individual(s)
#'
#' @export
#' @examples
#'
#'  #### Simple example of create_life_history usage:
#'  create_id_life.history.table(c("A-001", "L-003", "A-098"))
#'
create_id_life.history.table <- function(ID, censored_replaced_by_last_sighting = FALSE) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  create_id_life.transition.table(input$ID) %>%
    dplyr::select(-.data$origin) %>%
    dplyr::rename(clan = .data$destination) -> selections

  ## Life history before selection: spliting first row in the selection table
  selections %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::arrange(date, .by_group = TRUE) %>% ## in case data are not ordered
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(
      sex = fetch_id_sex(.data$ID),
      date_first_selection = ifelse(!is.na(.data$sex), fetch_id_date.selection.first(.data$ID), as.Date(NA)), # remove is.na if fetch_id_date.selection.first works for na and female
      date_age_1 = fetch_id_date.at.age(.data$ID, 1),
      date_age_2 = fetch_id_date.at.age(.data$ID, 2),
      # for individuals from clan X, the life history before selection is unknown
      unknown =  dplyr::if_else(.data$clan == "X", .data$date, as.Date(NA)),
      cub = dplyr::if_else(.data$clan != "X", .data$date, as.Date(NA)),
      subadult = dplyr::if_else(.data$clan != "X" & fetch_id_is.alive(.data$ID, .data$date_age_1), .data$date_age_1, as.Date(NA)),
      ## Only males and unknown sex individuals have the natal stage in life history
      natal = dplyr::if_else(.data$clan != "X" & ((is.na(.data$sex) | .data$sex == "male") & (.data$date_age_2 < .data$date_first_selection)) & fetch_id_is.alive(.data$ID, .data$date_age_2), .data$date_age_2, as.Date(NA))
     ) -> life_history_before_selection_wide

  life_history_before_selection_wide %>%
    dplyr::select(-.data$date, -.data$date_age_1, -.data$date_age_2) %>%
    dplyr::select(-.data$sex) %>%
    tidyr::pivot_longer(cols = c("cub", "subadult", "natal", "unknown"),
                        names_to = "life_stage",
                        values_to = "starting_date") %>%
    dplyr::filter(!is.na(.data$starting_date)) -> life_history_before_selection

  ## Life history after selection
  selections %>%
    dplyr::mutate(is_transient = .data$clan == "Y",
                  birth_clan = fetch_id_clan.birth(.data$ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::arrange(date, .by_group = TRUE) %>%  ## in case data are not ordered
    dplyr::slice(-1) %>%
    dplyr::mutate(selection_times = dense_rank(.data$date),
                  life_stage = case_when(
                    .data$selection_times == 1 & .data$clan == .data$birth_clan ~ "philopatric",
                    ## because we are not sure that those coming from X have dispersed only 1 or more times before, we call them immigrant!
                    .data$selection_times == 1 & .data$clan != .data$birth_clan & .data$birth_clan == "X" ~ "immigrant",
                    .data$selection_times == 1 & .data$clan != .data$birth_clan ~ "disperser",
                    is_transient ~  "transient",
                    ## Transient does not count as selection event
                    TRUE ~ paste0("selector_", .data$selection_times - cumsum(.data$is_transient))
                    )
                  ) %>%
    dplyr::ungroup() %>%
    dplyr::select(.data$ID, .data$clan, starting_date = .data$date, .data$life_stage) -> life_history_after_selection

  lastsighting <- find_pop_observation.last()

  # Merge stages together and calculate the ending date of each stage by creating a column of dislocated starting date
  dplyr::bind_rows(life_history_before_selection, life_history_after_selection) %>%
    dplyr::arrange(.data$ID, .data$starting_date) %>%
    dplyr::mutate(deathdate = fetch_id_date.death(.data$ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::mutate(ending_date = lead(.data$starting_date) - 1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(# if the deathdate is NA, use last sighting date as the ending date
                  ending_date = dplyr::case_when(is.na(.data$ending_date) & is.na(.data$deathdate) & !!censored_replaced_by_last_sighting ~ !!lastsighting,
                                                 is.na(.data$ending_date) & is.na(.data$deathdate) & !(!!censored_replaced_by_last_sighting) ~ as.Date(NA),
                                                 is.na(.data$ending_date) & !is.na(.data$deathdate) ~ .data$deathdate,
                                                 TRUE ~ .data$ending_date)) %>%
    dplyr::select(.data$ID, .data$clan, .data$life_stage, .data$starting_date, .data$ending_date) %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output

  output
}

#' @describeIn create_family create a tidy table with individuals and their selection events.
#'
#' @export
#'
#' @examples
#' #### Simple examples of create_id_life.transition.table usage:
#' create_id_life.transition.table(c("A-001", "L-003", "A-098"))
#'
create_id_life.transition.table <- function(ID = NULL) {

  ID <- check_arg_ID(ID)

  input <- tibble::tibble(ID = ID)

  lastsighting <- find_pop_observation.last()

  ## Add female philopatry in the selection event
  input %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID),
                  date_age_2 = fetch_id_date.at.age(.data$ID, 2),
                  first_conception_date = fetch_id_date.conception.first(.data$ID)) %>%
    dplyr::filter(.data$sex == "female" & fetch_id_is.alive(.data$ID, .data$date_age_2) & .data$date_age_2 < !!lastsighting) %>%
    dplyr::mutate(origin = fetch_id_clan.birth(.data$ID),
                  destination = .data$origin,
                  date = dplyr::if_else(.data$date_age_2 < .data$first_conception_date | is.na(.data$first_conception_date), .data$date_age_2, .data$first_conception_date)) %>%
    dplyr::select(.data$ID, .data$origin, .data$destination, .data$date) -> female_philopatry

  ## Extract selection event from selection table
  selections <- extract_database_table("selections")
  focal_selections_no_young_females <- selections[selections$ID %in% input$ID, ]
  focal_selections <- dplyr::bind_rows(focal_selections_no_young_females, female_philopatry)

  # Add birth as selection event
  input %>%
    dplyr::mutate(origin = "W", # origin of birth events will be marked as W (womb)
                  destination = fetch_id_clan.birth(ID = .data$ID),
                  date = fetch_id_date.birth(ID = .data$ID)) %>%
    dplyr::full_join(focal_selections, by = c("ID", "date", "origin","destination")) %>%
    dplyr::arrange(.data$ID, .data$date) -> transition_full ## restore empty rows but does not conserve ID ranking

  dplyr::left_join(input, transition_full, by = "ID") -> output

  output

}


#' @describeIn create_family create a tidy table with individuals and their litters.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_litter_starting.table usage:
#' create_litter_starting.table(c("A-001", "L-003", "A-098"))
#'
create_litter_starting.table <- function(parent = NULL) {
  parent <- check_arg_ID(parent, fill = TRUE)

  ## Reading the full table and keeping only one row for each litter_ID:
  create_dyad.offspring_litter.table(parent = parent) %>%
    dplyr::select(.data$parent, .data$litter_ID) %>%
    dplyr::distinct() %>%
    dplyr::ungroup() -> litters

  litters
}


#' @describeIn create_family create a tidy table with all litters for each ID and the corresponding number of daughters, sons and cubs with unknown sex.
#'
#' @export
#' @examples
#' ### Simple example of usage of create_litter_offspring.count ###
#' create_litter_offspring.count("A-001_004")
#'
create_litter_offspring.count <- function(litter_ID) {
  litter_ID <- check_arg_litter.ID(litter_ID)
  litter.df <- tibble::tibble(litter_ID = litter_ID)
  parent <- substr(litter_ID, 1, 5)

  create_dyad.offspring_litter.table(parent) %>%
    dplyr::mutate(sex_offspring = ifelse(.data$filiation == "social_only",
                                         paste("social", fetch_id_sex(.data$offspring), sep = "_"),
                                         fetch_id_sex(.data$offspring))) -> input

  input$sex_offspring[!is.na(input$offspring) & is.na(input$sex_offspring) & (input$filiation == "genetic_only" | input$filiation == "social_and_genetic")] <- "unknown"
  input$sex_offspring[!is.na(input$offspring) & is.na(input$sex_offspring) & input$filiation == "social_only"] <- "social_unknown"

  input %>%
    dplyr::mutate(sex_offspring = factor(.data$sex_offspring,
                                         levels = c("female",
                                                    "male",
                                                    "unknown",
                                                    "social_female",
                                                    "social_male",
                                                    "social_unknown"))) -> input

  ## Each row becomes a litter:
  suppressWarnings( ## to prevent spurious warnings from old dplyr:
                    ## Factor `sex_offspring` contains implicit NA, consider using `forcats::fct_explicit_na`
    input %>%
      dplyr::count(.data$parent, .data$litter_ID, .data$sex_offspring, .drop = FALSE) -> litters
  )
  tidyr::pivot_wider(litters, names_from = .data$sex_offspring, values_from = .data$n, values_fill = list(n = 0)) -> litters

  litter.df %>%
    dplyr::left_join(litters, by = "litter_ID") %>%
    select(-(.data$parent)) -> output

  output

}



#' @describeIn create_family create a tidy table with all daughters, sons, and cubs with unknown sex that a mother gave birth to in her life.
#' @export
#' @examples
#'
#' ### Simple example of usage of create_id_offspring.table ###
#' create_id_offspring.count(ID = c("A-001", "A-008"))
#'
create_id_offspring.count <- function(ID, filiation = c("genetic_only", "social_and_genetic")) {

  ID <- check_arg_ID(ID)
  filiation <- check_arg_filiation(filiation)

  create_dyad.offspring_starting.table(ID) %>%
    dplyr::mutate(sex_offspring = fetch_id_sex(.data$offspring)) %>%
    dplyr::filter(.data$filiation %in% !!filiation | is.na(.data$filiation)) -> offspring

  offspring$sex_offspring[is.na(offspring$sex_offspring) & !is.na(offspring$offspring)] <- "unknown"

  offspring %>%
    dplyr::group_by(.data$parent) %>%
    dplyr::summarise(n_females = sum(.data$sex_offspring == "female"),
                     n_males = sum(.data$sex_offspring == "male"),
                     n_unknown = sum(.data$sex_offspring == "unknown")) -> output

  return(output)

}



#' @describeIn create_family create a table that documents the starting and ending time of each clan the focal individual(s) stayed.
#' @export
#' @examples
#'
#' #### Simple example of create_selection_history usage:
#' create_id_selection.history(c("A-001","A-080"))
#'
create_id_selection.history <- function(ID, censored_replaced_by_last_sighting = FALSE) {

  input <- check_arg_ID(ID)
  lastsighting <- find_pop_observation.last()

  create_id_life.transition.table(input) %>%
    dplyr::select(-.data$origin) %>%
    dplyr::rename(clan = .data$destination) %>%
    group_by(.data$ID) %>%
    dplyr::mutate(
      clan_after = dplyr::lead(.data$clan, 1),
      date_after_1 = dplyr::lead(.data$date, 1) - 1,
      date_after_2 = dplyr::lead(.data$date, 2) - 1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(deathdate = fetch_id_date.death(.data$ID),
                  ending_date = dplyr::case_when(!is.na(.data$clan_after) & .data$clan != .data$clan_after ~ .data$date_after_1,
                                                 is.na(.data$deathdate) & is.na(.data$date_after_2) & !!censored_replaced_by_last_sighting ~ !!lastsighting,
                                                 is.na(.data$deathdate) & is.na(.data$date_after_2) & !(!!censored_replaced_by_last_sighting) ~ as.Date(NA),
                                                 is.na(.data$date_after_2) ~ .data$deathdate,
                                                 TRUE ~ .data$date_after_2)) %>%
    dplyr::rename(starting_date = .data$date) %>%
    dplyr::select(.data$ID, .data$clan, .data$starting_date, .data$ending_date) %>%
    dplyr::group_by(.data$ID, .data$ending_date, .data$clan) %>%
    dplyr::slice(1) %>% ## first row of groups with the same ending date do not correspond to a selection event but to a age development
    dplyr::ungroup() -> output

  output
}
