#' Download benchmarks (for developers)
#'
#' This function downloads the benchmark results performed during the continuous integration.
#'
#' This is not designed for normal users but it allows developers to check how fast the code is
#' running.
#'
#' @inheritParams fetch_family
#' @param compact A boolean indicating whether (TRUE, default) or not (FALSE) to trim the output to
#'   the most useful columns
#' @param max_commits The maximum number of commits with benchmark results to return (default = 10)
#'
#' @return A `tibble`.
#' @export
#'
#' @examples
#' \dontrun{
#'   download_package_benchmarks()
#' }
#'
download_package_benchmarks <- function(compact = TRUE, max_commits = 10, debug = FALSE) {

  ## test if the function can run:
  if (!interactive())  stop("this function can only be used in interactive mode")

  if (!requireNamespace("bench", quietly = TRUE)) stop("you must install the R package {bench} to use download_info_benchmark")

  ## fetch benchmarks from GitHub:
  bench::cb_fetch()
  ## retrieve benchmarks:
  all <- bench::cb_read()
  if (debug) return(all)

  ## identify commits with benchmarks:
  which_benchs <- sapply(all$benchmarks, nrow) > 0
  if (sum(which_benchs) == 0) {
    stop("no benchmark results found for any commits")
  }

  ## keep only commits with benchmarks:
  all_benchs <- all[which_benchs, c("subject", "benchmarks")]

  ## apply nrow restriction:
  max_commits <- min(c(max_commits, nrow(all_benchs)))
  all_benchs <- all_benchs[seq_len(max_commits), ]

  ## select the desired commit:
  commit <- utils::menu(
    choices = all_benchs$subject,
    title = "For which commit do you want to see the benchmarks?"
  )
  ## unnesting the selected tibble:
  output <- all_benchs[commit, "benchmarks"][[1]][[1]]

  ## drop useless columns:
  if (compact) {
    output <- output[, c("name", "p0", "mean", "p100", "mem_alloc")]
  }

  output
}
