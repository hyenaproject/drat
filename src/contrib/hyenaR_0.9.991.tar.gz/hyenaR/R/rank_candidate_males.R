
#' Determine all candidate males for a birth
#'
#' Extract candidate males (sexually active males in the clan) and compute
#' theirs ranks.
#'
#' @param cub_ID ID of the cub
#' @return A tibble with male names rank and other info about the cub
#' @export
#' @import dplyr
get_candidate_males_rank <- function(cub_ID) {

  ###########
  # load data

  hyenas <- extract_database_table(tables = "hyenas") %>%
    mutate(birthdate = lubridate::ymd(birthdate))

  selections <- extract_database_table(tables = "selections") %>%
    mutate(date = lubridate::ymd(date))

  deaths <- extract_database_table(tables = "deaths") %>%
    mutate(deathdate = lubridate::ymd(deathdate))

  #######################################
  # retrieve cub´s information from hyenas

  ID_info <- hyenas[hyenas$ID == cub_ID, ]

  mother_genetic <- female <- ID_info$mothergenetic
  father <- ID_info$father
  sex <- ifelse(ID_info$sex == 1, "male", "female")
  focal_date <- ID_info$birthdate - days(110)
  birth_date <- ID_info$birthdate
  clan <- fem_clan <- ID_info$birthclan
  date_range <- c(focal_date - days(90), focal_date + days(90))

  #############
  # get mom rank

  mom_input <- data.frame(
    ID = mother_genetic,
    date = focal_date
  )

  if (is.na(mom_input$ID)) {
    mom_rank <- data.frame(
      gender_rank = NA,
      gender_rank_std = NA,
      stringsAsFactors = FALSE
    )
  } else {
    mom_rank <- calculate_rank(mom_input)[, c("gender_rank", "gender_rank_std")]
  }

  ##########################
  # retrieve candidate males

  disp_clan3 <- retrieve_candidate_males(cub_ID, hyenas, selections, deaths)


  #########################################
  # change date for the deaths or dispersers

  input <- disp_clan3 %>%
    mutate(date = lubridate::ymd(ifelse(deathdate <= focal_date & !is.na(deathdate), as.character(deathdate - days(1)),
      ifelse(out_date <= focal_date, as.character(out_date - days(1)),
        ifelse(date >= focal_date, as.character(date + days(1)), as.character(focal_date))
      )
    ))) %>%
    select(ID, date)


  ##################
  # compute the rank

  rank <- calculate_rank(input = input)[, c("ID", "sel_rank", "sel_rank_std", "date")] %>%
    rename(candidate_date_rank = date)

  ##################
  # merge everything

  disp_clan4 <- left_join(disp_clan3, rank, by = "ID") %>%
    select(ID, sel_rank, sel_rank_std, candidate_date_rank) %>%
    mutate(
      cub_ID = cub_ID,
      cub_mother_genetic = mother_genetic,
      cub_father = father,
      cub_conception_date = focal_date,
      cub_birth_date = birth_date,
      cub_sex = sex,
      mom_gender_rank = as.numeric(mom_rank[1, "gender_rank"]),
      mom_gender_rank_std = as.numeric(mom_rank[1, "gender_rank_std"])
    ) %>%
    rename(
      candidate_male = ID,
      candidate_sel_rank = sel_rank,
      candidate_sel_rank_std = sel_rank_std
    )

  birthdate <- deathdate <- ID <- sel_rank <- sel_rank_std <- candidate_date_rank <- days <- out_date <- NULL

  return(disp_clan4)
}


################################################################################

#' return all candidate males for a given cub (used internally)
#'
#' Extract candidate males (sexually active males in the clan) and compute.
#' @name retrieve_candidate_males
#' @param cub_ID ID of the cub
#' @param hyenas hyenas table from the database
#' @param selections selections table from the database
#' @param deaths deaths table from the database
#' @return A tibble with hyenas info about the candidate males
#' @import dplyr



retrieve_candidate_males <- function(cub_ID, hyenas, selections, deaths) {
  #######################################
  # retrieve cub´s information from hyenas

  ID_info <- hyenas[hyenas$ID == cub_ID, ]
  mother_genetic <- female <- ID_info$mothergenetic
  focal_date <- ID_info$birthdate - days(110)
  clan <- fem_clan <- ID_info$birthclan
  date_range <- c(focal_date - days(90), focal_date + days(90))


  ##############################################################################
  # get males that have been in the clan at least once befor the conception + 90

  chose_clan <- selections %>%
    filter(destination == fem_clan) %>% ## keep the one that have been in the clan at least once
    filter(date <= date_range[2]) %>%
    pull(ID)

  been_in_clan <- selections %>%
    filter(ID %in% chose_clan) %>%
    group_by(ID) %>%
    mutate(out_date = lead(date, default = today())) %>%
    ungroup() %>%
    filter(destination == fem_clan)

  been_in_clan2 <- been_in_clan %>%
    filter(date <= date_range[2] & out_date > date_range[1])


  ####################################################
  # join the information about birthdate and deathdate

  disp_clan2 <- left_join(been_in_clan2, hyenas, by = "ID") %>%
    left_join(deaths, by = "ID")

  disp_clan3 <- disp_clan2 %>%
    filter(is.na(deathconfirmed) | ymd(deathconfirmed) > focal_date) %>%
    filter(is.na(deathdate) | ymd(deathdate) > date_range[1])

  days <- destination <- ID <- today <- out_date <- deathconfirmed <- deathdate <- NULL ## to please R CMD check

  return(disp_clan3)
}


################################################################################

#' return all candidate males for a list of cubs
#'
#' Extract candidate males (sexually active males in the clan) and put them in a
#' dataframe.
#'
#' @name find_clan_id.mate.candidate
#' @param cub_ID_df a dataframe with 1 col (ID)
#' @return A tibble with hyenas info about the candidate males
#' @import dplyr
#' @import purrr
#' @export

find_clan_id.mate.candidate <- function(cub_ID_df) {
  hyenas <- extract_database_table(tables = "hyenas") %>%
    mutate(birthdate = lubridate::ymd(birthdate))

  selections <- extract_database_table(tables = "selections") %>%
    mutate(date = lubridate::ymd(date))

  deaths <- extract_database_table(tables = "deaths") %>%
    mutate(deathdate = lubridate::ymd(deathdate))


  x <- map(cub_ID_df$ID, ~ retrieve_candidate_males(
    cub_ID = .x, hyenas = hyenas,
    selections = selections, deaths = deaths
  )[, "ID"])

  ncol <- max(map_dbl(x, ~ length(.x[[1]])))

  out <- as.data.frame(matrix(NA, nrow = nrow(cub_ID_df), ncol = ncol))
  colnames(out) <- c(paste0("ID", 1:ncol))

  for (i in 1:nrow(cub_ID_df)) {
    for (j in 1:ncol(out)) {
      out[i, j ] <- x[[i]][[1]][j]
    }
  }
  row <- out[1, ]
  out$n_candidate <- apply(out, 1, function(row) sum(!is.na(row)))
  out$n_typed_candidate <- apply(out, 1, function(row) sum(hyenas$DNA[hyenas$ID %in% row] == "yes"))
  out$proportion_typed <- out$n_typed_candidate / out$n_candidate
  out$cub_name <- cub_ID_df$ID


  ### get additional information about the cub

  infos <- hyenas %>%
    filter(ID %in% out$cub_name) %>%
    select(mothergenetic, sex, birthdate, ID) %>%
    mutate(sex = ifelse(sex == 1, "M", ifelse(sex == 2, "F", NA)))

  out2 <- out %>%
    left_join(infos, by = c("cub_name" = "ID")) %>%
    select(cub_name, mothergenetic, sex, birthdate, n_typed_candidate, n_candidate, proportion_typed, everything())

  birthdate <- deathdate <- ID <- cub_name <- n_typed_candidate <- n_candidate <- proportion_typed <- mothergenetic <- sex <- NULL ## to please R CMD check

  return(out2)
}
