#' Defunct Functions in Package hyenaR
#'
#' The functions or variables listed here are no longer part of hyenaR as they are no longer needed.
#'
#' @param ... Arguments formerly passed to the function that is now defunct.
#'
#' @name hyenaR-defunct
NULL

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
indv_summary <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Replaced by \code{\link{fetch_id_has.reproduced}},
#' \code{\link{fetch_id_number.offspring}}, and \code{\link{fetch_id_has.twin.litter}}
#' @export
#'
calc_repro <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
test_integrity <- function(...) .Defunct("check_database_is.correct")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_dna <- function(...) .Defunct("fetch_id_is.sampled.dna")

###########################

#' @describeIn hyenaR-defunct Defunct function
#'
#' @export
calculate_selection_events <- function(...) .Defunct("create_id_life.transition.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_selection_events <- function(...) .Defunct("create_id_life.transition.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_selection_status <- function(...) .Defunct("fetch_id_life.stage")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_offspringtable_count <- function(...) .Defunct("multifetch_id_offspring.count")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_littertable_type <- function(...) .Defunct("fetch_litter_litter.type")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_offspringtable_with_litter <- function(...) .Defunct("create_dyad.offspring_litter.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_littertable <- function(...) .Defunct("create_litter_starting.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_littertable_count <- function(...) .Defunct("multifetch_litter_offspring.count")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_matingtable <- function(...) .Defunct("create_dyad.mate_conception.table")


###########################
#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
check_arg_status <- function(...) .Defunct("check_arg_life.stage")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
calc_candidate_males <- function(...) .Defunct("create_dyad.mate_candidate.table.oldfn")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
check_arg_recode_litters <- function(...) .Defunct("check_arg_litter.type")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
download_info_benchmarks <- function(...) .Defunct("download_package_benchmarks")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_id_conception.table <- function(...) .Defunct("create_dyad.mate_conception.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
download_primary_data <- function(...) .Defunct("download_package_csv")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
check_database <- function(...) .Defunct("check_database_is.loaded")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
extract_all_info <- function(...) .Defunct("extract_database_row")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_id_offspring.litter.fulltable <- function(...) .Defunct("create_dyad.offspring_litter.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
extract_database <- function(...) .Defunct("extract_database_table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_offspringtable <- function(...) .Defunct("create_dyad.offspring_starting.table")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_id_life.history <- function(...) .Defunct("create_id_life.history.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
load_database <- function(...) .Defunct("load_package_database.dummy")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
extract_allrankinfo <- function(...) .Defunct("create_id_rank.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
recode_litters <- function(...) .Defunct("recode_offspring.sex_litter.type")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
build_dummy_data <- function(...) .Defunct("build_package_database.dummy")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
recode_rankstd_to_cat <- function(...) .Defunct("recode_rank.std_rank.cat")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_id_life.transition <- function(...) .Defunct("create_id_life.transition.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
stretch_age <- function(...) .Defunct("reshape_row_age.seq")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
build_database <- function(...) .Defunct("build_package_database.full")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
stretch_schedule <- function(...) .Defunct("reshape_row_date.seq")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_basetable_from_IDs <- function(...) .Defunct("create_id_starting.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
build_optional_vignette <- function(...) .Defunct("build_package_vignette.extra")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
extract_samples <- function(...) .Defunct("create_sample_summary.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_adults <- function(...) .Defunct("find_clan_id.adult")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
get_clan_members <- function(...) .Defunct("find_clan_id.all")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_scan_deaths <- function(...) .Defunct("find_clan_id.dead")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_females <- function(...) .Defunct("find_clan_id.female")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_immigrants <- function(...) .Defunct("find_clan_id.immigrant")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_selection_status <- function(...) .Defunct("find_clan_id.life.stage")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_males <- function(...) .Defunct("find_clan_id.male")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
get_candidate_males_horizontal <- function(...) .Defunct("find_clan_id.mate.candidate")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_clans <- function(...) .Defunct("find_clan_name.all")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
info_package <- function(...) .Defunct("find_package_info")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_firstsighting <- function(...) .Defunct("find_pop_observation.first")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
find_lastsighting <- function(...) .Defunct("find_pop_observation.last")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
get_token <- function(...) .Defunct("find_system_token.github")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
pull_column_from_table <- function(...) .Defunct("fetch_database_column")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_dyad.offspring_is.offspring <- function(...) .Defunct("fetch_dyad_is.offspring")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_age <- function(...) .Defunct("fetch_id_age")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_birthclan <- function(...) .Defunct("fetch_id_clan.birth")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_clan <- function(...) .Defunct("fetch_id_clan.current")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_date <- function(...) .Defunct("fetch_id_date.at.age")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_birthdate <- function(...) .Defunct("fetch_id_date.birth")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_date_at_first_conception <- function(...) .Defunct("fetch_id_date.conception.first")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_deathdate <- function(...) .Defunct("fetch_id_date.death")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_first_observed_date <- function(...) .Defunct("fetch_id_date.observation.first")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_last_observed_date <- function(...) .Defunct("fetch_id_date.observation.last")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_date_at_first_selection <- function(...) .Defunct("fetch_id_date.selection.first")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_lifespan <- function(...) .Defunct("fetch_id_duration.lifespan")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_tenure <- function(...) .Defunct("fetch_id_duration.tenure")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_father <- function(...) .Defunct("fetch_id_id.father")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_mothergenetic <- function(...) .Defunct("fetch_id_id.mother.genetic")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_mothersocial <- function(...) .Defunct("fetch_id_id.mother.social")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_alive <- function(...) .Defunct("fetch_id_is.alive")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_censored_left <- function(...) .Defunct("fetch_id_is.censored.left")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_immigrant <- function(...) .Defunct("fetch_id_is.immigrant")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_native <- function(...) .Defunct("fetch_id_is.native")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_observable <- function(...) .Defunct("fetch_id_is.observable")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_is_observed <- function(...) .Defunct("fetch_id_is.observed")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_clanadults <- function(...) .Defunct("fetch_id_number.adult")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_clantotal <- function(...) .Defunct("fetch_id_number.all")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_offspring_number <- function(...) .Defunct("fetch_id_number.offspring")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_rank <- function(...) .Defunct("fetch_id_rank")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_rankstd <- function(...) .Defunct("fetch_id_rank.std")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_birthrankstd <- function(...) .Defunct("fetch_id_rank.birth.std")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_observable <- function(...) .Defunct("fetch_id_is.observable")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_observed <- function(...) .Defunct("fetch_id_is.observed")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_support <- function(...) .Defunct("fetch_support_natives")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_survived <- function(...) .Defunct("fetch_id_is.alive")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_censored_left <- function(...) .Defunct("fetch_id_is.censored.left")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_birthrank <- function(...) .Defunct("fetch_id_rank.birth")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_litterdominance <- function(...) .Defunct("fetch_id_rank.litter")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_nativerankstd <- function(...) .Defunct("fetch_id_rank.native.std")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_nativerank <- function(...) .Defunct("fetch_id_rank.native")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_selrankstd <- function(...) .Defunct("fetch_id_rank.selector.male.std")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_selrank <- function(...) .Defunct("fetch_id_rank.selector.male")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_genderrankstd <- function(...) .Defunct("fetch_id_rank.sex.std")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_genderrank <- function(...) .Defunct("fetch_id_rank.sex")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
fetch_sex <- function(...) .Defunct("fetch_id_sex")
