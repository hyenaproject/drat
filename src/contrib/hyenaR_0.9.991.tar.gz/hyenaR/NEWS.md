# News for hyenaR

The content of the NEWS has now moved to the following vignette: https://github.com/hyenaproject/hyenaR/blob/master/vignettes/news.Rmd

You can see its content after installing the package by simply running:

```{r}
vignette("news", package = "hyenaR")
```
