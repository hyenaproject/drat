context("Test create_rank_python.table behaviour")

test_that("create_rank_python.table returns a tibble with data frame, tibble and named list input", {
  output <- create_rank_python.table(py.input.tbl = data.frame(ID = "A-080", date = "1997-01-01", stringsAsFactors = FALSE))
  expect_equal(class(output)[1], "tbl_df")
})

test_that("Providing a matrix or vector returns an error", {
  input <- matrix(nrow = 2, ncol = 2, data = c("A-080", "L-001", "1997-01-01", "1996-07-01"))
  colnames(input) <- c("ID", "date")

  expect_error(create_rank_python.table(py.input.tbl = z))
  expect_error(create_rank_python.table(py.input.tbl = c("A-080", "L-001", "1997-01-01", "1996-07-01")))
})

test_that("Providing a wrong name and/or date returns an error", {
  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-AAA", date = "1997-01-01")))
  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-001", date = "0001-01-01")))
  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-AAA", date = "0001-01-01")))

  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-AAA", date = "1997-01-01")))
  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-001", date = "0001-01-01")))
  expect_error(create_rank_python.table(py.input.tbl = data.frame(ID = "A-AAA", date = "0001-01-01")))
})
