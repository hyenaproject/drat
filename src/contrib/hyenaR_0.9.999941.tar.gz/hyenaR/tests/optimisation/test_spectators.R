rm(list = ls())
library(profvis)
library(bench)
load_package_database.dummy("../source_data/Fisidata.sqlite")
hyenas <- .database$database$data$hyenas %>%
  dplyr::left_join(.database$database$data$deaths, by = "name")

clan_members <- get_clan_members2(date = "1997-08-16", clan = "A", age = 1, hyena = hyenas)
ancestry <- get_ancestry3(clan_members)
ancestors_info <- get_ancestors_A_B_C(ancestry, "A-001", "A-011", hyenas)

get_spectators <- function(ancestry_DF, indv_A, indv_B, ancestors_info) {
  A_ancestors <- as_vector(ancestors_info$A_ancestors)
  B_ancestors <- as_vector(ancestors_info$B_ancestors)
  spectators <- ancestry_DF[ancestry_DF$name != indv_A & ancestry_DF$name != indv_B, ] %>%
    dplyr::mutate(
      ancestor_A = apply(., 1, function(row) length(dplyr::intersect(row[-1], A_ancestors)) > 0),
      ancestor_B = apply(., 1, function(row) length(dplyr::intersect(row[-1], B_ancestors)) > 0),
      type = ifelse(.data$ancestor_A & !.data$ancestor_B, "A_relative", ifelse(.data$ancestor_B & !.data$ancestor_A, "B_relative", ifelse(.data$ancestor_A & .data$ancestor_B, "both_relatives", "non_relatives")))
    ) %>%
    dplyr::select("name", "currentclan", "native",
                  "ancestor_A", "ancestor_B", "type",
                  dplyr::everything())
  return(spectators)
}

get_spectators2 <- function(ancestry_DF, indv_A, indv_B, ancestors_info) {
  spectators <- ancestry_DF[ancestry_DF$name != indv_A & ancestry_DF$name != indv_B, ]
  G_columns <- grepl(pattern = "G", x = colnames(spectators))
  ancestors <- spectators[, G_columns]
  rest <- spectators[, !G_columns]
  rest$ancestor_A <- apply(ancestors, 1, function(row) any(row %in% ancestors_info$A_ancestors))
  rest$ancestor_B <- apply(ancestors, 1, function(row) any(row %in% ancestors_info$B_ancestors))
  test_var <- 1 + (rest$ancestor_A * 2) + rest$ancestor_B
  rest$type <- c("non_relatives", "B_relative", "A_relative", "both_relatives")[test_var]
  dplyr::bind_cols(rest, ancestors)
}

# debugonce(get_spectators2)
test1 <- get_spectators(ancestry, "A-001", "A-011", ancestors_info)
test2 <- get_spectators2(ancestry, "A-001", "A-011", ancestors_info)

row.names(test1) <- NULL
row.names(test2) <- NULL

identical(test1, test2)


m <- bench::mark(
  get_spectators(ancestry, "A-001", "A-011", ancestors_info),
  get_spectators2(ancestry, "A-001", "A-011", ancestors_info)
)

summary(m, relative = TRUE)
ggplot2::autoplot(m)
