#' General options for the package hyenaR
#'
#' General options that influence the behaviour of functions in the package.
#' Check the example for how to set and get the value of a given option.
#'
#' All the options of the package follow the naming convention `hyenaR_xxx` with
#' `xxx` being the name of the option.
#'
#' The current options implemented so far are:
#'
#' - `hyenaR_CPUcores` (numeric). The number of CPU cores to use for intensive
#' computation. The default is 1.
#'
#' - `hyenaR_verbose` (logical). Whether verbose messages should be displayed in
#' hyenaR functions or not. The default is `TRUE`.
#'
#'
#' ## Info for developers
#'
#' The syntax for options used in this package is the same as the one used to
#' influence any general option in R. It is also stored in the same place: in
#' the object [`.Options`]. The original R options are stored in a hidden object
#' called `.hyenaR`. This object `.hyenaR` is used to restore the initial
#' setting of R once hyenaR is detached to prevent hyenaR from modifying
#' the general R options once you are done using the package.
#' Although users rarely detach packages,
#' this is particularly useful for developers since the package is automatically
#' detached each time developers reload a package on the fly.
#'
#' Developers should make good use of such options whenever suitable. They
#' should not override local options, but rather set the default behaviour for
#' whenever such options have not been defined locally by the user.
#'
#' @name hyenaR_options
#' @aliases hyenaR_options, .hyenaR
#'
#' @seealso [`options`]
#'
#' @examples
#' getOption("hyenaR_verbose")  ## Return the current value of hyenaR_verbose
#'
#' \dontrun{
#' options(hyenaR_verbose = FALSE) ## Set the option hyenaR_verbose to FALSE
#' }
#'
NULL
