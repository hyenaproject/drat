#' Recode vectors
#'
#' These functions allows for the recoding of vectors.
#'
#' @inheritParams arguments
#' @name recode_family
#' @aliases recode_family recode
#' @return The recoded vector.
#'
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL


#' @describeIn recode_family recode standardized ranks into categories
#'
#' Note that 0% corresponds to the top ranking individual!
#'
#' @export
#'
#' @examples
#'
#' #### Simple example of recode_rank.std_rank.cat usage:
#'
#' set.seed(1)
#' some_ranks <- seq(-1, 1, length = 10)
#' some_prob.ranks <- runif(3)
#' recode_rank.std_rank.cat(some_ranks, prob.ranks = some_prob.ranks)
#'
#' #### More realistic example of recode_rank.std_rank.cat usage:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_id_starting.table(clan = "A", at = "1997-01-01") %>%
#'     mutate(rankstd = fetch_id_rank.std(ID = ID, at = "1997-01-01"),
#'            rankstd_cat = recode_rank.std_rank.cat(rankstd, prob.ranks = c(0.25, 0.5, 0.75)))
#' }
#'
recode_rank.std_rank.cat <- function(ranks, prob.ranks = NULL, digits = 2) {

  if (is.null(prob.ranks)) {
    warning("The argument 'prob.ranks' has not been defined, so the input vector has not been recoded!")
    return(rank)
  }

  if (any((prob.ranks < 0) | (prob.ranks > 1))) {
    stop("The probabilities should be all between 0 and 1.")
  }

  ranks <- check_function_arg.ranks(ranks, std = TRUE)

  ranks <- abs((ranks - 1) * 1/2)  ## to bring back ranks between 0 and 1 with 0 being to

  prob.ranks <- sort(unique(c(0, prob.ranks, 1)))

  res <- cut(ranks, breaks = prob.ranks, include.lowest = TRUE)

  levels_list <- lapply(strsplit(levels(res), ","),
                        function(str) 100*as.numeric(sub("\\[|\\(|\\]", "", str, perl = TRUE)))
  levels(res) <- unlist(lapply(levels_list,
                               function(x) paste0(signif(x[1], digits = digits), "--",
                                                  signif(x[2], digits = digits), "%")))
  as.character(res) ## convert to character in order not to get a factor
}

#' @describeIn recode_family recode absolute ranks into standardized ranks
#'
#' Note that the standardisation does not fill gaps in the ranking. For that you should use [`dplyr::dense_rank()`].
#'
#' @export
#'
#' @examples
#'
#' #### Simple example of recode_rank.abs_rank.std usage:
#'
#' some_ranks <- 1:10
#' recode_rank.abs_rank.std(some_ranks)
#'
#' #### More realistic example of recode_rank.abs_rank.std usage:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_id_starting.table(clan = "A", lifestage = "adult", at = "1997-12-31") %>%
#'     mutate(rank = fetch_id_rank(ID = ID, at = "1997-12-31"),
#'            rank_adults = dense_rank(rank),
#'            rank_adults_std = recode_rank.abs_rank.std(rank_adults)) %>%
#'     arrange(rank_adults)
#' }
#'
recode_rank.abs_rank.std <- function(ranks) {

  ranks <- check_function_arg.ranks(ranks, std = FALSE)

  (length(ranks) - ranks) / ((length(ranks) - 1)/2) - 1
}


#' @describeIn recode_family classifies litters with a string that is a combination of "f" (= female offspring),
#' "m" (= male offspring), "u" (= offspring with unknown sex), according to the number of daughters, sons and
#' cubs with unknown sex present in the litter.
#'
#' @export
#'
#' @examples
#'
#' ### Simple example of the recode_offspring.sex_litter.type:
#'
#' daughters.nb <- c(1, 2, 1, 0)
#' sons.nb <- c(0, 0, 1, 0)
#' unknown.nb <- c(1, 1, 1, 0)
#' social.daughters.nb <- c(0, 0, 0, 0)
#' social.sons.nb <- c(1, 0, 0, 0)
#' social.unknown.nb <- c(0, 0, 0, 0)
#'
#' recode_offspring.sex_litter.type(daughters.nb,
#'                                  sons.nb,
#'                                  unknown.nb,
#'                                  social.daughters.nb,
#'                                  social.sons.nb,
#'                                  social.unknown.nb)
#'
recode_offspring.sex_litter.type <- function(daughters.nb = 0, sons.nb = 0, unknown.nb = 0, social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0) {

  args <- check_function_arg.litter.type(daughters.nb, sons.nb, unknown.nb, social.daughters.nb, social.sons.nb, social.unknown.nb)

  type <- rep(NA_character_, length(args$daughters.nb))

  for (i in seq_len(length(args$daughters.nb))) {
    type[i] <- paste(c(rep("f", args$daughters.nb[i]),
                       rep("m", args$sons.nb[i]),
                       rep("u", args$unknown.nb[i]),
                       rep("sf",args$social.daughters.nb[i]),
                       rep("sm", args$social.sons.nb[i]),
                       rep("su", args$social.unknown.nb[i])), collapse = "_")
  }

  type[type == ""] <- NA_character_

  type
}

#' @describeIn recode_family Recode between clanIDs and full clan names
#'
#' @export
#' @examples
#'
#' ### Return full clan names from clanID:
#' recode_clan_name(clan = c("A", "L"))
#'
#' ### Return clanID from full clan name
#' recode_clan_name(clan = c("AIRSTRIP", "LEMALA"))
recode_clan_name <- function(clan, verbose = TRUE){

  input        <- dplyr::tibble(clan = toupper(clan))
  messages     <- vector() ## Create an empty vector which messages are appended. Print if verbose.
  clan_details <- extract_database_table("clans") %>%
    dplyr::select("clanID", "clanname")

  if (all(nchar(input$clan) == 1)) {

    messages <- append(messages, "Converting clanIDs to full names. \n")

    input %>%
      dplyr::mutate(clan = check_function_arg.clan(.data$clan, full.clan.names = FALSE)) %>%
      dplyr::left_join(clan_details, by = c("clan" = "clanID")) %>%
      dplyr::pull(.data$clanname) -> output

  } else {

    messages <- append(messages, "Converting full names to clanIDs. \n")

    input %>%
      dplyr::mutate(clan = check_function_arg.clan(.data$clan, full.clan.names = TRUE)) %>%
      dplyr::left_join(clan_details, by = c("clan" = "clanname")) %>%
      dplyr::pull(.data$clanID) -> output

  }

  if (any(is.na(output))) {

    messages <- append(messages, "Some clans are not identifiable. Returning NAs. \n")

  }

  if (verbose && length(messages) > 0) {

    message(messages, appendLF = FALSE)

  }

  output

}

#' Recode meta-lifestages into raw lifestages
#'
#' @param lifestage Vector of lifestage values.
#'
#' @return An expanded vector of lifestage values.
#' @export
#'
#' @examples
#' #Adult is any individuals that is not either 'cub' or 'subadult' lifestage
#' recode_lifestage_meta.to.raw("adult")
#'
#' #Selector is any sexually mature male (i.e. philopatric or dispersing males)
#' recode_lifestage_meta.to.raw("selector")

recode_lifestage_meta.to.raw <- function(lifestage) {

  #Dead will not be filled by default. Only turns up with meta-lifestage 'all' or 'dead'
  raw_lifestage <- c(check_function_arg.lifestage(.fill = TRUE), "dead")

  if (any(lifestage == "all")) {

    #If the user specifies 'all' all other additional lifestages are redundant
    return(raw_lifestage)

  }

  #An individual that has made its first selection and is non-transient (exact number of selections is KNOWN)
  if (any(lifestage == "selector")) {

    new_lifestages <- c("philopatric", "disperser", "selector_2", "selector_3", "selector_4", "selector_5")
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "selector")

  }

  #An individual that has made its first selection and is non-transient (exact number of selections is UNKNOWN)
  if (any(lifestage == "foreigner")) {

    new_lifestages <- paste0("foreigner_", 1:5)
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "foreigner")

  }

  #An individual that has made its first selection and is non-transient (exact number of selections may be known or unknown)
  if (any(lifestage == "sexually_active")) {

    new_lifestages <- setdiff(raw_lifestage, c("cub", "subadult", "natal", "transient", "unknown", "dead"))
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "sexually_active")

  }

  #An individual <2yo
  if (any(lifestage == "adult")) {

    new_lifestages <- setdiff(raw_lifestage, c("cub", "subadult", "dead"))
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "adult")

  }

  #An individual that has not made its first selection
  if (any(lifestage == "preselector")) {

    new_lifestage <- c("cub", "subadult", "natal")
    lifestage <- setdiff(unique(c(lifestage, new_lifestage)), "preselector")

  }

  #An individual that has not left its birth clan
  if (any(lifestage == "native")) {

    new_lifestage <- c("cub", "subadult", "natal", "philopatric")
    lifestage <- setdiff(unique(c(lifestage, new_lifestage)), "native")

  }

  #Everything except dead
  if (any(lifestage == "alive")) {

    new_lifestage <- check_function_arg.lifestage(.fill = TRUE)
    lifestage <- setdiff(unique(c(lifestage, new_lifestage)), "alive")

  }

  lifestage

}

#' Convert excel dates (stored as numeric) into date-time object.
#'
#' This is a simplified version of janitor::excel_numeric_to_date() that converts
#' dates encoded as serial numbers to Date class. We have recreated the function
#' here to reduce dependencies.
#'
#' Unlike janitor function, our internal function
#' *always* returns datetime object with rounded seconds. Additional functionality
#' in original function is removed for simplicity. If we need to use this more
#' frequently in the future, we may need to expand it (or add the janitor dependency).
#'
#' @inheritParams arguments
#' @return A vector of date time objects
#'
#' @export
#' @examples
#' recode_numeric_excel.to.date(0, tz = "GMT")

recode_numeric_excel.to.date <- function(date.excel, tz = "Africa/Dar_es_Salaam"){

  if (all(is.na(date.excel))) {

    return(as.POSIXct(as.character(NA)))

  } else if (!is.numeric(date.excel)) {

    stop("argument `date.excel` must be of class numeric")

  }

  #Assuming we have data (not just NAs) apply excel conversion
  date_num_days <- (as.double(date.excel) * 86400L + 0.001)%/%86400L
  date_num_days_no_floating_correction <- date.excel%/%1
  mask_day_rollover <- !is.na(date.excel) & date_num_days > date_num_days_no_floating_correction
  #Round seconds by default. This is an option in janitor function that has been removed
  date_num_seconds <- round((date.excel - date_num_days) * 86400)
  date_num_seconds[mask_day_rollover] <- 0
  if (any(mask_day_rollover)) {
    warning(sum(mask_day_rollover), " date.excel values are within 0.001 sec of a later date and were rounded up to the next day.")
  }

  #1899-12-30 is the origin used for all modern excel programs
  #Janitor includes option to deal with pre-2011 mac (where origin is different),
  #but we don't need this.
  dates <- as.Date(floor(date_num_days), origin = "1899-12-30")

  #Add time to create datetime object
  #NOTE: We need as.character() so that as.POSIXlt accepts tz arg
  datetimes      <- as.POSIXlt(as.character(dates), tz = tz)
  datetimes$sec  <- date_num_seconds%%60
  datetimes$min  <- floor(date_num_seconds/60)%%60
  datetimes$hour <- floor(date_num_seconds/3600)
  datetimes      <- as.POSIXct(datetimes, tz = tz)

  datetimes

}

#' Convert character to lower snake case
#'
#' snake case uses underscore instead of space (e.g. col_name). We use all
#' lower case. The exception is the term 'ID', which is kept upper case (e.g. injuryID).
#' ID is assumed to occur only at the end of a word.
#' There are a number of packages that can convert to snake case, but we
#' write our own code here to reduce dependencies.
#'
#' @inheritParams arguments
#' @return Vector of character strings in snake case.
#' @export
#'
#' @examples
#' #Convert single string to snake
#' recode_chr_snake.case("Device Name")
#'
#' #Convert multiple strings
#' #N.B.: When ID occurs at the end of the string it remains capitalized.
#' recode_chr_snake.case(c("Device Name", "HyenaID", "Kid ID"))

recode_chr_snake.case <- function(character){

  #Convert to full lower case snake
  full_snake <- gsub(tolower(character), pattern = " ", replacement = "_")

  #Re-capitalize 'ID' which we consistently use in capital
  output  <- gsub(full_snake, pattern = "id$", replacement = "ID")

  return(output)

}

#' Recode data frame to sf object using CRS specified in package options.
#'
#' Takes a dataframe and returns an sf object in the specified CRS.
#' This function is used internally and is not exported. It is
#' not intended to be used on its own.
#'
#' @inheritParams arguments
#' @return An sf object.
#' @export
#'
#' @examples
#' #Example weather data stored with the package for example
#' input <- load_data_weatherstation.file(system.file("extdata/weather_Mlima",
#'                                           "weather_data_test1.xlsx",
#'                                           package = "hyenaR"))
#'
#' #Return object with geographic CRS
#' recode_df_sf(input, crs = "EPSG:4326")
#'
#' #Convert to projected
#' recode_df_sf(input, crs = 'EPSG:32736')
recode_df_sf <- function(df, crs){

  df  <- check_df_sf(df)

  #Expects an input with lat and long
  output <- sf::st_as_sf(df,
                         coords = c("longitude", "latitude"),
                         crs = 'EPSG:4326')

  #If alternative CRS is specific (not WGS84), then transform it.
  if (crs != sf::st_crs(4326)) {

    output <- output %>%
      sf::st_transform(crs = crs)

  }

  return(output)

}

#' Recode any input to date class
#'
#' Accepts character string, date-time (i.e. POSIXct, POSIXlt), or Date object.
#'
#' @inheritParams arguments
#'
#' @return A vector of class Date
#' @export
#'
#' @examples
#' #Accept a character string
#' recode_x_date("1999-01-01")
#'
#' #Accept a POSIX object and retain correct time-zone
#' input <- lubridate::ymd_hms("1999-01-01 00:00:00", tz = "Africa/Dar_es_Salaam")
#' recode_x_date(input)
#'
#' #If given an object that is already class Date nothing will change
#' recode_x_date(as.Date("1999-01-01"))
recode_x_date <- function(date, tz = "Africa/Dar_es_Salaam") {
    as.Date(date, tz = tz)
}
