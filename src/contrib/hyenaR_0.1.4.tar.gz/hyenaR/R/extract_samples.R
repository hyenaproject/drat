#' Extract sample data with information on individuals
#'
#' @param db Location of database. If unspecified, will use dummy database for examples.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#'
#' @return Return a tibble with sample and individual information
#' @export
#'
#' @examples
#'
#' #Load database (use dummy database)
#' load_db()
#'
#' #Extract information in 2016
#' extract_samples(start_date = "2016-01-01", end_date = "2016-12-31")
#'

extract_samples <- function(db = NULL, start_date = -Inf, end_date = Inf){

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Get access to hyenas and deaths table
  hyenas      <- .GlobalEnv$database$data$hyenas
  deaths      <- .GlobalEnv$database$data$deaths
  selections  <- .GlobalEnv$database$data$selections
  samples     <- .GlobalEnv$database$data$samples %>%
    mutate(collectiondate = lubridate::ymd(collectiondate))
  sightings   <- .GlobalEnv$database$data$sightings
  # hyenas      <- tbl(connection, "hyenas")
  # deaths     <- tbl(connection, "deaths")
  # selections <- tbl(connection, "selections")
  # samples    <- tbl(connection, "samples")

  #We need to know the latest date in the database.
  #This will be the end_date if Inf is provided
  #We need an actual value (rather than Inf) to calculate age
  # latest_date <- lubridate::ymd(tbl(connection, "sightings") %>%
  latest_date <- lubridate::ymd(sightings %>%
                                  summarise(latest_date = max(date, na.rm = T)) %>%
                                  collect() %>%
                                  .$latest_date)

  #If end date is Inf then convert to latest date...
  if(is.infinite(end_date)){

    end_date <- latest_date

  } else {

    #Otherwise, make sure it's a date objecct
    end_date <- lubridate::ymd(end_date)

  }

  #If start date is not Inf make sure that it's a date object
  if(!is.infinite(start_date)){

    start_date <- lubridate::ymd(start_date)

  }

  #Subset the samples table to just include most important info.
  output_table <- samples %>%
    #Just include hyenas and samples collected within specified dates
    filter(species == "hy" & between(collectiondate, start_date, end_date)) %>%
    #Join in birthdate of every individual
    left_join(select(hyenas, name, sex, birthclan, birthdate), by = "name") %>%
    #Join in deathdate as well
    left_join(select(deaths, name, deathdate), by = "name") %>%
    collect() %>%
    mutate(collectiondate = lubridate::ymd(collectiondate),
           birthdate = lubridate::ymd(birthdate), deathdate = lubridate::ymd(deathdate),
           sex = ifelse(sex == 1, "Male", ifelse(sex == 2, "Female", NA)))

  pb <- progress_estimated(n = nrow(output_table))

  output_table <- output_table %>%
    #Determine the age of each individual in months when the sample was taken
    mutate(age = pmap_dbl(.l = list(age_units = "months",
                                    birthdate = as.character(birthdate),
                                    deathdate = as.character(deathdate),
                                    end_date  = as.character(collectiondate)),
                          .f = calc_age)) %>%
    #Include dispersal/clan info
    bind_cols(pmap_df(.l = list(focal_indv = .$name,
                                sex = .$sex, age = .$age,
                                start_date = as.character(.$collectiondate), end_date = as.character(.$collectiondate), birthclan = .$birthclan),
                      .f = calc_currentclan, pb = pb, selections = selections)) %>%
    mutate(sample_code = paste(name, collectiondate, stored1, sep = "_")) %>%
    select(sample_code, subsample_code = code, name, collectiondate, collectiontime = stored1, clan = current_clan, type, treatment, sex, age, birthclan, dispersal_status = status)

  return(output_table)

}
