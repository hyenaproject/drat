context("Test reshape_xxx functions")

test_that("find_date_sequence in reshape works as expected", {

  ref <- structure(9862:9871, class = "Date")

  #Returns a date range with from/to/by
  job1 <- find_date_sequence(from = "1997/01/01", to = "1997/01/10", by = "day")
  expect_equal(ref, job1)

  #Returns a date range with from/to/length.out
  job2 <- find_date_sequence(from = "1997/01/01", to = "1997/01/10", length.out = 10)
  expect_equal(ref, job2)

  #Returns a date range with from/length.out/by
  job3 <- find_date_sequence(from = "1997/01/01", length.out = 10, by = "day")
  expect_equal(ref, job3)

  #Fills to when from/length.out are provided
  job4 <- find_date_sequence(from = "1997/01/01", length.out = 10, max.date = "1997/01/10")
  expect_equal(ref, job4)

  #Fills from when to/length.out are provided
  job5 <- find_date_sequence(to = "1997/01/10", length.out = 10, min.date = "1997/01/01")
  expect_equal(ref, job5)

  #Fills to when from/by are provided
  job6 <- find_date_sequence(from = "1997/01/01", by = "day", max.date = "1997/01/10")
  expect_equal(ref, job6)

  #Fills from when to/by are provided
  job7 <- find_date_sequence(to = "1997/01/10", by = "day", min.date = "1997/01/01")
  expect_equal(ref, job7)

  #Returns a date range with from/length.out/by/to (i.e. to is ignored)
  job8 <- find_date_sequence(from = "1997/01/01", to = "1997-12-01", length.out = 10, by = "day")
  expect_equal(ref, job8)

})

test_that("reshape_row_age.seq does not drop rows", {
 ref <- structure(list(ID = c("A-001", "A-001", "A-002", "A-002", "A-001", "A-001"),
                       age = c(2, 4, 2, 4, 2, 4),
                       unit = c("year", "year", "year", "year", "year", "year")),
                  row.names = c(NA, -6L),
                  class = c("tbl_df", "tbl", "data.frame"))
 tibble(ID = c("A-001", "A-002", "A-001")) %>%
   reshape_row_age.seq(
     age = c(2, 4),
     unit = "year",
     ID
   ) -> job
 expect_equal(ref, job)
})


test_that("reshape_row_date.seq can handle duplicates", {

  ref <- structure(list(ID = c("A-001", "A-001", "A-001", "A-002", "A-002", "A-002", "A-001", "A-001", "A-001"),
                        date = structure(c(9862, 9876, 9890, 9862, 9876, 9890, 9862, 9876, 9890),
                                         class = "Date")),
                   row.names = c(NA, -9L), class = c("tbl_df", "tbl", "data.frame"))

  tibble(ID = c("A-001", "A-002", "A-001")) %>%
    reshape_row_date.seq(
      from = "1997-01-01",
      to = "1997-02-01",
      by = "2 week",
      ID
    ) -> job

  expect_equal(ref, job)
})


test_that("reshape_row_date.seq can handle missing from and to", {

  ref <- structure(list(ID = c("A-001", "A-001", "A-001", "A-001", "A-002", "A-002", "A-002", "A-002"),
                        date = structure(c(9598, 9781, 9963, 10146, 9598, 9781, 9963, 10146), class = "Date")),
                   row.names = c(NA, -8L), class = c("tbl_df", "tbl", "data.frame"))

  tibble(ID = c("A-001", "A-002")) %>%
    reshape_row_date.seq(
      by = "6 months",
      ID
    ) -> job

  expect_equal(ref, job)
})


test_that("reshape_row_date.seq can handle NSE properly", {

  ref <- structure(list(ID = c("A-001", "A-001", "A-001", "A-002", "A-002", "A-002", "A-003", "A-003", "A-003", "A-004", "A-004", "A-004", "A-006", "A-006", "A-006", "A-008", "A-008", "A-008", "A-009", "A-009", "A-009", "A-010", "A-010", "A-010", "A-011", "A-011", "A-011", "A-013", "A-013", "A-013", "A-014", "A-014", "A-014", "A-015", "A-015", "A-015", "A-016", "A-016", "A-016", "A-017", "A-017", "A-017", "A-018", "A-018", "A-018", "A-019", "A-019", "A-019", "A-020", "A-020", "A-020", "A-040", "A-040", "A-040", "A-041", "A-041", "A-041", "A-042", "A-042", "A-042", "A-045", "A-045", "A-045", "A-046", "A-046", "A-046", "A-047", "A-047", "A-047", "A-048", "A-048", "A-048", "A-049", "A-049", "A-049", "A-050", "A-050", "A-050", "A-051", "A-051", "A-051", "A-052", "A-052", "A-052", "A-053", "A-053", "A-053", "A-054", "A-054", "A-054", "A-055", "A-055", "A-055", "A-056", "A-056", "A-056", "A-057", "A-057", "A-057", "A-080", "A-080", "A-080", "A-081", "A-081", "A-081", "A-083", "A-083", "A-083", "A-084", "A-084", "A-084", "A-085", "A-085", "A-085", "A-086", "A-086", "A-086", "A-087", "A-087", "A-087", "A-088", "A-088", "A-088", "A-089", "A-089", "A-089", "A-092", "A-092", "A-092", "A-093", "A-093", "A-093", "A-095", "A-095", "A-095", "A-113", "A-113", "A-113", "M-053", "M-053", "M-053"),
                        date = structure(c(9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013, 9648, 9831, 10013),
                                         class = "Date")), row.names = c(NA, -141L),
                   class = c("tbl_df", "tbl", "data.frame"))

  ## test if simple usage works:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    reshape_row_date.seq(from = "1996/06/01",
                         to = "1997/06/01",
                         by = "6 month",
                         ID) -> job1

  ## test if placeholders outside tables can be used:
  foo <- "1996/06/01"
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    reshape_row_date.seq(from = foo,
                         to = "1997/06/01",
                         by = "6 month",
                         ID) -> job2

  ## test if placeholders from table can be used:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    mutate(from = "1996/06/01", to = "1997/06/01", by_ = "6 month") %>%
    reshape_row_date.seq(from = from,
                         to = to,
                         by = by_,
                         ID) -> job3

  ## test if column can called `by` can be used:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    mutate(from = "1996/06/01", to = "1997/06/01", by = "6 month") %>%
    reshape_row_date.seq(from = from,
                         to = to,
                         by = by,
                         ID) -> job4

  ## test if column can called `by` can be used via outer placeholder:

  foo <- "6 month"
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    mutate(from = "1996/06/01", to = "1997/06/01") %>%
    reshape_row_date.seq(from = from,
                         to = to,
                         by = foo,
                         ID) -> job5

  expect_equal(ref, job1)
  expect_equal(ref, job2)
  expect_equal(ref, job3)
  expect_equal(ref, job4)
  expect_equal(ref, job5)

})



test_that("reshape_row_age.seq can handle NSE properly", {

  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-001", "A-001", "A-002", "A-002", "A-002", "A-002", "A-002", "A-003", "A-003", "A-003", "A-003", "A-003", "A-004", "A-004", "A-004", "A-004", "A-004", "A-006", "A-006", "A-006", "A-006", "A-006", "A-008", "A-008", "A-008", "A-008", "A-008", "A-009", "A-009", "A-009", "A-009", "A-009", "A-010", "A-010", "A-010", "A-010", "A-010", "A-011", "A-011", "A-011", "A-011", "A-011", "A-013", "A-013", "A-013", "A-013", "A-013", "A-014", "A-014", "A-014", "A-014", "A-014", "A-015", "A-015", "A-015", "A-015", "A-015", "A-016", "A-016", "A-016", "A-016", "A-016", "A-017", "A-017", "A-017", "A-017", "A-017", "A-018", "A-018", "A-018", "A-018", "A-018", "A-019", "A-019", "A-019", "A-019", "A-019", "A-020", "A-020", "A-020", "A-020", "A-020", "A-040", "A-040", "A-040", "A-040", "A-040", "A-041", "A-041", "A-041", "A-041", "A-041", "A-042", "A-042", "A-042", "A-042", "A-042", "A-045", "A-045", "A-045", "A-045", "A-045", "A-046", "A-046", "A-046", "A-046", "A-046", "A-047", "A-047", "A-047", "A-047", "A-047", "A-048", "A-048", "A-048", "A-048", "A-048", "A-049", "A-049", "A-049", "A-049", "A-049", "A-050", "A-050", "A-050", "A-050", "A-050", "A-051", "A-051", "A-051", "A-051", "A-051", "A-052", "A-052", "A-052", "A-052", "A-052", "A-053", "A-053", "A-053", "A-053", "A-053", "A-054", "A-054", "A-054", "A-054", "A-054", "A-055", "A-055", "A-055", "A-055", "A-055", "A-056", "A-056", "A-056", "A-056", "A-056", "A-057", "A-057", "A-057", "A-057", "A-057", "A-080", "A-080", "A-080", "A-080", "A-080", "A-081", "A-081", "A-081", "A-081", "A-081", "A-083", "A-083", "A-083", "A-083", "A-083", "A-084", "A-084", "A-084", "A-084", "A-084", "A-085", "A-085", "A-085", "A-085", "A-085", "A-086", "A-086", "A-086", "A-086", "A-086", "A-087", "A-087", "A-087", "A-087", "A-087", "A-088", "A-088", "A-088", "A-088", "A-088", "A-089", "A-089", "A-089", "A-089", "A-089", "A-092", "A-092", "A-092", "A-092", "A-092", "A-093", "A-093", "A-093", "A-093", "A-093", "A-095", "A-095", "A-095", "A-095", "A-095", "A-113", "A-113", "A-113", "A-113", "A-113", "M-053", "M-053", "M-053", "M-053", "M-053"),
        age = c(1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L, 1L, 2L, 3L, 4L, 5L),
        unit = c("month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month", "month")
      ),
      row.names = c(NA,-235L),
      class = c("tbl_df",
                "tbl", "data.frame")
    )

  ## test if simple usage works:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    reshape_row_age.seq(age = 1:5,
                        unit = "month",
                        ID) -> job1

  ## test if placeholders outside tables can be used:
  foo <- "month"
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    reshape_row_age.seq(age = 1:5,
                        unit = foo,
                        ID) -> job2

  ## test if placeholders from table can be used:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    mutate(theunit = "month") %>%
    reshape_row_age.seq(age = 1:5,
                        unit = theunit, ## unit clashes with grid::unit...
                        ID) -> job3

  ## test if placeholders from table can be used with another name:
  create_id_starting.table(clan = "A", at = "1997/01/01", lifestage = "!dead") %>%
    mutate(foo_tbl = "month") %>%
    reshape_row_age.seq(age = 1:5,
                        unit = foo_tbl,
                        ID) -> job4

  expect_equal(ref, job1)
  expect_equal(ref, job2)
  expect_equal(ref, job3)
  expect_equal(ref, job4)

})


test_that("reshape_row_age.seq can keep multiple columns", {

  ref <- structure(list(parentID = c("A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "A-001"),
                        offspringID = c("A-010", "A-010", "A-018", "A-018", "A-046", "A-046", "A-084", "A-084", "A-088", "A-088", "A-089", "A-089"),
                        age = c(1L, 2L, 1L, 2L, 1L, 2L, 1L, 2L, 1L, 2L, 1L, 2L),
                        unit = c("year", "year", "year", "year", "year", "year", "year", "year", "year", "year", "year", "year")),
                   row.names = c(NA, -12L),
                   class = c("tbl_df", "tbl", "data.frame"))

  create_id_offspring.table(ID = "A-001") %>%
    reshape_row_age.seq(
      parentID, offspringID,
      age = 1:2,
      unit = "year") -> job

  expect_equal(ref, job)

})
