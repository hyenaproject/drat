context("Test check_database_xxx functions")

test_that("check_database_is.loaded works as intended", {
  expect_message(check_database_is.loaded())

  rm(list = ".database", envir = .GlobalEnv)
  expect_error(check_database_is.loaded())

  load_package_database.dummy()

})

test_that("check_database_is.correct returns a boolean", {

  job1 <- check_database_is.correct()

  expect_true(job1)

})
