context("Test functions associated with HyenaPopmod simulation...")

test_that("simulation can be loaded", {

  if (requireNamespace("HyenaPopmod", quietly = TRUE)) {

    #Run simulation object if HyenaPopmod is loaded
    sim_test <- HyenaPopmod::simulation$new(number_steps = 5, number_clans = 1,
                                            start_clan_size = 2, sex_ratio = 0.5, mean_age = 6,
                                            seed = 123)
    sim_test$run_sim()

    #.database is created with sim attribute
    expect_true(attr(.database, "datatype") == "sim")

    #Test that we can run a regular hyenaR function
    lh_table <- create_id_life.history.table()
    expect_equal(class(lh_table), c("tbl_df", "tbl", "data.frame"))

    #Reload dummy data incase there are other tests that need to be run
    load_package_database.dummy()

  }

})
