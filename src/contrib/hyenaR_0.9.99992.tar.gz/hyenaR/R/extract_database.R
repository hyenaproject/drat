#' Extract data frames from the hyena database.
#'
#' Extract data frames from the hyena database loaded with [load_package_database.dummy]. Can
#' be used to extract a single table or multiple tables.
#'
#' @inheritParams arguments
#' @return If only one table is requested, will return a single `tibble`. If
#'   multiple tables are requested, will return a list of `tibbles`.
#' @export
#'
#' @examples
#'
#' # Load the dummy dataset
#' load_package_database.dummy()
#'
#' # Extract the hyenas table from the dummy database
#' hyenas <- extract_database_table(tbl.names = "hyenas")
#'
#' # Extract the hyenas and deaths table from the dummy database
#' # as a list
#' data_list <- extract_database_table(tbl.names = c("hyenas", "deaths"))
extract_database_table <- function(tbl.names = NULL) {
  table_name <- data <- NULL ## Satisfy R CMD check

  if (!exists(".database")) {
    stop("Please call load_package_database.full(), load_package_database.dummy(), or load_package_database.sim() before attempting to extract data tables.")
  }

  possible_tables <- .database$database$table_name

  ## extract all tables if not specified otherwise:
  if (is.null(tbl.names)) {
    tbl.names <- possible_tables
  }

  ## check that requested table name exists in the database:
  if (!all(tbl.names %in% possible_tables)) {
    wrong_tables <- tbl.names[which(!tbl.names %in% possible_tables)]

    stop(paste0("These table names are not in the database: ", paste(wrong_tables, collapse = ", "), ".\n\nThe possible table names are: ", paste(possible_tables, collapse = ", "), ".\n\nPlease check your spelling and try again."))
  }

  ## create a list of all the requested data tables:
  output_list <- .database$database %>%
    dplyr::filter(table_name %in% tbl.names) %>%
    dplyr::pull(data)

  ## If only one table is requested return a single tibble object, rather than a
  ## list:
  if (length(tbl.names) == 1) {
    return(output_list %>% `[[`(1))

    ## If more than one table is requested return a list of tibbles:
  } else {
    names(output_list) <- tbl.names
    return(output_list)
  }
}


#' Extract all available info on a given hyena.
#'
#' This function returns all rows from primary tables which contain in their ID column the
#' ID provided as argument. The empty rows, columns and tables are dropped to make
#' the information available easier to visualise.
#'
#' Note that if the ID of the hyenas is mentioned in a column that is not the column ID, then
#' the information is not retained by this function (such as in table `interactions`).
#'
#' @inheritParams arguments
#' @return A list of tables.
#' @export
#'
#' @examples
#' load_package_database.dummy()
#' extract_database_row("A-001")
extract_database_row <- function(ID) {
  all <- extract_database_table()
  ## remove tables without ID as column and without the individidual(s) in the ID column:
  tables <- lapply(all, function(tbl) {
    if ("ID" %in% colnames(tbl)) {
      tbl[tbl$ID %in% ID, ]
      } else data.frame()})
  ## remove empty rows:
  tables <- lapply(tables, function(tbl) {
    to_delete_row <- apply(tbl, 1, function(x) all(is.na(x)))
    tbl[!to_delete_row, ]
  })
  ## remove empty columns:
  tables <- lapply(tables, function(tbl) {
    to_delete_col <- apply(tbl, 2, function(x) all(is.na(x)))
    tbl[, !to_delete_col]
  })
  ## remove empty tables:
  null_info <- unlist(lapply(tables, function(x) nrow(x) == 0))
  tables[!null_info]
}

