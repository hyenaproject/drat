## Note: extract is probably a poor name for these functions and it does not match
## the other extract functions. We need to think of something better but these
## functions may disappear if the Python code is revised.

#' Extract all ranks
#'
#' This function allows for computing all rank information. It is a user level
#' function that calls [create_rank_python.table()]. Before calling [create_rank_python.table()], the
#' function filter out individuals not alive at the requested date.
#'
#' Note for developers: this function is also used as companion function for
#' all the ```fetch_xxx``` calls that are internally rely on a call to
#' [create_rank_python.table()].
#'
#' @inheritParams arguments
#' @export
#' @examples
#' #### Simple example of extract_allrankinfo usage:
#' load_package_database.dummy()
#' create_id_rank.table(ID = c("A-080", "M-094"), at = c("1996-10-04", "1996-07-01"))
#' create_id_rank.table(ID = c("A-080"), at = c("1996-10-04", "1996-07-01"))
#'
#' #### Example with missing information:
#' create_id_rank.table(ID = c("A-001", "A-100"), at = c("1996-04-12", "1997-08-15"))
create_id_rank.table <- function(ID, at) {
  tibble::tibble(ID = ID, date = as.Date(at)) %>%
    dplyr::mutate(
      surv = fetch_id_is.alive(ID = ID, at = date),
      date = date
    ) -> input

  input %>%
    dplyr::group_by(ID, date) %>%
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::filter(surv) -> input_alive

  if (nrow(input_alive) == 0) {

    warning("None of the selected individuals are alive on these dates")
    return(tibble::tibble())

  }

  message(paste("Extracting info for", nrow(input_alive), "cases that are alive and unique at the requested date..."))

  info <- create_rank_python.table(py.input.tbl = input_alive)

  if (length(info) == 0) {
    return(input)
  }

  info %>%
    dplyr::mutate(date = as.Date(date)) %>%
    dplyr::left_join(x = input, y = ., by = c("ID", "date")) -> output

  surv <- NULL ## to please R CMD check

  return(output)
}


#' @describeIn create_family create a list of table where all informations about the given ID are summarised.
#' @export
#' @examples
#'
#' #### Simple example of extract_id_summary usage:
#' extract_id_summary(ID = "A-001")
#'
extract_id_summary <- function(ID) {
  ID <- check_function_arg.ID(ID)

  birthdate <- tryCatch(check_function_arg.date(fetch_id_date.birth(ID = ID)), error = function(cond) {
    stop("The function needs of known birthdate() to work. Some birthdates you used may either be missing or not within the correct study period. Please run 'check_function_arg.date(fetch_id_date.birth(ID = ID))' to check the problem in more depth.")
  })

  date2yo <- tryCatch(check_function_arg.date(fetch_id_date.at.age(ID = ID, age = 2)), error = function(cond) {
    stop("The function needs of a known date at 2 yrs to work. It is possible that some dates at 2 yrs do not fall within the determined study period. Please run 'check_function_arg.date(fetch_id_date.at.age(ID = ID, age = 2))' to explore the problem in more depth.")
  })

  last.obs <- tryCatch(check_function_arg.date(fetch_id_date.observation.last(ID)), error = function(cond) {
    stop("The function needs of proper last observation date(s) to work. It is possible that some date(s) for the last observation do not fall within the determined study period. Please run 'check_function_arg.date(fetch_id_date.observation.last(ID = ID)' to check the problem in more depth.")
  })

  hyena <- tibble::tibble(ID = ID,
                          sex = fetch_id_sex(.data$ID),
                          dna = fetch_id_is.sampled.dna(.data$ID),
                          birthclan = fetch_id_clan.birth(.data$ID),
                          gen.mum = fetch_id_id.mother.genetic(.data$ID),
                          soc.mum = fetch_id_id.mother.social(.data$ID),
                          father = fetch_id_id.father(.data$ID),
                          clan.last.sighting = fetch_id_clan.current(.data$ID, at = last.obs)
  )

  dates <- tibble::tibble(ID = ID,
                          birthdate = birthdate,
                          first.sighting = fetch_id_date.observation.first(.data$ID),
                          last.sighting = last.obs,
                          deathdate = fetch_id_date.death(.data$ID)
  )

  rank <- create_id_rank.table(ID, at = c(birthdate,
                                          date2yo,
                                          last.obs))

  conceptions <- create_id_mate.conception.table(ID = ID)

  offspring.litter <- create_id_offspring.table(ID = ID) %>%
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID))

  life.history <- create_id_life.history.table(ID)

  sightings <- extract_database_row(ID)$sightings %>%
    dplyr::relocate(.data$ID, .before = .data$date_time)

  interactions <- extract_database_row(ID)$interactions

  summary.table <- list(hyena = hyena, dates = dates, rank = rank, conceptions = conceptions, offspring = offspring.litter,
                        life.history = life.history, sightings = sightings, interactions = interactions)

  summary.table
}
