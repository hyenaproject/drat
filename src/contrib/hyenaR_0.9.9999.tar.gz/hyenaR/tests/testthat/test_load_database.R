context("Test that we can load the (dummy) database with load_package_database.dummy()")

test_that("load_package_database.dummy() creates a hidden global object and returns a message when loading dummy data", {

  # Message saying we are using the dummy database
  expect_message(load_package_database.dummy())
  expect_true(exists(".database"))

})

test_that("deathdate correctly accounts for deathconfirmed information", {

  #Confirmed deaths
  all_deaths <- extract_database_table("hyenas") %>%
    dplyr::left_join(extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(!is.na(deathdate)) %>%
    dplyr::mutate(lastobsv = fetch_id_date.observation.last(ID = ID),
                  deathconfirmed = as.Date(.data$deathconfirmed)) %>% ## FIXME: deathconfirmed is chr because first value is NA
                                                                      ## therefore when we writetable to database it coerces to string
                                                                      ## May not be a major issue because we want to replace the database
    dplyr::select(ID, deathconfirmed, lastobsv, deathdate)

  confirmed <- all_deaths %>%
    dplyr::filter(!is.na(deathconfirmed))

  #Check that there is a confirmed deaths that is <1yr from last observation
  #These are needed to check the SQL code
  #Want to provide this warning in case we change how the dummy data is calculated
  if (all(find_pop_date.observation.last() - confirmed$deathconfirmed > 365)) {

    warning("No individuals with recent deathconfirmed (<365 days since last observation) in the dummy database.
            We cannot fully test death dates.")

  }

  unconfirmed <- all_deaths %>%
    dplyr::filter(is.na(deathconfirmed))

  #When death is confirmed, deathdate should be exactly the same as deathconfirmed
  expect_true(all(confirmed$deathconfirmed == confirmed$deathdate))

  #When death is unconfirmed, deathdate should be one day after the last observation
  expect_true(all(unconfirmed$deathdate == unconfirmed$lastobsv + 1))

})
