context("Test create_xxx functions")

test_that("all create functions return the correct type", {

  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_starting.table())[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-10-30", clan.overlap = "always", lifestage.overlap = "always"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "birth"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_offspring_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_mate.conception.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count("A-001_004"))[1], "tbl_df")
  expect_equal(class(create_id_offspring.count(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sighting_starting.table(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sample_starting.table(at = "1996/07/30"))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.table(litterID = c("A-001_004", "A-001_002")))[1], "tbl_df")
  expect_equal(class(create_offspring_starting.table(ID = "A-001"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.mother(parentID = "A-001"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.father(parentID = "A-011"))[1], "tbl_df")
  expect_equal(class(create_offspring_litterID.from.all(parentID = c("A-011", "A-001")))[1], "tbl_df")
  expect_equal(class(create_cervus_input(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_offspring_father.candidate.table(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_dyad_table.bystander("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_relatedness.table(c("A-011", "A-001"), filiation = "mother_social"))[1], "tbl_df")
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_clan_rank.social("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_interaction.type("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
})


test_that("create_offspring_litterID.from.all works as intended", {
  ref <- structure(list(parentID = c("A-011", "A-011", "A-011", "A-058"),
                        offspringID = c("A-080", "A-092", "A-054", NA), filiation = c("father","father", "father", NA),
                        litterID = c("A-002_001", "A-016_002", NA, NA),
                        birthdate = structure(c(9658, 9798, 9487, NA), class = "Date")),
                   row.names = c(NA,  -4L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_offspring_litterID.from.all(parentID = c("A-011", "A-058"))
  expect_equal(ref, job)
})


test_that("create_id_starting.table returns output as intended", {

  #When ID is specified, return only these individuals
  job1 <- create_id_starting.table(ID = c("A-080", "L-094"))
  ref1 <- structure(list(ID = c("A-080", "L-094")),
                    row.names = c(NA, -2L),
                    class = c("tbl_df", "tbl", "data.frame"))

  expect_equal(job1, ref1)

  #When no arguments are specified, return all possible individuals
  #Check expected outcome (ref2a) and raw data (ref2b)
  job2 <- create_id_starting.table()
  ref2a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                "A-055", "A-056", "A-057", "A-058", "A-080", "A-081", "A-082",
                                "A-083", "A-084", "A-085", "A-086", "A-087", "A-088", "A-089",
                                "A-090", "A-091", "A-092", "A-093", "A-094", "A-095", "A-096",
                                "A-097", "A-098", "A-099", "A-100", "A-113", "A-114", "L-001",
                                "L-002", "L-003", "L-004", "L-005", "L-006", "L-007", "L-008",
                                "L-009", "L-010", "L-011", "L-012", "L-013", "L-014", "L-015",
                                "L-040", "L-041", "L-042", "L-043", "L-044", "L-045", "L-046",
                                "L-047", "L-048", "L-049", "L-080", "L-081", "L-082", "L-083",
                                "L-084", "L-085", "L-086", "L-087", "L-088", "L-089", "L-090",
                                "L-091", "L-092", "L-093", "L-094", "L-095", "L-096", "L-097",
                                "L-098", "L-099", "L-100", "L-101", "L-102", "L-103", "L-104",
                                "L-105", "L-106", "L-108", "L-109", "L-110", "M-004", "M-047",
                                "M-051", "M-053", "N-043", "S-002", "S-043")),
                    row.names = c(NA, -122L), class = c("tbl_df", "tbl", "data.frame"))
  ref2b <- extract_database_table("hyenas") %>%
    dplyr::select(.data$ID)
  expect_identical(job2, ref2a, ref2b)

  #When only clan (and no date) are provided, return all individuals born into this clan
  #Check expected outcome (ref3a) and raw data (ref3b)
  job3  <- create_id_starting.table(clan = "A")
  ref3a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
                                "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
                                "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
                                "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
                                "A-099", "A-100", "A-113", "A-114")),
                    row.names = c(NA, -51L),
                    class = c("tbl_df", "tbl", "data.frame"))
  ref3b <- extract_database_table("hyenas") %>%
    dplyr::filter(.data$birthclan == "A") %>%
    dplyr::select(.data$ID)
  expect_identical(job3, ref3a, ref3b)

  #When date(s) are provided, return all individuals that were alive on these date(s)
  #Check expected outcome (ref4/5a) and raw data (ref4/5b)
  job4  <- create_id_starting.table(at = "1996-04-12")
  ref4a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
                                "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
                                "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
                                "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
                                "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
                                "L-083", "L-088", "L-089", "M-004", "M-047", "M-051", "M-053",
                                "N-043", "S-002", "S-043")),
                    row.names = c(NA, -78L), class = c("tbl_df", "tbl", "data.frame"))
  ref4b <- extract_database_table("hyenas") %>%
    dplyr::left_join(extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-04-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select(.data$ID)
  expect_identical(job4, ref4a, ref4b)

  job5  <- create_id_starting.table(from = "1996-04-12", to = "1996-05-12")
  ref5a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
                                "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
                                "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
                                "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
                                "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
                                "L-083", "L-084", "L-085", "L-088", "L-089", "M-004", "M-047",
                                "M-051", "M-053", "N-043", "S-002", "S-043")),
                    row.names = c(NA, -80L), class = c("tbl_df", "tbl", "data.frame"))
  ref5b <- extract_database_table("hyenas") %>%
    dplyr::left_join(extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-05-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select(.data$ID)
  expect_identical(job5, ref5a, ref5b)

  #Clan, lifestage, date will return all individuals of that lifestage, in this clan on that date
  job6 <- create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
  ref6 <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-009", "A-013", "A-014", "A-015", "A-016", "A-017",
                                "A-020", "L-001", "L-002", "L-003", "L-004", "L-005", "L-006",
                                "L-007", "L-008", "L-009", "L-011", "L-012", "L-014")),
                    row.names = c(NA, -25L), class = c("tbl_df", "tbl", "data.frame"))

  expect_identical(job6, ref6)

  #Only those individuals that were born/emigrated into the clan during this period
  job7 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start")
  ref7 <- structure(list(ID = c("A-011", "A-042", "A-044", "A-045", "A-047",
                                "A-048", "A-050", "A-051", "A-055", "A-080", "A-081", "A-086",
                                "A-087", "A-088", "A-089", "A-090", "A-091", "A-092", "A-093",
                                "A-094", "A-095", "A-096", "A-097", "A-098", "A-099", "A-100",
                                "A-114", "M-051", "M-053", "S-043")),
                    row.names = c(NA, -30L), class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job7, ref7)

  #Only those individuals that started these lifestages during this period
  job8 <- create_id_starting.table(lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref8 <- structure(list(ID = c("A-008", "A-010", "A-018", "A-019", "A-040",
                                "A-049", "L-010", "L-013", "L-015", "L-088", "M-047", "M-051",
                                "M-053", "N-043", "S-043")),
                    row.names = c(NA, -15L),
                    class = c("tbl_df", "tbl", "data.frame"))

  expect_identical(job8, ref8)

  #Only those individuals in the clan and lifestage during this whole period
  job9 <- create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-01-30", clan.overlap = "always", lifestage.overlap = "always")
  ref9 <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-008", "A-009", "A-010", "A-013", "A-014", "A-015", "A-016",
                                "A-017", "A-019", "A-020", "A-040")),
                    row.names = c(NA, -16L),
                    class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job9, ref9)

  #Default overlap method is any (at least 1 day of overlap)
  job10a <- create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any")
  job10b <- create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30")
  ref10  <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                "A-016", "A-017", "A-018", "A-019", "A-020", "A-040")),
                    row.names = c(NA, -18L),
                    class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job10a, job10b, ref10)

  #When sex and clan are provided, return all females born in this clan
  #Check expected outcome (ref11a) and raw data (ref11b)
  job11  <- create_id_starting.table(sex = "female", clan = "A")
  ref11a <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
                                "A-016", "A-017", "A-018", "A-019", "A-020", "A-080", "A-081",
                                "A-088", "A-096", "A-098", "A-114")),
                    row.names = c(NA, -23L),
                    class = c("tbl_df", "tbl", "data.frame"))
  ref11b <- extract_database_table("hyenas") %>%
    dplyr::filter(.data$birthclan == "A" & .data$sex == "female") %>%
    dplyr::select(.data$ID)
  expect_identical(job11, ref11a, ref11b)

  #When dead is specified, should return all individuals that have died in clan A up to focal date
  job12 <- create_id_starting.table(clan = "A", lifestage = "dead", at = "1997-01-01")
  ref12 <- structure(list(ID = c("A-007", "A-043", "A-044", "A-058", "A-082")),
                     row.names = c(NA, -5L), class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job12, ref12)

  #If lifestage is not specified or specified as !dead, everything EXCEPT dead will be used
  job13a <- create_id_starting.table(clan = "A", at = "1997-01-01")
  job13b <- create_id_starting.table(clan = "A", lifestage = "!dead", at = "1997-01-01")
  ref13  <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-008", "A-009", "A-010", "A-011", "A-013", "A-014", "A-015",
                                 "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
                                 "A-042", "A-045", "A-046", "A-047", "A-048", "A-049", "A-050",
                                 "A-051", "A-052", "A-053", "A-054", "A-055", "A-056", "A-057",
                                 "A-080", "A-081", "A-083", "A-084", "A-085", "A-086", "A-087",
                                 "A-088", "A-089", "A-092", "A-093", "A-095", "A-113", "M-053")),
                     row.names = c(NA, -47L), class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job13a, job13b, ref13)

  #If lifestage is not specified but fill.dead = TRUE, everything INCLUDING dead will be used
  job14 <- create_id_starting.table(clan = "A", at = "1997-01-01", fill.dead = TRUE)
  ref14 <- structure(list(ID = c("A-001", "A-002", "A-003", "A-004", "A-006",
                                 "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
                                 "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
                                 "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
                                 "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
                                 "A-055", "A-056", "A-057", "A-058", "A-080", "A-081", "A-082",
                                 "A-083", "A-084", "A-085", "A-086", "A-087", "A-088", "A-089",
                                 "A-092", "A-093", "A-095", "A-113", "M-053")),
                     row.names = c(NA, -52L), class = c("tbl_df", "tbl", "data.frame"))
  expect_identical(job14, ref14)

  #The difference between job14 (all lifestage include dead) and job13a/b (all lifestage except dead)
  #should be job 12 (all dead)
  expect_identical(setdiff(job14$ID, job13a$ID), setdiff(job14$ID, job13b$ID), job12$ID)

})


test_that("create_offspring_litterID.from.father works as intended", {
  ref <- structure(list(parentID = c("A-011", "A-011", "A-011", "A-040"),
                        offspringID = c("A-054", "A-080", "A-092", NA), filiation = c("father","father", "father", NA),
                        litterID = c(NA, "A-002_001", "A-016_002",NA),
                        birthdate = structure(c(9487, 9658, 9798, NA), class = "Date")),
                   row.names = c(NA, -4L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_offspring_litterID.from.father(parentID = c("A-011", "A-040"))
  expect_equal(ref, job)
})


test_that("create_offspring_litterID.from.mother works as intended", {
  ref <- structure(list(parentID = c("A-001", "A-001", "A-001", "A-001","A-001", "A-001", "A-058"),
                        offspringID = c("A-010", "A-018", "A-046","A-084", "A-088", "A-089", NA),
                        filiation = c("mother_social_genetic","mother_social_genetic", "mother_social_genetic", "mother_social_genetic",
                                      "mother_social_genetic", "mother_social_genetic", NA),
                        litterID = c("A-001_001","A-001_002", "A-001_002", "A-001_003", "A-001_004", "A-001_004",NA),
                        birthdate = structure(c(9029, 9268, 9268, 9411, 9842, 9842,NA), class = "Date")),
                   row.names = c(NA, -7L),
                   class = c("tbl_df","tbl", "data.frame"))
  job <- create_offspring_litterID.from.mother(parentID = c("A-001", "A-058"))
  expect_equal(ref, job)
})


test_that("create_offspring_starting.table works as intended", {
  ref <- structure(list(parentID = c("A-001", "L-003", "A-100", "A-011","A-058"),
                        offspringID = c("A-010", NA, NA, NA, NA),
                        filiation = c("mother_social_genetic",NA, NA, NA, NA)),
                   row.names = c(NA, -5L),
                   class = c("tbl_df","tbl", "data.frame"))
  job <- create_offspring_starting.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
                                         from = "1994-01-01", to = "1995-01-01")
  expect_equal(ref, job)
})


test_that("create_litter_offspring.table returns output as intended", {
  ref <- structure(list(litterID = c("A-001_004", "A-001_004", "A-001_002",
                                     "A-001_002"),
                        parentID = c("A-001", "A-001", "A-001", "A-001"),
                        offspringID = c("A-088", "A-089", "A-018", "A-046"),
                        filiation = c("mother_social_genetic","mother_social_genetic",
                                      "mother_social_genetic", "mother_social_genetic"),
                        birthdate = structure(c(9842, 9842, 9268, 9268), class = "Date")),
                   row.names = c(NA,-4L),
                   class = c("tbl_df", "tbl", "data.frame"))
  job <- create_litter_offspring.table(litterID = c("A-001_004", "A-001_002"))
  expect_equal(ref, job)

})


test_that("create_id_offspring.count returns output as intended", {
  ref <- structure(
    list(
      parentID = c("A-001", "A-008"),
      n_females = c(3L,
                    NA),
      n_males = c(3L, NA),
      n_unknown = c(0L, NA)
    ),
    row.names = 1:2,
    class = c("tbl_df",
              "tbl", "data.frame")
  )
  job <- create_id_offspring.count(ID = c("A-001", "A-008"))
  expect_equal(ref, job)
})

test_that("create_litter_offspring.count returns output as intended", {
  ref <-
    structure(
      list(
        litterID = "A-001_004",
        female = 1L,
        male = 1L,
        unknown = 0L,
        social.female = 0L,
        social.male = 0L,
        social.unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- create_litter_offspring.count("A-001_004")
  expect_equal(ref, job)
})

test_that("create_litter_starting.table return the expected output", {
  ref <- structure(list(parentID = c(rep("A-001",4), "L-003", "A-098"),
                        litterID = c("A-001_001", "A-001_002", "A-001_003", "A-001_004", "L-003_001", NA_character_)),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -6L))
  job <- create_litter_starting.table(c("A-001", "L-003", "A-098"))
  expect_equal(ref,job)
})


test_that("create_id_mate.conception.table returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "A-001", "A-001", "A-001", "A-001", "L-003", "A-098"),
      mate = c("A-045", "A-045", NA, NA, NA, "L-043", NA),
      date = structure(c(8919, 9158, 9158, 9301, 9732, 9240, NA), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -7L)
  )
  job <- create_id_mate.conception.table(c("A-001", "L-003", "A-098"))
  expect_identical(ref, job)
})


test_that("create_id_life.history.table returns the correct output", {
  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040", "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080, 7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079, 7444, Inf, 9232, 9597, 9687, Inf), class = "Date"),
        isrightcensored = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE),
        isleftcensored = c(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA,-7L)
    )
  job <- create_id_life.history.table(c("A-001", "A-040"), censored.to.last.sighting = FALSE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040",
               "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080,
                                    7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079,
                                  7444, 10147, 9232, 9597, 9687, 10057), class = "Date"),
        isrightcensored = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE),
        isleftcensored = c(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE)
      ),
      row.names = c(NA,-7L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  job2 <- create_id_life.history.table(c("A-001", "A-040"), censored.to.last.sighting = TRUE)
  expect_identical(ref2, job2)


  ## Test that the function produces a warning when not cached
  expect_warning(uncached <- create_id_life.history.table(ID = c("A-001", "A-040"), .cache = FALSE))

  #Test that cached and non-cached output are the same beyond the ending date
  cached   <- create_id_life.history.table(ID = c("A-001", "A-040"), .cache = TRUE)
  uncached %>%
    dplyr::rename(ending_date = .data$ending_date_na_as_na) %>%
    dplyr::select(- .data$ending_date_na_as_last_sighting) -> uncached
  expect_identical(cached, uncached)

  ## Same with censoring
  expect_warning(uncached <- create_id_life.history.table(ID = c("A-001", "A-040"),
                                                          censored.to.last.sighting = TRUE,
                                                          .cache = FALSE))
  cached   <- create_id_life.history.table(ID = c("A-001", "A-040"),
                                           censored.to.last.sighting = TRUE,
                                           .cache = TRUE)
  uncached %>%
    dplyr::rename(ending_date = .data$ending_date_na_as_last_sighting) %>%
    dplyr::select(- .data$ending_date_na_as_na) -> uncached
  expect_identical(cached, uncached)

})

test_that("create_id_selection.history returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "L-094"),
      clan = c("A", "L"),
      starting_date = structure(c(6715, 9896), class = "Date"),
      ending_date = structure(c(10225, 10225), class = "Date")
    ),
    class = c("tbl_df","tbl", "data.frame"),
    row.names = c(NA,-2L)
  )
  job <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = TRUE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "L-094"),
        clan = c("A", "L"),
        starting_date = structure(c(6715, 9896), class = "Date"),
        ending_date = structure(c(NA_real_, NA_real_), class = "Date")
      ),
      class = c("tbl_df",
                "tbl", "data.frame"),
      row.names = c(NA,-2L)
    )

  job2 <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = FALSE)
  expect_identical(ref2, job2)
})

test_that("create_id_life.transition.table returns the correct output", {
  ref <- structure(list(ID = c("A-001", "A-001", "A-008", "A-008", "A-044", "A-044"),
                        origin = c("W", "A", "W", "A", "W", "X"),
                        destination = c("A", "A", "A", "A", "X", "A"),
                        date = structure(c(6715, 7445, 8906, 9636, 5254, 9598), class = "Date")),
                   row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame"))
  job <- create_id_life.transition.table(c("A-001", "A-008", "A-044"))
  expect_identical(ref, job)
})

test_that("create_sighting_starting.table returns output as intended", {

  ref <- structure(list(ID = c("A-001", "A-002", "A-002"),
                        sighting_time = structure(c(857977740, 857977740, 857979360),
                                                  class = c("POSIXct", "POSIXt"),
                                                  tzone = "Africa/Dar_es_Salaam"),
                        latitude = c(-3.14017, -3.14017, -3.1415),
                        longitude = c(35.50417, 35.50417, 35.50333),
                        sighting_clan = c("A", "A", "A")),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -3L))
  job <- create_sighting_starting.table(ID = c("A-001", "A-002"), from = "1997-03-01", to = "1997-03-10")
  expect_equal(ref, job)

})

test_that("create_sample_starting.table works with dates provided", {

  ref <- structure(list(ID = c("L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                               "L-043"),
                        sampleID = c("N0001", "N0002a",
                                     "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a", "N0005",
                                     "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c", "N0008d",
                                     "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011", "N0012",
                                     "N0013", "N0014"),
                        collection_time = structure(c(838744200, 838736640, 838744200, 838737000, 838744200,
                                                      838740600, 838744200, 838740600, 838744200, 838740600, 838744200,
                                                      838738800, 838749600, 838746000, 838746000, 838746000, 838749600,
                                                      838749600, 838749600, 838749600, 838749600, 838751400, 838739700,
                                                      838745100, 838735200), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
                        type = c("testicle", "liver", "liver",
                                 "spleen", "spleen", "salivary gland", "salivary gland", "lymph node",
                                 "lymph node", "tonsil", "tonsil", "voice box", "muscle",
                                 "muscle", "muscle", "muscle", "brain", "brain", "brain",
                                 "blood", "CSF", "eye", "tongue", "gland", "penis"),
                        treatment = c("liq N", "10% Form", "liq N", "10% Form", "liq N",
                                      "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                      "10% Form", "liq N", "Ethanol", "Ethanol", "10% Form", "glycerol",
                                      "glycerol", "liq N", "liq N", "liq N", "10% Form", "10% Form",
                                      "10% Form", "10% Form")), class = c("tbl_df", "tbl", "data.frame"
                                      ), row.names = c(NA, -25L))

  job <- create_sample_starting.table(from = "1996-07-01",
                                      to = "1996-08-01", verbose = FALSE)

  ref2 <- structure(list(ID = c("L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
                                "L-043", "L-043", "L-043", "L-043", "L-043", "L-043"),
                         sampleID = c("N0001",
                                      "N0002a", "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a",
                                      "N0005", "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c",
                                      "N0008d", "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011",
                                      "N0012", "N0013", "N0014"),
                         collection_time = structure(c(838744200,
                                                       838736640, 838744200, 838737000, 838744200, 838740600, 838744200,
                                                       838740600, 838744200, 838740600, 838744200, 838738800, 838749600,
                                                       838746000, 838746000, 838746000, 838749600, 838749600, 838749600,
                                                       838749600, 838749600, 838751400, 838739700, 838745100, 838735200), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
                         type = c("testicle",
                                  "liver", "liver", "spleen", "spleen", "salivary gland", "salivary gland",
                                  "lymph node", "lymph node", "tonsil", "tonsil", "voice box",
                                  "muscle", "muscle", "muscle", "muscle", "brain", "brain", "brain",
                                  "blood", "CSF", "eye", "tongue", "gland", "penis"),
                         treatment = c("liq N",
                                       "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                       "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
                                       "Ethanol", "Ethanol", "10% Form", "glycerol", "glycerol", "liq N",
                                       "liq N", "liq N", "10% Form", "10% Form", "10% Form", "10% Form")),
                    class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -25L))

  job2 <- create_sample_starting.table(ID = "L-043", verbose = FALSE)

  expect_equal(ref, job)
  expect_equal(ref2, job2)

})

test_that("create_clan_obsv.effort.table returns the correct output", {

  expect_equal(class(create_clan_obsv.effort.table(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  ref <- structure(list(clan = c("A", "L"),
                       from = structure(c(9862, 9862), class = "Date"),
                       to = structure(c(10196, 10196), class = "Date"),
                       effort_adult = c(34/34, 26/26),
                       effort_cub = c(19/21, 19/21),
                       effort_all = c(53/55, 45/47)),
                  row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame"))

  #We keep the new argument just to make sure we can compare new & and old method
  job <- create_clan_obsv.effort.table(clan = c("A", "L"), from = "1997-01-01", to = "1997-12-01")
  expect_equal(ref, job)

})

test_that("create_cervus_input works as intended",{
  ref <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      sex = c(
        "female",
        "female",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male"
      ),
      motherID = c(
        "A-015",
        NA,
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014"
      ),
      birthdate = structure(
        c(
          8906,
          6715,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797
        ),
        class = "Date"
      ),
      clan.conception = c("A",
                          NA, "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      ),
      genotyped = c(
        NA,
        NA,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE,
        FALSE,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE
      ),
      index.candidate = c(
        "candidate1",
        "candidate1",
        "candidate1",
        "candidate2",
        "candidate3",
        "candidate4",
        "candidate5",
        "candidate6",
        "candidate7",
        "candidate8",
        "candidate9",
        "candidate10",
        "candidate11"
      ),
      N.typed = c(NA, NA, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L,
                  8L),
      N.potential = c(NA, NA, 11L, 11L, 11L, 11L, 11L, 11L, 11L,
                      11L, 11L, 11L, 11L),
      prop.typed = c(
        NA,
        NA,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727
      )
    ),
    row.names = c(NA,-13L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_cervus_input(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref, job)
} )


test_that("create_offspring_father.candidate.table works as intended", {
  ref <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      )
    ),
    row.names = c(NA,-13L),
    class = c("tbl_df",
              "tbl", "data.frame")
  )
  job <- create_offspring_father.candidate.table(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref, job)
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(list(ID = c("A-001", "A-084", "A-018", "A-046", "A-010",
                               "A-003", "A-015", "A-008", "A-013", "A-016", "A-019", "A-020",
                               "A-041", "A-049", "A-081", "A-057", "A-085", "A-002", "A-004",
                               "A-006", "A-007", "A-009", "A-014", "A-017", "A-040", "A-043",
                               "A-052", "A-053", "A-056", "A-058", "A-080", "A-054", "A-083",
                               "A-113", "A-011", "A-042", "A-044", "A-045", "A-047", "A-048",
                               "A-050", "A-051", "M-053"), rank = c(1, 2, 3, 3, 5, 6, 6, 8,
                                                                    8, 8, 11, 11, 11, 11, 11, 16, 16, 18, 18, 18, 18, 18, 18, 18,
                                                                    18, 18, 18, 18, 18, 18, 18, 32, 32, 32, 35, 35, 35, 35, 35, 35,
                                                                    35, 35, 35)), row.names = c(NA, -43L), class = c("tbl_df", "tbl",
                                                                                                                     "data.frame"))
  job <- create_clan_rank.social("A", "1996-07-30")
  expect_equal(ref, job)
})

test_that("create_id_table.ancestors return a list column with ancestors", {
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30")$ancestors), "list")
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(
    list(ID.1 = c("A-084"),
         ID.2 = c("A-001"),
         date = as.Date(c("1997-04-01")),
         ID.1_is_migrant = c(FALSE),
         ID.2_is_migrant = c(FALSE),
         mrcaID = c("A-001"),
         type = c("native_related")),
    row.names = c(NA,-1L),
    class = c("tbl_df", "tbl", "data.frame"))
  job <- create_dyad_interaction.type(ID.1 = "A-084", ID.2 = "A-001", "1997-04-01")
  expect_equal(ref, job)
})

test_that("create_id_overlap.table works as intended", {

  #Dummy data to filter
  input <- structure(list(ID = c("A", "A", "B", "C"),
                          starting_date = c("1996-01-01", "1997-01-01", "1997-01-01", "1996-05-01"),
                          ending_date = c("1996-12-31", "1997-02-01", "1997-03-01", "1997-04-05")),
                     row.names = c(NA, -4L), class = c("tbl_df", "tbl", "data.frame"))

  job1 <- create_id_overlap.table(input, from = "1996-11-01", to = "1997-11-01", overlap = "start")

  ref1 <- structure(list(ID = c("A", "B"),
                         starting_date = c("1997-01-01", "1997-01-01"),
                         ending_date = c("1997-02-01", "1997-03-01")),
                    row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame"))

  expect_equal(job1, ref1)

})

