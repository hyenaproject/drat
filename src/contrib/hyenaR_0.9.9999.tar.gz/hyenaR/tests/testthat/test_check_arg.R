context("Test check_function_arg. functions")

test_that("check_function_arg.period works as intended", {

  expect_error(check_function_arg.period("90"))

  ref <- new("Period", .Data = 0, year = 0, month = 0, day = 90, hour = 0, minute = 0)
  job <- check_function_arg.period("90 days")

  expect_equal(ref, job)
})


test_that("check_function_arg.filiation works as intended", {

  expect_error(check_function_arg.filiation("social"))

  ref <- c("mother_social", "mother_genetic")
  job <- check_function_arg.filiation(c("mother_social", "mother_genetic"))

  expect_equal(ref, job)
})

test_that("check_function_arg.lineage works as intended", {

  expect_error(check_function_arg.lineage("mother"))

  ref <- c("mothersocial", "father")
  job <- check_function_arg.lineage(c("mothersocial", "father"))

  expect_equal(ref, job)
})

test_that("check_function_arg.date works as intended", {

  #Fails if we start with the wrong format
  expect_error(check_function_arg.date(c("19961001", "1996-05-01")))

  #Fails if wrong format occurs later
  expect_error(check_function_arg.date(c("1996-05-01", "19961001")))

  #Fails if we used two (accepted) formats
  expect_error(check_function_arg.date(c("1996-05-01", "1996/10/01")))

  #Succeeds with YYYY-MM-DD or YYYY/MM/DD
  ref <- structure(c(9617, 9770), class = "Date")
  job1 <- check_function_arg.date(c("1996-05-01", "1996-10-01"))
  job2 <- check_function_arg.date(c("1996/05/01", "1996/10/01"))
  expect_equal(ref, job1)
  expect_equal(ref, job2)

  #Succeeds with NAs
  ref3 <- structure(c(9617, NA), class = "Date")
  job3 <- check_function_arg.date(c("1996/05/01", NA))
  expect_equal(ref3, job3)

  #Fails with NULL if fill != TRUE
  expect_error(check_function_arg.date(date = NULL, fill = FALSE))

  #Fails with NULL if fill == TRUE but fill.value is NULL or incorrect
  expect_error(check_function_arg.date(date = NULL, fill = TRUE, fill.value = NULL))
  expect_error(check_function_arg.date(date = NULL, fill = TRUE, fill.value = "1900/01/01"))

  #Fills NULL if fill.value is provided
  ref4 <- as.Date("1996-04-12")
  job4 <- check_function_arg.date(date = NULL, fill = TRUE, fill.value = find_pop_date.observation.first())
  expect_equal(ref4, job4)

  })

test_that("check_function_arg.litter.ID works as intended", {
  ref <- "A-001_004"
  job <- check_function_arg.litter.ID("A-001_004")
  expect_equal(ref, job)
})

test_that("check_function_arg.litter.type works as intended", {
  ref <- list(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = c(0, 0, 0),
              social.daughters.nb = c(0, 0, 0), social.sons.nb = c(0, 0, 0), social.unknown.nb = c(0, 0, 0))
  job <- check_function_arg.litter.type(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = 0,
                                  social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0)
  expect_equal(ref, job)
})

test_that("check_function_arg.logical works as intended", {
  ref <- TRUE
  job <- check_function_arg.logical(TRUE)
  expect_equal(ref, job)
})

test_that("check_function_arg.date.fromtoat works as intended", {

  #Fails when incorrect date format is used in fromtoat
  expect_error(check_function_arg.date.fromtoat(from = "19961001", to = "1996-10-02"))
  expect_error(check_function_arg.date.fromtoat(from = "1996-10-01", to = "19961002"))
  expect_error(check_function_arg.date.fromtoat(at = "19961002"))

  #Fails when multiple (acceptable) date formats are used
  expect_error(check_function_arg.date.fromtoat(from = c("1996-10-01", "19960101"), to = "1996/10/02"))

  #Fails when from/to and at are used
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", to = "1996-05-01", at = "1997-01-01"))
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", at = "1997-01-01"))
  expect_error(check_function_arg.date.fromtoat(to = "1997-10-01", at = "1997-01-01"))

  #Fails when from !<= to
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", to = "1996-05-01"))

  #at returns equal values
  ref1 <- structure(as.list(structure(c(9770, 9770), class = "Date")), names = c("from", "to"))
  job1 <- check_function_arg.date.fromtoat(at = "1996-10-01")
  expect_equal(ref1, job1)

  #from/to return different values
  ref2 <- structure(as.list(structure(c(9617, 9770), class = "Date")), names = c("from", "to"))
  job2 <- check_function_arg.date.fromtoat(from = "1996-05-01", to = "1996-10-01")
  expect_equal(ref2, job2)

  #Fill values when from or to are not provided with min/max values
  ref3 <- list(from = structure(9598, class = "Date"), to = structure(10225, class = "Date"))
  job3 <- check_function_arg.date.fromtoat(fill = TRUE,
                                           max.date = find_pop_date.observation.last(),
                                           min.date = find_pop_date.observation.first())
  expect_equal(ref3, job3)

  ref4 <- list(from = structure(9862, class = "Date"), to = structure(10225, class = "Date"))
  job4 <- check_function_arg.date.fromtoat(from = "1997-01-01", fill = TRUE,
                                           max.date = find_pop_date.observation.last())
  expect_equal(ref4, job4)

  ref5 <- list(from = structure(9598, class = "Date"), to = structure(10196, class = "Date"))
  job5 <- check_function_arg.date.fromtoat(to = "1997-12-01", fill = TRUE,
                                           min.date = find_pop_date.observation.first())
  expect_equal(ref5, job5)

  #Fails when fill is FALSE
  expect_error(check_function_arg.date.fromtoat(fill = FALSE))

  #Fails when fill == TRUE but max/min values are incorrect
  expect_error(check_function_arg.date.fromtoat(fill = TRUE))
  expect_error(check_function_arg.date.fromtoat(from = "1997-01-01", fill = TRUE, max.date = "1900-12-01"))
  expect_error(check_function_arg.date.fromtoat(to = "1997-01-01", fill = TRUE, min.date = "1900-12-01"))

  #Allows for NAs
  check_function_arg.date.fromtoat(from = "1997/01/01", to = NA)
  check_function_arg.date.fromtoat(from = NA, to = "1997/01/01")
  check_function_arg.date.fromtoat(at = NA)

})

test_that("check_function_output works as intended", {


  ########## fetch scenario
  in_1_fetch <- tibble::tibble(ID = c("A-100", "A-100", "A-101", NA))

  out_1_fetch <- tibble::tibble(ID = c("A-100", "A-100",  "A-101", NA), ## matching different key
                            offspringID = c("A-999", "A-998", NA, "A-997"))

  expect_error(check_function_output(input.tbl = in_1_fetch,
               output.tbl = out_1_fetch,
               join.by = "ID",
               duplicates = "input",
               output.IDcolumn = "sex",
               debug = FALSE)) ## matching different key

  ###
  out_2_fetch <- tibble::tibble(ID = c("A-100", "A-100","A-101", NA),  ## matching different key (eventhoug they are simillar)
                            sex = c("Female", "Female", "Male", NA))

  expect_error(check_function_output(input.tbl = in_1_fetch,
               output.tbl = out_2_fetch,
               join.by = "ID",
               duplicates = "input",
               output.IDcolumn = "sex",
               debug = FALSE))


  ###
  out_3_fetch <- tibble::tibble(ID = c("A-100", "A-101", NA),
                            sex = c("Female", "Male", NA))


   ref1 <- c("Female", "Female", "Male", NA)
   job1 <- check_function_output(input.tbl = in_1_fetch,
                       output.tbl = out_3_fetch,
                       join.by = "ID",
                       duplicates = "input",
                       output.IDcolumn = "sex",
                       debug = FALSE)


   expect_equal(job1, ref1)

   ### create scenario // need unique input
   in_1_create <- tibble(ID = c("A-100", "A-100", "A-101", NA),
                             date = c("1999-01-01", "2001-01-01", "1999-01-01",NA))

   out_1_create <- tibble(ID = c("A-100", "A-100", "A-100", "A-101", NA),
                              date = c("1999-01-01", "2001-01-01","2001-01-01", "1999-01-01", NA),
                             offspringID = c("A-999", "A-998", "A-450", NA, NA))

   expect_error(check_function_output(input.tbl = in_1_create,
                             output.tbl = out_1_create,
                             join.by = "ID", ## duplicated ID in input.tbl
                             duplicates = "output",
                             output.IDcolumn = NULL,
                             debug = FALSE))
   ###
   ref2 <- tibble(ID = c("A-100", "A-100", "A-100", "A-101", NA),
                  date = c("1999-01-01", "2001-01-01",  "2001-01-01", "1999-01-01", NA),
                  offspringID = c("A-999", "A-998", "A-450", NA, NA))

   job2 <- check_function_output(input.tbl = in_1_create,
                        output.tbl = out_1_create,
                        join.by = c("ID", "date"), ## unique combination of ID and date
                        duplicates = "output",
                        output.IDcolumn = NULL,
                        debug = FALSE)

   expect_equal(ref2, job2)

   ## missmatches in variable types:
   in_1 <- tibble::tibble(ID = factor(c("A-100", "A-100", "A-101", NA)))
   out_1 <- tibble::tibble(ID = c("A-100", "A-101", NA))
   expect_error(check_function_output(input.tbl = in_1,
                         output.tbl = out_1,
                         join.by = "ID", ## unique combination of ID and date
                         duplicates = "input",
                         output.IDcolumn = "ID",
                         debug = FALSE))

})


test_that("check_function_arg.CPUcores works as intended", {
  expect_error(check_function_arg.CPUcores(Inf))
  expect_error(check_functiob_arg.CPUcored(NA))
  expect_equal(check_function_arg.CPUcores(2, verbose = FALSE), 2)
  expect_equal(check_function_arg.CPUcores(NULL), 1)
})


test_that("check_function_arg.verbose works as intended", {
  expect_error(check_function_arg.verbose(NA))
  expect_error(check_function_arg.verbose("bla"))
  expect_true(check_function_arg.verbose(NULL))
  expect_true(check_function_arg.verbose(TRUE))
  expect_false(check_function_arg.verbose(FALSE))
})

test_that("check_function_arg.lifestage works as intended", {

  #Works with regular life stages and allows for multiple life stages by default
  ref1 <- c("cub", "subadult")
  job1 <- check_function_arg.lifestage(c("cub", "subadult"))
  expect_equal(ref1, job1)

  #Fills in all life stages except dead when fill = TRUE and fill.dead = FALSE
  ref2 <- c("cub", "subadult", "natal", "philopatric", "disperser", "transient",
           "unknown", "immigrant", "selector_2", "selector_3", "selector_4",
           "selector_5")
  job2 <- check_function_arg.lifestage(fill = TRUE, fill.dead = FALSE)
  expect_equal(ref2, job2)

  #Fills in all life stages and dead when fill = TRUE and fill.dead = TRUE
  ref3 <- c("cub", "subadult", "natal", "philopatric", "disperser", "transient",
            "unknown", "immigrant", "selector_2", "selector_3", "selector_4",
            "selector_5", "dead")
  job3 <- check_function_arg.lifestage(fill = TRUE, fill.dead = TRUE)
  expect_equal(ref3, job3)

  #Negates a single lifestage when using !
  ref4 <- c("cub", "disperser", "immigrant", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "subadult", "transient",
            "unknown")
  job4 <- check_function_arg.lifestage(lifestage = "!dead")
  expect_equal(ref4, job4)

  #Negates multiple lifestages using !
  ref5 <- c("disperser", "immigrant", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "subadult", "transient",
            "unknown")
  job5 <- check_function_arg.lifestage(lifestage = c("!dead", "!cub"))
  expect_equal(ref5, job5)

  #Recodes meta-lifestages correctly
  ref6 <- c("disperser", "immigrant", "philopatric", "selector_2", "selector_3",
            "selector_4", "selector_5")
  job6 <- check_function_arg.lifestage(lifestage = "selector")
  expect_equal(ref6, job6)

  #Negates meta-lifestages correctly
  ref7 <- c("cub", "dead", "natal", "subadult", "transient", "unknown")
  job7 <- check_function_arg.lifestage(lifestage = "!selector")
  expect_equal(ref7, job7)

  #Order of lifestage output is alphabetical
  job8  <- check_function_arg.lifestage(lifestage = c("philopatric", "disperser"))
  job9  <- check_function_arg.lifestage(lifestage = c("disperser", "philopatric"))
  job10 <- check_function_arg.lifestage(lifestage = c("!cub", "!subadult", "!natal", "!transient",
                                                      "!unknown", "!immigrant", "!selector_2", "!selector_3", "!selector_4",
                                                      "!selector_5", "!dead"))
  expect_identical(job8, job9, job10)

  #Fails when too many life stages are provided
  expect_error(check_function_arg.lifestage(lifestage = c("cub", "subadult"), arg.max.length = 1))

  #Fails when incorrect life stages are given
  expect_error(check_function_arg.lifestage(lifestage = "wrong!"))

  #Fails when trying to negate and add at the same time
  expect_error(check_function_arg.lifestage(lifestage = c("!dead", "adult")))

  #Fails when no lifestage are provided and fill = FALSE
  expect_error(check_function_arg.lifestage(lifestage = NULL, fill = FALSE))

})
