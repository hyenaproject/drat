context("Test recode_xxx functions")

test_that("recode_offspring.sex_litter.type returns an output of the correct class", {
  expect_equal(class(recode_offspring.sex_litter.type(1, 1, 1, 1, 1, 1)), "character")
})

test_that("recode_offspring.sex_litter.type returns the correct output", {
  ref <- list(daughters.nb = 1, sons.nb = 1, unknown.nb = 1, social.daughters.nb = 1, social.sons.nb = 1, social.unknown.nb = 1)
  job <- check_function_arg.litter.type(1, 1, 1, 1, 1, 1)
  expect_equal(ref, job)
})

test_that("recode_lifestage_meta.to.raw returns the correct output", {
  ref1 <- c("natal", "philopatric", "disperser", "transient", "immigrant",
            "selector_2", "selector_3", "selector_4", "selector_5")
  job1 <- recode_lifestage_meta.to.raw("adult")
  expect_identical(ref1, job1)

  ref2 <- c("philopatric", "disperser", "immigrant", "selector_2", "selector_3",
            "selector_4", "selector_5")
  job2 <- recode_lifestage_meta.to.raw("selector")
  expect_identical(ref2, job2)
})
