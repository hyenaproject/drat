library(testthat)
library(hyenaR)

test_check("hyenaR", stop_on_warning = FALSE)
warnings()
