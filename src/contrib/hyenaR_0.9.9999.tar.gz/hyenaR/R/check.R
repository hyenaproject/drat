#' Internal functions to check for expected conditions inside other functions
#'
#' ```check_function_xxx``` functions are used to check that
#' users have provided allowable argument values to a function. ```check_database_xxx```
#' functions are used to check for any data discrepancies during the process of
#' database building.
#'
#' @inheritParams arguments
#' @name check_family
#' @aliases check_family check
#'
#' @examples
#' ## Load the dummy dataset:
#' load_package_database.dummy()
NULL


#' @describeIn check_family Check the argument 'clan'
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.clan(c("A", "L"))
#' check_function_arg.clan(fill = TRUE)
check_function_arg.clan <- function(clan = NULL, strict = TRUE, fill = FALSE, main.clans = FALSE, full.clan.names = FALSE, input.unique = FALSE) {

  main.clans      <- check_function_arg.logical(main.clans)
  possible_clans <- find_clan_name.all(main.clans = main.clans, full.clan.names = full.clan.names)

  if (is.null(clan)) {
    if (fill) return(possible_clans)
    stop("The argument 'clan' has not been defined.")
  } else {
    if (any(!clan[!is.na(clan)] %in% possible_clans)) {
      if (strict) {
        stop(paste(c("The argument 'clan' contains clan(s) not corresponding to possible ones:",
                   unique(clan[!is.na(clan) & !clan %in% possible_clans])), collapse = " "))
      } else {
        warning("Clan(s) not corresponding to possible ones have been dropped.")
        clan <- clan[clan %in% possible_clans]
      }
    }
    if (input.unique & (length(unique(clan)) < length(clan))) {
      stop("Expecting unique clanIDs. Please remove any duplicates.")
    }
  }
  clan
}


#' @describeIn check_family Check the argument 'column' for extraction in the table hyenas.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.column("sex", tbl.name = "hyenas")
check_function_arg.column <- function(column, tbl.name) {
  if (length(column) != 1) {
    stop("The argument 'column' should be of length 1.")
  }
  if (length(tbl.name) != 1) {
    stop("The argument 'tbl.name' should be of length 1.")
  }
  tbl <- extract_database_table(tbl.names = tbl.name)
  if (!column %in% colnames(tbl)) {
    stop("The argument 'column' does not correspond to a column name!")
  }
  column
}



#' @describeIn check_family Check arguments 'date'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.date("1996/12/21")
check_function_arg.date <- function(date, argument.name = "date", arg.max.length = Inf,
                                    fill = FALSE, fill.value = NULL) {

  if (is.null(date)) {

    if (fill) {

      if (is.null(fill.value)) {

        stop("When `fill` is TRUE a date must be provided using `fill.value`")

      } else {

        date <- Recall(fill.value, argument.name = "fill.value", arg.max.length = 1)

      }

    } else {

      stop("Some dates have not been defined.")

    }

  }

  if (length(date) > arg.max.length) {

    stop(paste("The function you are using can only handle", arg.max.length, "date(s)"))

  }

  error_msg <- paste0("The argument '", argument.name, "' should use one (and only one) proper date format ('2000/02/29' or '2000-02-29').")

  ## The following catches error associated with the first element only, but this
  ## matters since the first element shapes the formatting of all elements:
  raw_date <- date ## for backup

  date <- tryCatch(as.Date(date), error = function(cond) {
    stop(error_msg)
  })

  ## The following catches all remaining errors:
  if (!all(is.na(raw_date[is.na(date)]))) { ## since as.Date only test the format of the first element, other element my have been turned into NAs even if the date is not NA
    stop(error_msg)
  }

  date_no_NA <- date[!is.na(date)]

  if (any(date_no_NA < find_pop_date.birth.first()) || any(date_no_NA > find_pop_date.observation.last())) {
    stop(paste0("The argument '", argument.name, "' is incorrect. All dates should be between ",
               find_pop_date.birth.first(), " (the earliest birthdate in the data) and ", find_pop_date.observation.last(),
               " (the last sighting date in the data)."))
  }

  date

}


#' @describeIn check_family Check arguments 'duration'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.duration(10)
#' check_function_arg.duration(lubridate::duration(10, "year"))
check_function_arg.duration <- function(duration) {
  if (missing(duration) | is.null(duration) | !class(duration) %in% c("numeric", "Duration")) {
    stop("The argument 'duration' has not been defined.")
  }
  duration
}


#' @describeIn check_family Check the argument 'overlap', it should always be
#' used with argument describing time window (e.g. 'from' , 'to')
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.overlap("start")

check_function_arg.overlap <- function(overlap = NULL) {
  if (length(overlap) != 1) {
    stop("The argument 'overlap' should be of length 1.")
  }
  if (is.null(overlap)) {
    stop("The argument 'overlap' has not been defined.")
  }
  possible <- c("start", "end", "within", "always", "birth", "any")
  if (!overlap %in% possible) {
    stop(paste(c("The argument 'overlap' should one of:\n ", paste0("'", possible, "' ")), collapse = ""))
  }
  overlap
}


#' @describeIn check_family Check arguments 'filiation'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.filiation("mother_social")
check_function_arg.filiation <- function(filiation) {
  possible_filiation <- c("mother_social", "mother_genetic", "mother_social_genetic", "father")
  if (missing(filiation) || is.null(filiation) ||
      class(filiation) != "character" || !all(filiation %in% possible_filiation)) {
    stop("The argument 'filiation' has not been set correctly. It must be: 'mother_social', 'mother_genetic', 'mother_social_genetic', 'father', or a combination of those.")
  }
  filiation
}

#' @describeIn check_family Check the argument 'ID'
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.ID("A-001")
#' check_function_arg.ID(fill = TRUE)


check_function_arg.ID <- function(ID = NULL, strict = TRUE, fill = FALSE, arg.max.length = Inf) {

  possible_IDs <- sort(extract_database_table("hyenas")$ID)

  if (is.null(ID)) {
    if (fill) return(possible_IDs)
    stop("The argument 'ID' has not been defined.")
  }

  if (is.list(ID)) {
      stop("The function you are using cannot take list of list-column as an input for IDs. Perhaps you need to unnest first.")
  }

  if (length(ID) > arg.max.length) {
      stop(paste("The function you are using can only handle", arg.max.length, "ID(s)"))
  }

  not_existing <- ID[!is.na(ID) & !ID %in% possible_IDs]

  if (length(not_existing) > 0) {

    if (strict) {
        stop(paste("The argument 'ID' contains ID(s) not corresponding to possible ones:", paste(not_existing, collapse = " ")))
     }

    warning("ID(s) not corresponding to possible ones have been dropped.")
    ID <- ID[ID %in% possible_IDs]
  }

  ID
}


#' @describeIn check_family Check the argument corresponding to folder paths
#' @export
#' @examples
#' check_function_arg.path("~/Download")
check_function_arg.path <- function(path, mustWork = FALSE) {
  path <- normalizePath(path, mustWork = mustWork)
  path
}


#' @describeIn check_family Check the argument 'period'
#' @export
#' @examples
#' check_function_arg.period("90 days")
check_function_arg.period <- function(period, null.ok = FALSE, coerce = TRUE){

  if (null.ok && is.null(period)) {
    return(NULL)
  }

  error_msg <- "The argument 'period' is incorrect, it should be of the same format as e.g. '10 days', '2 weeks', etc."

  ## missing test:
  if (missing(period) || is.null(period)) {
    stop(error_msg)
  }

  ## class test:
  if (!class(period)[1] %in% c("character", "Period")) {
    stop(error_msg)
  }

  ## lubridate test:

  test_lubridate_OK <- !is.na(lubridate::as.period(period))

  if (!all(test_lubridate_OK)) {
    stop(error_msg)
  }

  ## base test: (we need it because lubridate does strange things with some input, e.g. lubridate::as.period("1 dys"))
  test_base_OK <- tryCatch(all(sapply(period, function(p) length(seq.Date(from = as.Date("1900/01/01"),
                                        to = as.Date("1900/01/02"),
                                        by = p))) > 0), error = function(e) FALSE)

  if (lubridate::as.period(period) != 0 && !test_base_OK) {
    ## Note R base does not handle period of 0 but we use that in the package,
    ## so we skip the base test for such a case.
    stop(error_msg)
  }

  ## Only coerce if needed and output:
  if (!coerce) {
    return(period) ## do not coerce to period for compatibility with both base R and lubridate!
  }

  lubridate::as.period(period)
}

#' @describeIn check_family Check the argument 'lifestage'
#' @export
#' @examples
#' check_function_arg.lifestage("philopatric")
check_function_arg.lifestage <- function(lifestage = NULL, fill = FALSE, fill.dead = FALSE, arg.max.length = Inf) {

  ###Define possible lifestage and meta-lifestage values###
  #raw is the values that correspond to the 'life_stage' column in create_id_life.history.table
  #meta are lifestage arguments that correspond to multiple actual lifestages (e.g. adult != cub & subadult)
  raw_lifestage      <- c("cub", "subadult", "natal", "philopatric", "disperser", "transient", "unknown", "immigrant",
                          paste0("selector_", 2:5), "dead")
  meta_lifestage     <- c("adult", "selector")
  possible_lifestage <- c(raw_lifestage, meta_lifestage)

  ###Fill in NULL if required###
  #Do this first. No need to check other statements if lifestage = NULL
  if (is.null(lifestage)) {
    if (fill && arg.max.length == Inf) {
      #If the user wants to fill they have to specify that they want to fill 'dead'
      if (fill.dead) {
        return(raw_lifestage)
      } else {
        return(setdiff(raw_lifestage, "dead"))
      }
    }
    stop("The argument 'lifestage' has not been defined.")
  }

  ###Save the user input to create informative error message below###
  input_lifestage <- lifestage

  ###Determine if we are adding or negating lifestages###
  if (any(stringr::str_detect(lifestage, pattern = "^!"))) {

    if (!all(stringr::str_detect(lifestage, pattern = "^!"))) {
      stop("Lifestage accepts either a vector of lifestages to include or to negate (using '!'), not both.")
    }

    #Specify that we want to negate rather than add lifestages
    negate <- TRUE

    #Remove ! from lifestages now, we can work with them the same way for either negation or addition cases
    lifestage <- stringr::str_remove(lifestage, "!")

  } else {

    negate <- FALSE

  }

  ###Check that all lifestages are possible###
  if (any(!lifestage[!is.na(lifestage)] %in% possible_lifestage)) {
    stop(paste0(c("The argument 'lifestage' contains values not corresponding to possible ones: ",
                 crayon::yellow(paste(unique(lifestage[!is.na(lifestage) & !lifestage %in% possible_lifestage]), collapse = ", ")),
                 "\n Please choose from: ", crayon::yellow(paste(possible_lifestage, collapse = ", ")))))
  }

  ###Recode meta-lifestages to raw lifestages###
  #Made this a separate function to allow us to cleanly add new meta-lifestages later
  lifestage <- recode_lifestage_meta.to.raw(lifestage)

  ###Apply negation of necessary###
  if (negate) {
    lifestage <- setdiff(raw_lifestage, lifestage)
  }

  ###Check argument length###
  if (length(lifestage) > arg.max.length) {
    stop(paste0("The function you are using can only handle ", arg.max.length, " life stage(s). \n You have provided: ", crayon::yellow(paste(input_lifestage, collapse = ", ")),
                "\n This corresponds to the actual lifestages: ", crayon::yellow(paste(lifestage, collapse = ", "))))
  }

  lifestage[order(lifestage)]

}

#' @describeIn check_family Check any logical argument
#' @export
#' @examples
#' check_function_arg.logical(TRUE)
check_function_arg.logical <- function(logical) {
  if (!is.logical(logical)) {
    stop("The argument 'logical' is incorrect, it should be TRUE or FALSE")
  }

  logical
}


#' @describeIn check_family Check the argument 'unit'
#' @export
#' @examples
#' check_function_arg.unit(c("day", "days", "week", "weeks"))
check_function_arg.unit <- function(unit, arg.max.length = Inf) {
  if (length(unit) > arg.max.length) {
    stop(paste("The function you are using can only handle", arg.max.length, "unit(s)"))
  }
  unit %>% purrr::map_chr(~ case_when(
    .x == "days" ~ "day",
    .x == "weeks" ~ "week",
    .x == "months" ~ "month",
    .x == "years" ~ "year",
    TRUE ~ .x
  )) -> unit

  if (!all(unit %in% c("day", "week", "month", "year"))) {
    stop("The argument(s) 'unit' must be 'day', 'week', 'month', or 'year'!")
  }
  unit
}


#' @describeIn check_family Check if the database is loaded and if it is the dummy one
#'
#' This function should not be directly used by the user.
#'
#' Note for developers: this function triggers an error with an informative
#' message if there is no loaded database. It also displays a message if the
#' dummy database is the one that has been loaded by [load_package_database.dummy].
#'
#' @return This function returns nothing directly.
#' @export
#'
#' @seealso [load_package_database.dummy]
#'
#' @examples
#' check_database_is.loaded()
check_database_is.loaded <- function() {
  if (!exists(".database")) {
    stop("No loaded database. See ?load_package_database")
  }

  if (attr(.database, "dummy")) {
    message("Using the dummy dataset!")
  }

  invisible(NULL)

}

#' @describeIn check_family Check for errors in the database
#'
#' Check for integrity in the data/missing information including:
#' - All individuals die after being born
#' - All individuals give birth after 1yo
#' - All mothers/fathers are female/male
#'
#' @return A boolean (has the database passed all tests)
#' @export
#' @examples
#'
#' # Check dummy database
#' # check_database_is.correct()

check_database_is.correct <- function(debug = FALSE) {

  # Extract all records for every existing individual
  # Do this first so it only needs to be done once.
  all_indv <- create_id_starting.table() %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID),
                  birthdate = fetch_id_date.birth(.data$ID),
                  deathdate = fetch_id_date.death(.data$ID),
                  surv = is.na(.data$deathdate),
                  mothergenetic = fetch_id_id.mother.genetic(.data$ID),
                  father = fetch_id_id.father(.data$ID))

  ################################
  # TEST: Birth is before death #
  ################################

  # Test to see if all individuals have a death date after their birth date
  flawed_deaths <- all_indv[!all_indv$surv & lubridate::ymd(all_indv$birthdate) > lubridate::ymd(all_indv$deathdate), ]

  number_flawed_deaths <- nrow(flawed_deaths)

  ###################################
  # TEST: Parents have correct sex #
  ###################################

  # Extract all individuals with a known mother
  flawed_maternity <- all_indv %>%
    filter(!is.na(.data$mothergenetic)) %>%
    # Check that mother is female
    mutate(mothersex = fetch_id_sex(ID = .data$mothergenetic),
           motherIsF = is.na(.data$mothersex) | .data$mothersex == "female") %>%
    filter(!.data$motherIsF)

  number_flawed_maternity <- nrow(flawed_maternity)

  # Extract all individuals with a known father
  flawed_paternity <- all_indv %>%
    filter(!is.na(.data$father)) %>%
    # Check that father is male
    mutate(fathersex = fetch_id_sex(ID = .data$father),
           fatherIsM = is.na(.data$fathersex) | .data$fathersex == "male") %>%
    filter(!.data$fatherIsM)

  number_flawed_paternity <- nrow(flawed_paternity)

  ################################
  # OUTPUT ALL INTEGRITY RESULTS #
  ################################

  tibble::tibble(
    integrity_issue = c("Flawed_death", "Flawed_maternity", "Flawed_paternity"),
    total_number = c(number_flawed_deaths, number_flawed_maternity, number_flawed_paternity),
    details = list(flawed_deaths, flawed_maternity, flawed_paternity)
  ) -> output

  if (debug) {
    message(paste("Individuals with death before birth:", number_flawed_deaths))
    message(paste("Males assigned as mothers:", number_flawed_maternity))
    message(paste("Females assigned as mothers:", number_flawed_paternity))
    message("See output for more details.")

    return(output)

  }

  all(output$total_number == 0)

}

#' @describeIn check_family Check that the arguments have the same length.
#'
#' @export
#' @examples
#' check_function_arg.litter.type(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = 0,
#' social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0)
#'
check_function_arg.litter.type <- function(daughters.nb, sons.nb, unknown.nb, social.daughters.nb, social.sons.nb, social.unknown.nb) {
  length_daughters.nb  <- ifelse(length(daughters.nb) == 1 && daughters.nb == 0, 0, length(daughters.nb))
  length_sons.nb    <- ifelse(length(sons.nb) == 1 && sons.nb == 0, 0, length(sons.nb))
  length_unknown.nb <- ifelse(length(unknown.nb) == 1 && unknown.nb == 0, 0, length(unknown.nb))
  length_social.daughters.nb <- ifelse(length(social.daughters.nb) == 1 && social.daughters.nb == 0, 0, length(social.daughters.nb))
  length_social.sons.nb <- ifelse(length(social.sons.nb) == 1 && social.sons.nb == 0, 0, length(social.sons.nb))
  length_social.unknown.nb <- ifelse(length(social.unknown.nb) == 1 && social.unknown.nb == 0, 0, length(social.unknown.nb))
  lengths <- unique(c(length_daughters.nb, length_sons.nb, length_unknown.nb, length_social.daughters.nb, length_social.sons.nb,
                      length_social.unknown.nb))
  lengths <- lengths[lengths != 0]
  ## check that lengths are good:
  if (length(lengths) > 1) {
    stop("recode_offspring.sex_litter.type needs arguments of same length or of value 0")
  }
  ## replicate 0 if needed:
  if (length(lengths) == 1) { ## don't do anything if only 0s
    if (length_daughters.nb == 0) daughters.nb <- rep(0, lengths)
    if (length_sons.nb == 0) sons.nb <- rep(0, lengths)
    if (length_unknown.nb == 0) unknown.nb <- rep(0, lengths)
    if (length_social.daughters.nb == 0) social.daughters.nb <- rep(0, lengths)
    if (length_social.sons.nb == 0) social.sons.nb <- rep(0, lengths)
    if (length_social.unknown.nb == 0) social.unknown.nb <- rep(0, lengths)
  }
  list(daughters.nb = daughters.nb, sons.nb = sons.nb, unknown.nb = unknown.nb, social.daughters.nb = social.daughters.nb, social.sons.nb = social.sons.nb, social.unknown.nb = social.unknown.nb)
}

#' @describeIn check_family Check that litter argument is correct.
#'
#' @export
#' @examples
#' check_function_arg.litter.ID(litterID = "A-001_004")
#' check_function_arg.litter.ID(fill = TRUE)
#'
check_function_arg.litter.ID <- function(litterID = NULL, strict = TRUE, fill = FALSE) {

  possible_litters <- find_pop_litterID(main.clans = FALSE)

  if (is.null(litterID)) {
    if (fill) return(possible_litters)
    stop("The argument 'litter' has not been defined.")
  } else {
    if (any(!litterID[!is.na(litterID)] %in% possible_litters)) {
      if (strict) {
        stop("The argument 'litter' contains litterID(s) not corresponding to possible ones.")
      } else {
        warning("litterID(s) not corresponding to possible ones have been dropped.")
        litterID <- litterID[litterID %in% possible_litters]
      }
    }
  }
if (length(litterID) == 0) {
    return(NA_character_)
}
litterID
}

#' @describeIn check_family Check arguments 'from', 'to', 'at'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' #Check when both from and to are provided
#' check_function_arg.date.fromtoat(from = "1996/12/21", to = "1997/12/21")
#'
#' #When either from or to are not provided, they can be filled
#' #using arguments fill, min.date and max.date
#' check_function_arg.date.fromtoat(to = "1997/12/21", fill = TRUE,
#'                                  min.date = "1997-01-01")
#' check_function_arg.date.fromtoat(from = "1997/01/21", fill = TRUE,
#'                                  max.date = "1997-12-01")
#'
#' #When at is provided, from/to have the same value
#' check_function_arg.date.fromtoat(at = "1997/12/21")
#'
#' #from/to and at cannot be provided together
#' #this will throw an error
#' #check_function_arg.date.fromtoat(from = "1995/12/21", at = "1996/12/21")

check_function_arg.date.fromtoat <- function(from = NULL, to = NULL, at = NULL,
                                             arg.max.length = Inf,
                                             fill = TRUE,
                                             min.date = NULL,
                                             max.date = NULL) {

  if (!fill) { #If we will not fill, user must provide at or from/to.

    if (any(is.null(from), is.null(to)) && is.null(at)) {
      stop("Provide either a single date using argument `at` or \n a date range by providing both arguments `from` and `to`.")

    }

  }

  #Can't use from/to and at
  if (any(!is.null(from), !is.null(to)) && !is.null(at)) {
    stop("Provide either a single date using argument `at` or \n a date range by providing one or both arguments `from` or `to`.")

  }

  if (!is.null(at)) { # from and to are the same when using at
    #at is never filled (it's unclear what it would be filled with!)
    from <- check_function_arg.date(at, argument.name = "at")
    to   <- check_function_arg.date(at, argument.name = "at")
  } else {
    from <- check_function_arg.date(from, argument.name = "from", fill = fill, fill.value = min.date)
    to   <- check_function_arg.date(to, argument.name = "to", fill = fill, fill.value = max.date)
  }

  if (length(from) > arg.max.length || length(to) > arg.max.length) {

    stop(paste("The function you are using can only handle", arg.max.length, "date(s)"))

  }

  #Allow for NAs. Only check relationship between dates when both from/to are available.
  if (any(stats::na.omit(from > to))) {

    stop("'from' date must be earlier than (or the same as) 'to' date")

  }

  list(from = from, to = to)

}


#' @describeIn check_family Check arguments 'lineage'.
#'
#' This function should not be directly used by the user.
#'
#' @export
#' @examples
#' check_function_arg.lineage("mothersocial")
#'
check_function_arg.lineage <- function(lineage) {
  possible_lineage <- c("mothersocial", "mothergenetic", "father")
  if (missing(lineage) || is.null(lineage) ||
      class(lineage) != "character" || !all(lineage %in% possible_lineage)) {
    stop("The argument 'lineage' has not been set correctly. It must be: 'mothersocial', 'mothergenetic' or 'father'")
  }
  lineage
}

#' @describeIn check_family Check that sightings, selections and hyena tables are all consistent
#'
#' Use to check database tables before database is built.
#' Run within [build_package_database.full()].
#'
#' @return A boolean. Does every individual have a full record (TRUE/FALSE).

check_database_has.full.records <- function(hyenas.tbl, sightings.tbl, selections.tbl) {

  ## Old name
  #full_record_check

  message("Checking that all individuals have full records in hyenas, sightings and selections...")

  names_selections <- stringr::str_trim(unique(selections.tbl$ID)[!is.na(unique(selections.tbl$ID)) & unique(selections.tbl$ID) != ""])
  names_sightings  <- stringr::str_trim(unique(sightings.tbl$ID)[!is.na(unique(sightings.tbl$ID)) & unique(sightings.tbl$ID) != ""])
  names_hyenas     <- stringr::str_trim(unique(hyenas.tbl$ID)[!is.na(unique(hyenas.tbl$ID)) & unique(hyenas.tbl$ID) != ""])

  # Check that any time there is a recorded selection that the individual must have a hyena and sightings record
  correct_selections_hyena     <- names_selections %in% names_hyenas
  correct_selections_sightings <- names_selections %in% names_sightings

  # Check that any time there is a recorded sighting that the individual must have a hyena record.
  correct_sightings <- names_sightings %in% names_hyenas

  # Check that anything in hyenas is also in sightings
  correct_hyenas <- names_hyenas %in% names_sightings

  if (all(correct_selections_hyena) && all(correct_selections_sightings) && all(correct_sightings)) {
    message("All individuals have full records!")
    return(TRUE)
  } else {
    bad_records <- bind_rows(
      tibble::tibble(ID = names_selections[!correct_selections_hyena], table1 = "selections", table2 = "hyenas"),
      tibble::tibble(ID = names_selections[!correct_selections_sightings], table1 = "selections", table2 = "sightings"),
      tibble::tibble(ID = names_sightings[!correct_sightings], table1 = "sightings", table2 = "hyenas"),
      tibble::tibble(ID = names_hyenas[!correct_hyenas], table1 = "hyenas", table2 = "sightings")
    ) %>%
      dplyr::filter(!is.na(.data$ID))


    purrr::pwalk(
      .l = list(ID = bad_records$ID, table1 = bad_records$table1, table2 = bad_records$table2),
      .f = function(ID, table1, table2) {
        message(glue::glue("'{ID}' has a record in {table1} but not in {table2}!"))
      }
    )

    warning("There seem to be issues! Please ask Oliver to check and fix the above records, re-download the files, and rebuild the database.")
  }
  return(FALSE)
}

#' @describeIn check_family Check output of functions.
#'
#' This function should not be directly used by the user.
#' @export
#' @examples
#' input.tbl <- data.frame(ID = c("A-100", "A-100", "A-101", NA))
#'
#' output.tbl <- data.frame(ID = c("A-100", "A-101", NA),
#'                           sex = c("Female", "Male", NA))
#'
#' check_function_output(input.tbl = input.tbl,
#'              output.tbl = output.tbl,
#'              join.by = "ID",
#'              duplicates = "input",
#'              output.IDcolumn = "sex",
#'              debug = FALSE)
#'
check_function_output <- function(input.tbl,
                         output.tbl,
                         join.by,
                         duplicates = "input",
                         output.IDcolumn = NULL,
                         debug = FALSE) {

  ## check input format
  input.tbl <- check_function_arg.tbl(input.tbl)
  output.tbl <- check_function_arg.tbl(output.tbl)
  duplicates <- check_function_arg.duplicates(duplicates)

  ## by input must be named:
  if (is.null(names(join.by))) {
    names(join.by) <- join.by
  }

    ## check the debug
  if (debug) output.IDcolumn <- NULL

  ## compute name of surrounding function:
  fun_name <- as.character(sys.call(1L))[[1]]

  ## trim inputs:
  input <- input.tbl[, names(join.by), drop = FALSE]
  output <- output.tbl[, join.by, drop = FALSE]

  ## check for duplicates:

  # input
  duplicates_in_input <- nrow(unique(input)) < nrow(input)
  if (!(duplicates == "input") && duplicates_in_input) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated input!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  # output
  duplicates_in_output <- nrow(unique(output)) < nrow(output)
  if (!(duplicates == "output") && duplicates_in_output) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated output!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  # both
  if ((duplicates == "none") && (duplicates_in_input || duplicates_in_output)) {
    stop(paste0("Internal issue detected by check_output:\nDuplicated output or input!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  ## actual join job (left join to keep all the input IDs):
   out_temp <- dplyr::left_join(input.tbl, output.tbl, by = join.by)

  ## check that the row order and length are correct:
  ref_input <- input[, names(join.by)]
  ref_output <- out_temp[, names(join.by)] ## select only the matching col of the temp_output
  ## Here we use drop for finner test of factors in case of single variables

  if (duplicates == "output") { ## rep output not input
    ref_output <- unique(ref_output) ## reduce the output to check if the order and length match the unduplicated input
  }

  ## compare variable class:
  types_in_ref_input <- sapply(ref_input, class)
  types_in_ref_output <- sapply(ref_output, class)

  if (!all(types_in_ref_input == types_in_ref_output)) {
    stop(paste0("Internal inconsistency detected by check_output:\nThe objects ref_input and not ref_output have missmatches in variable class (probably caused by a wrong usage of factors)!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  if (!(identical(ref_input, ref_output))) { ## check that the input and ouptut are correct
    stop(paste0("Internal inconsistency detected by check_output:\nDiscrepancy in row order/length between ref_input and ref_output!\nCalled by ", fun_name, ".\nPlease contact the devel team!"))
  }

  ## rename columns as in output table:
  colnames(out_temp)[match(names(join.by), colnames(out_temp))] <- join.by

  ## trim output with selected columns:
  if (is.null(output.IDcolumn)) {
    output.IDcolumn <- colnames(out_temp)
  }

   out_temp[, output.IDcolumn, drop = TRUE]
}

#' @describeIn check_family Check arguments 'tbl'.
#' @export
#' @examples
#' check_function_arg.tbl(data.frame(ID = c("A-100", "A-100", "A-101", NA)))
check_function_arg.tbl <- function(tbl){

  if (!any(class(tbl) %in% c("data.frame", "tbl_df", "tbl"))) {
    stop(paste0("One of the arguments you are using is of the wrong class, it must be a tibble or a data.frame"))
 }

  if (!any("tbl_df" %in% class(tbl))) {
    tbl <- tibble::as_tibble(tbl)
  }
  tbl
}

#' @describeIn check_family Check arguments 'duplicates'.
#' @export
#' @examples
#' check_function_arg.duplicates("input")
check_function_arg.duplicates <- function(duplicates) {
  possible_arg <- c("input", "output", "none")
  if (missing(duplicates) || is.null(duplicates) ||
      class(duplicates) != "character" || length(duplicates) > 1 || !(duplicates %in% possible_arg)) {
    stop("The argument 'lineage' has not been set correctly. It must be: 'input', 'output' or 'none', exclusively")
  }
  duplicates
}


#' @describeIn check_family Check arguments 'verbose'.
#' @export
#' @examples
#' check_function_arg.verbose(TRUE)
#' check_function_arg.verbose(FALSE)
#' check_function_arg.verbose(NULL)
#'
check_function_arg.verbose <- function(verbose) {
  if (!is.null(verbose) && (!is.logical(verbose) || is.na(verbose))) {
    stop("The verbose argument of the function should be NULL, TRUE or FALSE")
  }
  if (is.null(verbose)) {
    verbose <- getOption("hyenaR_verbose")
  }
  verbose
}


#' @describeIn check_family Check arguments 'CPUcores'.
#' @export
#' @examples
#' check_function_arg.CPUcores(2)
#' check_function_arg.CPUcores(NULL)
#'
check_function_arg.CPUcores <- function(CPUcores, verbose = NULL) {

  verbose <- check_function_arg.verbose(verbose)

  if (!is.null(CPUcores) && !is.numeric(CPUcores)) {
    stop("The CPUcores argument of the function should be NULL, or a number")
  }
  if (is.null(CPUcores)) {
    CPUcores <- getOption("hyenaR_CPUcores")
  }
  CPUcores <- floor(CPUcores)  ## in case users give floating numbers...
  max_cpu <- parallel::detectCores()
  if (CPUcores > max_cpu) {
    stop(paste0("The CPUcores argument of the function should not be greater than the number of CPU cores available on your system (", max_cpu, ")"))
  }
  if (verbose && CPUcores < max_cpu && !.hyenaR$flag_CPUcores) {
    .hyenaR$flag_CPUcores <- TRUE
    message(paste0("The CPUcores argument of the function could be greater than what you are currently using since the number of CPU cores available on your system is ",
                  max_cpu,
                  ".\nYou can set the number of CPU cores to use in the entire package by setting \n'options(hyenaR_CPUcores = xx)', with 'xx' the number of CPU cores to use. ",
                  "\nNote: this message will only be displayed once per session.\n"))
  }
  CPUcores
}


#' @describeIn check_family Check if arguments is a character.
#' @export
#' @examples
#' check_function_class.is.character("bla")
#' check_function_class.is.character()
check_function_class.is.character <- function(character) {
## this function allows for testing even if the variable does not exist, which is the case is the argument is a placeholder for a column in the table...
  tryCatch(is.character(character), error = function(e) FALSE)
}

#' @describeIn check_family Check argument 'sex'.
#' @export
#' @examples
#' check_function_class.is.character("male")
check_function_arg.sex <- function(sex, fill = TRUE) {

  possible_sex <- c("male", "female", NA_character_)

  check_function_class.is.character(sex)

  if (is.null(sex)) {
    if (fill) {
      sex <- possible_sex
    } else {
      stop("The argument 'sex' has not been defined.")
    }
  } else {
    if (any(!sex[!is.na(sex)] %in% possible_sex)) {
      stop("The argument 'sex' can only contain 'male', 'female', and NA (for unknown sex).")
    }
  }

  sex

}
