#' Find individuals
#'
#' The functions described here all return a vector of individuals
#' (ID). Here are a few thing to know about these functions:
#' - As any find function, these functions should not be use to add columns to
#' existing tables since they consider only one query at a time (they are not
#' functions of the fetch family).
#' - The core function doing the actual work is always `find_clan_id()`. You can
#' either call this core function directly and customise all its arguments, or
#' for simplicity, you can use the other functions (e.g.
#' `find_clan_id.male.all()`). These latter functions are shortcuts
#' for `find_clan_id()` where sex and lifestage are already specified.
#' Users should probably rely on these secondary functions unless they
#' want something complex which is not directly obtainable by such shortcuts
#' (such as a combination of life history stages).
#' - The secondary functions are named following the scheme
#' `find_clan_id.SEX.LIFESTAGE()` where `SEX` is a placeholder that can be
#' `male`, `female` or `anysex` (which contains males, females and individuals
#' of unknown sex) and where `LIFESTAGE` is a placeholder for `all`, `cub`,
#' `subadult`, `natal`, `adult`, `philopatric`, `immigrant`, `disperser`,
#' `transient`, `selector` or `dead`. Note that all combinations are programmed
#' even if the don't make biological sense (e.g.
#' `find_clan_id.female.transient()`).
#' - All `find_clan_xxx()` function described here have a matching
#' `find_pop_xxx()` function. The `pop` function return the individuals for all
#' clans (both crater and rim clans, default) unless the argument `main.clans` is
#' set to `TRUE`. Again, the `find_pop_xxx()` functions are shortcuts using
#' `find_clan_xxx()` behind the curtains. The benefits of using the
#' `find_pop_xxx()` functions is that you do not need to enumerate the clans.
#'- All these functions take the same arguments as
#'[`create_id_starting.table()`], so they allow for time windows specification
#'with arguments `from` and `to`, as well as overlap between the clans or
#'lifestages and the time window. For example, you can find individuals that had
#'a particular lifestage either at the beginning, at the end, or during the
#'entire time period by setting the argument `lifestage.overlap` to the
#'adequate value (see section **Arguments** below). The same is true of the
#'clan.
#'
#' @export
#' @inheritParams arguments
#' @name find_clan_id
NULL


#' @describeIn find_clan_id find individuals for given clan(s), lifestage(s) and time requirement(s)
#' @export
#' @examples
#' load_package_database.dummy()
#'
#' #### Example of find_id_clan usage:
#'
#' # find all the individuals that were born in clan A
#' find_clan_id(clan = "A")
#'
#' # find all the females that were born in clan A
#' find_clan_id(sex = "female", clan = "A")
#'
#' # find individuals that were philopatric in clan A and L on 1996-04-12
#' find_clan_id(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
#'
#' # find individuals that start their membership in clan A between 1996-04-12 and 1997-12-30
#' find_clan_id(clan = "A", from = "1996-04-12", to = "1997-12-30",
#' clan.overlap = "start")
#'
#' # find individuals in clan "A" that becomes selector for the first time
#' # between 1996-04-12 and 1997-12-30
#' find_clan_id(clan = "A",
#'              lifestage = c("philopatric", "disperser"),
#'              from = "1996-04-12", to = "1997-12-30",
#'              lifestage.overlap = "start")
#'
#' # find individuals that were philopatric in clan A for the whole period from
#' # 1996-04-12 to 1997-12-30
#' find_clan_id(clan = "A", lifestage = "philopatric",
#'              from = "1996-12-01", to = "1997-10-30", clan.overlap = "always",
#'              lifestage.overlap = "always")
#'
#' # find individuals that were present as philopatric in clan A for sometime during
#' # 1996-04-12 to 1997-12-30
#' find_clan_id(clan = "A", lifestage = "philopatric",
#'              from = "1996-04-12", to = "1997-12-30",
#'              clan.overlap = "any", lifestage.overlap = "any")
#'
#'
find_clan_id <- function(clan = NULL, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                         clan.overlap = "any", lifestage.overlap = "any", fill.dead = FALSE,
                         verbose = TRUE) {

  check_function_arg.clan(clan = clan) ## to check that a clan has been defined!

  create_id_starting.table(clan = clan, sex = sex,
                           lifestage = lifestage,
                           at = at, from = from, to = to,
                           clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                           fill.dead = fill.dead, verbose = verbose) %>%
    dplyr::pull(.data$ID) -> output


  output

}


#' @describeIn find_clan_id find all individuals, given lifestage(s) and time requirement(s)
#' @export
#' @examples
#' #### Examples of find_pop_id usage:
#'
#' find_pop_id()
#' find_pop_id(main.clans = FALSE)
#' find_pop_id(sex = "female", lifestage = "cub", at = "1997/12/01")
#'
#'
find_pop_id <- function(main.clans = FALSE, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                        clan.overlap = "any", lifestage.overlap = "any",
                        verbose = TRUE) {

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id(clan = clans, sex = sex, lifestage = lifestage, at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = clan.overlap,
               verbose = verbose)

}


#' @describeIn find_clan_id find males for given clan(s) and time requirement(s)
#' @export
#' @examples
#' #### Example of find_clan_id.male.all usage:
#'
#' # find all males of clans A and L:
#' find_clan_id.male.all(clan = c("A", "L"))
#'
#'
find_clan_id.male.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                  clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "!dead", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find males for the entire population, given time requirement(s)
#' @export
#' @examples
#' #### Example of find_pop_id.male.all usage:
#'
#' # find all males for the main clans:
#' find_pop_id.male.all()
#'
#' # find all males for the whole population:
#' find_pop_id.male.all(main.clans = FALSE)
#'
#'
find_pop_id.male.all <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                  clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.all(clan = clans, at = at, from = from, to = to,
                        clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find male cubs for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.cub<- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                 clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "cub", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find male cubs for the entire population, given time requirement(s)
#' @export
find_pop_id.male.cub <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                  clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.cub(clan = clans, at = at, from = from, to = to,
                        clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find male subadults for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.subadult<- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "subadult", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find male subadults for the entire population, given time requirement(s)
#' @export
find_pop_id.male.subadult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.subadult(clan = clans, at = at, from = from, to = to,
                             clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.natal<- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                   clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "natal", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.natal <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.natal(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adult males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "adult",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adult males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.adult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.adult(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "immigrant", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.immigrant <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.immigrant(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "philopatric", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.philopatric <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.philopatric(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "disperser", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.disperser <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.disperser(clan = clans, at = at, from = from, to = to,
                              clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male", lifestage = "transient", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.transient <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.transient(clan = clans, at = at, from = from, to = to,
                              clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector males for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "male",
               lifestage = "selector",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.selector <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.selector(clan = clans, at = at, from = from, to = to,
                             clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = NULL, at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.all <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.all(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find female cubs for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.cub <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "cub", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find female cubs for the entire population, given time requirement(s)
#' @export
find_pop_id.female.cub <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.cub(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find subadult females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.subadult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "subadult", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find female subadults for the entire population, given time requirement(s)
#' @export
find_pop_id.female.subadult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.subadult(clan = clans, at = at, from = from, to = to,
                               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.natal <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "natal", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.natal <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.natal(clan = clans, at = at, from = from, to = to,
                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adult females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "adult",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adult females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.adult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.adult(clan = clans, at = at, from = from, to = to,
                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "immigrant", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.immigrant <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.immigrant(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "philopatric", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.philopatric <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.philopatric(clan = clans, at = at, from = from, to = to,
                                  clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "disperser", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.disperser <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.disperser(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female", lifestage = "transient", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.transient <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.transient(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector females for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = "female",
               lifestage = "selector",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.selector <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.selector(clan = clans, at = at, from = from, to = to,
                               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "!dead", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.all <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.all(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find cubs of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.cub <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "cub", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find cubs of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.cub <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.cub(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find subadults of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.subadult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "subadult", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find subadults of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.subadult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.subadult(clan = clans, at = at, from = from, to = to,
                               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.natal <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "natal", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find natal individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.natal <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.natal(clan = clans, at = at, from = from, to = to,
                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adults of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "adult",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find adults of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.adult <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.adult(clan = clans, at = at, from = from, to = to,
                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant individuals for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "immigrant", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find immigrant individuals for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.immigrant <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.immigrant(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "philopatric", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find philopatric individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.philopatric <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.philopatric(clan = clans, at = at, from = from, to = to,
                                  clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "disperser", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find disperser individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.disperser <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.disperser(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL, lifestage = "transient", at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find transient individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.transient <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.transient(clan = clans, at = at, from = from, to = to,
                                clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  find_clan_id(clan = clan, sex = NULL,
               lifestage = "selector",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find selector individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.selector <-  function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any"){

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.selector(clan = clans, at = at, from = from, to = to,
                               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find dead individuals of any sex, for given clan(s) and time requirement(s)
#' @export
find_clan_id.anysex.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                     clan.overlap = "any", lifestage.overlap = "any") {

  find_clan_id(clan = clan, sex = NULL,
               lifestage = "dead",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find dead individuals of any sex for the entire population, given time requirement(s)
#' @export
find_pop_id.anysex.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any") {

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.anysex.dead(clan = clans, at = at, from = from, to = to,
                           clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}

#' @describeIn find_clan_id find dead males, for given clan(s) and time requirement(s)
#' @export
find_clan_id.male.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                   clan.overlap = "any", lifestage.overlap = "any") {

  find_clan_id(clan = clan, sex = "male",
               lifestage = "dead",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find dead males for the entire population, given time requirement(s)
#' @export
find_pop_id.male.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                  clan.overlap = "any", lifestage.overlap = "any") {

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.male.dead(clan = clans, at = at, from = from, to = to,
                         clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find dead females, for given clan(s) and time requirement(s)
#' @export
find_clan_id.female.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                     clan.overlap = "any", lifestage.overlap = "any") {

  find_clan_id(clan = clan, sex = "female",
               lifestage = "dead",
               at = at, from = from, to = to,
               clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}


#' @describeIn find_clan_id find dead females for the entire population, given time requirement(s)
#' @export
find_pop_id.female.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any") {

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  find_clan_id.female.dead(clan = clans, at = at, from = from, to = to,
                          clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap)

}
