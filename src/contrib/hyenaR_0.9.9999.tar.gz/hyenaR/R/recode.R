#' Recode vectors
#'
#' These functions allows for the recoding of vectors.
#'
#' @inheritParams arguments
#' @name recode_family
#' @aliases recode_family recode
#' @return The recoded vector.
#'
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL


#' @describeIn recode_family recode standardized ranks into categories
#'
#' Note that 0% corresponds to the top ranking individual!
#'
#' @export
#'
#' @examples
#'
#' #### Simple example of recode_rank.std_rank.cat usage:
#'
#' set.seed(1)
#' some_ranks <- seq(-1, 1, length = 10)
#' some_prob.ranks <- runif(3)
#' recode_rank.std_rank.cat(some_ranks, prob.ranks = some_prob.ranks)
#'
#' #### More realistic example of recode_rank.std_rank.cat usage:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_id_starting.table(clan = "A", at = "1997-01-01") %>%
#'     mutate(rankstd = fetch_id_rank.std(ID = ID, at = "1997-01-01"),
#'            rankstd_cat = recode_rank.std_rank.cat(rankstd, prob.ranks = c(0.25, 0.5, 0.75)))
#' }
#'
recode_rank.std_rank.cat <- function(ranks, prob.ranks = NULL, digits = 2) {

  if (is.null(prob.ranks)) {
    warning("The argument 'prob.ranks' has not been defined, so the input vector has not been recoded!")
    return(rank)
  }

  if (any((ranks[!is.na(ranks)] < -1) | (ranks[!is.na(ranks)] > 1))) {
    stop("The ranks should be standardized, that is all between -1 and 1.")
  }

  if (any((prob.ranks < 0) | (prob.ranks > 1))) {
    stop("The probabilities should be all between 0 and 1.")
  }

  ranks <- abs((ranks - 1) * 1/2)  ## to bring back ranks between 0 and 1 with 0 being to

  prob.ranks <- sort(unique(c(0, prob.ranks, 1)))

  res <- cut(ranks, breaks = prob.ranks, include.lowest = TRUE)

  levels_list <- lapply(strsplit(levels(res), ","),
                        function(str) 100*as.numeric(sub("\\[|\\(|\\]", "", str, perl = TRUE)))
  levels(res) <- unlist(lapply(levels_list,
                               function(x) paste0(signif(x[1], digits = digits), "--",
                                                  signif(x[2], digits = digits), "%")))
  as.character(res) ## convert to character in order not to get a factor
}




#' @describeIn recode_family classifies litters with a string that is a combination of "f" (= female offspring),
#' "m" (= male offspring), "u" (= offspring with unknown sex), according to the number of daughters, sons and
#' cubs with unknown sex present in the litter.
#'
#' @export
#'
#' @examples
#'
#' ### Simple example of the recode_offspring.sex_litter.type:
#'
#' daughters.nb <- c(1, 2, 1, 0)
#' sons.nb <- c(0, 0, 1, 0)
#' unknown.nb <- c(1, 1, 1, 0)
#' social.daughters.nb <- c(0, 0, 0, 0)
#' social.sons.nb <- c(1, 0, 0, 0)
#' social.unknown.nb <- c(0, 0, 0, 0)
#'
#' recode_offspring.sex_litter.type(daughters.nb,
#'                                  sons.nb,
#'                                  unknown.nb,
#'                                  social.daughters.nb,
#'                                  social.sons.nb,
#'                                  social.unknown.nb)
#'
recode_offspring.sex_litter.type <- function(daughters.nb = 0, sons.nb = 0, unknown.nb = 0, social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0) {

  args <- check_function_arg.litter.type(daughters.nb, sons.nb, unknown.nb, social.daughters.nb, social.sons.nb, social.unknown.nb)

  type <- rep(NA_character_, length(args$daughters.nb))

  for (i in seq_len(length(args$daughters.nb))) {
    type[i] <- paste(c(rep("f", args$daughters.nb[i]),
                       rep("m", args$sons.nb[i]),
                       rep("u", args$unknown.nb[i]),
                       rep("sf",args$social.daughters.nb[i]),
                       rep("sm", args$social.sons.nb[i]),
                       rep("su", args$social.unknown.nb[i])), collapse = "_")
  }

  type[type == ""] <- NA_character_

  type
}

#' @describeIn recode_family Recode between clanIDs and full clan names
#'
#' @export
#' @examples
#'
#' ### Return full clan names from clanID:
#' recode_clan_name(clan = c("A", "L"))
#'
#' ### Return clanID from full clan name
#' recode_clan_name(clan = c("AIRSTRIP", "LEMALA"))
recode_clan_name <- function(clan, verbose = TRUE){

  input        <- dplyr::tibble(clan = toupper(clan))
  messages     <- vector() ## Create an empty vector which messages are appended. Print if verbose.
  clan_details <- extract_database_table("clans") %>%
    dplyr::select(.data$clanID, .data$clanname)

  if (all(nchar(input$clan) == 1)) {

    messages <- append(messages, "Converting clanIDs to full names. \n")

    input %>%
      dplyr::mutate(clan = check_function_arg.clan(.data$clan, full.clan.names = FALSE)) %>%
      dplyr::left_join(clan_details, by = c("clan" = "clanID")) %>%
      dplyr::pull(.data$clanname) -> output

  } else {

    messages <- append(messages, "Converting full names to clanIDs. \n")

    input %>%
      dplyr::mutate(clan = check_function_arg.clan(.data$clan, full.clan.names = TRUE)) %>%
      dplyr::left_join(clan_details, by = c("clan" = "clanname")) %>%
      dplyr::pull(.data$clanID) -> output

  }

  if (any(is.na(output))) {

    messages <- append(messages, "Some clans are not identifiable. Returning NAs. \n")

  }

  if (verbose && length(messages) > 0) {

    message(messages, appendLF = FALSE)

  }

  output

}

#' Recode meta-lifestages into raw lifestages
#'
#' @param lifestage Vector of lifestage values.
#'
#' @return An expanded vector of lifestage values.
#' @export
#'
#' @examples
#' #Adult is any individuals that is not either 'cub' or 'subadult' lifestage
#' recode_lifestage_meta.to.raw("adult")
#'
#' #Selector is any sexually mature male (i.e. philopatric or dispersing males)
#' recode_lifestage_meta.to.raw("selector")

recode_lifestage_meta.to.raw <- function(lifestage) {

  raw_lifestage <- check_function_arg.lifestage(fill = TRUE, fill.dead = TRUE)

  if (any(lifestage == "selector")) {

    new_lifestages <- setdiff(raw_lifestage, c("unknown", "cub", "subadult", "transient", "natal", "dead"))
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "selector")

  }

  if (any(lifestage == "adult")) {

    new_lifestages <- setdiff(raw_lifestage, c("unknown", "cub", "subadult", "dead"))
    lifestage <- setdiff(unique(c(lifestage, new_lifestages)), "adult")

  }

  lifestage

}
