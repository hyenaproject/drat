#' Fetch information about given hyena(s)
#'
#' These functions allows for the extraction of individual-level information
#' that either remain constant for a hyena over time, or that varies. The
#' ```fetch_xxx``` functions have not been designed to be particularly
#' efficient, so they should not be used by an intensive procedures (e.g.
#' simulations). Instead they have been designed to be particularly robust so
#' that they can be safely used directly by users.
#'
#' These functions can be used with inputs of length 1 or using vector. They
#' produce a vector of the same length and order than the hyenas name given.
#' Such vectors can easily be added to existing tables using e.g.
#' [dplyr::mutate()] (see example).
#'
#' Note for developpers: if ```debug``` is set to ```TRUE``` the functions
#' output a `tibble` (instead of a vector), with detailed information on what is
#' used for the computation. This is only possible for some but not all
#' functions.
#'
#' @inheritParams arguments
#' @name fetch_family
#' @aliases fetch_family fetch
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL


#' @describeIn fetch_family companion function for fetch functions; it cleans the input
#'  and reformat it as a `tibble`.
#'
#' This function should not be directly used by the user.
#' @examples
#'
#' # clean_input_fetch_xxx_at(ID = c("A-080", "L-012"), age = c(2, 3))
clean_input_fetch_xxx_at <- function(ID, age) {
  dplyr::tibble(ID = ID, age = age)
}


#' @describeIn fetch_family fetch the age of a hyena on a given day.
#'
#' Note that if the hyena is dead, the age will be ```NA```.
#' @export
#' @examples
#'
#'
#'
#' ################ examples for time varying fetch_xx functions ################
#'
#'
#' #### Detailed example of fetch_id_age usage:
#'
#' ### fetch age of 2 individuals at 2 dates:
#' fetch_id_age(ID = c("A-080", "L-012"), at = c("1997-10-04", "1996-07-01"))
#'
#' ### fetch age of 1 individual at 2 dates:
#' fetch_id_age(ID = "A-080", at = c("1996-10-04", "1997-01-04"))
#'
#' ### fetch age of 2 individuals at 1 date:
#' fetch_id_age(ID = c("A-080", "L-012"), at = "1996-07-01")
#'
#' ### more advanced usage (add a new column in the hyena table containing lifespan):
#' ## note: this is more easily done using fetch_id_duration.lifespan (see above)
#'
#' ## step 1. extract the hyena table:
#' hyena_table <- extract_database_table(tbl.names = "hyenas")
#'
#' ## step 2. add date of death and lifespan to a new table:
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#' hyena_table %>%
#'   mutate(
#'     death_date = fetch_id_date.death(ID = ID),
#'     lifespan = fetch_id_age(ID = ID, at = death_date)
#'   ) -> lifespan_table
#' }
#'
#' ## step 3. view the outcome
#' lifespan_table
#' # note: all existing columns may not show on your screen unless you run
#' # options(tibble.width = Inf)
fetch_id_age <- function(ID, at, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         date = check_function_arg.date(at))

  hyenas <- extract_database_table(tbl.names = "hyenas")
  deaths <- extract_database_table(tbl.names = "deaths")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::left_join(deaths, by = "ID") %>%
    dplyr::select(.data$ID, .data$birthdate, .data$deathdate) %>%
    dplyr::mutate(
      age = lubridate::interval(.data$birthdate, !!at) / lubridate::duration(1, units = check_function_arg.unit(!!unit))
    ) %>%
    dplyr::mutate(age = dplyr::case_when( ## give no focal age if dead!
      is.infinite(.data$age) ~ NA_real_,
      is.na(.data$deathdate) ~ .data$age,
      !!at <= .data$deathdate ~ .data$age,
      !!at > .data$deathdate ~ NA_real_
    )) -> output

  if (debug) {
    return(output)
  }

  output$age
}


#' @describeIn fetch_family fetch the birth clan of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_clan.birth usage:
#' fetch_id_clan.birth(ID = c("A-001", "A-007"))
fetch_id_clan.birth <- function(ID) {
  fetch_database_column(column = "birthclan", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the birthday of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.birth usage:
#' fetch_id_date.birth(ID = c("A-001", "A-007"))
fetch_id_date.birth <- function(ID) {
  fetch_database_column(column = "birthdate", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the birthday of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.conception usage:
#' fetch_id_date.conception(ID = c("A-001", "A-007"))
fetch_id_date.conception <- function(ID) {
  fetch_database_column(column = "birthdate", tbl.name = "hyenas", ID = ID) - 110
}


#' @describeIn fetch_family fetch the social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.birth usage:
#' fetch_id_rank.birth(ID = c("A-080", "A-100"))

fetch_id_rank.birth <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_id_date.birth(ID),
    birth_rank = fetch_id_rank(ID = ID, at = birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  birth_date <- NULL ## to please R CMD check

  output$birth_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.birth usage:
#' fetch_id_rank.birth.std(ID = c("A-080", "L-012"))
#'
#' #### Example with missing information
#' fetch_id_rank.birth.std(ID = c("A-001", "A-100"))

fetch_id_rank.birth.std <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_id_date.birth(ID),
    birth_rank = fetch_id_rank.std(ID = ID, at = birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  birth_date <- NULL ## to please R CMD check

  output$birth_rank
}


#' @describeIn fetch_family fetch the clan of a given individual on a given date.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_clan.current usage:
#' fetch_id_clan.current(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_clan.current <- function(ID, at, censored.to.last.clan = TRUE, debug = FALSE) {
  ## TODO? instead of censored.to.last.clan we could have an argument
  ## setting a time cut-off for the extrapolation, but note that individuals not
  ## seen for a year are considered dead, so such a cut-off would only mater if
  ## there is a need to choose something between 0 and 1 year... The cut-off
  ## could also be made age and sex dependent, but again that introduces
  ## complexity that is perhaps not required...

  check_function_arg.logical(censored.to.last.clan)
  check_function_arg.logical(debug)

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          date = check_function_arg.date(at))

  life_history_tbl <- create_id_life.history.table(ID = unique(input$ID),
                                                   censored.to.last.sighting = TRUE) ## keep TRUE here for generality, as we optionaly filter below by isrightcensored

  input %>%
    dplyr::full_join(life_history_tbl, by = "ID") %>%
    dplyr::distinct() -> life_history_tbl_with_date

  life_history_tbl_with_date %>%
    dplyr::filter(.data$date >= .data$starting_date & .data$date <= .data$ending_date) -> output

  if (!censored.to.last.clan) {
    output %>%
      dplyr::filter(!.data$isrightcensored) -> output
  }

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = c("ID", "date"),
                        duplicates = "input",
                        output.IDcolumn = "clan",
                        debug = debug)

}

#' @describeIn fetch_family fetch the date at which a given hyena has reached
#' a given age.
#'
#' Note that if the hyena is _known_ to be dead or censored, a date will still be given.
#' You can combine [fetch_id_age()] with [fetch_id_is.alive()] if it is not what you want.
#' @export
#'
#' @examples
#'
#' #### Detailed example of fetch_id_date.at.age usage:
#'
#' ### fetch date of 1 individual at 2 ages:
#' fetch_id_date.at.age(ID = c("A-080"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 1 age:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = 2)
#'
#' ### fetch date of 2 individuals at 2 ages in years:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 2 ages in weeks:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = c(2, 3), unit = "week")

fetch_id_date.at.age <- function(ID, age, unit = "year", debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          age = age,
                          unit = check_function_arg.unit(unit, arg.max.length = 1L))

  input %>%
    mutate(birthdate = fetch_id_date.birth(ID),
           date = as.Date(.data$birthdate + lubridate::duration(.data$age, units = .data$unit[1]))) -> output

  if (debug) {
    return(output)
  }

  output$date
}


#' @describeIn fetch_family fetch the date at which a given individual has conceived its first known offspring.
#'
#' Note that conception is here defined as the offspring birthdate minus 110 days.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.conception.first usage:
#' fetch_id_date.conception.first(ID = c("A-001", "L-003"))
#'
#' ### Fetch the date at first conception for all:
#' fetch_id_date.conception.first(find_pop_id())

fetch_id_date.conception.first <- function(ID, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID))

  create_offspring_starting.table(unique(input$ID)) %>%
    dplyr::filter(!is.na(.data$filiation) & .data$filiation != "mother_social") %>%
    dplyr::mutate(offspring_birthdate = fetch_id_date.birth(ID = .data$offspringID)) %>%
    dplyr::group_by(.data$parentID) %>%
    dplyr::arrange(.data$offspring_birthdate, .by_group = TRUE) %>%
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(conception_date = .data$offspring_birthdate - lubridate::days(110)) -> output



  if (debug) {
    return(output)
  }

  check_function_output(input,
                        output,
                        join.by = c("ID" = "parentID"),
                        duplicates = "input",
                        output.IDcolumn = "conception_date")
}


#' @describeIn fetch_family fetch the date at first selection a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.genetic usage:
#' fetch_id_date.selection.first(ID = c("A-011", "A-040"))

fetch_id_date.selection.first <- function(ID, debug = FALSE) {

  ID <- check_function_arg.ID(ID)
  input <- tibble::tibble(ID = !!ID)

  create_id_life.transition.table(ID = unique(ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(2) %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output

  if (debug) return(output)

  output$date

}


#' @describeIn fetch_family fetch the date of a given hyena at its death.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.death usage:
#' fetch_id_date.death(ID = c("L-012", "A-007"))

fetch_id_date.death <- function(ID) {
  fetch_database_column(column = "deathdate", tbl.name = "deaths", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the (genetic) father of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.father usage:
#' fetch_id_id.father(ID = c("A-080", "L-012"))

fetch_id_id.father <- function(ID) {
  fetch_database_column(column = "father", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the first date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the first sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.observation.first usage:
#' fetch_id_date.observation.first(ID = c("A-080", "L-012"))

fetch_id_date.observation.first <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  extract_database_table(tbl.names = "sightings") %>%
    dplyr::mutate(sighting_date = as.Date(date_time)) -> sightings

  input %>%
    dplyr::left_join(sightings, by = "ID") %>%
    dplyr::select(ID, sighting_date) %>%
    dplyr::group_by(ID) %>%
    dplyr::summarise(first_obs_date = min(sighting_date)) %>%
    dplyr::ungroup() %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output
  ## Note: the last left_join is important because otherwise summarise changes the order of the rows!!!!!

  if (debug) {
    return(output)
  }

  sighting_date <- first_obs_date <- date_time <- NULL ## to please R CMD check

  output$first_obs_date
}


#' @describeIn fetch_family fetch the social rank within sex of a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.sex usage:
#' fetch_id_rank.sex(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.sex <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$gender_rank))) output %>% mutate(gender_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank
}


#' @describeIn fetch_family fetch the standardized social rank within sex of a given
#'   individual on a given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.sex.std usage:
#' fetch_id_rank.sex.std(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.sex.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$gender_rank_std))) output %>% mutate(gender_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank_std
}


#' @describeIn fetch_family fetch if a given individual was alive on a given
#'   date.
#'
#'   The functions simply check if a given date falls between the birth and
#'   death date of a given hyena. It does not consider any other complexity.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.alive usage:
#' fetch_id_is.alive(ID = c("A-080", "L-012"), at = c("1997-10-04", "1997-10-04"))

fetch_id_is.alive <- function(ID, at, debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(at))

  input %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(.data$ID),
                  deathdate = fetch_id_date.death(.data$ID),
                  surv = dplyr::case_when(.data$date > find_pop_date.observation.last() ~ NA,
                                          (is.na(.data$deathdate) | .data$deathdate > .data$date) & (.data$date >= .data$birthdate) ~ TRUE,
                                          TRUE ~ FALSE)) -> output

  if (debug) {
    return(output)
  }

  output$surv
}


#' @describeIn fetch_family fetch whether an individual's deathdate is confirmed.
#'
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_id_is.death.confirmed usage:
#' fetch_id_is.death.confirmed(c("A-100", "L-003"))

fetch_id_is.death.confirmed <- function(ID) {

  input <- check_function_arg.ID(ID)

  confirmed_death_date <- fetch_database_column(column = "deathconfirmed", tbl.name = "hyenas", ID = input)

  !is.na(confirmed_death_date)

}


#' @describeIn fetch_family fetch if a given hyena is an immigrant
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.immigrant usage:
#' fetch_id_is.immigrant(ID = c("A-001", "A-002"), at = "1997-11-01")

fetch_id_is.immigrant <- function(ID, at, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          at = check_function_arg.date(at))

  input %>%
    dplyr::mutate(native = fetch_id_is.native(ID, at)) -> output

  if (debug) return(output)

  !output$native
}


#' @describeIn fetch_family fetch if a given hyena is a native
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.native usage:
#' fetch_id_is.native(ID = c("A-001", "A-002"), at = "1997-11-01")

fetch_id_is.native <- function(ID, at, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          at = check_function_arg.date(at))

  input %>%
    dplyr::mutate(birthclan = fetch_id_clan.birth(ID),
                  current_clan = fetch_id_clan.current(ID, at = at),
                  native = birthclan == current_clan) -> output

  if (debug) return(output)

  birthclan <- current_clan <- NULL ## To please R CMD check

  output$native
}


#' @describeIn fetch_family fetch whether an individual could have _potentially_ be observed for a given duration.
#'
#' Note that the actual time of death of the hyena is irrelevant for this function.
#' @export
#'
#' @examples
#'
#' #### Simple example of fetch_id_is.observable usage:
#' fetch_id_is.observable(c("A-100", "L-003"), duration = 3, unit = "week")

fetch_id_is.observable <- function(ID, duration = NULL, unit = "year", debug = FALSE) {

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         duration = check_function_arg.duration(duration),
                         unit = check_function_arg.unit(unit))

  hyenas <- extract_database_table("hyenas")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(ID),
                  date_firstsighting = find_pop_date.observation.first(),
                  date_lastsighting = find_pop_date.observation.last(),
                  followup = furrr::future_pmap(list(duration, unit),
                                                ~ lubridate::duration(..1, units = ..2))
    ) -> output

  output$followup <- do.call("c", output$followup) ## Workaround tidyr::unnest(followup) which is way too slow

  output %>%
    dplyr::mutate(left_censored = birthdate < date_firstsighting,
                  right_censored = birthdate + followup > date_lastsighting, ## not compared to death (this is important!)
                  ## so perhaps calling that right_censored is misleading
                  observable = !left_censored & !right_censored) -> output

  if (debug) {
    return(output)
  }

  birthdate <- date_firstsighting <- date_lastsighting <- left_censored <- right_censored <- followup <- NULL ## to please R CMD check

  output$observable
}


#' @describeIn fetch_family fetch if the focal individual(s) have selected given clan(s) at given date(s).
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_id_is.selector usage:
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"))
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error.margin.selection = "30 days")
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040"),
#'                      clan = c("A", "A", "A"),
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error.margin.selection = "90 days")

fetch_id_is.selector <- function(ID, clan, at, error.margin.selection = "0 days", debug = FALSE){

  input <- tibble::tibble(ID = check_function_arg.ID(ID), clan = check_function_arg.clan(clan), date = check_function_arg.date(at))
  error.margin.selection <- check_function_arg.period(error.margin.selection)

  life_history <- create_id_life.history.table(unique(ID), censored.to.last.sighting = TRUE) %>%
    dplyr::filter(.data$life_stage != "dead")

  dplyr::left_join(input, life_history, by = c("ID", "clan")) %>%
    dplyr::mutate(
      starting_date_approx = .data$starting_date - !!error.margin.selection,
      ending_date_approx = .data$ending_date + !!error.margin.selection,
      overlap = .data$date >= .data$starting_date_approx & .data$date <= .data$ending_date_approx,
      is_selector = .data$overlap & !(.data$life_stage %in% c("cub", "subadult", "natal", "transient", "unknown")),
      death_confirmed = fetch_id_is.death.confirmed(.data$ID),
      deathdate = fetch_id_date.death(.data$ID),
      # if really dead, then it is not a selector:
      is_selector = ifelse(.data$death_confirmed & .data$date > .data$deathdate, FALSE, .data$is_selector))  -> output

  if (debug) {
    return(output)
  }

  output %>%
    dplyr::group_by(.data$ID, .data$clan, .data$date) %>%
    dplyr::summarise(is_selector = any(.data$is_selector)) %>%
    dplyr::left_join(input, ., by = c("ID", "clan", "date")) -> output2

  output2$is_selector
}


#' @describeIn fetch_family fetch if individuals could have been observed on
#'   a given date.
#'
#'   The functions simply check if a given date falls between the first and the
#'   last sighting. It does not consider any other complexity, such as if
#'   someone was actually in the field at this particular date.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.observed usage:
#'fetch_id_is.observed(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-07-01"))

fetch_id_is.observed <- function(ID, at, debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(at))

  input %>%
    dplyr::mutate(
      first_obs_date = fetch_id_date.observation.first(ID = ID),
      last_obs_date = fetch_id_date.observation.last(ID = ID),
      obs = (date >= first_obs_date) & (date <= last_obs_date)
    ) -> output
  ## Note: we do not use between() because it is not a fully vectorized function.

  if (debug) {
    return(output)
  }

  first_obs_date <- last_obs_date <- NULL ## to please R CMD check

  output$obs
}


#' @describeIn fetch_family fetch the last date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the last sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.observation.last usage:
#' fetch_id_date.observation.last(ID = c("A-080", "L-012"))
fetch_id_date.observation.last <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = check_function_arg.ID(ID))

  extract_database_table(tbl.names = "sightings") %>%
    dplyr::mutate(sighting_date = as.Date(.data$date_time)) -> sightings

  input %>%
    dplyr::distinct() %>%
    dplyr::left_join(sightings, by = "ID") %>%
    dplyr::select(.data$ID, .data$sighting_date) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(last_obs_date = find_vector_max(.data$sighting_date, keep.class = FALSE)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(last_obs_date = as.Date(.data$last_obs_date)) -> output

  ## Note (Alex, 2020/06/19) to handle NAs such as produced by A-100 in the dummy data we need to avoid
  ## having NA of class Date within the summarise call. For some reason it makes dplyr crash.
  ## This is why we coerce at the end

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = "ID",
                        duplicates = "input",
                        output.IDcolumn = "last_obs_date",
                        debug = debug)

}


#' @describeIn fetch_family fetch the lifespan of a given hyena at its death.
#' @export
#' @examples
#'
#' ################### examples for fetch_xx functions ###################
#'
#'
#' #### Detailed example of fetch_id_duration.lifespan usage:
#' ### note: what is shown here also applies to all other fetch_xx_yy functions
#'
#' ### fetch the lifespan of all individuals:
#' fetch_id_duration.lifespan(ID = find_pop_id())
#'
#' ### fetch the lifespan of two individuals:
#' fetch_id_duration.lifespan(ID = c("A-007", "A-043"))

fetch_id_duration.lifespan <- function(ID, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  hyenas <- extract_database_table(tbl.names = "hyenas")
  deaths <- extract_database_table(tbl.names = "deaths")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::left_join(deaths, by = "ID") %>%
    dplyr::select(ID, birthdate, deathdate) %>%
    dplyr::mutate(lifespan = lubridate::interval(birthdate, deathdate) / lubridate::duration(1, units = check_function_arg.unit(unit))) -> output

  if (debug) {
    return(output)
  }

  birthdate <- deathdate <- lifespan <- NULL ## to please R CMD check

  output$lifespan
}


#' @describeIn fetch_family fetch the life stage of given individual(s) on given date(s).
#' @export
#' @examples
#'
#'
#' #### Simple example of fetch_id_lifestage usage:
#' fetch_id_lifestage(ID = c("A-001"), at = c("1997-01-01"))

fetch_id_lifestage <- function(ID, at, debug = FALSE) {

  input_full <- dplyr::tibble(ID = check_function_arg.ID(ID),
                              date = check_function_arg.date(at))
  input <-  unique(input_full)

  ## reduce to unique case for speed up:
  life_history <- create_id_life.history.table(unique(ID), censored.to.last.sighting = TRUE)

  dplyr::left_join(input, life_history, by = "ID") %>%
    dplyr::filter(.data$date >= .data$starting_date  &
                    (.data$date <= .data$ending_date | is.na(.data$ending_date))) -> life_stage

  ## left joins will return NA for unmatched dates
  check_function_output(input.tbl = input_full, duplicates = "input", output.tbl = life_stage,
                        join.by = c("ID", "date"),
                        output.IDcolumn = "life_stage", debug = debug)
}



#' @describeIn fetch_family fetch the ID of the dominance status in the litter of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.litter usage:
#' fetch_id_rank.litter(ID = c("A-018", "A-046"))
fetch_id_rank.litter <- function(ID) {
  fetch_database_column(column = "litterdominance", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the genetic mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.genetic usage:
#' fetch_id_id.mother.genetic(ID = c("A-080", "L-012"))
fetch_id_id.mother.genetic <- function(ID) {
  fetch_database_column(column = "mothergenetic", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the social mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.social usage:
#' fetch_id_id.mother.social(ID = c("A-080", "L-012"))
fetch_id_id.mother.social <- function(ID) {
  fetch_database_column(column = "mothersocial", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the social rank within native for a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.native usage:
#' fetch_id_rank.native(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))
fetch_id_rank.native <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$nat_rank))) output %>% mutate(nat_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank
}


#' @describeIn fetch_family fetch the standardised social rank within native for a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.native usage:
#' fetch_id_rank.native.std(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))
fetch_id_rank.native.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$nat_rank_std))) output %>% mutate(nat_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank_std
}

#' @describeIn fetch_family fetch the number of known offspring produced by a given individual.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_number.offspring usage:
#' fetch_id_number.offspring(ID = c("A-001", "A-100", "L-003"))
#' fetch_id_number.offspring(ID = c("A-001", "A-001"), from = c("1994-09-21", "1995-10-08"))

fetch_id_number.offspring <- function(ID, from = NULL, to = NULL, at = NULL,
                                      fill = TRUE,
                                      filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                      first.event = "birthdate", debug = FALSE) {

  min.date <- switch(first.event,
                      birthdate = find_pop_date.birth.first(),
                      observation = find_pop_date.observation.first(),
                      conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ID         <- check_function_arg.ID(ID)
  filiation  <- check_function_arg.filiation(filiation)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = TRUE,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(parentID = ID,
                         from = from, to = to)

  create_offspring_starting.table(unique(ID)) %>%
    dplyr::left_join(., input, by = "parentID") %>% #Join in from/to to allow for a vector of different from/to dates
    dplyr::filter(.data$filiation %in% !!filiation) %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(ID = .data$offspringID)) %>%
    dplyr::filter(.data$birthdate >= .data$from & .data$birthdate <= .data$to) %>%
    dplyr::group_by(.data$parentID, .data$from, .data$to) %>%
    dplyr::summarise(offspring_nb = dplyr::n_distinct(.data$offspringID, na.rm = TRUE)) %>%
    dplyr::ungroup() %>%
    dplyr::left_join(input, ., by = c("parentID", "from", "to")) %>%
    dplyr::mutate(offspring_nb = replace(.data$offspring_nb, is.na(.data$offspring_nb), 0L)) -> output

  if (debug) {

    return(output)
  }

  output$offspring_nb
}


#' @describeIn fetch_family fetch the social rank of a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank usage:
#' fetch_id_rank(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank <- function(ID, at, debug = FALSE) {

  if (is.null(ID) || is.null(at)) {
    return(NULL)
  }
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$rank))) output %>% mutate(rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on
#'   a given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.std usage
#' fetch_id_rank.std(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.std <- function(ID, at, debug = FALSE) {

  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$rank_std))) output %>% mutate(rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank_std

}


#' @describeIn fetch_family fetch the social rank of a given individual on a given date within males
#'   that selected their clan.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retrieve such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.selector.male usage:
#' fetch_id_rank.selector.male(ID = c("A-080", "L-012"),
#'                             at = c("1997-01-04", "1996-06-30")) ## TODO: change ID
fetch_id_rank.selector.male <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$sel_rank))) {
    output %>% mutate(sel_rank = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on a given date
#'   within males that selected their clan.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retrieve such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.selector.male.std usage:
#' fetch_id_rank.selector.male.std(ID = c("A-001", "A-002"),
#'                                 at = c("1997-01-04", "1996-06-30"))  ## TODO: change ID
fetch_id_rank.selector.male.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$sel_rank_std))) {
    output %>% mutate(sel_rank_std = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank_std
}


#' @describeIn fetch_family fetch the sex of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_sex usage:
#' fetch_id_sex(ID = c("A-001", "A-007"))
fetch_id_sex <- function(ID) {
  ID <-  check_function_arg.ID(ID)
  fetch_database_column("sex", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the tenure duration a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_duration.tenure usage:
#' fetch_id_duration.tenure(ID = c("A-011", "A-040"), at = "1997-12-30") ## TODO change ID and date
fetch_id_duration.tenure <- function(ID, at, unit = "year", debug = FALSE) {


  ID <-  check_function_arg.ID(ID)
  at <-  check_function_arg.date(at)
  input <- tibble::tibble(ID, at)

  create_id_life.history.table(ID = unique(ID), censored.to.last.sighting = TRUE) %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID)) %>%
    # add date of interest in the life history table
    # use unique in order to avoid creating duplicated rows
    dplyr::left_join(x = ., y = unique(input), by = "ID") %>%
    # for females, non-selectors and cases when focal date does not fall into the tenureship in a clan, returns NA
    dplyr::filter(.data$sex == "male" & .data$at >= .data$starting_date & .data$at <= .data$ending_date & !(.data$life_stage %in% c("cub", "subadult", "natal", "unknown"))) %>%
    dplyr::mutate(tenure = as.numeric(lubridate::interval(.data$starting_date, .data$at) / lubridate::duration(1, units = check_function_arg.unit(unit)))) -> output

    output <- check_function_output(input.tbl = input,
                          output.tbl = output,
                          join.by = c("ID", "at"),
                          duplicates = "input",
                          output.IDcolumn = "tenure",
                          debug = debug)
  output
}


#' @describeIn fetch_family fetch if the individuals are genetically typed
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_is.sampled.dna usage:
#' fetch_id_is.sampled.dna(c("A-003", "A-002"))

fetch_id_is.sampled.dna <- function(ID) {
  ID <- check_function_arg.ID(ID)
  dna <- fetch_database_column(column = "DNA", tbl.name = "hyenas", ID = ID)
  as.logical(dna) ## should be already reading TRUE/FALSE
}


#' @describeIn fetch_family fetch whether the second argument is offspring of the first argument, according
#' to the filiation argument.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad_is.offspring usage:
#' fetch_dyad_is.offspring(ID = c("A-001", "A-001"), offspringID = c("A-010", "A-049"))
#'
fetch_dyad_is.offspring <- function(ID, offspringID, filiation = c("mother_genetic", "mother_social_genetic", "father"), debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  offspringID <- check_function_arg.ID(offspringID)
  filiation <- check_function_arg.filiation(filiation)
  input <- tibble::tibble(parentID = ID, offspringID = offspringID)

  ## Note: we do note account for offspring that would have missing filiation (but that should probably not exist)
  create_offspring_starting.table(unique(ID)) %>%
    dplyr::filter(.data$filiation %in% !!filiation | is.na(.data$filiation)) -> real_offspring

  input %>%
    dplyr::left_join(real_offspring, by = c("parentID", "offspringID")) %>%
    dplyr::mutate(is_offspring = ifelse(!is.na(.data$filiation), TRUE, FALSE)) -> output

  if (debug) return(output)

  output$is_offspring
}

#' @describeIn fetch_family fetch the type of filiation between the first argument and the second one.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad_filiation usage:
#' fetch_dyad_filiation(parentID = c("A-001", "A-001"), offspringID = c("A-010", "A-049"))
#'
fetch_dyad_filiation <- function(parentID, offspringID, debug = FALSE) {
  parentID <- check_function_arg.ID(parentID)
  offspringID <- check_function_arg.ID(offspringID)
  input <- tibble::tibble(parentID = parentID, offspringID = offspringID)

  offspring_table <- create_offspring_starting.table(unique(parentID))

  input %>%
    dplyr::left_join(offspring_table, by = c("parentID", "offspringID")) -> output

  if (debug) return(output)

  output$filiation

}


#' @describeIn fetch_family fetch the litterID of the given IDs according to filiation argument. If filiation is 'mother_genetic'
#' the function will retrieve the genetic litter. If filiation is 'mother_social' the function will retrieve the social litters
#' where cubs have been adopted. If the cub has never been adopted and filiation is 'mother_social' the function will return NA.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_litterID usage:
#'fetch_id_litterID(ID = c("A-010", "A-049"))
#' fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_social")
#' fetch_id_litterID(ID = "A-054")
#'
fetch_id_litterID <- function(ID, filiation = "mother_genetic", debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation)
  ## The function accepts only 'mother_genetic' and 'mother_social'
  if (!(filiation %in% c("mother_genetic", "mother_social"))) stop("The function works only with 'mother_genetic' or 'mother_social'. 'mother_social_genetic' in this case is included in 'mother_genetic")
  offspring <- tibble::tibble(offspringID = ID)

  if (filiation ==  "mother_genetic") {
    ## We keep only the genetic mothers to retrieve the genetic litters.
    offspring %>%
      dplyr::mutate(mother = fetch_id_id.mother.genetic(.data$offspringID)) -> mother.offspring
    ## create_offspring_litterID.from.mother is based on create_offspring_starting.table that returns all
    ## offsprings, both genetic and social. A cub could then a duplicate in the output.tbl, because genetic
    ## offspring of a female in 'mother' column but also social offspring of another female in 'mother' column.
    ## To avoid this we filter the correct filiation.
    create_offspring_litterID.from.mother(unique(mother.offspring$mother)) %>%
      dplyr::filter(.data$filiation %in% c("mother_genetic", "mother_social_genetic")) -> litters.mother
  } else {
    offspring %>%
      ## We keep only the social mothers who adopted for real the offspring to retrieve the social litters.
      dplyr::mutate(motherID = fetch_id_id.mother.social(.data$offspringID),
             gen.mumID = fetch_id_id.mother.genetic(.data$offspringID)) %>%
      dplyr::filter(.data$gen.mumID != .data$motherID) %>%
      dplyr::select(.data$offspringID, .data$motherID) -> mother.offspring
    create_offspring_litterID.from.mother(unique(mother.offspring$motherID)) %>%
      dplyr::filter(.data$filiation == "mother_social") -> litters.mother
  }

  check_function_output(input.tbl = offspring, output.tbl = litters.mother, join.by = "offspringID",
                        duplicates = "input", output.IDcolumn = "litterID", debug = debug)
}

#' @describeIn fetch_family fetch the litter type for each given litter. Each litter is defined by a combination of letter,
#' (f = female, m = male, u = cub with unknown sex, preceded from 's' if the cub is social).
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_litter.type usage:
#' fetch_litter_litter.type(litterID = "A-001_004")
#'
fetch_litter_litter.type <- function(litterID, debug = FALSE)  {

  litterID <- check_function_arg.litter.ID(litterID)

  create_litter_offspring.count(litterID) %>%
    dplyr::mutate(type = recode_offspring.sex_litter.type(.data$female,
                                        .data$male,
                                        .data$unknown,
                                        .data$social.female,
                                        .data$social.male,
                                        .data$social.unknown)) -> output

  if (debug) return(output)

  output$type

}

#' @describeIn fetch_family fetch if at least one member of the litter is genetically typed.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_is.sampled.dna usage:
#' fetch_litter_is.sampled.dna(litterID = c("A-001_004", "A-001_001", "A-001_004"))
#'
fetch_litter_is.sampled.dna <- function(litterID, debug = FALSE) {
  parentID <- unique(substr(litterID, 1, 5))
  litter <- tibble::tibble(litterID = litterID)
  all.litters <- create_offspring_litterID.from.all(unique(parentID))
  litter %>%
    dplyr::left_join(all.litters, by = "litterID") %>%
    dplyr::select(.data$offspringID, .data$litterID, .data$filiation) %>%
    dplyr::mutate(dna = fetch_id_is.sampled.dna(.data$offspringID)) %>%
    dplyr::group_by(.data$litterID) %>%
    dplyr::mutate(litter_dna = any(.data$dna)) %>%
    dplyr::ungroup() %>%
    dplyr::select(.data$litterID, .data$litter_dna) %>%
    dplyr::distinct() %>%
    dplyr::ungroup() -> output_distinct

  litter %>%
    dplyr::left_join(output_distinct) -> output
  if (debug) return(output)
  output$litter_dna
}


#' @describeIn fetch_family fetch whether individuals have produced any offspring.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_has.reproduced usage:
#' fetch_id_has.reproduced(ID = c("A-001", "A-007"))
fetch_id_has.reproduced <- function(ID, from = NULL, to = NULL, at = NULL, first.event = "birthdate", debug = FALSE) {

  ## Note: we do not check the arguments, since they are checked in the following call.
  fetch_id_number.offspring(ID = ID, from = from, to = to, at = at, first.event = first.event) > 0 -> output

  if (debug) {

    return(output)

  }

  output

}

#' @describeIn fetch_family fetch whether individuals have produced a twin litter.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_had.twins usage:
#' fetch_id_has.twin.litter(ID = c("A-001", "A-007"))
fetch_id_has.twin.litter <- function(ID, from = NULL, to = NULL, at = NULL,
                                     fill = TRUE, first.event = "birthdate", debug = FALSE) {

  ## This function is somewhat redundant with create_littertable_count;
  ## however, create_littertable_count has no option to filter
  ## by date (from, to, at), which is needed for determining
  ## reproductive success over a given time scale

  min.date <- switch(first.event,
                      birthdate = find_pop_date.birth.first(),
                      observation = find_pop_date.observation.first(),
                      conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ID         <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(parentID = ID,
                         from = from, to = to)

  unique_input <- input %>%
    dplyr::distinct()

  create_offspring_litterID.from.all(unique(ID)) %>%
    dplyr::left_join(., unique_input, by = "parentID") %>% #Join in from/to to allow for a vector of different from/to dates
    dplyr::filter(.data$birthdate >= .data$from & .data$birthdate <= .data$to) %>%
    dplyr::group_by(.data$parentID, .data$from, .data$to, .data$litterID) %>%
    dplyr::summarise(litter_size = n(), .groups = "drop_last") %>% # Find litter size for each litter
    dplyr::summarise(twin = any(!is.na(.data$litterID) & .data$litter_size > 1)) -> output_raw

  check_function_output(input, output_raw, join.by = c("parentID", "from", "to"),
                        debug = debug, duplicates = "input", output.IDcolumn = "twin")

}

#' @describeIn fetch_family fetch the adult sex ratio (female/all adults) in a clan at a given
#'   date.
#' @export
#' @examples
#' fetch_clan_sex.ratio.adult(clan = "A", at = "1996/01/01")
fetch_clan_sex.ratio.adult <- function(clan = NULL, at, debug = FALSE) {

  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         date = check_function_arg.date(at))

  input %>%
    dplyr::mutate(nradultmale = fetch_clan_number.male.adult(clan = .data$clan, at = .data$date),
                  nradult = fetch_clan_number.anysex.adult(clan = .data$clan, at = .data$date),
                  sexratio = .data$nradultmale/.data$nradult) -> output

  if(debug){

    return(output)

  }

  if(any(output$nradult == 0)){

    message("Some clans have no adults on the given date. These will return a sex ratio 'NA'")

  }

  output$sexratio

}

#' @describeIn fetch_family fetch the adult sex ratio (female/all adults) in the whole population
#' at a given date.
#' @inheritParams find_clans
#' @export
#' @examples
#' fetch_pop_sex.ratio.adult(at = "1996/01/01")
fetch_pop_sex.ratio.adult <- function(at, main.clans = TRUE, debug = FALSE) {

  input <- dplyr::tibble(date = check_function_arg.date(at))
  clans <- find_clan_name.all(main.clans = main.clans)

  combos <- expand.grid(date = unique(input$date), clan = clans, stringsAsFactors = FALSE)

  # Need to call `fetch_clan` with debug because we can't determine pop ratio from clan ratios
  fetch_clan_sex.ratio.adult(clan = combos$clan, at = combos$date, debug = TRUE) %>%
    dplyr::group_by(.data$date) %>%
    dplyr::summarise(nradultmale = sum(.data$nradultmale),
                     nradult = sum(.data$nradult),
                     sexratio = .data$nradultmale/.data$nradult) %>%
    dplyr::left_join(input, ., by = "date") -> output

  if(debug){

    return(output)

  }

  output$sexratio

}

#' @describeIn fetch_family fetch the age ratio (adult/clan size) in a clan at a given
#'   date.
#' @export
#' @examples
#' fetch_clan_adult.ratio(clan = "A", at = "1996/01/01")
fetch_clan_adult.ratio <- function(clan = NULL, at, debug = FALSE) {

  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         date = check_function_arg.date(at))

  input %>%
    dplyr::mutate(nradult = fetch_clan_number.anysex.adult(clan = .data$clan, at = .data$date),
                  nrindv = fetch_clan_number.anysex.all(clan = .data$clan, at = .data$date),
                  ageratio = .data$nradult/.data$nrindv) -> output

  if(debug){

    return(output)

  }

  if(any(output$nrindv == 0)){

    message("Some clans have no individuals on the given date. These will return an age ratio 'NA'")

  }

  output$ageratio

}

#' @describeIn fetch_family fetch the age ratio (adult/clan size) in the whole population
#' at a given date.
#' @inheritParams find_clans
#' @export
#' @examples
#' fetch_pop_adult.ratio(at = "1996/01/01")
fetch_pop_adult.ratio <- function(at, main.clans = TRUE, debug = FALSE) {

  input <- dplyr::tibble(date = check_function_arg.date(at))
  clans <- find_clan_name.all(main.clans = main.clans)

  combos <- expand.grid(date = unique(input$date), clan = clans, stringsAsFactors = FALSE)

  # Need to call `fetch_clan` with debug because we can't determine pop ratio from clan ratios
  fetch_clan_adult.ratio(clan = combos$clan, at = combos$date, debug = TRUE) %>%
    dplyr::group_by(.data$date) %>%
    dplyr::summarise(nradult = sum(.data$nradult),
                     nrindv = sum(.data$nrindv),
                     ageratio = .data$nradult/.data$nrindv) %>%
    dplyr::left_join(input, ., by = "date") -> output

  if(debug){

    return(output)

  }

  output$ageratio

}

#' @describeIn fetch_family fetch if the individuals are adults at a given date
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_is.adult usage:
#' fetch_id_is.adult(ID = c("A-003", "A-002"), at = "1997-01-01")
#'
fetch_id_is.adult <- function(ID, at, debug = FALSE) {

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         date = check_function_arg.date(at)) %>%
    dplyr::mutate(isalive = fetch_id_is.alive(ID = .data$ID, at = .data$date))

  if(!all(input$isalive)){

    #Do we want this to be a warning or an error?
    warning("Some individuals were not alive at this date. These individuals will return NA")

  }

  input %>%
    dplyr::mutate(age = fetch_id_age(ID = .data$ID, at = .data$date),
                  isadult = .data$age > 2) -> output

  if (debug) {
    return(output)
  }

  output$isadult

}

#' @describeIn fetch_family fetch whether individuals are left/right or both censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored usage:
#' fetch_id_is.censored(ID = c("A-001", "A-007"), censored.left= TRUE, censored.right = FALSE)
#' fetch_id_is.censored(ID = c("A-001", "A-007"), from = "1980-03-04", to = "1988-07-09")
fetch_id_is.censored <- function(ID, censored.left= TRUE, censored.right= TRUE,
                                 from = find_pop_date.observation.first(), to = find_pop_date.observation.last(), debug = FALSE) {
  if (censored.left == FALSE & censored.right== FALSE) {
    stop("'left' and 'right' arguments are both FALSE. Try putting  at least one equal to TRUE ")
  }
  ID <- check_function_arg.ID(ID)
  from <- check_function_arg.date(from)
  to <- check_function_arg.date(to)

  dates.ID <- tibble::tibble(ID = ID,
                             from = from,
                             to = to,
                             alive.from = fetch_id_is.alive(ID, at = from),
                             alive.to = fetch_id_is.alive(ID, at = to))
  dates.ID %>%
    dplyr::mutate(is.censored = dplyr::case_when(censored.left == TRUE & is.na(.data$from) ~ NA,
                                                 censored.right== TRUE & is.na(.data$to) ~ NA,
                                                 censored.left== TRUE & .data$alive.from ~ TRUE,
                                                 censored.right== TRUE & .data$alive.to ~ TRUE,
                                                 TRUE ~ FALSE)) -> censored.ID
  if (debug) return(censored.ID)
  censored.ID$is.censored
}


#' @describeIn fetch_family fetch whether individuals are right-censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored.left usage:
#' fetch_id_is.censored.left(ID = c("A-001", "A-007"))
#' fetch_id_is.censored.left(ID = c("A-001", "A-007"), at = "1980-03-04")
#'
fetch_id_is.censored.left <- function(ID, at = find_pop_date.observation.first(), debug = FALSE) {
  fetch_id_is.censored(ID, from = at, censored.left = TRUE, censored.right= FALSE, debug = debug)
}


#' @describeIn fetch_family fetch whether individuals are left-censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored.right usage:
#' fetch_id_is.censored.right(ID = c("A-001", "A-007"))
#' fetch_id_is.censored.right(ID = c("A-001", "A-007"), at = "1980-03-04")
#'
fetch_id_is.censored.right <- function(ID, at = find_pop_date.observation.last(), debug = FALSE) {
  fetch_id_is.censored(ID, to = at, censored.left = FALSE, censored.right= TRUE, debug = debug)
}


#' @describeIn fetch_family fetch the birthday of a given litter.
#' @export
#' @examples
#'
#' #### Simple example of fetch_litter_date.birth usage:
#' fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
fetch_litter_date.birth <- function(litterID, debug = FALSE) {
  litterID <- check_function_arg.litter.ID(litterID)
  litter.table <- tibble::tibble(litterID = litterID)
  parentID <- substring(litterID, first = 1, last = 5)

  create_offspring_litterID.from.all(parentID = unique(parentID)) %>%
    dplyr::group_by(litterID) %>%
    dplyr::mutate(n.cubs = n(),
                  n.birthdates = length(unique(.data$birthdate)),
                  any.genetic = any(.data$filiation %in% c("mother_social_genetic", "mother_genetic")),
                  not.genetic.sibs = !.data$any.genetic & .data$n.cubs > 1 & .data$n.birthdates > 1,
                  litter.birthdate = dplyr::case_when(.data$any.genetic ~ .data$birthdate[.data$filiation %in% c("mother_social_genetic", "mother_genetic")][1],
                                                      .data$not.genetic.sibs ~ min(.data$birthdate),
                                                      TRUE ~ .data$birthdate)) %>%
    dplyr::distinct(.data$litterID, .data$litter.birthdate, .keep_all = TRUE) -> litter_birthdate

  if (any(litter_birthdate$not.genetic.sibs)) message("Some litters contained only social cubs born at different dates. For those 'fetch_litter_date.birth()' returned the birth date of the oldest cub.")

  litter.table %>%
    dplyr::left_join(litter_birthdate, by = "litterID") -> output

  if (debug) return(output)

  output$litter.birthdate
}

#' @describeIn fetch_family fetch how many times an individuals was sighted.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_had.twins usage:
#' fetch_id_number.sighting(ID = c("A-001", "A-007"))
fetch_id_number.sighting <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                     fill = TRUE, first.event = "observation", debug = FALSE) {

  min.date <- switch(first.event,
                      birthdate = find_pop_date.birth.first(),
                      observation = find_pop_date.observation.first(),
                      conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         from = from, to = to)

  input %>%
    dplyr::distinct() %>%
    dplyr::group_by(from, to) %>%
    dplyr::summarise(all_indv = list(ID)) -> unique_input #Save us from calling create_sighting_starting.table() redundantly

  purrr::pmap_df(.l = unique_input,
                 .f = function(all_indv, from, to){

                   create_sighting_starting.table(ID = all_indv, from = from, to = to) %>%
                     dplyr::mutate(from = from, to = to)

                 }) %>%
    dplyr::group_by(.data$ID, .data$from, .data$to) %>% #For every individual and date range
    dplyr::summarise(nrsighting = n()) %>%
    dplyr::ungroup() %>%
    dplyr::left_join(input, ., by = c("ID", "from", "to")) %>% # Join back to match original input
    dplyr::mutate(nrsighting = replace(.data$nrsighting, is.na(.data$nrsighting), 0L)) -> output # NAs are 0 counts

  if(debug){

    return(output)

  }

  output$nrsighting

}

#' @describeIn fetch_family fetch is an individual(s) was sighted.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_had.twins usage:
#' fetch_id_has.sighting(ID = c("A-001", "A-007"))
fetch_id_has.sighting <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                  fill = TRUE, first.event = "observation", debug = FALSE) {

  min.date <- switch(first.event,
                      birthdate = find_pop_date.birth.first(),
                      observation = find_pop_date.observation.first(),
                      conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         from = from, to = to)

  input %>%
    dplyr::distinct() %>%
    dplyr::mutate(nrsighting = fetch_id_number.sighting(ID = .data$ID, from = .data$from, to = .data$to),
                  hassighting = .data$nrsighting > 0) %>%
    dplyr::left_join(input, ., by = c("ID", "from", "to")) -> output

  if(debug){

    return(output)

  }

  output$hassighting

}


#' @describeIn fetch_family fetch the number of litters of each individual during a given period of time.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_number.litter:
#'
#' fetch_id_number.litter(ID = c("A-001", "A-001"), first.event = "observation")
#' fetch_id_number.litter(ID = c("A-001", "A-008"))
#' fetch_id_number.litter(ID = "A-008")
#'
fetch_id_number.litter <- function(ID, from = NULL, to = NULL, at = NULL,
                                   fill = TRUE, first.event = "birthdate", debug = FALSE) {

  min.date <- switch(first.event,
                      birthdate = find_pop_date.birth.first(),
                      observation = find_pop_date.observation.first(),
                      conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ID <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to
  input <- tibble::tibble(parentID = ID)

  create_offspring_starting.table(ID = unique(ID), from = from, to = to) %>%
    dplyr::mutate(litterID = dplyr::if_else(.data$filiation %in% c("mother_genetic", "mother_social_genetic", "father"),
                              fetch_id_litterID(.data$offspringID, filiation = "mother_genetic"),
                              fetch_id_litterID(.data$offspringID, filiation = "mother_social"))) %>%
    dplyr::group_by(.data$parentID) %>%
    dplyr::mutate(litters.count = dplyr::if_else(!is.na(.data$offspringID), dplyr::n_distinct(.data$litterID), as.integer(0))) %>%
    dplyr::ungroup() %>%
    dplyr::distinct(.data$parentID, .data$litters.count) -> litters.tbl

  check_function_output(input.tbl = input, output.tbl = litters.tbl,
                        join.by = "parentID", duplicates = "input", output.IDcolumn = "litters.count", debug = debug)

}


#' @describeIn fetch_family fetch if some individuals are included in the dummy dataset or not.
#' @export
#' @examples
#' table(fetch_id_is.dummy(find_pop_id()))

fetch_id_is.dummy <- function(ID) {
  ID.possible <- find_pop_id.dummy()
  ID <- check_function_arg.ID(ID)
  ID %in% ID.possible
  }


#' @describeIn fetch_family fetch the reproductive mates of each individuals.
#'
#' If there are several mates per individual, the funcion returns a list.
#'
#' @inheritParams fetch_clan_id
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mate usage:
#'
#' fetch_id_id.mate(c("A-001", "L-003", "A-100", "L-003"))
#'
#' if (require("dplyr") & require("tidyr")){
#' tibble(ID = c("A-001", "L-003", "A-100", "L-003")) %>%
#'   mutate(mates = fetch_id_id.mate(ID)) %>%
#'   unnest_longer(col = mates)
#' }
#'
fetch_id_id.mate <- function(ID = NULL, CPUcores = NULL, .parallel.min = 1000) {

  input <- tibble::tibble(ID = !!ID)  ## Checked internally, so no need to do it here

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if(is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## We loop ## TODO: we should loop only on unique combination, but we need a general wrapper for that...
  if (CPUcores > 1 && nrow(input) >= .parallel.min) {
    output <- furrr::future_pmap(input, ~ do.call("find_id_id.mate", list(...)),
                                 .progress = TRUE,
                                 .options = furrr::future_options(globals = ".database"))
  } else {
    if(CPUcores > 1 && (nrow(input) < .parallel.min)) message("Argument CPUcores ignored as less than 1000 cases to compute.")
    output <- purrr::pmap(input, ~ unique(do.call("find_id_id.mate", list(...))))
  }

  names(output) <- ID

  output
}


#' @describeIn fetch_family fetch if functions are defunct or not
#' @export
#' @examples
#' fetch_function_is.defunct(c(fetch_sex, fetch_id_sex))
#' fetch_function_is.defunct(c("fetch_sex", "fetch_id_sex"))
#'
fetch_function_is.defunct <- function(fn) {
  sapply(fn, function(fn) any(grepl("Defunct", body(fn))))
}
