context("Test multifetch_xxx functions")

test_that("all multifetch functions return the correct type of output", {

  expect_equal(class({
    create_id_starting.table(clan = "A", at = "1997-01-01") %>%
      mutate(date = as.Date("1997-01-01")) %>%
      join_allranks()
  })[1], "tbl_df")
  expect_equal(class(multifetch_id_offspring.count("A-001"))[1], "tbl_df")
  expect_equal(class(multifetch_litter_offspring.count("A-001_004"))[1], "tbl_df")
  expect_equal(class(multifetch_id_birth.info("A-001"))[1], "tbl_df")

})

test_that("multifetch_id_offspring.count returns the correct output", {
  ref <-
    structure(
      list(
        n_females = 3L,
        n_males = 3L,
        n_unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- multifetch_id_offspring.count("A-001")
  expect_equal(ref, job)
})

test_that("multifetch_litter_offspring.count returns the correct output",
          {
            ref <-
              structure(
                list(
                  female = 1L,
                  male = 1L,
                  unknown = 0L,
                  social.female = 0L,
                  social.male = 0L,
                  social.unknown = 0L
                ),
                row.names = c(NA,-1L),
                class = c("tbl_df", "tbl", "data.frame")
              )
            job <- multifetch_litter_offspring.count("A-001_004")
            expect_equal(ref, job)
          })

test_that("multifetch_clan_obsv.effort returns the correct output", {

  expect_equal(class(multifetch_clan_obsv.effort(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  #ref <-
  #  structure(
  #    list(
  #      effort_adult = c(34/34, 26/26),
  #      effort_cub = c(19/21, 19/21),
  #      effort_all = c(53/55, 45/47)
  #    ),
  #    row.names = c(NA,-2L),
  #    class = c("tbl_df", "tbl", "data.frame")
  #  ) ## FIXME: Was that correct?

  ref <- structure(list(effort_adult = c(1, 1),
                        effort_cub = c(1, 1),
                        effort_all = c(1, 1)),
                   row.names = c(NA, -2L),
                   class = c("tbl_df", "tbl", "data.frame"))

  #We keep the new argument just to make sure we can compare new & and old method
  job <- multifetch_clan_obsv.effort(clan = c("A", "L"), from = "1997-01-01", to = "1997-12-01")
  expect_equal(ref, job)

})


test_that("multifetch_id_birth.info works as intended", {
  ref <- structure(
    list(
      sex = c("female", "female", "male"),
      motherID = c(NA,"A-015", "A-006"),
      fatherID = c(NA, "A-045", "A-045"),
      birthdate = structure(c(6715,8906, 10088),
                            class = "Date"),
      clan.birth = c("A", "A", "A"),
      clan.conception = c(NA, "A", "A")),
    row.names = c(NA,-3L),
    class = c("tbl_df", "tbl", "data.frame"))
  job <- multifetch_id_birth.info(ID = c("A-001", "A-008", "A-100"))
  expect_equal(ref, job)
})

