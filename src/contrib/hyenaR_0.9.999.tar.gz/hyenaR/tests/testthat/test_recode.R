context("Test recode_xxx functions")

test_that("recode_offspring.sex_litter.type returns an output of the correct class", {
  expect_equal(class(recode_offspring.sex_litter.type(1, 1, 1, 1, 1, 1)), "character")
})

test_that("recode_offspring.sex_litter.type returns the correct output", {
  ref <- list(daughters.nb = 1, sons.nb = 1, unknown.nb = 1, social.daughters.nb = 1, social.sons.nb = 1, social.unknown.nb = 1)
  job <- check_function_arg.litter.type(1, 1, 1, 1, 1, 1)
  expect_equal(ref, job)
})
