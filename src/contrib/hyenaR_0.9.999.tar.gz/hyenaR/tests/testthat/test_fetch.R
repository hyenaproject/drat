context("Test fetch_xxx_yyy functions")

test_that("all fetch functions return the correct type of vector", {
  expect_equal(class(fetch_id_sex(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_id_clan.birth(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_id_date.birth(ID = c("A-080", "L-001")))[1], "Date")
  expect_equal(class(fetch_id_date.conception(ID = c("A-080", "L-001")))[1], "Date")
  expect_equal(class(fetch_id_id.mother.genetic(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_id_id.mother.social(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_id_id.father(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_id_rank.litter(ID = c("A-018", "M-007")))[1], "integer")

  expect_equal(class(fetch_id_rank.birth(ID = c("A-080")))[1], "integer")
  expect_equal(class(fetch_id_rank.birth.std(ID = c("A-080")))[1], "numeric")

  expect_equal(class(fetch_id_date.birth(ID = c("A-080", "L-001")))[1], "Date")
  expect_equal(class(fetch_id_date.selection.first(ID = c("A-011", "A-040")))[1], "Date")

  expect_equal(class(fetch_id_duration.lifespan(ID = c("A-080", "L-001")))[1], "numeric")
  expect_equal(class(fetch_id_lifestage( c("A-001", "A-001", "A-040" ), c("1988-06-10", "1989-07-12", "1996-07-12")))[1], "character")


  expect_equal(class(fetch_id_number.offspring(ID = c("A-001", "A-100", "L-003")))[1], "integer")
  expect_equal(class(fetch_id_date.conception.first(ID = c("A-001", "L-003")))[1], "Date")

  expect_equal(class(fetch_id_duration.tenure(ID = c("A-011", "A-040"), at = "1997-12-30"))[1], "numeric")

  expect_equal(class(fetch_id_age(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))[1], "numeric")
  expect_equal(class(fetch_id_age(ID = "A-080", at = c("1997-01-01", "1996-07-01")))[1], "numeric")
  expect_equal(class(fetch_id_age(ID = c("A-080", "L-001"), at = "1996-07-01"))[1], "numeric")
  expect_equal(class(fetch_id_date.at.age(ID = c("A-080", "L-001"), age = c(2, 3), unit = "week"))[1], "Date")

  expect_equal(class(fetch_id_is.immigrant(ID = c("A-080", "L-001"), at = "1997-12-30"))[1], "logical")
  expect_equal(class(fetch_id_is.native(ID = c("A-080", "L-001"), at = "1997-12-30"))[1], "logical")

  expect_equal(class(fetch_id_date.observation.first(ID = c("A-080", "L-001")))[1], "Date")

  expect_equal(class(fetch_id_date.observation.last(ID = c("A-080", "L-001")))
  [1], "Date")
  expect_equal(class(fetch_id_is.observed(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "logical")
  expect_equal(class(fetch_id_is.alive(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "logical")
  expect_equal(class(fetch_id_rank(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "integer")
  expect_equal(class(fetch_id_rank.std(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "numeric")
  expect_equal(class(fetch_id_rank.sex(ID = c("A-001", "N-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "integer")
  expect_equal(class(fetch_id_rank.sex.std(ID = c("A-001", "N-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "numeric")
  expect_equal(class(fetch_id_rank.native(ID = c("A-001", "N-001"), at = c("1997-01-01", "1996-07-01")))
               [1], "integer")
  expect_equal(class(fetch_id_rank.native.std(ID = c("A-001", "N-001"), at = c("1997-01-01", "1996-07-01")))
               [1], "numeric")
  expect_equal(class(fetch_id_clan.current(ID = c("A-080", "L-001"), at = c("1997-01-01", "1996-07-01")))
  [1], "character")
  expect_equal(class(fetch_id_is.censored.left(ID = c("A-001", "A-007")))[1], "logical")
  expect_equal(class(fetch_id_is.death.confirmed(c("A-080", "L-001")))[1], "logical")
  expect_equal(class(fetch_id_is.observable(ID = c("A-080", "L-001"), duration = 3))[1], "logical")
  expect_equal(class(fetch_id_is.selector(c("A-044", "A-044" ), c("A", "A"), c("1996-05-10", "1996-08-11")))[1], "logical")
  expect_equal(class(fetch_dyad_is.offspring(c("A-001","A-001"),c("A-010", "A-049"))),"logical")
  expect_equal(class(fetch_dyad_filiation(c("A-001","A-001"),c("A-010", "A-049"))), "character")
  expect_equal(class(fetch_litter_litter.type("A-001_004")), "character")
  expect_equal(class(fetch_litter_is.sampled.dna(litterID = c("A-001_004", "A-001_001", "A-001_004"))), "logical")
  expect_equal(class(fetch_id_is.sampled.dna(ID = c("A-011", "A-100"))), "logical")
  expect_equal(class(fetch_id_has.twin.litter(ID = c("A-001", "A-007"), to = "1997-12-30")), "logical")
  expect_equal(class(fetch_id_has.reproduced(ID = c("A-001", "A-007"), to = "1997-12-30")), "logical")
  expect_equal(class(fetch_id_is.sampled.dna(ID = c("A-003", "A-002"))), "logical")
  expect_equal(class(fetch_clan_sex.ratio.adult(clan = "A", at = "1997/01/01")), "numeric")
  expect_equal(class(fetch_pop_sex.ratio.adult(at = "1997/01/01")), "numeric")
  expect_equal(class(fetch_clan_adult.ratio(clan = "A", at = "1997/01/01")), "numeric")
  expect_equal(class(fetch_pop_adult.ratio(at = "1997/01/01")), "numeric")
  expect_equal(class(fetch_id_is.adult(ID = "A-001", at = "1997-01-01")), "logical")
  expect_equal(class(fetch_id_is.censored(ID = c("A-001", "A-007"), from = "1980-03-04", to = "1988-07-09")), "logical")
  expect_equal(class(fetch_id_is.censored.right(ID = c("A-001", "A-007"))), "logical")
  expect_equal(class(fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001")))[1], "Date")
  expect_equal(class(fetch_id_number.sighting(ID = c("A-001", "A-007"), to = "1997-12-30")), "integer")
  expect_equal(class(fetch_id_litterID(ID = c("A-010", "A-049"))), "character")
  expect_equal(class(fetch_id_number.litter(ID = "A-001")), "integer")

  expect_equal(class(fetch_dyad_interaction.winner("A-001", "A-084", "1997-04-10")), "character")
  expect_equal(class(fetch_id_follow.MRCA.choice(ID = c("A-010", "A-018"), loserID = "A-010")), "logical")
  expect_equal(class(fetch_id_is.migrant(ID = c("A-084", "A-010"), at = "1997-04-01")), "logical")
  expect_equal(class(fetch_id_is.descendant(ID = c("A-010", "A-084"), ancestorID = c("A-001"))), "logical")
  expect_equal(class(fetch_id_id.offspring.from.ancestor(ID = "A-084", ancestorID = c("A-001"))), "character")

  expect_equal(class(fetch_clan_number(clan = c("A", "L"), at = "1997/01/01"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = c("A", "L"), at = "1997/01/01"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = "A", at = "1997/01/01"))[1], "integer")

  expect_equal(class(fetch_clan_number(clan = "A"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = "A", lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-10-30", clan.overlap = "always", lifestage.overlap = "always"))[1], "integer")
  expect_equal(class(fetch_clan_number(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any"))[1], "integer")

  expect_equal(class(fetch_clan_number.anysex.dead(clan = "A", from = "1997/01/01"))[1], "integer")
  expect_equal(class(fetch_clan_number.anysex.dead(clan = "A", to = "1997/01/01"))[1], "integer")
  expect_equal(class(fetch_clan_number.anysex.dead(clan = "A", at = "1997/01/01"))[1], "integer")
  expect_equal(class(fetch_clan_number.anysex.dead(clan = "A"))[1], "integer")
  expect_equal(class(fetch_pop_number.anysex.dead())[1], "integer")
})


test_that("fetch_id_number.litter works as intended", {
  ref <- c(4L, 4L, 0L)
  job <- fetch_id_number.litter(ID = c("A-001", "A-001", "A-008"), first.event = "birthdate")
  expect_equal(ref, job)
})


test_that("fetch_id_litterID works as intended", {
  ref <- c("A-001_001", "A-003_001")
  job <- fetch_id_litterID(ID = c("A-010", "A-049"))
  expect_equal(ref, job)
})


test_that("fetch_litter_date.birth returns output as intended", {
  ref <- as.Date(c("1995-05-18", "1996-06-11"))
  job <- fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
  expect_equal(ref, job)
})


test_that("fetch_id_is.censored.left returns output as intended", {
  ref <- c(FALSE, FALSE)
  job <- fetch_id_is.censored.left(ID = c("A-001", "A-007"), at = "1980-03-04")
  expect_equal(ref, job)
})


test_that("fetch_id_is.censored.right returns output as intended", {
  ref <- c(FALSE, FALSE)
  job <- fetch_id_is.censored.right(ID = c("A-001", "A-007"), at = "1980-03-04")
  expect_equal(ref, job)
})


test_that("fetch_id_is.censored returns output as intended", {
  ref <- c(TRUE, FALSE)
  job <- fetch_id_is.censored(ID = c("A-001", "A-007"), from = "1980-03-04", to = "1988-07-09")
  expect_equal(ref, job)
})


test_that("fetch_litter_is.sampled.dna returns the output as intended", {
  ref <- c(TRUE, TRUE, TRUE)
  job <- fetch_litter_is.sampled.dna(litterID = c("A-001_004", "A-001_001", "A-001_004"))
  expect_equal(ref, job)
})


test_that(" fetch_litter_litter.type returns the correct output", {
  ref <- c("f_m")
  job <- fetch_litter_litter.type("A-001_004")
  expect_equal(ref, job)
})


test_that("fetch_dyad_filiation returns the correct output", {
  parentID <- c("A-001", "A-001")
  offspring <- c("A-010","A-049")
  ref <- c("mother_social_genetic", NA_character_)
  job <- fetch_dyad_filiation(parentID, offspring)
  expect_equal(ref, job)
})

test_that("fetch_dyad_is.offspring returns the correct output", {
  ID <- c("A-001", "A-001")
  offspring <- c("A-010","A-049")
  ref <- c(TRUE, FALSE)
  job <- fetch_dyad_is.offspring(ID, offspring)
  expect_equal(ref,job)
})

test_that("fetch_id_is.sampled.dna returns the correct output", {
  ref <- c(TRUE, FALSE)
  job <- fetch_id_is.sampled.dna(c("A-003", "A-002"))
  expect_equal(ref, job)
})

test_that("fetch_id_is.selector returns the correct output", {
  ref <- c(TRUE, FALSE)
  job <- fetch_id_is.selector( c("A-044", "A-044" ), c("A", "A"), c("1996-05-10", "1996-08-11"))
  expect_equal(ref, job)
})

test_that("fetch_id_is.death.confirmed returns the correct output", {
  ref <- c(FALSE, FALSE)
  job <- fetch_id_is.death.confirmed(c("A-001", "A-080"))
  expect_equal(ref, job)
})

test_that("fetch_id_lifestage returns the correct output", {
  ref <- c("cub","subadult","philopatric")
  job <- fetch_id_lifestage( c("A-001", "A-001", "A-040" ), c("1988-06-10", "1989-07-12", "1996-07-12"))
  expect_equal(ref, job)
})

test_that("fetch_id_has.reproduced returns the correct output", {

  ref1 <- c(TRUE, TRUE)
  job <- fetch_id_has.reproduced(ID = c("A-001", "A-007"),
                                 to = "1997-12-30", first.event = "birthdate")
  expect_equal(ref1, job)

})

test_that("fetch_id_has.twin.litter returns the correct output", {

  ref1 <- c(TRUE, FALSE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-007"), to = "1997-12-30", first.event = "birthdate")
  expect_equal(ref1, job)

})

test_that("fetch_id_number.offspring returns 0 when there is no litter", {

  ref1 <- c(6L, 1L)
  job <- fetch_id_number.offspring(ID = c("A-001", "A-007"),
                                to = "1997-12-30", first.event = "birthdate")
  expect_equal(ref1, job)
})

test_that("fetch_id_date.at.age returns the correct output", {

  ## many ID with year unit:
  ref <- structure(c(7445, 9059, 7810, 7498, 8597, 7499, 9636, 9511, 9759,
                     8869, 8740, 5745, 8232, 8568, 6308, 9998, 9755, 8614, 9598, 9690,
                     8593, 9271, 5984, 7498, 9998, 7785, 9324, 9599, 9380, 9199, 9349,
                     9343, 10217, 8264, 9652, 9592, 10000, 10388, 10398, 10177, 10264,
                     10141, 10153, 10527, 10527, 10572, 10572, 10611, 10611, 10528,
                     10586, 10718, 10550, 10754, 10754, 10794, 10794, 10818, 10219,
                     10826, 4486, 7408, 4120, 9503, 6677, 8503, 4851, 8138, 8139,
                     9660, 9568, 7042, 9599, 9509, 9600, 8503, 7773, 7042, 8138, 9503,
                     9504, 9868, 8503, 8869, 9958, 10364, 10364, 10111, 10112, 10358,
                     10358, 10373, 10373, 10049, 10080, 10387, 10403, 10403, 10382,
                     10626, 10648, 10688, 10688, 10695, 10691, 10691, 10712, 10712,
                     10758, 10758, 10912, 10912, 10956, 10956, 10952, 4912, 9416,
                     9417, 9235, 8869, 7879, 9511), class = "Date")
  job <- fetch_id_date.at.age(find_pop_id(), age = 2, unit = "year")
  expect_equal(ref, job)

  ## many ID with month unit:
  ref <- structure(c(6775, 8389, 7140, 6828, 7927, 6829, 8966, 8841, 9089,
                     8199, 8070, 5075, 7562, 7898, 5638, 9328, 9085, 7944, 8928, 9020,
                     7923, 8601, 5314, 6828, 9328, 7115, 8654, 8929, 8710, 8529, 8679,
                     8673, 9547, 7594, 8982, 8922, 9330, 9718, 9728, 9507, 9594, 9471,
                     9483, 9857, 9857, 9902, 9902, 9941, 9941, 9858, 9916, 10048,
                     9880, 10084, 10084, 10124, 10124, 10148, 9549, 10156, 3816, 6738,
                     3450, 8833, 6007, 7833, 4181, 7468, 7469, 8990, 8898, 6372, 8929,
                     8839, 8930, 7833, 7103, 6372, 7468, 8833, 8834, 9198, 7833, 8199,
                     9288, 9694, 9694, 9441, 9442, 9688, 9688, 9703, 9703, 9379, 9410,
                     9717, 9733, 9733, 9712, 9956, 9978, 10018, 10018, 10025, 10021,
                     10021, 10042, 10042, 10088, 10088, 10242, 10242, 10286, 10286,
                     10282, 4242, 8746, 8747, 8565, 8199, 7209, 8841), class = "Date")

  job <- fetch_id_date.at.age(find_pop_id(), age = 2, unit = "month")
  expect_equal(ref, job)
})


test_that("fetch_clan/pop_sex.ratio returns expected values", {

  #Single input
  ref1 <- 16/31
  job1 <- fetch_clan_sex.ratio.adult(clan = "A", at = "1997/01/01")
  expect_equal(ref1, job1)

  #Multiple input (checks for reordering and duplication)
  ref2 <- c(8/21, 16/31, 8/21)
  job2 <- fetch_clan_sex.ratio.adult(clan = c("L", "A", "L"),
                               at = c("1997/01/01", "1997/01/01", "1997/01/01"))
  expect_equal(ref2, job2)

  #Population level
  ref3 <-  c(27/56, 27/56, 27/56)
  job3 <- fetch_pop_sex.ratio.adult(at = c("1997/06/01", "1997/01/01", "1997/06/01"))

  expect_equal(ref3, job3)

})

test_that("fetch_clan/pop_adult.ratio returns expected values", {

  #Single input
  ref1 <- 31/47
  job1 <- fetch_clan_adult.ratio(clan = "A", at = "1997/01/01")
  expect_equal(ref1, job1)

  #Multiple input (checks for reordering and duplication)
  ref2 <- c(21/34, 31/47, 21/34)
  job2 <- fetch_clan_adult.ratio(clan = c("L", "A", "L"),
                               at = c("1997/01/01", "1997/01/01", "1997/01/01"))
  expect_equal(ref2, job2)

  #Pop function
  ref3 <- c(2/7, 56/85, 2/7)
  job3 <- fetch_pop_adult.ratio(at = c("1997/12/01", "1997/01/01", "1997/12/01"))
  expect_equal(ref3, job3)

})

test_that("fetch_id_is.adult returns expected values", {

  #Works with single input
  ref1 <- c(TRUE)
  job1 <- fetch_id_is.adult(ID = "A-001", at = "1997-01-01")
  expect_equal(ref1, job1)

  #Works with multiple individuals and one date
  ref2 <- c(FALSE, TRUE)
  job2 <- fetch_id_is.adult(ID = c("A-018", "A-001"), at = "1997-01-01")
  expect_equal(ref2, job2)

  #Works with multiple individuals and multiple date
  ref3 <- c(FALSE, TRUE)
  job3 <- fetch_id_is.adult(ID = c("A-018", "A-001"), at = c("1996-01-01", "1997-01-01"))
  expect_equal(ref3, job3)

  #Returns warning and NA when individual has died
  ref4 <- c(NA, TRUE)
  expect_warning(job4 <- fetch_id_is.adult(ID = c("A-007", "A-001"), at = c("1997-11-01", "1997-01-01")))
  expect_equal(ref4, job4)

})

test_that("fetch_id_duration.tenure returns expected values", {
  #Returns NA if ID is female
  ref1 <- c(NaN)
  job1 <- fetch_id_duration.tenure(ID = "A-001", at = "1990-07-10")
  expect_equal(ref1, job1)

  #Works with single input
  ref2 <- c(1.00)
  job2 <- round(fetch_id_duration.tenure(ID = "A-040", at = "1997-07-10"), 2)
  expect_equal(ref2, job2)

  #Works with multiple individual with single date
  ref3 <- c(1.00, 1.24)
  job3 <- round(fetch_id_duration.tenure(ID = c("A-040", "M-053"), at = "1997-07-10"), 2)
  expect_equal(ref3, job3)

  #Works with multiple individual with multiple date
  ref4 <- c(1.00, 1.44)
  job4 <- round(fetch_id_duration.tenure(ID = c("A-040", "M-053"), at = c("1997-07-10", "1997-09-20")), 2)
  expect_equal(ref4, job4)

})

test_that("fetch_id_number.sighting returns expected output", {

  #Single input
  ref1 <- 28L
  job1 <- fetch_id_number.sighting(ID = "A-001", to = "1997-12-30")
  expect_equal(ref1, job1)

  #Multiple inputs (check for reordering and duplicates)
  ref2 <- c(11L, 20L, 11L)
  job2 <- fetch_id_number.sighting(ID = c("A-002", "A-001", "A-002"),
                                   from = c("1997-02-01", "1997-01-01", "1997-02-01"),
                                   to = c("1997-12-30", "1997-12-30", "1997-12-30"))
  expect_equal(ref2, job2)

})

test_that("fetch_id_has.sighting returns expected output", {

  #Single input
  ref1 <- TRUE
  job1 <- fetch_id_has.sighting(ID = "A-001", to = "1997-12-30")
  expect_equal(ref1, job1)

  #Multiple inputs (check for reordering and duplicates)
  ref2 <- c(FALSE, TRUE, FALSE)
  job2 <- fetch_id_has.sighting(ID = c("A-007", "A-001", "A-007"),
                                   from = c("1997-01-01", "1997-01-01", "1997-01-01"),
                                   to = c("1997-02-01", "1997-12-30", "1997-02-01"))
  expect_equal(ref2, job2)

})


test_that("fetch_id_clan.current returns expected output", {

  #Single individual
  ref <- "A"
  job <- fetch_id_clan.current(ID = "A-080", at = "1997-01-04")
  expect_equal(ref, job)

  #Multiple individuals same date
  ref2 <- c("A", "S")
  job2 <- fetch_id_clan.current(ID = c("A-080", "S-043"), at = "1997-01-04")
  expect_equal(ref2, job2)

  #Multiple individuals different dates
  ref3 <- c("A", "S")
  job3 <- fetch_id_clan.current(ID = c("A-080", "S-043"),
                                at = c("1997-01-04", "1997-01-05"))
  expect_equal(ref3, job3)

  #Duplicate/unordered records
  ref4 <- c("A", "S", "A")
  job4 <- fetch_id_clan.current(ID = c("A-080", "S-043", "A-080"),
                                at = c("1997-01-04", "1994-02-01", "1997-01-04"))
  expect_equal(ref4, job4)

  #If removing right censoring
  ref5 <- c("A", NA_character_)
  job5 <- fetch_id_clan.current(ID = c("A-080", "S-043"),
                                at = c("1997-01-04", "1997-07-01"), censored.to.last.clan = FALSE)
  expect_equal(ref5, job5)

  #If date is missing
  expect_error(fetch_id_clan.current(ID = "A-080"))

})

test_that("fetch_id_is.dummy output is correct", {
  expect_true(all(fetch_id_is.dummy(find_pop_id())))
})


test_that("fetch_function_is.defunct output is correct", {
  ref <- c(TRUE, FALSE)
  job <- fetch_function_is.defunct(c(fetch_sex, fetch_id_sex))
  expect_equal(ref, job)
})


test_that("fetch_id_number.offspring returns different output for different time periods", {
  ref <- c(3L, 3L, 0L, 2L)
  job <-  fetch_id_number.offspring(ID = c("A-001", "A-001", "L-002", "L-002"),
                                    from = c("1994-09-21", "1995-10-08", "1994-06-20", "1995-10-01"),
                                    to = c("1995-05-20", "1996-12-15", "1994-07-20", "1997-04-08"))
  expect_equal(ref, job)
})

test_that("fetch_clan_number runs under different settings",{
  ref2 <- rep(51, 20)
  ref3 <- rep(58, 20)

  job2 <- fetch_clan_number(clan = rep("A", 20), lifestage = NULL, at = NULL, from = NULL, to = NULL,
                            clan.overlap = "any", lifestage.overlap = "any",
                            CPUcores = 2, .parallel.min = 10, verbose = TRUE)

  job3 <- fetch_clan_number(clan = rep("A", 20), lifestage = NULL, at = NULL, from = "1997/01/01", to = "1997/12/30",
                            clan.overlap = "any", lifestage.overlap = "any",
                            CPUcores = 1, .parallel.min = 1000, verbose = TRUE)

  expect_equal(ref2, job2)
  expect_equal(ref3, job3)
})

test_that("fetch_dyad_interaction.winner output is correct", {
  ref <- "A-001"
  job <- fetch_dyad_interaction.winner("A-001", "A-084", "1997-04-10")
  expect_equal(ref, job)
})

test_that("fetch_id_follow.MRCA.choice output is correct", {
  ref <- c(FALSE, TRUE)
  job <- fetch_id_follow.MRCA.choice(ID = c("A-010", "A-018"), loserID = "A-010")
  expect_equal(ref, job)
})

test_that("fetch_id_is.migrant output is correct", {
  ref <- c(FALSE, FALSE)
  job <- fetch_id_is.migrant(ID = c("A-084", "A-010"), at = "1997-04-01")
  expect_equal(ref, job)
})

test_that("fetch_id_is.descendant output is correct", {
  ref <- c(TRUE, TRUE)
  job <- fetch_id_is.descendant(ID = c("A-010", "A-084"), ancestorID = c("A-001"))
  expect_equal(ref, job)
})

test_that("fetch_id_id.offspring.from.ancestor output is correct", {
  ref <- "A-084"
  job <- fetch_id_id.offspring.from.ancestor(ID = "A-084", ancestorID = c("A-001"))
  expect_equal(ref, job)
})


test_that("fetch_id_id.mate output is correct", {
  ref <-
    list(
      `A-001` = "A-045",
      `A-002` = "A-011",
      `A-003` = character(0),
      `A-004` = character(0),
      `A-006` = "A-045",
      `A-007` = character(0),
      `A-008` = character(0),
      `A-009` = character(0),
      `A-010` = character(0),
      `A-011` = c("A-002", "A-016"),
      `A-013` = "A-050",
      `A-014` = "A-051",
      `A-015` = "A-045",
      `A-016` = "A-011",
      `A-017` = character(0),
      `A-018` = character(0),
      `A-019` = character(0),
      `A-020` = character(0),
      `A-040` = character(0),
      `A-041` = character(0),
      `A-042` = character(0),
      `A-043` = character(0),
      `A-044` = character(0),
      `A-045` = c("A-015", "A-001", "A-006"),
      `A-046` = character(0),
      `A-047` = character(0),
      `A-048` = character(0),
      `A-049` = character(0),
      `A-050` = "A-013",
      `A-051` = "A-014",
      `A-052` = character(0),
      `A-053` = character(0),
      `A-054` = character(0),
      `A-055` = character(0),
      `A-056` = character(0),
      `A-057` = character(0),
      `A-058` = character(0),
      `A-080` = character(0),
      `A-081` = character(0),
      `A-082` = character(0),
      `A-083` = character(0),
      `A-084` = character(0),
      `A-085` = character(0),
      `A-086` = character(0),
      `A-087` = character(0),
      `A-088` = character(0),
      `A-089` = character(0),
      `A-090` = character(0),
      `A-091` = character(0),
      `A-092` = character(0),
      `A-093` = character(0),
      `A-094` = character(0),
      `A-095` = character(0),
      `A-096` = character(0),
      `A-097` = character(0),
      `A-098` = character(0),
      `A-099` = character(0),
      `A-100` = character(0),
      `A-113` = character(0),
      `A-114` = character(0),
      `L-001` = character(0),
      `L-002` = c("L-043", "L-047", "L-041"),
      `L-003` = "L-043",
      `L-004` = c("L-047", "L-040"),
      `L-005` = c("L-043", "L-042"),
      `L-006` = character(0),
      `L-007` = c("L-042", "L-043"),
      `L-008` = c("L-047", "L-040"),
      `L-009` = "L-041",
      `L-010` = character(0),
      `L-011` = character(0),
      `L-012` = "L-042",
      `L-013` = "L-047",
      `L-014` = "L-042",
      `L-015` = "L-047",
      `L-040` = c("L-004", "L-008"),
      `L-041` = c("L-009", "L-002"),
      `L-042` = c("L-007", "L-012", "L-014", "L-005"),
      `L-043` = c("L-002", "L-005", "L-007", "L-003"),
      `L-044` = character(0),
      `L-045` = character(0),
      `L-046` = character(0),
      `L-047` = c("L-008", "L-004", "L-013", "L-002", "L-015"),
      `L-048` = character(0),
      `L-049` = character(0),
      `L-080` = character(0),
      `L-081` = character(0),
      `L-082` = character(0),
      `L-083` = character(0),
      `L-084` = character(0),
      `L-085` = character(0),
      `L-086` = character(0),
      `L-087` = character(0),
      `L-088` = character(0),
      `L-089` = character(0),
      `L-090` = character(0),
      `L-091` = character(0),
      `L-092` = character(0),
      `L-093` = character(0),
      `L-094` = character(0),
      `L-095` = character(0),
      `L-096` = character(0),
      `L-097` = character(0),
      `L-098` = character(0),
      `L-099` = character(0),
      `L-100` = character(0),
      `L-101` = character(0),
      `L-102` = character(0),
      `L-103` = character(0),
      `L-104` = character(0),
      `L-105` = character(0),
      `L-106` = character(0),
      `L-108` = character(0),
      `L-109` = character(0),
      `L-110` = character(0),
      `M-004` = character(0),
      `M-047` = character(0),
      `M-051` = character(0),
      `M-053` = character(0),
      `N-043` = character(0),
      `S-002` = character(0),
      `S-043` = character(0)
    )
  job1 <- fetch_id_id.mate(find_pop_id())
  job2 <- fetch_id_id.mate(find_pop_id(), CPUcores = 2, .parallel.min = 0)  ## same in parallel

  expect_equal(ref, job1)
  expect_equal(ref, job2)
})

test_that("fetch_id_date.conception works as intended", {
  ref <- structure(c(6605, 6659), class = "Date")
  job <- fetch_id_date.conception(ID = c("A-001", "A-007"))
  expect_equal(ref, job)
})

test_that("fetch_clan_number return the correct output", {

  job1 <- fetch_clan_number(clan = find_clan_name.all(main.clans = FALSE))
  job2 <- fetch_clan_number(clan = "A")
  job3 <- fetch_clan_number(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
  job4 <- fetch_clan_number(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start")
  job5 <- fetch_clan_number(clan = "A", lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  job6 <- fetch_clan_number(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-01-30", clan.overlap = "always", lifestage.overlap = "always")
  job7 <- fetch_clan_number(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any")
  job8 <- fetch_clan_number(sex = "female", clan = "A")

  ref1 <- c(51L, 49L, 4L, 1L, 2L, 15L)
  ref2 <- 51L
  ref3 <- 13:12
  ref4 <- 31L
  ref5 <- c(5L, 3L)
  ref6 <- 16L
  ref7 <- 18L
  ref8 <- 23L

  expect_equal(job1, ref1)
  expect_equal(job2, ref2)
  expect_equal(job3, ref3)
  expect_equal(job4, ref4)
  expect_equal(job5, ref5)
  expect_equal(job6, ref6)
  expect_equal(job7, ref7)
  expect_equal(job8, job8)

})


test_that("fetch_clan/pop_number.anysex.adult returns the correct output", {

  ref1 <- 31L
  job1 <- fetch_clan_number.anysex.adult(clan = "A", at = "1997-01-01")
  expect_equal(ref1, job1)

  ref2 <- 56L
  job2 <- fetch_pop_number.anysex.adult(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)

})

test_that("fetch_clan/pop_number.female.adult returns the correct output", {

  ref1 <- 15L
  job1 <- fetch_clan_number.female.adult(clan = "A", at = "1997-01-01")
  expect_equal(ref1, job1)

  ref2 <- 29L
  job2 <- fetch_pop_number.female.adult(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)

})

test_that("fetch_clan/pop_number.anysex.immigrant returns the correct output", {

  ref1 <- 8L
  job1 <- fetch_clan_number.anysex.immigrant(clan = "A", at = "1997-01-01")
  expect_equal(ref1, job1)

  ref2 <- 13L
  job2 <- fetch_pop_number.anysex.immigrant(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)

  expect_error(find_clan_id.immigrant(clan = c("A", "A"), at = "1997-01-01"))

})

test_that("fetch_clan/pop_number.male.all returns the correct output", {

  ref1 <- 28L
  job1 <- fetch_clan_number.male.all(clan = "A", at = "1997-01-01")
  expect_equal(ref1, job1)

  ref2 <- 48L
  job2 <- fetch_pop_number.male.all(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)

})


test_that("fetch_clan/pop_number.anysex.dead returns the correct output", {

  ref1 <- 5L
  job1 <- fetch_clan_number.anysex.dead(clan = "A", to = "1997-01-01")
  expect_equal(ref1, job1)

  ref2 <- 12L
  job2 <- fetch_pop_number.anysex.dead(to = "1997-01-01")
  expect_equal(ref2, job2)

})


test_that("fetch_pop/clan_number.XXX that should return no individuals do so", {
  ref <- 0L
  expect_equal(ref, fetch_pop_number.female.disperser())
  expect_equal(ref, fetch_pop_number.female.transient())
  expect_equal(ref, fetch_pop_number.female.natal())
})

test_that("find_pop/clan_xxx that return correct individuals when using lifestage.overlap", {

  ref <- 11L
  job <- fetch_pop_number.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "any")
  expect_equal(ref, job)

  ref <- 5L
  job <- fetch_pop_number.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "start")
  expect_equal(ref, job)

  ref <- 3L
  job <- fetch_pop_number.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "end")
  expect_equal(ref, job)

  ref <- 3L
  job <- fetch_pop_number.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "always")
  expect_equal(ref, job)

  ref <- 0L
  job <- fetch_pop_number.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "within")
  expect_equal(ref, job)

})

test_that("fetch_clan_number.xxx that return correct individuals when using clan.overlap", {

  ref <- 8L
  job <- fetch_clan_number.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "any")
  expect_equal(ref, job)

  ref <- 5L
  job <- fetch_clan_number.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "start")
  expect_equal(ref, job)

  ref <- 3L
  job <- fetch_clan_number.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "end")
  expect_equal(ref, job)

  ref <- 0L
  job <- fetch_clan_number.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "always")
  expect_equal(ref, job)

  ref <- 0L
  job <- fetch_clan_number.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "within")
  expect_equal(ref, job)

})

test_that("fetch_clan_number and fetch_pop_number are equivalent", {
  expect_equal(fetch_clan_number(list(find_clan_name.all(main.clans = FALSE))), fetch_pop_number())
})
