#' Generate starting data for the downstream analysis
#'
#' These functions generate the starting data according to
#' the clan, time, or life stage specified.
#'
#' @inheritParams arguments
#' @name starting_data
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL



#' @describeIn starting_data Create a table of unique hyenas based on their ID or clan, life stage, and time.
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_id_starting.table usage:
#' create_id_starting.table(c("A-001", "L-003", "A-100"))
#'
#' # create table with all the individuals
#' create_id_starting.table()
#'
#' # create table with all the individuals that were born in clan A
#' create_id_starting.table(clan = "A")
#'
#' # create a table with all the females that were born in clan A
#' create_id_starting.table(sex = "female", clan = "A")
#'
#' # create table with individuals that were philopatric in clan A and L on 1996-04-12
#' create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
#'
#' # create table with individuals that start their membership in clan A from
#' # 1996-04-12 to 1997-12-30
#' create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30",
#'                          clan.overlap = "start")
#'
#' # create table with individuals that becomes selector for the first time from
#' # 1996-04-12 to 1997-12-30
#' create_id_starting.table(lifestage = c("philopatric", "disperser"),
#'                          from = "1996-04-12", to = "1997-12-30",
#'                          lifestage.overlap = "start")
#'
#' # create table with individuals that were philopatric in clan A for the whole period from
#' # 1996-12-01 to 1997-10-30
#' create_id_starting.table(clan = "A", lifestage = "philopatric",
#'                          from = "1996-12-01", to = "1997-10-30",
#'                          clan.overlap = "always", lifestage.overlap = "always")
#'
#' # create table with individuals that were present as philopatric in clan A for
#' # sometime during 2000-01-01 to 2002-02-01
#' create_id_starting.table(clan = "A", lifestage = "philopatric",
#'                          from = "1996-04-12", to = "1997-12-30",
#'                          clan.overlap = "any", lifestage.overlap = "any")

create_id_starting.table <- function(ID = NULL, sex = NULL, clan = NULL, lifestage = NULL, from = NULL, to = NULL, at = NULL,
                                     clan.overlap = 'any', lifestage.overlap = 'any',
                                     verbose = TRUE) {

  # Sex is needed for filtering even if no dates provided so should be checked here

  messages <- vector()

  if (!is.null(ID)) {

    if (!(is.null(c(sex, clan, lifestage, from, to, at)) && clan.overlap == 'any' && lifestage.overlap == 'any')) {

      messages <- append(messages, "When ID is provided other arguments are ignored. \n")

    }

    tibble::tibble(ID = check_function_arg.ID(ID)) -> output

  } else {

    ## Check sex This will be needed in all circumstances
    sex <- check_function_arg.sex(sex, fill = TRUE)

    ## Check clan. This will be needed in all circumstances
    clan_null <- is.null(clan)
    clan      <- check_function_arg.clan(clan, fill = TRUE, main.clans = FALSE)

    #If no date information is given, simply return all individuals from in the focal clans
    if (all(is.null(lifestage), is.null(from), is.null(to), is.null(at)) && clan.overlap == "any" && lifestage.overlap == "any") {

      messages <- append(messages, "No date information provided. Returning only individuals born in the focal clans. \n")

      extract_database_table("hyenas") %>%
        dplyr::filter(.data$birthclan %in% !!clan & .data$sex %in% !!sex) -> output

      message(messages, appendLF = FALSE)

      output %>%
        dplyr::select(.data$ID) %>%
        dplyr::arrange(.data$ID) -> output

      return(output)
    }

    #If date information is provided, other arguments are relevant
    lifestage           <- check_function_arg.lifestage(lifestage, fill = TRUE)
    clan.overlap      <- check_function_arg.overlap(clan.overlap)
    lifestage.overlap <- check_function_arg.overlap(lifestage.overlap)
    date_range          <- check_function_arg.date.fromtoat(from = from, to = to, at = at, fill = TRUE,
                                                            max.date = find_pop_date.observation.last(),
                                                            min.date = find_pop_date.birth.first(), arg.max.length = 1)
    from                 <- date_range$from
    to                   <- date_range$to

    if (from >= (find_pop_date.observation.last() - lubridate::years(1))) {

      messages <- append(messages, "You are searching for individuals less than a year before the last observation date. Individuals with unknown fate may be missing from the output. \n")

    }

    create_id_life.history.table(censored.to.last.sighting = TRUE) %>%
      dplyr::mutate(sex = fetch_id_sex(.data$ID)) %>%
      dplyr::filter(.data$clan %in% !!clan & .data$life_stage %in% !!lifestage & .data$sex %in% !!sex) -> life_history

    #If at is provided (or from and to are the same) then we ignore the overlap arguments
    if (from == to && (lifestage.overlap != "any" || clan.overlap != "any")) {

      messages <- append(messages, "'clan.overlap' or 'lifestage.overlap' is ignored because 'at' is specified \n")

      lifestage.overlap <- "any"
      clan.overlap      <- "any"

    }

    ## filtering by the lifestage.overlap
    ## start: the starting date of life stage falls in the focal period
    if (lifestage.overlap == "start") {
      life_history %>%
        dplyr::filter(.data$starting_date >= !!from & .data$starting_date <= !!to) -> output_raw
    }
    ## end: the ending date of life stage falls in the focal period
    else if (lifestage.overlap == "end") {
      life_history %>%
        dplyr::filter(.data$ending_date >= !!from & .data$ending_date <= !!to) -> output_raw
    }
    ## within: the interval of the life stage falls completely inside the focal period
    else if (lifestage.overlap == "within") {
      life_history %>%
        dplyr::filter(.data$starting_date >= !!from & .data$ending_date <= !!to) -> output_raw
    }
    ## always: the focal period falls completely inside the interval of the life stage
    else if (lifestage.overlap == "always") {
      life_history %>%
        dplyr::filter(.data$starting_date <= !!from &  .data$ending_date >= !!to) -> output_raw
    }
    ## any: any overlap between the focal period and interval of the life stage
    else {
      life_history %>%
        dplyr::filter((.data$starting_date >= !!from & .data$starting_date <= !!to) | (.data$ending_date >= !!from & .data$ending_date <= !!to) | (!!from >= .data$starting_date &  !!to <= .data$ending_date)) -> output_raw
    }

    if (nrow(output_raw) > 0) {

      ## filtering by the clan.overlap
      ## merge individuals' staying in a single clan
      output_raw %>%
        dplyr::group_by(.data$ID, .data$clan) %>%
        dplyr::summarise(
          clan_starting_date = min(.data$starting_date),
          clan_ending_date = max(.data$ending_date)) %>%
        dplyr::ungroup() -> output_clan_summary

      ## start: the starting date in the clan falls in the focal period
      if (clan.overlap == "start") {
        output_clan_summary %>%
          dplyr::filter(.data$clan_starting_date >= !!from & .data$clan_starting_date <= !!to) -> output
      }
      ## end: the ending date in the clan falls in the focal period
      else if (clan.overlap == "end") {
        output_clan_summary %>%
          dplyr::filter(.data$clan_ending_date >= !!from & .data$clan_ending_date <= !!to) -> output
      }
      ## within: the interval within the clan falls completely inside the focal period
      else if (clan.overlap == "within") {
        output_clan_summary %>%
          dplyr::filter(.data$clan_starting_date >= !!from & .data$clan_ending_date <= !!to) -> output
      }
      ## always: the focal period falls completely inside the interval within the clan
      else if (clan.overlap == "always") {
        output_clan_summary %>%
          dplyr::filter(.data$clan_starting_date <= !!from & .data$clan_ending_date >= !!to ) -> output
      }
      ## any: any overlap between the focal period and interval within the clan
      else {
        output_clan_summary %>%
          dplyr::filter((.data$clan_starting_date >= !!from & .data$clan_starting_date <= !!to) | (.data$clan_ending_date >= !!from & .data$clan_ending_date <= !!to) | (!!from >= .data$clan_starting_date &  !!to <= .data$clan_ending_date)) -> output
      }

    } else {

      output <- output_raw

    }

  }

  if (verbose && length(messages) > 0) { message(messages, appendLF = FALSE) }

  output %>%
    dplyr::select(.data$ID) %>%
    dplyr::arrange(.data$ID) %>%
    dplyr::distinct(.data$ID)

}




#' Fetch the individuals in a given clan fulfilling multiple conditions
#'
#' This function is a flexible function to retrieve individuals fulfilling
#' a wide range of criterion.
#'
#' @inheritParams arguments
#' @return a list of IDs
#' @export
#'
#' @examples
#' load_package_database.dummy()
#' fetch_clan_id(clan = c("A", "A"), lifestage = c("philopatric", "cub"),
#'              from = "1996-04-12", to = "1997-12-30",
#'              clan.overlap = "any", lifestage.overlap = "any")
#'
#' if(require("dplyr")) {
#' tibble(clan = c("A", "A"),
#'       lifestage = c("philopatric", "cub"),
#'       from = "1996-04-12", to = "1997-12-30",
#'       clan.overlap = "any",
#'       lifestage.overlap = "any") %>%
#'       mutate(id = fetch_clan_id(clan = clan, lifestage = lifestage,
#'                                 from = from, to = to,
#'                                 clan.overlap = clan.overlap,
#'                                 lifestage.overlap = lifestage.overlap))
#' }
#'
#' ## Note that the previous examples create different ID vectors for
#' ## philopatric and cub.
#' ## If instead you want for example ID for both philopatric and cub lifestages
#' ## combined within clans, you need to define a list column for defining the
#' ## lifestage:
#'
#' fetch_clan_id(clan = c("A", "L"),
#'              lifestage = list(c("philopatric", "cub"),
#'                               c("philopatric", "cub")),
#'              from = "1996-04-12", to = "1997-12-30",
#'              clan.overlap = "any", lifestage.overlap = "any")
#'
fetch_clan_id <- function(clan = NULL, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                          clan.overlap = "any", lifestage.overlap = "any", CPUcores = NULL,
                          .parallel.min = 1000) {

  ## no test needed as tested within find_clan_id which is called below

  input <- tibble::tibble(clan = !!clan,
                          sex = !!sex,
                          lifestage = !!lifestage,
                          at = !!at,
                          from = !!from,
                          to = !!to,
                          clan.overlap = !!clan.overlap,
                          lifestage.overlap = !!lifestage.overlap,
                          verbose = FALSE)

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if(is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## Before we loop, we want to make sure the cache exists, otherwise, each iteration of a parallel loop would build its own cache.
  if (!"life_history" %in% find_package_cached.table()) {
    create_id_life.history.table() ## trigger caching
  }

  ## We loop ## TODO: we should loop only on unique combination, but we need a general wrapper for that...
  if (CPUcores > 1 && nrow(input) >= .parallel.min) {
    furrr::future_pmap(input, ~ do.call("find_clan_id", list(...)),
                       .progress = TRUE,
                       .options = furrr::future_options(globals = ".database"))
  } else {
    if(CPUcores > 1 && (nrow(input) < .parallel.min)) message("Argument CPUcores ignored as less than 1000 cases to compute.")
    purrr::pmap(input, ~ unique(do.call("find_clan_id", list(...))))
  }
}


