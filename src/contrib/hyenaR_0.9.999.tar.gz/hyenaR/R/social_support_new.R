#' @describeIn create_family create a table with the type of interaction between ID.1 and ID.2.
#'
#' @return Returns a 7 columns data frame with ID.1, ID.2, date, ID.1_life_stage, ID.2_life_stage, mrcaID, and type of interaction.
#' @export
#' @examples
#' create_dyad_interaction.type(ID.1 = "A-084", ID.2 = "A-001", "1997-04-01")
#'
create_dyad_interaction.type <- function(ID.1, ID.2, at) {

  input <- tibble::tibble(ID.1 = check_function_arg.ID(ID.1),
                          ID.2 = check_function_arg.ID(ID.2),
                          date = check_function_arg.date(at))

  output <- input %>%
    dplyr::distinct() %>%
    dplyr::mutate(ID.1_is_migrant = fetch_id_is.migrant(ID.1, at),
                  ID.2_is_migrant = fetch_id_is.migrant(ID.2, at),
                  mrcaID = purrr::map2_chr(ID.1, ID.2, find_dyad_id.ancestor.MRCA, filiation = "mother_social"),
                  type = dplyr::case_when(.data$ID.1_is_migrant & .data$ID.2_is_migrant ~ "migrant_migrant",
                                         !.data$ID.1_is_migrant & .data$ID.2_is_migrant ~ "native_migrant",
                                         .data$ID.1_is_migrant & !.data$ID.2_is_migrant ~ "migrant_native",
                                         !.data$ID.1_is_migrant & !.data$ID.2_is_migrant & !(is.na(.data$mrcaID)) ~ "native_related",
                                         !.data$ID.1_is_migrant & !.data$ID.2_is_migrant  & is.na(.data$mrcaID) ~ "native_unrelated",
                                         TRUE ~ NA_character_))

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = c("ID.1", "ID.2", "date"),
                        duplicates = "none")
}

#################################################################################

#' @describeIn find_family find the winner of an interaction between two migrants
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.migrant <- function(ID.1, ID.2, at){
  out <- fetch_id_duration.tenure(ID = c(ID.1, ID.2), at = at) ## the longest tenure wins

  if (out[1] > out[2]) winner <- ID.1
  else if (out[1] < out[2]) winner <- ID.2
  else winner <- NA

  winner
}

#################################################################################

#' @describeIn find_family find the winner of an interaction between a native and an migrant.
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.migrant <- function(nativeID, migrantID){
  nativeID ## the native wins
}

#################################################################################

#' Find the winner of interaction between two unrelated natives.
#'
#' @describeIn find_family find the winner of an interaction between two unrelated natives.
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.unrelated <- function(ID.1, ID.2, date){  ## remove the cubs ?

  clan <- fetch_id_clan.current(ID.1, date) ## slow

  input <- create_id_starting.table(clan = clan, at = date)

  output <- input %>%
    dplyr::rowwise() %>%
    dplyr::mutate(relat_ID.1 = find_dyad_relatedness(ID.1 = .data$ID, ID.2 = {{ID.1}}, filiation = "mother_social"), ### TODO try with a relat matrix
                  relat_ID.2 = find_dyad_relatedness(ID.1 = .data$ID, ID.2 = {{ID.2}}, filiation = "mother_social"))

  ID.1_sup <- sum(!is.na(output$relat_ID.1))
  ID.2_sup <- sum(!is.na(output$relat_ID.2))

  if (ID.1_sup > ID.2_sup) winner <- ID.1  ## the one with the most relatives wins
  else if (ID.1_sup < ID.2_sup) winner <- ID.2
  else winner <- NA

  winner
}

#################################################################################

#' Find the winner of interaction between two related natives.
#'
#' @describeIn find_family find the winner of an interaction between two related natives.
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.related <- function(ID.1, ID.2){

     find_dyad_MRCA.choice(ID.1, ID.2) ## the one supported by the MRCA wins
}

#################################################################################

#' @describeIn find_family find the winner of an interaction.
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_interaction.winner.from.interaction.type <- function(ID.1, ID.2, at, interaction.type){

  if (interaction.type == "native_related") winner <- find_dyad_winner.native.related(ID.1, ID.2) ## MRCA youngest ascendency
  else if (interaction.type == "native_unrelated") winner <- find_dyad_winner.native.unrelated(ID.1, ID.2, at) ## relatedness
  else if (interaction.type == "migrant_migrant") winner <- find_dyad_winner.migrant(ID.1, ID.2, date) ## tenure
  else if (interaction.type == "migrant_native") winner <- find_dyad_winner.native.migrant(nativeID = ID.2, migrantID = ID.1) ## clan members
  else if (interaction.type == "native_migrant") winner <- find_dyad_winner.native.migrant(nativeID = ID.1, migrantID = ID.2) ## clan memebers
  else NA
}

#################################################################################

#' @describeIn fetch_family fetch the winner of an interaction.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' fetch_dyad_interaction.winner("A-001", "A-084", "1997-04-10")
fetch_dyad_interaction.winner <- function(ID.1, ID.2, at){

  input_tbl <- create_dyad_interaction.type(ID.1, ID.2, at)

  output_tbl <- input_tbl %>%
    dplyr::rowwise() %>%
    dplyr::mutate(winner = find_dyad_interaction.winner.from.interaction.type(ID.1 = .data$ID.1, ID.2 = .data$ID.2, at = .data$date, interaction.type = .data$type))

  check_function_output(input_tbl,
                        output_tbl,
                        join.by = c("ID.1", "ID.2", "date"),
                        duplicates = "none",
                        output.IDcolumn = "winner")
}

#################################################################################

#' @describeIn find_family find the supported individual from the MRCA.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' find_dyad_MRCA.choice("A-001", "A-084")
find_dyad_MRCA.choice <- function(ID.1, ID.2){

  ID.1 <- check_function_arg.ID(ID.1, arg.max.length = 1)
  ID.2 <- check_function_arg.ID(ID.2, arg.max.length = 1)

  MRCA <- find_dyad_id.ancestor.MRCA(ID.1, ID.2, filiation = "mother_social") ## can pass filiation as an argument filiation if wanted

  if (is.na(MRCA)) { ## no common ancestor ### can be removed if function work only on related IDs.
    winner <- NA

  } else {## check which of the daughter of the MRCA is the youngest (will be supported by the MRCA)

      if (fetch_id_is.descendant(ID.1, ID.2)) winner <- ID.2 ## if ID.1 is descendant of ID.2 ID.2 wins
      else if (fetch_id_is.descendant(ID.2, ID.1)) winner <- ID.1 ## if ID.2 is descendant of ID.1 ID.1 wins
      else winner <- find_id_id.descendant.of.youngest.offspring(c(ID.1, ID.2), MRCA) ## winner is the descendant of the youngest
  }
  winner
}


#################################################################################

#' @describeIn create_family creates a table with bystander and their information relatively to the interacting parties.
#'
#' @return A character string. The winner of the interaction.
#' @export
#' @examples
#' create_dyad_table.bystander("A-001", "A-084", "1997-04-10")

create_dyad_table.bystander <- function(ID.1, ID.2, at) {  ### will need either to rename it or to make if vector compatible or

  ID.1 <- check_function_arg.ID(ID.1, arg.max.length = 1)
  ID.2 <- check_function_arg.ID(ID.2, arg.max.length = 1)

  date <- check_function_arg.date(at)

  clan_1 <- fetch_id_clan.current(ID.1, at = date)  ## slow
  clan_2 <- fetch_id_clan.current(ID.2, at = date)  ## slow

  if (clan_1 != clan_2) stop("ID.1 and ID.2 are not from the same clan")
  ####### get information about the clan members
  MRCA_choice <- find_dyad_MRCA.choice(ID.1, ID.2) ## find the winner

  ### get all clan members and their ancestors and life_stage
  create_id_starting.table(clan = clan_1, at = date) %>%
    dplyr::mutate(ID.1 = ID.1,
                  ID.2 = ID.2,
                  life_stage = fetch_id_lifestage(.data$ID, !!date), ### rule_1 is migrant or native keep the lifestage function to let the possibility to remove the cubs
                  relat_ID.1 = fetch_dyad_relatedness(.data$ID, ID.1), ## rule_2 is related to one or the other
                  relat_ID.2 = fetch_dyad_relatedness(.data$ID, ID.2), ## rule_2 is related to one or the other
                  life_stage_ID.1 = .data$life_stage[.data$ID == ID.1],
                  life_stage_ID.2 = .data$life_stage[.data$ID == ID.2],
                  supported_mrcaID = MRCA_choice, ## rule_3 find the ID supported by the MRCA (youngest ascendency)
                  loser = ifelse(.data$supported_mrcaID == .data$ID.1, .data$ID.2, ifelse(.data$supported_mrcaID == .data$ID.2, .data$ID.1, NA)),
                  follow_MRCA = fetch_id_follow.MRCA.choice(.data$ID, .data$loser[1]))

}

##################################################################################
#' @describeIn fetch_family fetch the individual not following the  MRCA. i.e. the descendant of older offspring.
#' @return Returns a logical indicating if an ID follow the choice of the MRCA.
#' @export
#' @examples
#' fetch_id_follow.MRCA.choice(ID = c("A-010", "A-018"), loserID = "A-010")
#'
fetch_id_follow.MRCA.choice <- function(ID, loserID) {

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          loserID = check_function_arg.ID(loserID, arg.max.length = 1))

  if (is.na(loserID)) {
    output <- input %>%
      dplyr::distinct() %>%
      dplyr::mutate(loser_descend = NA)

  } else {
    ### flag the descendant of older sisters
    loser_line <- find_id_id.ancestor.all(loserID, filiation = "mother_social")
    losers <- c(loserID, find_id_id.sibling.older(loser_line))

    output <- input %>%
      dplyr::distinct() %>%
      dplyr::mutate(loser_descend = !fetch_id_is.descendant(ID, losers))
  }

  check_function_output(input,
                        output,
                        join.by = "ID",
                        duplicates = "input",
                        output.IDcolumn = "loser_descend")

}
