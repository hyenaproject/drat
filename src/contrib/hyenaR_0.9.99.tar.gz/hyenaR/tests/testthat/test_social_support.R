context("Test the functions associated with social_support")

test_that("find_clan_id.all returns a list of clan members", {
  output_summary <- find_clan_id.all(date = "1996-08-16", clan = "A")

  # Test that a tibble is returned
  expect_equal(class(output_summary)[1], "tbl_df")
  # Test that it has more 0 rows (i.e. it actually returned clan members)
  expect_true(nrow(output_summary) > 0)
  # Test type of all columns is correct
  expect_true(is.character(output_summary$ID) &
    is.character(output_summary$currentclan) &
    is.logical(output_summary$native))
})

test_that("in_add_ancestors returns a list of ancestors", {
  hyenas <- extract_database_table(tables = "hyenas") %>%
    dplyr::left_join(extract_database_table(tables = "deaths"), by = "ID")
  selections <- extract_database_table(tables = "selections")

  clan_members <- in_get_clan_members(date = "1996-08-16", clan = "A", selections = selections, hyenas = hyenas)
  output_summary <- in_add_ancestors(clan_members = clan_members, hyenas = hyenas)

  # Test that a tibble is returned
  expect_equal(class(output_summary)[1], "tbl_df")
  # Test that it has more 0 rows (i.e. it actually returned clan members)
  expect_true(nrow(output_summary) > 0)
  # Test type of all columns is correct
  expect_true(is.character(output_summary$ID) &
    is.character(output_summary$currentclan) &
    is.logical(output_summary$native) &
    is.character(output_summary$destination) &
    is.character(output_summary$birthclan) &
    is.character(output_summary$date))
})

test_that("wrapper function calculate_social_support returns a expected values", {
  interactions <- data.frame(
    date = c("1997-01-01", "1997-01-01"), clan = c("A", "A"),
    focal = c("A-002", "A-011"), other = c("A-011", "A-002"), stringsAsFactors = FALSE
  )
  output_summary <- calculate_support(interaction = interactions, min_age = 1, table = FALSE)

  # Test that it has 2 rows as expected
  expect_equal(nrow(output_summary), 2)
  # Test that relative support values are as expected
  expect_equal(output_summary$indv_A, c(27, 0))
})
