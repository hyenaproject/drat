context("Test extract_ functions")

test_that("all extract functions return tibble(s)", {
  expect_equal(class(create_id_rank.table(ID = c("A-080", "A-001"), date = c("1997-01-01", "1997-01-01")))
  [1], "tbl_df")
  expect_equal(class(extract_database_row(ID = c("A-080", "A-001"))[[1]])[1], "tbl_df")
})
