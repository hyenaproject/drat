context("Test join_xxx functions")

test_that("all join functions return the correct type of output", {

  expect_equal(class({
    create_basetable(clan = "A", date = "1997-01-01") %>%
      join_allranks()
  })[1], "tbl_df")
  expect_equal(class(multifetch_id_offspring.count("A-001"))[1], "tbl_df")
  expect_equal(class(multifetch_litter_offspring.count("A-001_004"))[1], "tbl_df")

})

test_that("multifetch_id_offspring.count returns the correct output", {
  ref <-
    structure(
      list(
        n_females = 3L,
        n_males = 3L,
        n_unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- multifetch_id_offspring.count("A-001")
  expect_equal(ref, job)
})

test_that("multifetch_litter_offspring.count returns the correct output",
          {
            ref <-
              structure(
                list(
                  female = 1L,
                  male = 1L,
                  unknown = 0L,
                  social_female = 0L,
                  social_male = 0L,
                  social_unknown = 0L
                ),
                row.names = c(NA,-1L),
                class = c("tbl_df", "tbl", "data.frame")
              )
            job <- multifetch_litter_offspring.count("A-001_004")
            expect_equal(ref, job)
          })
