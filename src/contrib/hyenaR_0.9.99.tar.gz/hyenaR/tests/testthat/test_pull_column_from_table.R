context("Test fetch_database_column functions")


test_that("fetch_database_column is robust", {
  test1 <- fetch_database_column(column = "sex", table = "hyenas")
  n <- .database$database$data$hyenas$ID
  test2 <- fetch_id_sex(ID = n)
  foo <- function(ID) fetch_id_sex(ID = ID)
  test3 <- foo(ID = n)
  expect_identical(test1, test2)
  expect_identical(test2, test3)
})
