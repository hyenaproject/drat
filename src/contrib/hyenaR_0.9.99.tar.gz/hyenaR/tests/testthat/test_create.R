context("Test create_xxx functions")

test_that("all create functions return the correct type", {
  expect_equal(class(create_basetable(clan = c("A", "L"), date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L"), date = c("1997/01/01", "1997/12/30")))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = "A", date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = NULL, date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L")))[1], "tbl_df")
  expect_equal(class(create_basetable())[1], "tbl_df")
  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_dyad.offspring_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_dyad.mate_conception.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_matestable(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_dyad.offspring_litter.table(c("A-001", "A-008", "A-011", "A-040", "A-058")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count("A-001_004"))[1], "tbl_df")
  expect_equal(class(create_id_offspring.count(ID = c("A-001", "A-008")))[1], "tbl_df")
})

test_that("create_id_offspring.count returns output as intended", {
  ref <- structure(
      list(
        parent = c("A-001", "A-008"),
        n_females = c(3L,
                      NA),
        n_males = c(3L, NA),
        n_unknown = c(0L, NA)
      ),
      row.names = 1:2,
      class = c("tbl_df",
                "tbl", "data.frame")
    )
  job <- create_id_offspring.count(ID = c("A-001", "A-008"))
  expect_equal(ref, job)
})

test_that("create_litter_offspring.count returns output as intended", {
  ref <-
    structure(
      list(
        litter_ID = "A-001_004",
        female = 1L,
        male = 1L,
        unknown = 0L,
        social_female = 0L,
        social_male = 0L,
        social_unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- create_litter_offspring.count("A-001_004")
  expect_equal(ref, job)
})

test_that("create_litter_starting.table return the expected output", {
  ref <- structure(list(parent = c(rep("A-001",4), "L-003", "A-098"),
                        litter_ID = c("A-001_001", "A-001_002", "A-001_003", "A-001_004", "L-003_001", NA_character_)),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -6L))
  job <- create_litter_starting.table(c("A-001", "L-003", "A-098"))
  expect_equal(ref,job)
})


test_that("create_dyad.offspring_litter.table returns the expected output", {
  ref <- structure(list(parent = c(rep("A-001",6), "A-008", rep("A-011",3), "A-040", "A-058"),
                        offspring = c("A-010", "A-018", "A-046", "A-084","A-088", "A-089", NA_character_, "A-054", "A-080", "A-092", NA_character_, NA_character_),
                        filiation = c(rep("social_and_genetic",6), NA_character_, rep("genetic_only",3), NA_character_, NA_character_),
                        litter_ID = c("A-001_001", "A-001_002", "A-001_002", "A-001_003", "A-001_004", "A-001_004", rep(NA_character_,6)),
                        birthdate = as.Date(c("1994-09-21","1995-05-18", "1995-05-18", "1995-10-08",
                                              "1996-12-12", "1996-12-12", NA_character_, "1995-12-23", "1996-06-11", "1996-10-29", NA_character_, NA_character_))),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -12L))
  job <- create_dyad.offspring_litter.table(c("A-001", "A-008", "A-011", "A-040", "A-058"))
  expect_equal(ref,job)
})

test_that("create_dyad.offspring_starting.table returns the correct ouput", {
  ref <-
    structure(
      list(
        parent = c(
          "A-011",
          "A-011",
          "A-011",
          "A-045",
          "A-045",
          "A-045",
          "A-045",
          "A-001",
          "A-001",
          "A-001",
          "A-001",
          "A-001",
          "A-001"
        ),
        offspring = c(
          "A-054",
          "A-080",
          "A-092",
          "A-008",
          "A-010",
          "A-018",
          "A-100",
          "A-010",
          "A-018",
          "A-046",
          "A-084",
          "A-088",
          "A-089"
        ),
        filiation = c(
          "genetic_only",
          "genetic_only",
          "genetic_only",
          "genetic_only",
          "genetic_only",
          "genetic_only",
          "genetic_only",
          "social_and_genetic",
          "social_and_genetic",
          "social_and_genetic",
          "social_and_genetic",
          "social_and_genetic",
          "social_and_genetic"
        )
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = 1:13
    )
  job <- create_dyad.offspring_starting.table(c("A-011", "A-045", "A-001"))
  expect_equal(ref, job)
})



test_that("create_dyad.mate_conception.table returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "A-001", "A-001", "A-001", "A-001", "L-003", "A-098"),
      mate = c("A-045", "A-045", NA, NA, NA, "L-043", NA),
      date = structure(c(8919, 9158, 9158, 9301, 9732, 9240, NA), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -7L)
  )
  job <- create_dyad.mate_conception.table(c("A-001", "L-003", "A-098"))
  expect_identical(ref, job)
})


test_that("create_id_life.history.table returns the correct output", {
  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040", "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080, 7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079, 7444, 10225, 9232, 9597, 9687, 10225), class = "Date")
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA,-7L)
    )
  job <- create_id_life.history.table(c("A-001", "A-040"), censored_replaced_by_last_sighting = TRUE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040",
               "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080,
                                    7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079,
                                  7444, NA, 9232, 9597, 9687, NA), class = "Date")
      ),
      row.names = c(NA,-7L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  job2 <- create_id_life.history.table(c("A-001", "A-040"), censored_replaced_by_last_sighting = FALSE)
  expect_identical(ref2, job2)

})

test_that("create_id_selection.history returns the correct output", {
  ref <- structure(
      list(
        ID = c("A-001", "L-094"),
        clan = c("A", "L"),
        starting_date = structure(c(6715, 9896), class = "Date"),
        ending_date = structure(c(10225, 10225), class = "Date")
      ),
      class = c("tbl_df","tbl", "data.frame"),
      row.names = c(NA,-2L)
    )
  job <- create_id_selection.history(c("A-001", "L-094"), censored_replaced_by_last_sighting = TRUE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "L-094"),
        clan = c("A", "L"),
        starting_date = structure(c(6715, 9896), class = "Date"),
        ending_date = structure(c(NA_real_, NA_real_), class = "Date")
      ),
      class = c("tbl_df",
                "tbl", "data.frame"),
      row.names = c(NA,-2L)
    )

  job2 <- create_id_selection.history(c("A-001", "L-094"), censored_replaced_by_last_sighting = FALSE)
  expect_identical(ref2, job2)
})

test_that("create_id_life.transition.table returns the correct output", {
  ref <- structure(list(ID = c("A-001", "A-001", "A-008", "A-008", "A-044", "A-044"),
                        origin = c("W", "A", "W", "A", "W", "X"),
                        destination = c("A", "A", "A", "A", "X", "A"),
                        date = structure(c(6715, 7445, 8906, 9636, 5254, 9598), class = "Date")),
                   row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame"))
  job <- create_id_life.transition.table(c("A-001", "A-008", "A-044"))
  expect_identical(ref, job)
})

