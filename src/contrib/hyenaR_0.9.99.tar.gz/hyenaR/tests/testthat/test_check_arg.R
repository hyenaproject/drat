context("Test check_arg_ functions")

test_that("check_arg_period works as intended", {

  expect_error(check_arg_period("90"))

  ref <- new("Period", .Data = 0, year = 0, month = 0, day = 90, hour = 0, minute = 0)
  job <- check_arg_period("90 days")

  expect_equal(ref, job)
})


test_that("check_arg_filiation works as intended", {

  expect_error(check_arg_filiation("social"))

  ref <- c("social_only", "genetic_only")
  job <- check_arg_filiation(c("social_only", "genetic_only"))

  expect_equal(ref, job)
})

test_that("check_arg_lineage works as intended", {

  expect_error(check_arg_lineage("mother"))

  ref <- c("mothersocial", "father")
  job <- check_arg_lineage(c("mothersocial", "father"))

  expect_equal(ref, job)
})

test_that("check_arg_date works as intended", {
  expect_error(check_arg_date(c("19961001", "1996-05-01")))
  expect_error(check_arg_date(c("1996-05-01", "19961001")))
  ref <- structure(c(9617, 9770), class = "Date")
  job1 <- check_arg_date(c("1996-05-01", "1996-10-01"))
  job2 <- check_arg_date(c("1996/05/01", "1996/10/01"))
  expect_equal(ref, job1)
  expect_equal(ref, job2)
  })


test_that("check_arg_litter.ID works as intended", {
  ref <- "A-001_004"
  job <- check_arg_litter.ID("A-001_004")
  expect_equal(ref, job)
})

test_that("check_arg_litter.type works as intended", {
  ref <- list(female = c(1, 0, 1), male = c(0, 2, 1), unknown = c(0, 0, 0),
              social_female = c(0, 0, 0), social_male = c(0, 0, 0), social_unknown = c(0, 0, 0))
  job <- check_arg_litter.type(female = c(1, 0, 1), male = c(0, 2, 1), unknown = 0,
                                  social_female = 0, social_male = 0, social_unknown = 0)
  expect_equal(ref, job)
})

test_that("check_arg_date.fromtoat works as intended", {

  #Date values are wrong
  expect_error(check_arg_date.fromtoat(from = "19961001", to = "1996-10-02"))
  expect_error(check_arg_date.fromtoat(from = "1996-10-01", to = "19961002"))
  expect_error(check_arg_date.fromtoat(from = "1996-10-01", to = "1996-10-02", at = "1996-01-01"))

  #From !<= to
  expect_error(check_arg_date.fromtoat(from = "1997-10-01", to = "1996-05-01"))

  #at returns equal values
  ref1 <- structure(as.list(structure(c(9770, 9770), class = "Date")), names = c("from", "to"))
  job1 <- check_arg_date.fromtoat(at = "1996-10-01")
  expect_equal(ref1$from, ref1$to)
  expect_equal(ref1$from, job1$from)

  #from/to return different values
  ref2 <- structure(as.list(structure(c(9617, 9770), class = "Date")), names = c("from", "to"))
  job2 <- check_arg_date.fromtoat(from = "1996-05-01", to = "1996-10-01")
  expect_equal(ref2$from, job2$from)
  expect_equal(ref2$to, job2$to)

})

