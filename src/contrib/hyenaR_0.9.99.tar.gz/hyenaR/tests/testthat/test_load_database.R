context("Test that we can load the (dummy) database with load_package_database.dummy()")

test_that("load_package_database.dummy() creates a hidden global object and returns a message when loading dummy data", {

  # Message saying we are using the dummy database
  expect_message(load_package_database.dummy())
  expect_true(exists(".database"))
})
