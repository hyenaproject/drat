#' Extract a column in a table.
#'
#' This function is used internally to pull columns from a table without droping NAs.
#' It should not be directly used by the user.
#'
#' @inheritParams check_arg_column
#' @inheritParams fetch_family
#'
#' @return a vector.
#' @export
#' @examples
#'
#' ######## Load the dummy dataset:
#' load_package_database.dummy()
#'
#' ######## pull sex from hyenas table for 2 individuals:
#' fetch_database_column(column = "sex", table = "hyenas", ID = c("A-001", "L-002", NA))
#'
#' ######## pull sex from hyenas table for all individuals:
#' fetch_database_column(column = "sex", table = "hyenas")
#'
fetch_database_column <- function(column, table, ID = NULL) {
  column <- check_arg_column(column = column, table = table)
  table <- extract_database_table(tables = table)
  if (length(table$ID) > length(unique(table$ID))) {
    warning("fetch_database_column only retrieves the first occurence when ID are repeated in the table.")
  }
  if (is.null(ID)) {
    return(table[, column, drop = TRUE])
  }
  table[match(ID, table$ID), column, drop = TRUE]
}
