#' Check that sightings, selections and hyena are all consistent
#'
#' Use to check database tables before database is built.
#' Run withint \code{\link{build_package_database.full}}.
#' @param hyenas Hyenas data table.
#' @param sightings Sightings data table.
#' @param selections Selections data table.
#'
#' @return TRUE if the check is successful, FALSE otherwise.

full_record_check <- function(hyenas, sightings, selections) {

  # Assing NULL to avoid global binding NOTE
  ID <- NULL

  message("Checking that all individuals have full records in hyenas, sightings and selections...")

  names_selections <- stringr::str_trim(unique(selections$ID)[!is.na(unique(selections$ID)) & unique(selections$ID) != ""])
  names_sightings <- stringr::str_trim(unique(sightings$ID)[!is.na(unique(sightings$ID)) & unique(sightings$ID) != ""])
  names_hyenas <- stringr::str_trim(unique(hyenas$ID)[!is.na(unique(hyenas$ID)) & unique(hyenas$ID) != ""])

  # Check that any time there is a recorded selection that the individual must have a hyena and sightings record
  correct_selections_hyena <- names_selections %in% names_hyenas
  correct_selections_sightings <- names_selections %in% names_sightings

  # Check that any time there is a recorded sighting that the individual must have a hyena record.
  correct_sightings <- names_sightings %in% names_hyenas

  # Check that anything in hyenas is also in sightings
  correct_hyenas <- names_hyenas %in% names_sightings

  if (all(correct_selections_hyena) & all(correct_selections_sightings) & all(correct_sightings)) {
    message("All individuals have full records!")
    return(TRUE)
  } else {
    bad_records <- bind_rows(
      tibble::tibble(ID = names_selections[!correct_selections_hyena], table1 = "selections", table2 = "hyenas"),
      tibble::tibble(ID = names_selections[!correct_selections_sightings], table1 = "selections", table2 = "sightings"),
      tibble::tibble(ID = names_sightings[!correct_sightings], table1 = "sightings", table2 = "hyenas"),
      tibble::tibble(ID = names_hyenas[!correct_hyenas], table1 = "hyenas", table2 = "sightings")
    ) %>%
      filter(!is.na(ID))


    pwalk(
      .l = list(ID = bad_records$ID, table1 = bad_records$table1, table2 = bad_records$table2),
      .f = function(ID, table1, table2) {
        message(glue::glue("'{ID}' has a record in {table1} but not in {table2}!"))
      }
    )

    warning("There seem to be issues! Please ask Oliver to check and fix the above records, re-download the files, and rebuild the database.")
  }
  return(FALSE)
}
