#' Build optional vignette
#'
#' This function aims at creating vignettes after the package installation.
#' These vignettes differ from those readily available in hyenaR.
#' Indeed, the vignette created here will use the real database, instead of the dummy data.
#' That means that you need to manually load the database before calling such function!
#'
#' @param file The file name of the vignette to be build, ending with `*.Rmd`
#' @param overwrite A boolean indicating whether to overwrite existing compiled vignettes (`TRUE`)
#' or not (`FALSE`, the default). If `FALSE`, the user will be prompted in case the vignette
#' already exists.
#' @param verbose A boolean indicating whether to display information during the compilation of the
#'  vignette(`TRUE`) or not (`FALSE`, the default).
#' @export
#'
#' @examples
#' \dontrun{
#' build_package_vignette.extra(file = "effect_of_ranks.Rmd")
#' }
#'
build_package_vignette.extra <- function(file, overwrite = FALSE, verbose = FALSE) {

  ## The vignette source files are stored in different places depending on whether one
  ## uses the installed version of the package or the one loaded with devtools during
  ## the development of the pacakge. We thus try both:
  path1 <- paste0(find.package("hyenaR"), "/inst/extdata/optional_vignettes/")
  path2 <- paste0(find.package("hyenaR"), "/extdata/optional_vignettes/")
  if (dir.exists(path1)) {
    path <- path1
    message("Note: creation of vignette using the development version of the package (not the installed one)")
  }
  if (dir.exists(path2)) {
    path <- path2
    message("Note: creation of vignette using the installed version of the package (not the developemental one)")
  }
  path_complete <- paste(path, file, sep = "/")
  path_complete <- check_arg_path(path_complete, mustWork = TRUE)

  ## We check if the vignette has already been created:
  path_html <- gsub(pattern = ".Rmd", replacement = ".html", x =  path_complete)

  if (file.exists(path_html) && interactive() && !overwrite) {
      choice <- utils::menu(
        choices = c("Display that vignette", "Recreate the vignette"),
        title = "A vignette with the same name has already been created before. What do you want to do?"
      )
    if (choice == 0) {
      message("You have aborted the vignette creation by inputing 0.")
      return(invisible(NULL))
    }
    if (choice == 1) {
      utils::browseURL(path_html)
      return(invisible(path_html))
    }
  }

  ## We check if {rmarkdown} is there because we don't have it  in IMPORTS:
  if (!requireNamespace("rmarkdown", quietly = TRUE)) {
    stop("You need to install the package 'rmarkdown' to use this function.")
  }

  ## We don't want to build such vignettes on dummy data:
  if (!exists(".database") || attr(.database, "dummy")) {
    stop("You must load the real database using e.g. load_package_database.dummy('Fisidata.sqlite') before using this function")
  }

  ## The actual job:
  message("The vignette is being created (be patient)...")
  vignette_path <- rmarkdown::render(path_complete, quiet = !verbose)
  message("The vignette has be created and is stored at the following location:")
  message(vignette_path)

  ## We open the vignette:
  utils::browseURL(vignette_path)

  ## We return the path:
  invisible(vignette_path)
}
