#' Schedule dates at a regular interval
#'
#' This function allows for creating a vector of dates at regular intervals. It
#' is particularly usefull to prepare dates used to retrieved characteritiscs
#' of hyenas that vary along their life. See [reshape_row_date.seq()] for a wrapper
#' function that directly expand a table created with the functions from the create
#' family (e.g. [create_basetable()]).
#'
#' @param from starting date (optional)
#' @param to end date (optional)
#' @param by increment of the sequence (optional)
#' @param length.out integer defining the desired length of the sequence
#'   (optional)
#'
#' @export
#' @seealso [seq.Date()], [reshape_row_date.seq()], [reshape_row_age.seq()]
#'
#' @examples
#'
#'
#' #### Simple applications not involving hyenas:
#'
#' ### create 10 dates, every month, starting from one date:
#' schedule(from = "1997/01/01", by = "month", length.out = 10)
#'
#' ### create 10 dates, every 2 months, starting from one date:
#' schedule(from = "1997/01/01", by = "2 month", length.out = 10)
#'
#' ### create as many dates as necessary, every month, between two dates:
#' schedule(from = "1997/01/01", to = "1997/10/01", by = "month")
#'
#' ### create as many dates as necessary, every 30 days, between two dates:
#' schedule(from = "1997/01/01", to = "1997/10/01", by = 30)
#'
#'
#' #### Application with hyenas:
#'
#' ### we want to retrieve the survival of hyenas from clan "A" every 6 months in 1997:
#'
#' ## step 1. we load the databse:
#' load_package_database.dummy()
#'
#' ## step 2. we create the hyena table of individuals alive at 1st January 1997:
#' my_hyenas <- create_basetable(clan = "A", date = "1997/01/01")
#'
#' ## step 3. we expand the hyena table to repeat each row at each date
#' ## and add survival info (see also ?reshape_row_date.seq for something more simple):
#'
#' if (require(dplyr) & require(tidyr)) { ## you need to load dplyr & tidyr to run this example
#'
#'   my_hyenas %>%
#'     select(-date) %>%
#'     group_by(ID) %>%
#'     expand(date = schedule(
#'       from = "1996/06/01",
#'       to = "1997/06/01",
#'       by = "6 month"
#'     )) %>%
#'     mutate(surv = fetch_id_is.alive(ID = ID, date = date))
#'
#'
#'   ### we want to retrieve the survival of hyenas from clan "A" alive at 1st January 1997
#'   ### from birth to June 1997 every 2 month:
#'   my_hyenas %>%
#'     mutate(
#'       birthdate = fetch_id_date.birth(ID = ID),
#'       enddate = as.Date("1997-06-01")
#'     ) %>%
#'     group_by(ID) %>%
#'     group_modify(~ .x %>% expand(date = schedule(
#'       from = birthdate,
#'       to = enddate,
#'       by = "2 months"
#'     ))) %>%
#'     mutate(surv = fetch_id_is.alive(ID = ID, date = date))
#' }
schedule <- function(from = NULL, to = NULL, by = NULL, length.out = NULL) {

  ## NA date if something is missing:
  if (!is.null(from) && is.na(from)) {
    return(as.Date(NA))
  }
  if (!is.null(to) && is.na(to)) {
    return(as.Date(NA))
  }
  if (!is.null(by) && is.na(by)) {
    return(as.Date(NA))
  }
  if (!is.null(length.out) && is.na(length.out)) {
    return(as.Date(NA))
  }

  ## create argument list to convert NULL as missing:
  argList <- list(from = from, to = to, by = by, length.out = length.out)
  argList <- argList[!unlist(lapply(argList, function(arg) {
    is.null(arg)
  }))]

  ## convert arguments to date:
  if (!is.null(from)) argList$from <- as.Date(from)
  if (!is.null(to)) argList$to <- as.Date(to)

  ## create the sequence:
  do.call(seq.Date, argList)
}


#' Stretch a table by repeating rows for different dates
#'
#' This function allows for repeating rows in a table so to obtain one row
#' per date with dates spanned at regular intervals. It
#' is particularly usefull to prepare a table to which the characteristic of
#' individuals will be retrieved along their life. If you need to stretch
#' a table to gather information on hyenas at given ages, use
#' [reshape_row_age.seq()] instead.
#'
#' This function internally relies on [schedule()].
#'
#' @param table the table to be expanded
#' @param from starting date (optional)
#' @param to end date (optional)
#' @param by increment of the sequence (optional)
#' @param length.out integer defining the desired length of the sequence
#'   (optional)
#'
#' @export
#' @seealso [schedule()], [reshape_row_age.seq()]
#'
#' @examples
#' #### Detailed example of reshape_row_date.seq usage:
#'
#' ### we want to retrieve the survival of hyenas from clan "A" every 6 months in 2009
#' ### this is the same example as that of the function schedule using this time
#' ### the function strecth_schedule:
#'
#' ## step 1. we load the databse:
#' load_package_database.dummy()
#'
#' ## step 2. we create the hyena table of individuals alive at 1st January 1997:
#' my_hyenas <- create_basetable(clan = "A", date = "1997/01/01")
#'
#' ## step 3. we expand the hyena table to repeat each row at each date
#' ## and add survival info:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'
#'   my_hyenas %>%
#'     reshape_row_date.seq(
#'       from = "1996/06/01",
#'       to = "1997/06/01",
#'       by = "6 month"
#'     ) %>%
#'     mutate(surv = fetch_id_is.alive(ID = ID, date = date))
#'
#'   ### we want to retrieve the survival of hyenas from clan "A" alive at 1st January 1997
#'   ### from birth to 1st June every 2 months:
#'   my_hyenas %>%
#'     mutate(
#'       birthdate = fetch_id_date.birth(ID = ID),
#'       enddate = as.Date("1997-06-01")
#'     ) %>%
#'     reshape_row_date.seq(from = birthdate, to = enddate, by = "2 months") %>%
#'     mutate(surv = fetch_id_is.alive(ID = ID, date = date))
#' }
#'
reshape_row_date.seq <- function(table, from = NULL, to = NULL, by = NULL, length.out = NULL) {

  ## turn arguments into columns:
  table %>%
    dplyr::mutate(
      from = {{from}},
      to = {{to}},
      by = {{by}},
      length.out = {{length.out}}
    ) -> input

  ## expand the table:
  input %>%
    dplyr::group_by(ID) %>%
    dplyr::group_modify(~ .x %>% tidyr::expand(date = schedule(from = from, to = to, by = by, length.out = length.out))) %>%
    dplyr::ungroup() -> output

  ID <- NULL ## to please R CMD check

  output
}



#' Stretch a table by repeating rows for different ages
#'
#' This function allows for repeating rows in a table so to obtain one row
#' per age with age spanned at any intervals. It
#' is particularly usefull to prepare a table to which the characteristic of
#' individuals will be retrieved along their life. If you need to stretch
#' a table to gather information on hyenas at given dates, use
#' [reshape_row_date.seq()] instead.
#'
#' @inheritParams reshape_row_date.seq
#' @param age one age, or a vector of ages
#' @param unit one unit, or a vector of units
#'
#' @export
#' @seealso [schedule()], [reshape_row_age.seq()]
#'
#' @examples
#' #### Simple example of reshape_row_age.seq usage:
#'
#' ## step 1. we load the databse:
#' load_package_database.dummy()
#'
#' ## step 2. we create the hyena table of individuals alive at 1st January 1997:
#' my_hyenas <- create_basetable(date = "1997/01/01")
#'
#' ## step 3. application:
#' reshape_row_age.seq(my_hyenas, age = c(1, 2, 5), unit = "year")
#'
#' reshape_row_age.seq(my_hyenas, age = c(6, 2), unit = c("month", "year"))
#'
#'
#' #### Advanced example of reshape_row_age.seq usage:
#'
#' ### Getting the survival at 0, 2, 6, 120 months:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   my_hyenas %>%
#'     reshape_row_age.seq(age = c(0, 2, 6, 120), unit = "month") %>%
#'     mutate(date = fetch_id_date.at.age(ID = ID, age = age, unit = "month"),
#'            surv = fetch_id_is.alive(ID = ID, date = date))
#' }
#'
reshape_row_age.seq <- function(table, age, unit) {

  ## turn arguments into columns:
  tibble::tibble(age = age, unit = unit) -> input

  ## check arguments:
  input$unit <- check_arg_unit(input$unit)

  ## expand the table:
  table %>%
    dplyr::group_by(ID) %>%
    dplyr::group_modify(~ .x %>% tidyr::expand(input)) %>%
    dplyr::ungroup() -> output

  ID <- NULL ## to please R CMD check

  output
}
