#' Obtain information about clans or the population
#'
#' These functions allows for the creating of vectors with various information about given clans or
#' the whole population. There are used to find out for example which hyenas exist, which clans
#' exist, the first sighting date for the whole population and so forth.
#'
#' All ```find_xxx``` functions output a vector which items are not repeated (they are unique).
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @param clan The letter of the clan(s). If `NULL` (default), returns
#'   information for the whole population.
#' @param date The date(s) using the format "YYYY-MM-DD". If `NULL` (default), returns
#'   information for the entire study period.
#' @name find_family
#' @aliases find_family find
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL


#' @describeIn find_family find all adults
#' @export
#' @examples
#'
#' #### Simple example of find_clan_id.adult usage:
#' find_clan_id.adult(clan = c("A", "L"), date = "1997/01/01")
find_clan_id.adult <- function(clan = NULL, date = NULL) {
  if (!is.null(date) & length(date) > 1) stop("The function find_clan_id.adult() cannot handle multiple dates.")
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(age = fetch_id_age(ID = ID, date = date)) %>%
    dplyr::filter(age > 2) %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  ID <- age <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family create a vector of all clans
#'
#' @param only_main A logical indicating whether to select only the 8 crater
#' floor clans (TRUE, default) or all known clans (FALSE)
#'
#' @export
#' @examples
#'
#' #### Example of find_clan_name.all usage:
#'
#' ### find all clans in the data:
#' find_clan_name.all(only_main = FALSE)
#'
#' ### find all crater floor clans in the data:
#' find_clan_name.all()
#'
find_clan_name.all <- function(only_main = TRUE) {

  extract_database_table("hyenas") %>%
    dplyr::pull(birthclan) -> clans

  clans <- sort(unique(clans))

  if (only_main) {
    main_possible <- c("A", "E", "F", "L", "M", "N", "S", "T")
    clans <- clans[clans %in% main_possible]
  }

  birthclan <- NULL ## to please R CMD check

  clans
}



#' @describeIn find_family find all females
#' @export
#' @examples
#'
#' #### Simple example of find_female usage:
#' find_clan_id.female(clan = c("A", "L"), date = "1997/01/01")
find_clan_id.female <- function(clan = NULL, date = NULL) {
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = ID)) %>%
    dplyr::filter(sex == "female") %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  id <- sex <- ID <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find date of first sighting.
#' @param from_conception Whether the data of the first sighting is estimated from dates inferred from conception (TRUE) or not (FALSE: default).
#' @export
#' @examples
#'
#' #### Example of find_pop_observation.first usage:
#' find_pop_observation.first()
#' find_pop_observation.first(from_conception = TRUE)
find_pop_observation.first <- function(from_conception = FALSE) {
  sightings <- extract_database_table("sightings")
  if (from_conception) return(min(as.Date(sightings$date_time)))
  min(as.Date(sightings$date_time[is.na(sightings$remarks) |
                                    (!is.na(sightings$remarks) & (sightings$remarks != "Estimated from conception") &
                                       !grepl(pattern = "identified in BBC documentary", x = sightings$remarks) &
                                       !grepl(pattern = "one-day visit", x = sightings$remarks))]))
}


#' @describeIn find_family create a vector of all individuals.
#' @export
#' @examples
#'
#' #### Detailed example of find_IDs usage:
#' ### note: what is shown here also applies to all other find_xxx functions
#'
#' ### find all hyenas from 2 clans at a single date:
#' find_IDs(clan = c("A", "L"), date = "1997/02/01")
#'
#' ### find all hyenas alive from 2 clans at one date per clan:
#' find_IDs(clan = c("A", "L"), date = c("1997/02/01", "1996/11/21"))
#'
#' ### find all hyenas in the data:
#' find_IDs()
find_IDs <- function(clan = NULL, date = NULL) {

  clan <- check_arg_clan(clan, fill = TRUE)

  if (is.null(date)) {
    extract_database_table("hyenas") %>%
      dplyr::filter(birthclan %in% {{clan}}) -> output
  } else {
    create_basetable(clan = {{clan}}, date = {{date}}) -> output
  }

  birthclan <- NULL ## to please R CMD check

  sort(output$ID)
}



#' @describeIn find_family find all immigrants
#'
#' Note that this function does not consider the sex.
#' @export
#' @examples
#'
#' #### Simple example of find_clan_id.immigrant usage:
#' find_clan_id.immigrant(clan = c("A", "L"), date = "1997/01/01")
find_clan_id.immigrant <- function(clan = NULL, date = NULL) {
  if (!is.null(date) & length(date) > 1) stop("The function find_clan_id.immigrant() cannot handle multiple dates.")
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(clan = fetch_id_clan.current(ID = ID, date = date),
                  birthclan = fetch_id_clan.birth(ID),
                  immigrant = birthclan != clan) %>%
    dplyr::filter(immigrant) %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  birthclan <- ID <- immigrant <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find date of last sighting.
#' @export
#' @examples
#'
#' #### Example of find_pop_observation.last usage:
#' find_pop_observation.last()
find_pop_observation.last <- function() {
  sightings <- extract_database_table("sightings")
  max(as.Date(sightings$date_time))
}


#' @describeIn find_family find all males
#' @export
#' @examples
#'
#' #### Simple example of find_clan_id.maleusage:
#' find_clan_id.male(clan = c("A", "L"), date = "1997/01/01")
find_clan_id.male<- function(clan = NULL, date = NULL) {
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  id <- sex <- ID <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find all deaths between 2 dates
#' @export
#' @param from The starting date of the interval (included).
#' @param to The ending date of the interval (included).
#' @examples
#'
#' #### Simple example of find_clan_id.dead usage:
#' find_clan_id.dead(from = "1996/08/12")
#' find_clan_id.dead(to = "1997/01/01")
#' find_clan_id.dead(from = "1996/08/12", to = "1997/01/01")
find_clan_id.dead <- function(from = NULL, to = NULL) {
  ## checking inputs:
  if (length(from) > 1 || length(to) > 1) {
    stop("The function find_clan_id.dead() cannot handle multiple dates for 'from' and 'to'.")
  }

  if (is.null(from)) {
    from <- find_pop_observation.first()
  }

  if (is.null(to)) {
    to <- find_pop_observation.last()
  }

  from <- check_arg_date(from)
  to <- check_arg_date(to)

  create_basetable() %>%
    mutate(death_date = fetch_id_date.death(ID = .data$ID)) %>%
    filter(.data$death_date >= !!from & .data$death_date <= !!to) -> output

  output$ID
}


#' @describeIn find_family find individuals of a given selection status (of both sexes) in given clan(s) at a given time.
#' @inheritParams check_arg_life.stage
#' @export
#' @examples
#' #### Simple example of find_philopatrics usage:
#' find_clan_id.life.stage(clan = c("A", "L"), date = "1997/02/01", status = "philopatric")
#'
find_clan_id.life.stage <- function(clan = NULL, date, status) {

  ## checking inputs:
  clan <- check_arg_clan(clan = clan, fill = TRUE)

  if (!is.null(date) & length(date) > 1) {
    stop("The function find_clan_id.life.stage() cannot handle multiple dates.")
  }

  date <- check_arg_date(date)
  status <- check_arg_life.stage(status)

  ## remove duplicates:
  input <- tibble(date = date,
                  clan = clan) %>% unique()

  ## retrieve selection status and filter:
  create_basetable(clan = input$clan, date = input$date) %>%
    mutate(status = fetch_id_life.stage(ID = .data$ID, date = .data$date)) %>%
    filter(status == !!status) -> output

  output$ID
}


#' @describeIn find_family find all adult males
#' @export
#' @examples
#'
#' #### Simple example of find_adult_males usage:
#' find_adult_males(clan = c("A", "L"), date = "1997/01/01")
find_adult_males <- function(clan = NULL, date = NULL) {

  clan <- check_arg_clan(clan)
  date <- check_arg_date(date)

  create_id_starting.table(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(date = !!date,
                  sex = fetch_id_sex(ID = .data$ID),
                  age = fetch_id_age(ID = .data$ID, date = .data$date)) %>%
    dplyr::filter(.data$age > 2 & .data$sex == "male") %>%
    dplyr::arrange(.data$ID) %>%
    dplyr::pull(.data$ID) -> output

  output
}


#' @describeIn find_family find all adult females
#' @export
#' @examples
#'
#' #### Simple example of find_adult_females usage:
#' find_adult_females(clan = c("A", "L"), date = "1997/01/01")
find_adult_females <- function(clan = NULL, date = NULL) {

  clan <- check_arg_clan(clan)
  date <- check_arg_date(date)

  create_id_starting.table(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(date = !!date,
                  sex = fetch_id_sex(ID = .data$ID),
                  age = fetch_id_age(ID = .data$ID, date = .data$date)) %>%
    dplyr::filter(.data$age > 2 & .data$sex == "female") %>%
    dplyr::arrange(.data$ID) %>%
    dplyr::pull(.data$ID) -> output

  output
}

