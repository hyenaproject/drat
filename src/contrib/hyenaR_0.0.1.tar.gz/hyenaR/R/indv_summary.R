#' Extract summary of an individual hyena(s) life during a given period.
#'
#' This function will extract information on:
#' - Birth (sex, clan, parentage, date)
#' - Death (date, age)
#' - Reproduction (lifetime reproductive success)
#' - Dispersal
#'
#' over a specified date range.
#'
#' N.B. The user can provide EITHER a date range OR an individual name, not both.
#' When an individual name is provided, a summary of the focal individual will be returned across its whole life.
#'
#' @param db Location of database. If unspecified, will use dummy database for examples.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param indv Vector of hyena names to extract summary.
#' When an individual name is provided, a summary of the focal individual will be returned across its whole life.
#' start_date and end_date will be ignored.
#' @param age_units The units of measurement used for age. Can be season (6 month time periods; default), years, months,
#' weeks, or days.
#' Other units specified by \code{\link{difftime}} (e.g. hours) are meaningless in this context
#' and will return an error.
#'
#' @return A tibble with information for each hyena provided.
#' @export
#' @import DBI
#' @import RSQLite
#' @import dplyr
#' @importFrom lubridate ymd
#'
#' @examples
#'
#' #Find information for some of the oldest individuals and some of the younger
#' #Individual names
#' indv = c("F-001", "F-086")
#' indv_summary(indv = indv)
#'
#' #Find information on all individuals born before a given date
#' indv_summary(start_date = "1999-01-01", end_date = "2000-01-01")

indv_summary <- function(db = NULL, start_date = -Inf, end_date = Inf, indv = NULL, age_units = "season"){

  #Assign variables to NULL to prevent global binding NOTE in R CMD Check
  name <- . <- sex <- birthclan <- current_clan <- birthdate <- mothergenetic <- mothersocial <- NULL
  father <- deathdate <- recentdate <- last_sighting <- surv <- age <- RS <- first_rank <- NULL
  start_clan <- dispersal <- repro <- twin <- NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Check that units of age are usable
  if(!age_units %in% c("season", "years", "months", "days", "weeks")){

    stop("The units you have specified for age are unsuitable. \n
          Please specify season, years, months, days or weeks.")

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Get access to hyenas table
  hyena <- tbl(connection, "hyenas")

  #We need to know the latest date in the database.
  #This will be the end_date if Inf is provided
  #We need an actual value (rather than Inf) to calculate age
  latest_date <- lubridate::ymd(tbl(connection, "sightings") %>%
    summarise(latest_date = max(date, na.rm = T)) %>%
    collect() %>%
    .$latest_date)

  #If individual ID(s) are provided, then we just use Inf dates regardless of what is provided.
  #I think it's too complicated to expect people to choose the date and Indv.
  #To provide date AND ID would require knowledge of when the individual was alive!! Which we don't know until we run this function!!
  if(!is.null(indv)){

    if(!is.infinite(start_date) || !is.infinite(end_date)){

      #Inform the user...
      print("When providing individual ID's the maximum time period will be considered. start_date and end_date are ignored.")

      #Make Inf/-Inf
      end_date   <- latest_date
      start_date <- -Inf

    }

  } else {

    #If no indv_ID is provided, we apply the start/end_dates and just use the names of all individuals.
    indv <- hyena %>%
      select(name) %>%
      collect() %>%
      .$name

    #If end date is Inf then convert to latest date...
    if(is.infinite(end_date)){

      end_date <- latest_date

    }

    #If start date is not Inf make sure that it's a date object
    if(!is.infinite(start_date)){

      start_date <- lubridate::ymd(start_date)

    }

  }

  #Subset the hyena and death tables...
  output_table <- hyena %>%
    #Use left join to join death data into the hyena data.
    #Only include those deaths that occured inside our period of interest...
    left_join(tbl(connection, "deaths") %>%
                filter(deathdate < end_date), by = "name") %>%
    #Filter just the wanted individual(s) (which is all individuals if not specified)...
    #Apply the date filter (which is just infinite if not specified)...
    filter(name %in% indv & birthdate < end_date & (is.na(deathdate) | deathdate >= start_date)) %>%
    select(name, sex, birthclan, birthdate, deathdate, mothergenetic, mothersocial, father) %>%
    #Make sex into M/F and birthdate into datetime object
    mutate(sex = ifelse(sex == 1, "Male", ifelse(sex == 2, "Female", NA))) %>%
    left_join(tbl(connection, "sightings") %>%
                filter(name %in% indv & date < end_date) %>%
                select(date, name) %>%
                group_by(name) %>%
                summarise(recentdate = max(date, na.rm = T)), by = "name") %>%
    collect()

  #Create progress bar object
  pb <- dplyr::progress_estimated(n = nrow(output_table), min_time = 30)

  output_table <- output_table %>%
    #Determine age of death using calc_age function (in otherfunctions.R).
    #For season, display as years rounded to the nearest 0.5 (i.e. every 6 month period).
    #For years, divide by 365 and include remainder.
    #For months just return a value of months (no remainder) using lubridate interval.
    #For other units (days and weeks) just make a difftime object of the given units
    mutate(age = pmap_dbl(.l = list(age_units = age_units,
                                    birthdate = birthdate,
                                    deathdate = deathdate,
                                    end_date  = end_date),
                          .f = calc_age),
           #Create a binary variable whether an individual survived the period of interest.
           surv = ifelse(is.na(deathdate), TRUE, FALSE),
           #If there is no deathdate recorded, the most recent date is the max date in sightings
           #Otherwise, just include the deathdate as the most recent date.
           last_sighting = lubridate::ymd(map2_chr(.x = deathdate, .y = recentdate,
                                          .f = ~ifelse(is.na(.x), .y, .x))),
           birthdate = lubridate::ymd(birthdate)) %>%
    #Use function calc_repro (otherfunctions.R) to create data frame of reproductive output for all individuals...
    #left_join this to our current data...
    #This function will create a binary variable whether the individual has given birth during this period
    #All males will be given NA. Females will be given 1 if they have an offspring with birthdate between start and end date
    #N.B. Here we are just saying whether they reproduced AT ALL. It doesn't matter if it was 1+ times.
    #Determine reproductive success until this point...
    #Determine whether there has been a twin litter produced during this period (i.e. were their offspring with overlapping birthdates)
    left_join(map2_df(.x = .$name, .y = .$sex, .f = calc_repro, start_date = start_date, end_date = end_date, hyena = hyena), by = "name") %>%
    #Determine current clan using calc_currentclan function (in otherfunctions.R)
    #We feed the progress bar function in here because it is the slowest part of the process (according the profvis)
    left_join(map2_df(.x = .$name, .y = .$birthclan, .f = calc_currentclan, start_date = start_date, end_date = end_date, selections = tbl(connection, "selections"), pb = pb), by = "name") %>%
    #Rearrange column order to make it more reasonable and remove extra variables.
    select(name, sex, birthclan, birthdate, mothergenetic, mothersocial, father, last_sighting, surv, age, start_clan, current_clan, dispersal, repro, RS, twin)

  dbDisconnect(connection)

  return(output_table)

}
