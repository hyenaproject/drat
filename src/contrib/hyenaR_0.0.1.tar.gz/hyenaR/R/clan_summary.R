#' Return a summary of given clan(s) on a given date(s)
#'
#' Provides summary statistics on chosen clans on a given date.
#' @param db Location of database. If unspecified, will use dummy database file for examples.
#' @param clan Name of clan(s) of interest. If left blank will return a summary of all clans in the specified database.
#' @param date Date at which the summary is taken.
#' If date is not provided, will use most recent date in the sightings table of the database.
#' Format should be YYYY-MM-DD.
#' @param python_loc Location of python on the computer. If unspecified,
#' will search in PATH.
#' @param internal Used internally. Do not change.
#'
#' @return Returns a tibble with the summary of chosen clans on all dates.
#' @export
#' @import RSQLite
#' @import DBI
#' @import dplyr
#' @import purrr
#' @importFrom lubridate ymd
#'
#' @examples
#'
#' #Obtain summary of clan A on Jan 1st 1998
#' clan_summary(clan = "A", date = "1998-01-01")

clan_summary <- function(db = NULL, clan = NULL, date = NULL, python_loc = NA, internal = FALSE){

  #Assign NULL to variables to prevent global binding NOTE in R CMD Check
  nr_males <- nr_females <- nr_adults <- nr_cubs <- birthclan <- . <-  NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Make sure that date is a character string.
  #This is required to work with Iljas python code.
  if(class(date) == "Date"){

    date <- as.character(date)

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #If clan is not provided, use all clans
  if(is.null(clan)){

    clan <- tbl(connection, "hyenas") %>%
      group_by(birthclan) %>%
      summarise() %>%
      collect() %>%
      .$birthclan

  }

  #Determine latest date in the current database
  latest_date <- ymd(tbl(connection, "sightings") %>%
                       select(date) %>%
                       summarise(latest_date = max(date, na.rm = T)) %>%
                       collect())

  #If date is not provided, use current system date.
  if(is.null(date)){

    date = as.character(latest_date)

    #Otherwise, if any date is provided BUT it is more recent than the most recent date
    #Simply change the date to the most recent date (and give a message)
  } else if(any(ymd(date) > latest_date)){

    error_date <- date[which(ymd(date) > latest_date)]

    date[which(ymd(date) > latest_date)] = as.character(latest_date)
    message(paste("Date:", error_date, "is too recent. \n It has been set to the most recent date in the database (", latest_date, ") \n"))

  }

  #Generate state of clans on each date
  raw_clan_summary <- get_rawclan_summary(db = db, clan = clan, date = date, python_loc = python_loc)

  #Create progress bar object
  #Will only display if at least 15 seconds have passed
  pb <- dplyr::progress_estimated(n = length(date), min_time = 0)

  #Run sapply on the hierarchy data for each clan
  #If we're running this file internally (i.e. for the population summary function)
  #then return a list to use with map (each list item is a date)
  #Otherwise, return a tibble
  if(internal){

    output_file <- map2(.x = raw_clan_summary$indv_summary,
                        .y = raw_clan_summary$date, .f = function(input, date){

      date = ymd(date)

      internal_map <- map_df(.x = as.list(clan), .f = function(clanname, input, date){

        current_clan <- input[clanname]

        ages = map(.x = current_clan, .f = function(indv, date){

          return(as.numeric(ymd(date) - indv$birthdate)/365)

        }, date)

        internal_file <- data_frame(date      = date,
                                  clan        = clanname,
                                  clan_size   = length(current_clan),
                                  nr_adults   = sum(map_lgl(.x = ages,
                                                             .f = ~.x >= 2)),
                                  nr_cubs     = sum(map_lgl(.x = ages,
                                                             .f = ~.x < 2)),
                                  nr_males    = sum(map_lgl(.x = current_clan,
                                                            .f = ~ifelse(is.null(.x$male), NA, .x$male)), na.rm = T),
                                  nr_females  = sum(map_lgl(.x = current_clan,
                                                            .f = ~ifelse(is.null(.x$male), NA, !.x$male)), na.rm = T),
                                  nr_youngfem = sum(map2_lgl(.x = current_clan, .y = ages,
                                                             .f = ~!is.null(.x$male) && !.x$male & .y < 5 & .y > 1))) %>%
          mutate(sex_ratio = nr_males/nr_females,
                 age_ratio = nr_adults/nr_cubs)

        return(internal_file)

      }, input, date)

      pb$tick()$print()

      return(internal_map)

    })

    dbDisconnect(connection)

    return(output_file)

  } else {

    output_file <- map2_df(.x = raw_clan_summary$indv_summary,
                        .y = raw_clan_summary$date, .f = function(input, date){

      date = ymd(date)

      internal_map <- map_df(.x = as.list(clan), .f = function(clanname, input, date){

        current_clan <- input[clanname]

        ages = map(.x = current_clan, .f = function(indv, date){

          return(as.numeric(ymd(date) - indv$birthdate)/365)

        }, date)

        internal_file <- data_frame(date        = date,
                                  clan        = clanname,
                                  clan_size   = length(current_clan),
                                  nr_adults   = sum(map_lgl(.x = ages,
                                                             .f = ~.x >= 2)),
                                  nr_cubs     = sum(map_lgl(.x = ages,
                                                             .f = ~.x < 2)),
                                  nr_males    = sum(map_lgl(.x = current_clan,
                                                            .f = ~ifelse(is.null(.x$male), NA, .x$male)), na.rm = T),
                                  nr_females  = sum(map_lgl(.x = current_clan,
                                                            .f = ~ifelse(is.null(.x$male), NA, !.x$male)), na.rm = T),
                                  nr_youngfem = sum(map2_lgl(.x = current_clan, .y = ages,
                                                             .f = ~(!is.null(.x$male) && !.x$male & .y < 5 & .y > 1)))) %>%
          mutate(sex_ratio = nr_males/nr_females,
                 age_ratio = nr_adults/nr_cubs)

        return(internal_file)

      }, input, date)

      pb$tick()$print()

      return(internal_map)

    })

    dbDisconnect(connection)

    return(output_file)

  }

}
