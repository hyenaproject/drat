#' Add multiple information about given hyena(s)
#'
#' These functions allows for extending a table containing at least the
#' column `id` by adding to it the information that is requested.
#'
#' Note for developpers: if ```debug``` is set to ```TRUE``` the functions
#' output a tibble, with detailed information on what is
#' used for the computation.
#'
#' @param .tbl The table to which the column(s) should be added.
#' @param compact Whether the new columns should be merged within a single columns (default is FALSE).
#' @param debug A ```logical``` indicating if the functions should run into
#'   debugging mode (TRUE) or not (FALSE, default).
#' @param filiation The type of parent-offspring relationship: "genetic_only",
#' "social_only", "social_and_genetic", or a combination.
#' @param ID The ID code of given hyena(s).
#' @param litter_ID The litter.ID of the litters of interest.
#' @name join_family
#' @aliases join_family join
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_database()
NULL


#' @describeIn join_family Add a logical colum for agonistic interactions
#' @export
#' @examples
#'
#' #### Simple example of join_agonistic usage:
#'
#' if (require(tibble)) { ## you need to load tibble to run this example
#'   tibble(party1 = c("A-001", "A-0x3", "A-001"),
#'          party2 = c("A-002", "A-002", "A-010+A-100"),
#'          winner = c("A-012", "A-0x3", "A-010+A-100")) %>%
#'     join_agonistic()
#' }
#'
join_agonistic <- function(.tbl){
  winner <- party1 <- party2 <- diff_ID <- clear_winner <- NULL

  if (!"party1" %in% colnames(.tbl)) stop("This function requires a column 'party1'.")
  if (!"party2" %in% colnames(.tbl)) stop("This function requires a column 'party2'.")
  if (!"winner" %in% colnames(.tbl)) stop("This function requires a column 'winner'.")

  .tbl %>%
    dplyr::mutate(clear_winner = winner == party1 | winner == party2,
                  diff_ID = party1 != party2,
                  agonistic = clear_winner & diff_ID) %>%
    dplyr::select(-clear_winner, -diff_ID)
}


#' @describeIn join_family All social rank information of a given individual on a given date.
#'
#' See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of join_allranks usage:
#' create_basetable(clan = "A", date = "1997-01-01") %>%
#'   join_allranks()
#'
#' #### Same but compact:
#' create_basetable(clan = "A", date = "1997-01-01") %>%
#'   join_allranks(compact = TRUE)
#' \dontrun{
#' #### Example with missing information:
#' load_database(file.choose())
#' if (require(tibble)) { ## you need to load tibble to run this example
#'   create_basetable() %>%
#'     mutate(date = fetch_birthdate(ID = ID)) %>%
#'     join_allranks()
#' }
#' }
#'
join_allranks <- function(.tbl, compact = FALSE, debug = FALSE) {
  if (!"ID" %in% colnames(.tbl)) stop("This function requires a column 'ID'.")
  if (!"date" %in% colnames(.tbl)) stop("This function requires a column 'date'.")

  data_all_ranks <- extract_allrankinfo(ID = .tbl$ID, date = .tbl$date)

  if (debug) {
    return(data_all_ranks)
  }

  .tbl %>%
    dplyr::left_join(data_all_ranks %>%
      dplyr::group_by(ID, date) %>%
      tidyr::nest(all_ranks = colnames(data_all_ranks %>%
        select(-ID, -date, -clan))),
    by = c("ID", "date")
    ) -> output

  if (!compact) {
    output %>%
      tidyr::unnest(all_ranks) -> output
  }

  ID <- date <- clan <- all_ranks <- NULL ## To please R CMD check

  output
}


#' @describeIn join_family Add a logical colum for dyadic interactions
#' @export
#' @examples
#'
#' #### Simple example of join_dyadic usage:
#' if (require(tibble)) { ## you need to load tibble to run this example
#' tibble(party1 = c("A-001", "A-0x3", "A-001"),
#'        party2 = c("A-002", "A-002", "A-010+A-100")) %>%
#'   join_dyadic()
#' }
#'
join_dyadic <- function(.tbl){
  party1 <- party2 <- n_party1 <- n_party2 <- dyadic1 <- dyadic2 <- NULL

  if (!"party1" %in% colnames(.tbl)) stop("This function requires a column 'party1'.")
  if (!"party2" %in% colnames(.tbl)) stop("This function requires a column 'party2'.")


  .tbl %>%
    dplyr::mutate(n_party1 = stringr::str_count(party1),
           n_party2 = stringr::str_count(party2),
           dyadic1 = n_party1 == 5 & n_party2 == 5,
           dyadic2 = stringr::str_detect(party1, ".-\\d{3}") & stringr::str_detect(party2, ".-\\d{3}"),
           dyadic = dyadic1 & dyadic2) %>%
    dplyr::select(-n_party1, -n_party2, -dyadic1, -dyadic2)

}

#' @describeIn join_family returns several vectors that can be simply added to an already existing table
#' by mean of `dplyr::mutate()`. The output will contain 3 columns about the number of daughters, sons and
#' offspring with unknown sex (according to the filiation argument) that the ID gave birth to in the entire life.
#' @export
#' @examples
#'
#' #### Simple example of multifetch_id_offspring.count:
#'  multifetch_id_offspring.count(ID = c("A-001", "A-008"))
#'
multifetch_id_offspring.count <- function(ID, filiation = c("genetic_only", "social_and_genetic"), debug = FALSE) {

  ID <- check_arg_ID(ID)
  filiation <- check_arg_filiation(filiation)

  id_offspring.count <- create_id_offspring.count(ID, filiation = filiation)

  if (debug) return(id_offspring.count)

  id_offspring.count[,-1]

}



#' @describeIn join_family returns several vectors that can be simply added to an already existing table
#' by mean of `dplyr::mutate()`. The output will contain 6 columns about the number of daughters, sons and
#' offspring with unknown sex, both social and genetic, for each litter.
#' @param litter_ID A character vector.
#'
#' @export
#' @examples
#'
#' #### Simple example of multifetch_litter_offspring.count:
#' multifetch_litter_offspring.count(litter_ID = c("A-001_004", "A-001_001", "A-001_004"))
#'
multifetch_litter_offspring.count <- function(litter_ID, debug = FALSE) {

  litter_ID <- check_arg_litter.ID(litter_ID)
  litter_offspring.count <- create_litter_offspring.count(litter_ID)

  if (debug) return(litter_offspring.count)

  litter_offspring.count[,-1]
}
