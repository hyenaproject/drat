#' Recode vectors
#'
#' These functions allows for the recoding of vectors.
#'
#' @param x The vector to be recoded
#' @name recode_family
#' @aliases recode_family recode
#' @return The recoded vector.
#'
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_database()
NULL


#' @describeIn recode_family recode standardized ranks into categories
#'
#' Note that 0% corresponds to the top ranking individual!
#'
#' @param probs The probabilities used to split the standardized ranks.
#' @param digits The number of digits to be displayed in the levels.
#' @export
#'
#' @examples
#'
#' #### Simple example of recode_rankstd_to_cat usage:
#'
#' set.seed(1)
#' some_ranks <- seq(-1, 1, length = 10)
#' some_probs <- runif(3)
#' recode_rankstd_to_cat(some_ranks, probs = some_probs)
#'
#' #### More realistic example of recode_rankstd_to_cat usage:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_basetable(clan = "A", date = "1997-01-01") %>%
#'     mutate(rankstd = fetch_rankstd(ID = ID, date = date),
#'            rankstd_cat = recode_rankstd_to_cat(rankstd, probs = c(0.25, 0.5, 0.75)))
#' }
#'
recode_rankstd_to_cat <- function(x, probs = NULL, digits = 2) {

  if (is.null(probs)) {
    warning("The argument 'probs' has not been defined, so the input vector has not been recoded!")
    return(x)
  }

  if (any((x[!is.na(x)] < -1) | (x[!is.na(x)] > 1))) {
    stop("The ranks should be standardized, that is all between -1 and 1.")
  }

  if (any((probs < 0) | (probs > 1))) {
    stop("The probabilities should be all between 0 and 1.")
  }

  x <- abs((x - 1) * 1/2)  ## to bring back ranks between 0 and 1 with 0 being to

  probs <- sort(unique(c(0, probs, 1)))

  res <- cut(x, breaks = probs, include.lowest = TRUE)

  levels_list <- lapply(strsplit(levels(res), ","),
                        function(str) 100*as.numeric(sub("\\[|\\(|\\]", "", str, perl = TRUE)))
  levels(res) <- unlist(lapply(levels_list,
                               function(x) paste0(signif(x[1], digits = digits), "--",
                                                  signif(x[2], digits = digits), "%")))
  as.character(res) ## convert to character in order not to get a factor
}




#' @describeIn recode_family classifies litters with a string that is a combination of "f" (= female offspring),
#' "m" (= male offspring), "u" (= offspring with unknown sex), according to the number of daughters, sons and
#' cubs with unknown sex present in the litter.
#'
#'
#' @param female an integer vector with the number of daughters for each litter.
#' @param male an integer vector with the number of sons for each litter.
#' @param unknown an integer vector with the number of cubs with unknown sex for each litter.
#' @param social_female an integer vector with the number of social daughters for each litter.
#' @param social_male an integer vector with the number of social males for each litter.
#' @param social_unknown an integer vector with the number of social cubs with unknown sex for each litter.
#'
#' @export
#'
#' @examples
#'
#' ### Simple example of the recode_litters:
#'
#' female <- c(1, 2, 1, 0)
#' male <- c(0, 0, 1, 0)
#' unknown <- c(1, 1, 1, 0)
#' social_female <- c(0, 0, 0, 0)
#' social_male <- c(1, 0, 0, 0)
#' social_unknown <- c(0, 0, 0, 0)
#'
#' recode_litters(female, male, unknown, social_female, social_male, social_unknown)
#'
recode_litters <- function(female = 0, male = 0, unknown = 0, social_female = 0, social_male = 0, social_unknown = 0) {

  args <- check_arg_recode_litters(female, male, unknown, social_female, social_male, social_unknown)

  type <- rep(NA_character_, length(args$female))

  for (i in seq_len(length(args$female))) {
    type[i] <- paste(c(rep("f", args$female[i]),
                       rep("m", args$male[i]),
                       rep("u", args$unknown[i]),
                       rep("sf",args$social_female[i]),
                       rep("sm", args$social_male[i]),
                       rep("su", args$social_unknown[i])), collapse = "_")
  }

  type[type == ""] <- NA_character_

  type
}


