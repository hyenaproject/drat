#' Deprecated function. Use [load_database] instead.
#'
#' load_db() is now [load_database]. Please use this function instead.
#' @export

load_db <- function() .Deprecated("load_database")


############################################################################################

#' Load all database tables for internal use in functions
#'
#' By design, the database loaded by this function will be stored in a hidden
#' environment. We do that so that other functions have access to it without the
#' user being tempted to interfere with it. If you wish to retrieve tables to
#' work with them directly, use [extract_database] instead. If you think that the
#' original table should be modified, the best practice is to modify the
#' original .csv files on GitHub (only Oliver should do that).
#'
#' @param db File path. If an .sqlite file path is provided, this database file
#'   will be used. If a file path is provided to a folder, an .sqlite file
#'   inside this folder will be used. If multiple .sqlite files are found in the
#'   path, the user will be prompted to choose one. If unspecified, the function
#'   will use the dummy database file.
#'
#' @seealso [extract_database]
#'
#' @return This function returns nothing directly, but it creates a tibble of
#'   tables and table names stored in a hidden environment.
#' @export
#'
#' @examples
#' # Load the dummy dataset
#' load_database()
load_database <- function(db = NULL) {

  ## create environment storing the data base:
  .database <<- new.env()
  attr(.database, "name") <- "environment storing the database and its path"
  attr(.database, "dummy") <- FALSE ## nb: will change below if dummy

  ## handle case where no database is specified (i.e. load dummy database):
  if (is.null(db)) {
    message("No database path specified. Using the dummy dataset!")

    db <- system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)
    attr(.database, "dummy") <- TRUE
  } else if (!grepl(pattern = ".sqlite", db)) {
    sqlite_file_paths <- list.files(path = db, pattern = ".sqlite", full.names = TRUE)

    if (length(sqlite_file_paths) > 1) {
      sqlite_file_names <- list.files(path = db, pattern = ".sqlite")

      choice <- utils::menu(
        choices = sqlite_file_names,
        title = "Multiple sqlite files exist in this folder. Which should be used?"
      )

      db <- sqlite_file_paths[choice]
    } else {
      db <- sqlite_file_paths
    }
  }

  ## connecto to the database:
  db <- path.expand(db)
  connection <- DBI::dbConnect(SQLite(), db)
  table_names <- DBI::dbListTables(connection)

  ## import each table from the database using .extract_table (see below):
  database <- tibble::tibble(
    table_name = table_names,
    data = purrr::map(
      .x = table_names,
      .f = ~ .extract_table(.x, connection)
    )
  )

  ## disconnect from the database:
  DBI::dbDisconnect(conn = connection)

  ## store the database and its path in the hidden environment:
  assign(x = "database", value = database, envir = .database)
  assign(x = "db", value = db, envir = .database)

  ## display message if time since last sighting if long:
  if (!attr(.database, "dummy")) {
    now <- Sys.Date()
    last <- find_lastsighting()
    days_since_last <- as.numeric(now - last)
    colour <- dplyr::case_when(days_since_last < 31 ~ "green",
                               days_since_last > 30 && days_since_last < 61 ~ "yellow",
                               days_since_last > 60 ~  "red")

    message(paste0("The last observation in the loaded database is ", crayon::style(paste(days_since_last, "days old"), bg = colour), "!"))
    if (days_since_last > 30) {
      message("Perhaps you should update it!\n For this:\n 1. download the new data (see, ?download_primary_data)\n 2. rebuild the database (see ?build_database)")
    }
  }

  ## return nothing directly:
  invisible(NULL)
}


####################################################################################

.extract_table <- function(.x, connection) {
  output_table <- dplyr::tbl(connection, .x) %>%
    dplyr::collect(output_table)

  ## If the table contains date and time data unite it into one date_time column (POSIXct)
  if (all(c("date", "time") %in% colnames(output_table))) {
    output_table %>%
      tidyr::unite(col = "date_time", date, time, sep = " ", remove = TRUE) %>%
      dplyr::mutate_at(
        .vars = dplyr::vars(contains("date_time")),
        as.POSIXct, tz = "Africa/Dar_es_Salaam",
        format = "%Y-%m-%d %H:%M"
      ) -> output_table

    ## In one case, the observationtime table, there are two cols that should be datetime,
    ## the departure and arrival column.
  }

  if (all(c("departure", "arrival") %in% colnames(output_table))) {
    output_table %>%
      tidyr::unite(col = "departure_date_time", date, departure, sep = " ", remove = FALSE) %>%
      tidyr::unite(col = "arrival_date_time", date, arrival, sep = " ", remove = TRUE) %>%
      dplyr::select(-departure) %>%
      dplyr::mutate_at(
        .vars = dplyr::vars(contains("date_time")),
        as.POSIXct, tz = "Africa/Dar_es_Salaam",
        format = "%Y-%m-%d %H:%M"
      ) -> output_table
  }
  output_table %>%
    ## There may be other date columns that should be converted to date format
    dplyr::mutate_at(
      .vars = dplyr::vars(dplyr::contains("date"), -dplyr::contains("date_time")),
      as.Date, format = "%Y-%m-%d", origin = "1970-01-01"
    ) %>%
    dplyr::mutate_at(
      .vars = dplyr::vars(dplyr::contains("sex")),
      ~ dplyr::case_when(
        .x == 1 ~ "male",
        .x == 2 ~ "female",
        TRUE ~ NA_character_
      )
    ) -> output_table

  time <- departure <- arrival <- NULL ## to please R CMD check

  return(output_table)
}
