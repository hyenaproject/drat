#' Defunct Functions in Package hyenaR
#'
#' The functions or variables listed here are no longer part of hyenaR as they are no longer needed.
#'
#' @param ... Arguments formerly passed to the function that is now defunct.
#'
#' @name hyenaR-defunct
NULL

###########################

#' @describeIn hyenaR-defunct Can be replicated using \code{\link{fetch}} functions.
#' @export

indv_summary <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Replaced by \code{\link{fetch_id_has.reproduced}},
#' \code{\link{fetch_offspring_number}}, and \code{\link{fetch_id_has.twin.litter}}
#' @export

calc_repro <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Replaced by \code{\link{check_database_is.correct}}
#' @export

test_integrity <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Replaced by \code{\link{fetch_id_is.sampled.dna}}, which
#' now returns a boolean (TRUE/FALSE) rather than character.
#' @export

fetch_dna <- function(...) .Defunct(package = 'hyenaR')

###########################

#' @describeIn hyenaR-defunct Replaced by [create_id_life.transition()]
#'
#' @export
calculate_selection_events <- function(...) .Defunct("create_id_life.transition")

###########################

#' @describeIn hyenaR-defunct Replaced by [create_id_life.transition()]
#'
#' @export
create_selection_events <- function(...) .Defunct("create_id_life.transition")

###########################

#' @describeIn hyenaR-defunct Replaced by [fetch_id_life.stage()]
#'
#' @export
fetch_selection_status <- function(...) .Defunct("fetch_id_life.stage")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_offspringtable_count <- function(...) .Defunct("multifetch_id_offspring.count")

###########################

#' @describeIn hyenaR-defunct Defunct function
#'
#' @export
#'
create_littertable_type <- function(...) .Defunct("fetch_litter_litter.type")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_offspringtable_with_litter <- function(...) .Defunct("create_id_offspring.litter.fulltable")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_littertable <- function(...) .Defunct("create_litter_starting.table")

###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_littertable_count <- function(...) .Defunct("multifetch_litter_offspring.count")


###########################

#' @describeIn hyenaR-defunct Defunct function
#' @export
#'
create_matingtable <- function(...) .Defunct("create_id_conception.table")
