#' Identify all offspring produced
#'
#' @param ... Parameters for the function.
#' @export
#'
calculate_offspring <- function(...) .Defunct("create_offspringtable")


#' Identify all known mates
#'
#' This function is for internal use only. For users, please use [create_matestable()] instead.
#'
#' The function takes as an input the `ID` of one or several hyena(s) and produces a list of all
#' the mates for each `ID`. A mate is here defined as an individual with which one made an
#' offspring. When looking for mates, the function search the hyenas that contain the `ID` of the
#' potential parents as mother or father.
#'
#' @param ID The ID of hyena(s).
#'
#' @return The list of all the mates for each individual.
#' @export
#'
#' @examples
#' load_database()
#' calculate_mates(c("A-001", "L-003"))
#'
#' \dontrun{
#' load_database(file.choose())
#' mates <- calculate_mates(find_IDs())
#' }
#'
calculate_mates <- function(ID) {
  #ID <- check_arg_ID(ID)  ## do not check as user level functions should!

  hyenas <- extract_database("hyenas")

  output <- furrr::future_map(
    .x = ID,
    ~ list({
      which_females    <- which(hyenas$mothergenetic %in% .x)
      which_males      <- which(hyenas$father %in% .x)
      mates_of_females <- unique(hyenas$mothergenetic[which_males])
      mates_of_males   <- unique(hyenas$father[which_females])
      mates <- c(mates_of_females, mates_of_males)
      mates[!is.na(mates)]
      }), .progress = FALSE
  )

  names(output) <- ID
  unlist(output, recursive = FALSE)
}

