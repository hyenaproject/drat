#' find_id_id.ancestor.all
#'
#' Return a vector of all ancestor for the given ID(s). The first being the focal id.
#'
#' @param ID A vectors of IDs.
#' @param .hyena_tbl The hyenas table from database.
#' @param lineage The type of lineage to look for (e.g. "mothergenetic", "mothersocial", "father").
#' @describeIn find_family find the ancestors of a given ID(s).
#' @return A vector of ID.
#' @export
#' @examples
#' # Load data (use dummy dataset)
#' load_database()
#' find_id_id.ancestor.all(ID = "A-100")
#'
find_id_id.ancestor.all <- function(ID, lineage =  "mothergenetic", .hyena_tbl = NULL) {

  if (is.null(.hyena_tbl)) .hyena_tbl <- extract_database("hyenas")

  d <- list(check_arg_ID(ID))
  lineage <- check_arg_lineage(lineage)

  i <- 1
    while (sum(!is.na(d[[i]])) > 0) {
    d[[i + 1]] <- .hyena_tbl[match(d[[i]], .hyena_tbl$ID), lineage, drop = TRUE]
    i <- i + 1
    }

  c(stats::na.omit(unlist(d)))
}


#################################################################
#' find_dyad_relatedness
#'
#' find the ralatedness between two IDs.
#'
#' @param ID1 A single ID.
#' @param ID2 A single ID.
#' @param lineage The type of lineage (e.g. "mothergenetic", "mothersocial", "father").
#' @describeIn find_family find the relatedness coeficient between 2 ids.
#' @return A coefficient of relatedness.
#' @export
#' @examples
#' load_database()
#' find_dyad_relatedness(ID1 = "A-084", ID2 = "A-001", lineage = "mothergenetic")
#'
find_dyad_relatedness <- function(ID1, ID2, lineage = "mothergenetic", .hyena_tbl = NULL) {

  ID1 <- check_arg_ID(ID1)
  ID2 <- check_arg_ID(ID2)
  lineage <- check_arg_lineage(lineage)

  if (is.null(.hyena_tbl)) .hyena_tbl <- extract_database("hyenas")

  line_A <- find_id_id.ancestor.all(as.character(ID1), lineage = lineage, .hyena_tbl = .hyena_tbl)
  line_B <- find_id_id.ancestor.all(as.character(ID2), lineage = lineage, .hyena_tbl = .hyena_tbl)

  if (length(base::intersect(line_A, line_B)) == 0) return(NA)

  ## common ancestor(s):
  steps_to_A_ancestor <- which(line_A %in% line_B)[1] - 1
  steps_to_B_ancestor <- which(line_B %in% line_A)[1] - 1
  0.5^(steps_to_A_ancestor + steps_to_B_ancestor)
}

#################################################################
#' find_dyad_common.ancestor
#'
#' Find the common ancestor between two IDs.
#'
#' @inheritParams find_dyad_relatedness
#' @return The id of the common ancestor.
#' @describeIn find_family find the most recent common ancestor between two ids.
#' @export
#' @examples
#' load_database()
#' find_dyad_id.ancestor.MRCA(ID1 = "A-010", ID2 = "A-001", lineage = "mothergenetic")
#'
find_dyad_id.ancestor.MRCA <- function(ID1, ID2, lineage = "mothergenetic", .hyena_tbl = NULL) {

  ID1 <- check_arg_ID(ID1)
  ID2 <- check_arg_ID(ID2)
  lineage <- check_arg_lineage(lineage)

  if (is.null(.hyena_tbl)) .hyena_tbl <- extract_database("hyenas")

  line_A <- find_id_id.ancestor.all(ID1, lineage = lineage, .hyena_tbl = .hyena_tbl)
  line_B <- find_id_id.ancestor.all(ID2, lineage = lineage, .hyena_tbl = .hyena_tbl)

  if (length(base::intersect(line_A, line_B)) == 0) return(NA)
  base::intersect(line_A, line_B)[1]
}

#################################################################
#' fetch_dyad_relatedness.via.mother.genetic
#'
#' Calculate the ralatedness between two IDs, user level function following the
#' fetch family.
#'
#' @inheritParams find_dyad_relatedness
#' @return A coefficient of relatedness.
#' @describeIn fetch_family fetch the coefficent of relatedness between two hyenas via genetic mother lineage.
#' @export
#' @examples
#' fetch_dyad_relatedness(ID1 = c("A-084", "A-010"),
#'                        ID2 = c("A-010", "A-001"),
#'                        lineage = "mothersocial")

fetch_dyad_relatedness  <- function(ID1, ID2, lineage = "mothergenetic", .hyena_tbl = NULL) {

  ID1 <- check_arg_ID(ID1)
  ID2 <- check_arg_ID(ID2)
  lineage <- check_arg_lineage(lineage)

  if (is.null(.hyena_tbl)) .hyena_tbl <- extract_database("hyenas")

purrr::pmap_dbl(list(ID1, ID2), ~ find_dyad_relatedness(..1, ..2, lineage = lineage, .hyena_tbl = .hyena_tbl))
}



#' @describeIn create_family create a tidy table with individuals and their relatedness.
#' @param ID A vector of ids
#' @export
#' @examples
#'
#' #### Simple example of create_relatedness table usage:
#' create_dyad_relatedness.table(c("A-100", "L-003", "A-100", "A-010"),
#'                               lineage = "father")

create_dyad_relatedness.table <- function(ID, lineage = "mothergenetic") {

  ID <- check_arg_ID(ID)
  lineage <- check_arg_lineage(lineage)
  ## create an empty matrix with output number of rows and 2 col
  input <- matrix(NA_character_, nrow = (length(ID) * (length(ID) - 1 )) / 2, ncol = 2)
  colnames(input) <- c("ID1", "ID2")

  ## add the IDs
  k <- 1
  for (i in 1:(length(ID) - 1)) {
    for (j in (i + 1):length(ID)) {
      input[k, 1] <- ID[i]
      input[k, 2] <- ID[j]
      k <- k + 1
    }
  }
  ## and turn into a df
  output <- tibble::as_tibble(input)

  ## calculate the relededness using find_dyad_relatedness.
  hyenas <- extract_database(tables = "hyenas") ## load the hyenas tbl once
  output <- output %>%
    dplyr::mutate(relatedness = fetch_dyad_relatedness(ID1 = .data$ID1, .data$ID2,
                                                       lineage = "mothergenetic",
                                                       .hyena_tbl = !!hyenas))
  return(output)
}
