## FUNCTIONS USED FOR ESTIMATING DEMOGRAPHY

#' Determine age of a specific individual.
#'
#' @param age_units Units with which age should be measured.
#' @param birthdate Birthdate of individual.
#' @param deathdate Deathdate of individual (if it exists).
#' @param end_date End date of the focal period.
#'
#' @return Returns the age of an individual in specified units.

calc_age <- function(age_units, birthdate, deathdate, end_date) {
  format <- "%Y-%m-%d"
  origin <- "1970-01-01"
  birthdate <- as.Date(birthdate, format = format, origin = origin)
  deathdate <- as.Date(deathdate, format = format, origin = origin)
  end_date <- as.Date(end_date, format = format, origin = origin)

  lastdate <- if (is.na(deathdate) | !is.na(deathdate) & deathdate > end_date) end_date else deathdate

  if (age_units == "season") {
    return(as.numeric(round((lastdate - birthdate) / (365 / 2)) * 0.5))
  } else if (age_units == "years") {
    return(as.numeric(lastdate - birthdate) / 365)
  } else if (age_units == "months") {
    return(lubridate::interval(birthdate, lastdate) %/% months(1))
  } else {
    return(round(as.numeric(difftime(lastdate, birthdate, units = age_units))))
  }
}

#####################################################################################

#' Determine current clan for an individual in a given period.
#'
#' Determines:
#' - Whether an individual dispersed during the focal period.
#' - Clan they were in at the start of the focal period.
#' - Clan they were in at the end of the focal period.
#'
#' @param focal_indv Name of focal individual.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param selections Selections table in the database
#' @param birthclan Clan where the individual was born.
#' @param pb R6 progress bar object.
#' @param sex Sex of individual (this will influence how a non-dispersed individual is treated)
#'
#' @import dplyr
#'
#' @return Returns a tibble with focal name and calculated variables.

calc_currentclan <- function(focal_indv, sex, start_date, end_date, selections, birthclan, pb) {

  # Assign NULL to avoid global binding NOTE
  ID <- destination <- . <- status <- dispersal <- NULL

  format <- "%Y-%m-%d"

  if (start_date == "-Inf") {
    start_date <- -Inf
  } else {
    start_date <- as.Date(start_date, format = format)
  }

  end_date <- as.Date(end_date, format = format)

  indv_selections <- selections %>%
    # Subset selections to just include the current individual.
    filter(ID == focal_indv) %>%
    collect()

  # If there are no records of dispersals for this individual EVER..
  if (nrow(indv_selections) == 0) {

    # If it's a male or has no sex give it no dispersal info
    if (is.na(sex) | sex == "Male") {

      # Then it could never have dispersed, so make everything NA
      dispersal <- NA
      status <- "Pre-disperser"
      tenure <- NA

      # Otherwise, if it's a female, say that it is undispersed (and has no tenure)
    } else {
      dispersal <- FALSE
      status <- "Undispersed"

      # These individuals do not have a tenure, this is a male only variable!
      tenure <- NA
    }

    # Then just output a tibble with start and end clan the same as birthclan
    # Give it a status of undispersed.
    pb$tick()

    return(tibble::tibble(ID = focal_indv, dispersal = dispersal, status = status, start_clan = birthclan, current_clan = birthclan, tenure = tenure))

    # Otherwise, if the individual has made a selection at some point in its life...
  } else {
    earlier_disp <- subset(indv_selections, date < start_date)

    # If there were no selections BEFORE the period of interest (or they were all philopatric)
    if (nrow(earlier_disp) == 0 | all(earlier_disp$origin == earlier_disp$destination)) {

      # Make start_clan the same as birthclan
      start_clan <- birthclan

      # Make tenure = NA. Tenure is only relevant once an individual has dispersed...
      tenure <- NA

      nr_disp <- 0

      # Otherwise, if there have been earlier selection that were not philopatric
    } else {

      # ...make start_clan the destination of the latest selection before the start date
      start_clan <- indv_selections %>%
        filter(as.Date(date, format = format) < start_date) %>%
        slice(n()) %>%
        .$destination

      # Make a variable tenure_start, that is the date that the individual first entered its current clan
      tenure_start <- as.Date(indv_selections %>%
        filter(as.Date(date, format = format) < start_date) %>%
        slice(n()) %>%
        .$date, format = format)

      # Determine the tenure at the current start_date (in months)
      tenure <- lubridate::interval(tenure_start, start_date) %/% months(1)

      nr_disp <- sum(earlier_disp$origin != earlier_disp$destination)
    }

    # If there were any dispersals AFTER the start date and before the end date (i.e. during the focal period)
    if (any(as.Date(indv_selections$date, format = format) >= start_date &
      as.Date(indv_selections$date, format = format) < end_date)) {

      # Save the destination clan as end_clan...
      end_clan <- indv_selections %>%
        filter(as.Date(date, format = format) >= start_date &
          as.Date(date, format = format) < end_date) %>%
        slice(n()) %>%
        .$destination

      dispersal <- TRUE

      # Reset tenure to 0
      tenure <- 0

      # Make the number of dispersals 1 more then it was previously
      nr_disp <- nr_disp + 1
    } else {

      # Otherwise, the end clan is the same as the start clan
      end_clan <- start_clan

      # There is no dispersal and tenure is unchanged.
      dispersal <- FALSE
    }

    # If birth_clan is the same as the end_clan
    if (birthclan == end_clan) {

      # If it's a male, this means it has made a selection decision but it stayed philopatric
      if (is.na(sex) | sex == "Male") {

        # Then it's a philopatric male and it's not counted as a dispersal
        status <- "Philopatric"

        # Otherwise, if it's female, we just say it's not dispersed
      } else {
        status <- "Undispersed"
        tenure <- NA
      }

      # Otherwise, if they have changed clans since they were born then it is considered to have dispersed (regardless of sex)
    } else {

      # Make it first time or second time disperser based on previous dispersal events
      if (nr_disp == 1) {
        status <- "Primary_disperser"
      } else if (nr_disp > 1) {
        status <- "Secondary_disperser"
      }
    }

    pb$tick()

    browser(expr = !is.character(status))

    return(tibble::tibble(ID = focal_indv, dispersal = dispersal, status = status, start_clan = start_clan, current_clan = end_clan, tenure = tenure))
  }
}

############################################################################################

calc_motherrank <- function(rank_std, sex, age, focal_mothergenetic, focal_mothersocial, date, deaths, data) {
  ID <- . <- deathdate <- NULL

  # In cases where there is no gender rank...
  if (is.na(rank_std)) {

    # And we're dealing with a cub
    if (age < 24) {

      # If it has a social mother listed (preferable to genetic mother only for rank)
      if (!is.na(focal_mothersocial)) {

        # If the mother was alive in the period of measurement...
        if (focal_mothersocial %in% data$ID) {

          # Return the gender rank of that mother
          return(filter(data, ID == focal_mothersocial) %>%
            .$rank_std)

          # Otherwise, if the social mother is not present we need to estimate her rank at another point
        } else {
          mother_last <- filter(deaths, ID == focal_mothersocial) %>%
            rename(date = deathdate) %>%
            collect()

          return(as.numeric(calculate_rank(input = mother_last) %>%
            .$rank_std))
        }

        # Do the same for the genetic mother if social mother is not provided
      } else if (!is.na(focal_mothergenetic)) {

        # If the mother was alive in the period of measurement...
        if (focal_mothergenetic %in% data$ID) {

          # Return the gender rank of that mother
          return(filter(data, ID == focal_mothergenetic) %>%
            .$rank_std)

          # Otherwise, if the social mother is not present we need to estimate her rank at another point
        } else {
          mother_last <- filter(deaths, ID == focal_mothergenetic) %>%
            rename(date = deathdate) %>%
            collect()

          return(as.numeric(calculate_rank(input = mother_last) %>%
            .$rank_std))
        }
      } else {
        return(NA)
      }

      # If the individual is an adult but has no gender rank, leave it as NA
    } else {
      return(NA)
    }
  } else {
    return(as.numeric(rank_std))
  }
}

#############################################################################

## FUNCTIONS USED TO CONVERT ITEM TYPES WHEN USING RETICULATE AND PYTHON.

#' Convert a dataframe to a list with items for each dataframe column.
#'
#' @param x First column
#' @param y Second column
#'
#' @return Returns a list with two items for column 1 and 2.

df_to_list <- function(x, y) {
  return(list(ID = x[1], date = y[1]))
}


#################################################################################

# EXTRACT RAW CLAN SUMMARIES WITH GEN_STATE IN PYTHON

#' Extract raw clan summary for \code{\link{clan_summary}}.
#'
#' @param clan Code of clan.
#' @param date Date of summary. YYYY-MM-DD
#'
#' @import DBI
#' @import RSQLite
#' @import dplyr
#'
#' @return A tibble with raw clan information.

get_rawclan_summary <- function(clan = NULL, date = NULL) {

  # Run python code to include my extra functions AND Ilja's function library
  reticulate::py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))
  reticulate::py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))

  # Generate state of clans on each date
  output_file <- reticulate::py$clan_summary(.database$db, dates = date)

  return(output_file)
}

#################################################################################

# UPDATE AND PRUNE DRAT REPOSITORY

#' Update the version of hyenaR in the drat folder.
#'
#' __This is an internal function__. Updates the version of hyenaR in the drat folder.
#' First update the version number in DESCRIPTION.
#'
#' @param drat_folder Location of drat folder.
#'
#' @import drat
#' @import devtools
# @importFrom utils choose.dir menu

update_drat <- function(drat_folder = NULL) {
  if (is.null(drat_folder)) {
    print("Please select the location of the drat folder...")

    stop("choose.dir not exist in linux") # drat_folder <- choose.dir()
  }

  print("Build package...")
  devtools::build()

  print("Update in drat...")
  targz <- list.files(pattern = "tar.gz", path = "..", full.names = TRUE)
  drat::insertPackage(targz, repodir = drat_folder)

  print("Prune out old version...")
  drat::pruneRepo(repopath = drat_folder, remove = TRUE)

  print("Do not forget to commit and push your drat!")
}
