#' Fetch information about given hyena(s)
#'
#' These functions allows for the extraction of individual-level information
#' that either remain constant for a hyena over time, or that varies. The
#' ```fetch_xxx``` functions have not been designed to be particularly
#' efficient, so they should not be used by an intensive procedures (e.g.
#' simulations). Instead they have been designed to be particularly robust so
#' that they can be safely used directly by users.
#'
#' These functions can be used with inputs of length 1 or using vector. They
#' produce a vector of the same length and order than the hyenas name given.
#' Such vectors can easily be added to existing tables using e.g.
#' [dplyr::mutate()] (see example).
#'
#' Note for developpers: if ```debug``` is set to ```TRUE``` the functions
#' output a `tibble` (instead of a vector), with detailed information on what is
#' used for the computation. This is only possible for some but not all
#' functions.
#'
#' @param ID The ID code of hyena(s).
#' @param clan The clan.
#' @param date The date(s) using the format "YYYY-MM-DD".
#' @param from The start date of a date range using the format
#' "YYYY-MM-DD" or "YYYY/MM/DD". Combined with argument 'to' to create date range.
#' Will default to earliest database observation date unless otherwise specified.
#' Cannot be used with argument 'at'.
#' @param to The end date of a date range using the format
#' "YYYY-MM-DD" or "YYYY/MM/DD". Combined with argument 'from' to create date range.
#' Will default to latest database observation date unless otherwise specified.
#' Cannot be used with argument 'at'.
#' @param at A single date using the format
#' "YYYY-MM-DD" or "YYYY/MM/DD". Cannot be used with arguments 'from' and 'to'.
#' @param duration A number providing the maximal duration of follow up.
#' @param age The age(s) of the hyena(s).
#' @param unit The unit for the age(s) of the hyena(s): "day", "week", "month"
#'   or "year" (default).
#' @param filiation The type of parent-offspring relationship: "genetic_only",
#' "social_only", "social_and_genetic", or a combination.
#' @param debug Whether the functions should run into
#'   debugging mode (`TRUE`) or not (`FALSE`, default).
#' @param error_margin The window period of estimated dates.
#' @name fetch_family
#' @aliases fetch_family fetch
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_database()
NULL


#' @describeIn fetch_family companion function for fetch functions; it cleans the input
#'  and reformat it as a `tibble`.
#'
#' This function should not be directly used by the user.
#' @examples
#'
#' # clean_input_fetch_xxx_at(ID = c("A-080", "L-012"), age = c(2, 3))
clean_input_fetch_xxx_at <- function(ID, age) {
  dplyr::tibble(ID = ID, age = age)
}


#' @describeIn fetch_family fetch the age of a hyena on a given day.
#'
#' Note that if the hyena is dead, the age will be ```NA```.
#' @export
#' @examples
#'
#'
#'
#' ################ examples for time varying fetch_xx functions ################
#'
#'
#' #### Detailed example of fetch_age usage:
#'
#' ### fetch age of 2 individuals at 2 dates:
#' fetch_age(ID = c("A-080", "L-012"), date = c("1997-10-04", "1996-07-01"))
#'
#' ### fetch age of 1 individual at 2 dates:
#' fetch_age(ID = "A-080", date = c("1996-10-04", "1997-01-04"))
#'
#' ### fetch age of 2 individuals at 1 date:
#' fetch_age(ID = c("A-080", "L-012"), date = "1996-07-01")
#'
#' ### more advanced usage (add a new column in the hyena table containing lifespan):
#' ## note: this is more easily done using fetch_lifespan (see above)
#'
#' ## step 1. extract the hyena table:
#' hyena_table <- extract_database(tables = "hyenas")
#'
#' ## step 2. add date of death and lifespan to a new table:
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#' hyena_table %>%
#'   mutate(
#'     death_date = fetch_deathdate(ID = ID),
#'     lifespan = fetch_age(ID = ID, date = death_date)
#'   ) -> lifespan_table
#' }
#'
#' ## step 3. view the outcome
#' lifespan_table
#' # note: all existing columns may not show on your screen unless you run
#' # options(tibble.width = Inf)
fetch_age <- function(ID, date, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(date))

  hyenas <- extract_database(tables = "hyenas")
  deaths <- extract_database(tables = "deaths")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::left_join(deaths, by = "ID") %>%
    dplyr::select(ID, birthdate, deathdate) %>%
    dplyr::mutate(
      age = lubridate::interval(birthdate, date) / lubridate::duration(1, units = check_arg_unit(unit))
    ) %>%
    dplyr::mutate(age = dplyr::case_when( ## give no focal age if dead!
      is.infinite(age) ~ NA_real_,
      is.na(deathdate) ~ age,
      date <= deathdate ~ age,
      date > deathdate ~ NA_real_
    )) -> output

  if (debug) {
    return(output)
  }

  birthdate <- deathdate <- date <- age <- NULL ## to please R CMD check

  output$age
}


#' @describeIn fetch_family fetch the birth clan of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_birthclan usage:
#' fetch_birthclan(ID = c("A-001", "A-007"))
fetch_birthclan <- function(ID) {
  pull_column_from_table(column = "birthclan", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the birthday of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_birthdate usage:
#' fetch_birthdate(ID = c("A-001", "A-007"))
fetch_birthdate <- function(ID) {
  pull_column_from_table(column = "birthdate", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_birthrank usage:
#' fetch_birthrank(ID = c("A-080", "A-100"))
#'
fetch_birthrank <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_birthdate(ID),
    birth_rank = fetch_rank(ID = ID, date = birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  birth_date <- NULL ## to please R CMD check

  output$birth_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_birthrank usage:
#' fetch_birthrankstd(ID = c("A-080", "L-012"))
#' \dontrun{
#' #### Example with missing information:
#' load_database(file.choose())
#' fetch_birthrankstd(ID = c("A-001", "A-100"))
#' }
fetch_birthrankstd <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_birthdate(ID),
    birth_rank = fetch_rankstd(ID = ID, date = birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  birth_date <- NULL ## to please R CMD check

  output$birth_rank
}


#' @describeIn fetch_family deprecated function! Use [fetch_is_censored_left()] instead.
#'
#' @export
fetch_censored_left <- function() .Deprecated("fetch_is_censored_left")


#' @describeIn fetch_family fetch the clan a given individual at a given age.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan usage:
#' fetch_clan(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30"))
fetch_clan <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$clan))) output %>% mutate(clan = NA_character_) -> output

  if (debug) {
    return(output)
  }

  output$clan
}


#' @describeIn fetch_family fetch the number of adults in the clan of a given
#'   individual on a given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_clanadults usage:
#' fetch_clanadults(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30"))
fetch_clanadults <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$clanadults))) output %>% mutate(clanadults = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$clanadults
}



#' @describeIn fetch_family fetch the clan size a given individual on a given
#'   date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_clantotal usage:
#' fetch_clantotal(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30"))
fetch_clantotal <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$clantotal))) output %>% mutate(clantotal = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$clantotal
}


#' @describeIn fetch_family fetch the date at which a given hyena has reached
#' a given age.
#'
#' Note that if the hyena is _known_ to be dead or censored, a date will still be given.
#' You can combine [fetch_age()] with [fetch_is_alive()] if it is not what you want.
#' @export
#'
#' @examples
#'
#' #### Detailed example of fetch_date usage:
#'
#' ### fetch date of 1 individual at 2 ages:
#' fetch_date(ID = c("A-080"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 1 age:
#' fetch_date(ID = c("A-080", "L-012"), age = 2)
#'
#' ### fetch date of 2 individuals at 2 ages in years:
#' fetch_date(ID = c("A-080", "L-012"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 2 ages in weeks:
#' fetch_date(ID = c("A-080", "L-012"), age = c(2, 3), unit = "week")
#'
fetch_date <- function(ID, age, unit = "year", debug = FALSE) {
  input <- tibble::tibble(ID = check_arg_ID(ID),
                          age = age,
                          unit = check_arg_unit(unit, max.length = 1L))

  input %>%
    mutate(birthdate = fetch_birthdate(ID),
           date = as.Date(.data$birthdate + lubridate::duration(.data$age, units = .data$unit[1]))) -> output

  if (debug) {
    return(output)
  }

  output$date
}


#' @describeIn fetch_family fetch the date at which a given individual has conceived its first known offspring.
#'
#' Note that conception is here defined as the offspring birthdate minus 110 days.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_date_at_first_conception usage:
#' fetch_date_at_first_conception(ID = c("A-001", "L-003"))
#' \dontrun{
#' #### Simple example of fetch_date_at_first_conception usage on all data:
#'
#' ### Fetch the date at first conception for all:
#' fetch_date_at_first_conception(find_IDs())
#' }
fetch_date_at_first_conception <- function(ID, debug = FALSE) {
  input <- tibble::tibble(ID = check_arg_ID(ID))

  create_offspringtable(ID) %>%
    dplyr::filter(!is.na(.data$filiation) & .data$filiation != "social_only") %>%
    dplyr::mutate(offspring_birthdate = fetch_birthdate(ID = .data$offspring)) %>%
    dplyr::group_by(.data$parent) %>%
    dplyr::arrange(.data$offspring_birthdate, .by_group = TRUE) %>%
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(conception_date = .data$offspring_birthdate - lubridate::days(110)) %>%
    dplyr::left_join(x = input, y = ., by = c("ID" = "parent")) -> output

  if (debug) {
    return(output)
  }

  output$conception_date
}


#' @describeIn fetch_family fetch the date at first selection a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_mothergenetic usage:
#' fetch_date_at_first_selection(ID = c("A-011", "A-040"))
fetch_date_at_first_selection <- function(ID, debug = FALSE) {

  ID <- check_arg_ID(ID)
  input <- tibble::tibble(ID = !!ID)

  create_id_life.transition(ID = unique(ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(2) %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output

  if (debug) return(output)

  output$date

}


#' @describeIn fetch_family fetch the date of a given hyena at its death.
#' @export
#' @examples
#'
#' #### Simple example of fetch_deathdate usage:
#' fetch_deathdate(ID = c("L-012", "A-007"))
fetch_deathdate <- function(ID) {
  pull_column_from_table(column = "deathdate", table = "deaths", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the (genetic) father of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_father usage:
#' fetch_father(ID = c("A-080", "L-012"))
fetch_father <- function(ID) {
  pull_column_from_table(column = "father", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the first date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the first sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_first_observed_date usage:
#' fetch_first_observed_date(ID = c("A-080", "L-012"))
fetch_first_observed_date <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  extract_database(tables = "sightings") %>%
    dplyr::mutate(sighting_date = as.Date(date_time)) -> sightings

  input %>%
    dplyr::left_join(sightings, by = "ID") %>%
    dplyr::select(ID, sighting_date) %>%
    dplyr::group_by(ID) %>%
    dplyr::summarise(first_obs_date = min(sighting_date)) %>%
    dplyr::ungroup() %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output
  ## Note: the last left_join is important because otherwise summarise changes the order of the rows!!!!!

  if (debug) {
    return(output)
  }

  sighting_date <- first_obs_date <- date_time <- NULL ## to please R CMD check

  output$first_obs_date
}


#' @describeIn fetch_family fetch the social rank within sex of a given individual on a
#'   given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_genderrank usage:
#' fetch_genderrank(ID = c("A-001", "A-002"), date = c("1997-01-04", "1996-06-30"))
fetch_genderrank <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$gender_rank))) output %>% mutate(gender_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank
}


#' @describeIn fetch_family fetch the standardized social rank within sex of a given
#'   individual on a given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_genderrankstd usage:
#' fetch_genderrankstd(ID = c("A-001", "A-002"), date = c("1997-01-04", "1996-06-30"))
fetch_genderrankstd <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$gender_rank_std))) output %>% mutate(gender_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank_std
}


#' @describeIn fetch_family fetch if a given individual was alive on a given
#'   date.
#'
#'   The functions simply check if a given date falls between the birth and
#'   death date of a given hyena. It does not consider any other complexity.
#' @export
#' @examples
#'
#' #### Simple example of fetch_is_alive usage:
#' fetch_is_alive(ID = c("A-080", "L-012"), date = c("1997-10-04", "1997-10-04"))
fetch_is_alive <- function(ID, date, debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(date))

  hyenas <- extract_database(tables = "hyenas")
  deaths <- extract_database(tables = "deaths")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::left_join(deaths, by = "ID") %>%
    dplyr::select(ID, birthdate, deathdate) %>%
    dplyr::mutate(
      surv = (is.na(deathdate) | deathdate > date) & (date >= birthdate)
    ) -> output

  if (debug) {
    return(output)
  }

  birthdate <- deathdate <- NULL ## to please R CMD check

  output$surv
}


#' @describeIn fetch_family fetch whether an individual could have _potentially_ be observed when young.
#'
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_is_censored_left usage:
#' fetch_is_censored_left(c("A-100", "L-003"))
fetch_is_censored_left <- function(ID, debug = FALSE) {

  input <- dplyr::tibble(ID = check_arg_ID(ID))

  hyenas <- extract_database("hyenas")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::mutate(birthdate = fetch_birthdate(ID),
                  date_firstsighting = find_firstsighting(),
                  left_censored = birthdate < date_firstsighting) -> output

  if (debug) {
    return(output)
  }

  birthdate <- date_firstsighting <- left_censored <- NULL ## to please R CMD check

  output$left_censored
}


#' @describeIn fetch_family fetch whether an individual's deathdate is confirmed.
#'
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_is_deathconfirmed usage:
#' fetch_is_deathconfirmed(c("A-100", "L-003"))
fetch_is_deathconfirmed <- function(ID) {

  input <- check_arg_ID(ID)

  confirmed_death_date <- pull_column_from_table(column = "deathconfirmed", table = "hyenas", ID = input)

  !is.na(confirmed_death_date)

}


#' @describeIn fetch_family fetch if a given hyena is an immigrant
#' @export
#' @examples
#'
#' #### Simple example of fetch_is_immigrant usage:
#' fetch_is_immigrant(ID = c("A-001", "A-002"), date = "1997-11-01")
fetch_is_immigrant <- function(ID, date, debug = FALSE) {
  input <- tibble::tibble(ID = check_arg_ID(ID),
                          date = check_arg_date(date))

  input %>%
    dplyr::mutate(native = fetch_is_native(ID, date)) -> output

  if (debug) return(output)

  !output$native
}


#' @describeIn fetch_family fetch if a given hyena is a native
#' @export
#' @examples
#'
#' #### Simple example of fetch_is_native usage:
#' fetch_is_native(ID = c("A-001", "A-002"), date = "1997-11-01")
fetch_is_native <- function(ID, date, debug = FALSE) {
  input <- tibble::tibble(ID = check_arg_ID(ID),
                          date = check_arg_date(date))

  input %>%
    dplyr::mutate(birthclan = fetch_birthclan(ID),
                  current_clan = fetch_clan(ID, date = date),
                  native = birthclan == current_clan) -> output

  if (debug) return(output)

  birthclan <- current_clan <- NULL ## To please R CMD check

  output$native
}


#' @describeIn fetch_family fetch whether an individual could have _potentially_ be observed for a given duration.
#'
#' Note that the actual time of death of the hyena is irrelevant for this function.
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_is_observable usage:
#' fetch_is_observable(c("A-100", "L-003"), duration = 3, unit = "week")
fetch_is_observable <- function(ID, duration = NULL, unit = "year", debug = FALSE) {

  input <- dplyr::tibble(ID = check_arg_ID(ID),
                         duration = check_arg_duration(duration),
                         unit = check_arg_unit(unit))

  hyenas <- extract_database("hyenas")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::mutate(birthdate = fetch_birthdate(ID),
                  date_firstsighting = find_firstsighting(),
                  date_lastsighting = find_lastsighting(),
                  followup = furrr::future_pmap(list(duration, unit),
                                                ~ lubridate::duration(..1, units = ..2))
    ) -> output

  output$followup <- do.call("c", output$followup) ## Workaround tidyr::unnest(followup) which is way too slow

  output %>%
    dplyr::mutate(left_censored = birthdate < date_firstsighting,
                  right_censored = birthdate + followup > date_lastsighting, ## not compared to death (this is important!)
                  ## so perhaps calling that right_censored is misleading
                  observable = !left_censored & !right_censored) -> output

  if (debug) {
    return(output)
  }

  birthdate <- date_firstsighting <- date_lastsighting <- left_censored <- right_censored <- followup <- NULL ## to please R CMD check

  output$observable
}


#' @describeIn fetch_family fetch if the focal individual(s) have selected given clan(s) at given date(s).
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_id_is.selector usage:
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      date = c("1996-07-10", "1996-07-12", "1996-04-13"))
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      date = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error_margin = "30 days")
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040"),
#'                      clan = c("A", "A", "A"),
#'                      date = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error_margin = "90 days")

fetch_id_is.selector <- function(ID, clan, date, error_margin = "0 days", debug = FALSE){

  input <- tibble::tibble(ID = check_arg_ID(ID), clan = check_arg_clan(clan), date = check_arg_date(date))
  error_margin <- check_arg_period(error_margin)

  life_history <- create_id_life.history(unique(ID), censored_replaced_by_last_sighting = TRUE)

  dplyr::left_join(input, life_history, by = c("ID", "clan")) %>%
    dplyr::mutate(
      starting_date_approx = .data$starting_date - !!error_margin,
      ending_date_approx = .data$ending_date + !!error_margin,
      overlap = .data$date >= .data$starting_date_approx & .data$date <= .data$ending_date_approx,
      is_selector = .data$overlap & !(.data$life_stage %in% c("cub", "subadult", "natal", "transient", "unknown")),
      death_confirmed = fetch_is_deathconfirmed(.data$ID),
      deathdate = fetch_deathdate(.data$ID),
      # if really dead, then it is not a selector:
      is_selector = ifelse(.data$death_confirmed & .data$date > .data$deathdate, FALSE, .data$is_selector))  -> output

  if (debug) {
    return(output)
  }

  output %>%
    dplyr::group_by(.data$ID, .data$clan, .data$date) %>%
    dplyr::summarise(is_selector = any(.data$is_selector)) %>%
    dplyr::left_join(input, ., by = c("ID", "clan", "date")) -> output2

  output2$is_selector
}


#' @describeIn fetch_family fetch if individuals could have been observed on
#'   a given date.
#'
#'   The functions simply check if a given date falls between the first and the
#'   last sighting. It does not consider any other complexity, such as if
#'   someone was actually in the field at this particular date.
#' @export
#' @examples
#'
#' #### Simple example of fetch_is_observed usage:
#' fetch_is_observed(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-07-01"))
fetch_is_observed <- function(ID, date, debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(date))

  input %>%
    dplyr::mutate(
      first_obs_date = fetch_first_observed_date(ID = ID),
      last_obs_date = fetch_last_observed_date(ID = ID),
      obs = (date >= first_obs_date) & (date <= last_obs_date)
    ) -> output
  ## Note: we do not use between() because it is not a fully vectorized function.

  if (debug) {
    return(output)
  }

  first_obs_date <- last_obs_date <- NULL ## to please R CMD check

  output$obs
}


#' @describeIn fetch_family fetch the last date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the last sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_last_observed_date usage:
#' fetch_last_observed_date(ID = c("A-080", "L-012"))
fetch_last_observed_date <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  extract_database(tables = "sightings") %>%
    dplyr::mutate(sighting_date = as.Date(date_time)) -> sightings

  input %>%
    dplyr::left_join(sightings, by = "ID") %>%
    dplyr::select(ID, sighting_date) %>%
    dplyr::group_by(ID) %>%
    dplyr::summarise(last_obs_date = max(sighting_date, na.rm = TRUE)) %>%
    ## Note: na.rm = TRUE is a temporary patch that should disappear when issue #56 will be solved
    dplyr::ungroup() %>%
    dplyr::left_join(x = input, y = ., by = "ID") -> output
  ## Note: the last left_join is important because otherwise summarise changes the order of the rows!!!!!

  if (debug) {
    return(output)
  }

  sighting_date <- last_obs_date <- date_time <- NULL ## to please R CMD check

  output$last_obs_date
}


#' @describeIn fetch_family fetch the lifespan of a given hyena at its death.
#' @export
#' @examples
#'
#' ################### examples for fetch_xx functions ###################
#'
#'
#' #### Detailed example of fetch_lifespan usage:
#' ### note: what is shown here also applies to all other fetch_xx_yy functions
#'
#' ### fetch the lifespan of all individuals:
#' fetch_lifespan(ID = find_IDs())
#'
#' ### fetch the lifespan of two individuals:
#' fetch_lifespan(ID = c("A-007", "A-043"))
#'
fetch_lifespan <- function(ID, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  hyenas <- extract_database(tables = "hyenas")
  deaths <- extract_database(tables = "deaths")

  input %>%
    dplyr::left_join(hyenas, by = "ID") %>%
    dplyr::left_join(deaths, by = "ID") %>%
    dplyr::select(ID, birthdate, deathdate) %>%
    dplyr::mutate(lifespan = lubridate::interval(birthdate, deathdate) / lubridate::duration(1, units = check_arg_unit(unit))) -> output

  if (debug) {
    return(output)
  }

  birthdate <- deathdate <- lifespan <- NULL ## to please R CMD check

  output$lifespan
}


#' @describeIn fetch_family fetch the life stage of given individual(s) on given date(s).
#' @export
#' @examples
#'
#'
#' #### Simple example of fetch_id_life.stage usage:
#' fetch_id_life.stage(ID = c("A-001"),date = c("1997-01-01"))

fetch_id_life.stage <- function(ID, date, debug = FALSE) {

  input_full <- dplyr::tibble(ID = check_arg_ID(ID),
                              focal_date = check_arg_date(date))
  input <-  unique(input_full)

  ## reduce to unique case for speed up:
  life_history <- create_id_life.history(unique(ID), censored_replaced_by_last_sighting = TRUE)

  dplyr::left_join(input, life_history, by = "ID") %>%
    dplyr::filter(.data$focal_date >= .data$starting_date  & (.data$focal_date <= .data$ending_date | is.na(.data$ending_date))) -> life_stage

  ## left joins will return NA for unmatched dates
  output <- dplyr::left_join(input_full, life_stage)

  output$life_stage

}



#' @describeIn fetch_family fetch the ID of the dominance status in the litter of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_litterdominance usage:
#' fetch_litterdominance(ID = c("A-018", "A-046"))
fetch_litterdominance <- function(ID) {
  pull_column_from_table(column = "litterdominance", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the genetic mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_mothergenetic usage:
#' fetch_mothergenetic(ID = c("A-080", "L-012"))
fetch_mothergenetic <- function(ID) {
  pull_column_from_table(column = "mothergenetic", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the social mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_mothersocial usage:
#' fetch_mothersocial(ID = c("A-080", "L-012"))
fetch_mothersocial <- function(ID) {
  pull_column_from_table(column = "mothersocial", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the social rank within native for a given individual on a
#'   given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_nativerank usage:
#' fetch_nativerank(ID = c("A-001", "A-002"), date = c("1997-01-04", "1996-06-30"))
fetch_nativerank <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$nat_rank))) output %>% mutate(nat_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank
}


#' @describeIn fetch_family fetch the standardised social rank within native for a given individual on a
#'   given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_nativerank usage:
#' fetch_nativerankstd(ID = c("A-001", "A-002"), date = c("1997-01-04", "1996-06-30"))
fetch_nativerankstd <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$nat_rank_std))) output %>% mutate(nat_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank_std
}


#' @describeIn fetch_family deprecated function! Use [fetch_is_observable()] instead.
#' @export
fetch_observable <- function() .Deprecated("fetch_is_observable")


#' @describeIn fetch_family deprecated function! Use [fetch_is_observed()] instead.
#' @export
fetch_observed <- function() .Deprecated("fetch_is_observed")


#' @describeIn fetch_family fetch the number of known offspring produced by a given individual.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_offspring_number usage:
#' fetch_offspring_number(ID = c("A-001", "A-100", "L-003"))
#' \dontrun{
#' #### Simple example of fetch_offspring_number usage on all data:
#'
#' ### Fetch the date at first conception for all:
#' fetch_offspring_number(find_IDs())
#' }
fetch_offspring_number <- function(ID, from, to, at,
                                   filiation = c("genetic_only", "social_and_genetic"), debug = FALSE) {

  ID         <- check_arg_ID(ID)
  filiation  <- check_arg_filiation(filiation)
  date_range <- check_arg_date.fromtoat(from, to, at)
  from       <- date_range$from
  to         <- date_range$to

  ## Make table of all focals individuals
  ## This is joined into our offspring table below so that
  ## no focal IDs are lost during filtering
  create_basetable_from_IDs(ID = ID) %>%
    dplyr::rename(parent = .data$ID) -> foundation_table

  create_offspringtable(ID) %>%
    dplyr::filter(.data$filiation %in% !!filiation) %>%
    dplyr::mutate(birthdate = fetch_birthdate(ID = .data$offspring)) %>%
    dplyr::filter(between(.data$birthdate, from, to)) %>%
    dplyr::right_join(foundation_table, by = "parent") %>% # Join back focal individuals to account for cases where
    dplyr::group_by(.data$parent) %>%                      # reproductive success is 0.
    dplyr::summarise(
      offspring_nb = dplyr::n_distinct(.data$offspring, na.rm = TRUE)
    ) -> output

  if (debug) {
    return(output)
  }

  output$offspring_nb
}


#' @describeIn fetch_family fetch the social rank of a given individual on a
#'   given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_rank usage:
#' fetch_rank(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30"))
fetch_rank <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$rank))) output %>% mutate(rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on
#'   a given date.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_rankstd usage:
#' fetch_rankstd(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30"))
fetch_rankstd <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$rank_std))) output %>% mutate(rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank_std
}


#' @describeIn fetch_family fetch the social rank of a given individual on a given date within males
#'   that selected their clan.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_selrank usage:
#' fetch_selrank(ID = c("A-080", "L-012"), date = c("1997-01-04", "1996-06-30")) ## ToDo: change ID
fetch_selrank <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$sel_rank))) {
    output %>% mutate(sel_rank = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on a given date
#'   within males that selected their clan.
#'
#'   See [calculate_rank] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_selrankstd usage:
#' fetch_selrankstd(ID = c("A-001", "A-002"), date = c("1997-01-04", "1996-06-30"))  ## ToDo: change ID
fetch_selrankstd <- function(ID, date, debug = FALSE) {
  output <- extract_allrankinfo(ID = ID, date = date)

  if (suppressWarnings(is.null(output$sel_rank_std))) {
    output %>% mutate(sel_rank_std = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank_std
}


#' @describeIn fetch_family fetch the sex of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_sex usage:
#' fetch_sex(ID = c("A-001", "A-007"))
fetch_sex <- function(ID) {
  pull_column_from_table("sex", table = "hyenas", ID = ID)
}


#' @describeIn fetch_family deprecated function! Use [fetch_support_natives()] instead.
#'
#' @export

fetch_support <- function() .Deprecated("fetch_support_natives")


#' @describeIn fetch_family fetch the social support of natives and immigrants at a given time.
#'
#' This functions called [fetch_support_natives()] for natives and [fetch_support_immigrants()] for
#' immigrants, and combine the results.
#' @export
#' @examples
#'
#'#### Simple example of fetch_support_all usage:
#' fetch_support_all(ID = c("A-011", "A-100"), date = c("1997-01-04", "1997-11-30"))
#'
#'
#' #### Advanced example of fetch_support_all usage:
#' \dontrun{
#' load_database(file.choose()) # use the full dataset
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_basetable(clan = "E", date = "2006-04-01") %>%
#'     mutate(support = fetch_support_all(ID, date),
#'            rank = fetch_rank(ID, date)) -> res
#'   res
#' }
#' }
fetch_support_all <- function(ID, date, debug = FALSE) {
  time1 <- proc.time()

  input <- tibble::tibble(ID = check_arg_ID(ID),
                          date = check_arg_date(date))

  input %>%
    dplyr::mutate(immigrant = fetch_is_immigrant(ID, date = date)) -> input_full

  input_full %>%
    dplyr::filter(immigrant) -> input_immigrants

  input_full %>%
    dplyr::filter(!immigrant) -> input_natives

  message("Fetching support for immigrants...")
  input_immigrants %>%
    dplyr::mutate(support = suppressMessages(fetch_support_immigrants(ID, date = date))) -> output_immigrants

  message("Fetching support for natives...")
  input_natives %>%
    dplyr::mutate(support = suppressMessages(fetch_support_natives(ID, date = date))) -> output_natives

  output_immigrants %>%
    dplyr::bind_rows(output_natives) %>%
    dplyr::left_join(x = input_full, y = ., by = c("ID", "date", "immigrant")) -> output

  if (debug) return(output)

  birthclan <- current_clan <- immigrant <- NULL ## To please R CMD check

  time2 <- proc.time()

  message(crayon::green("All done in", round(time2 - time1)[[3]], "seconds!"))

  output$support
}


#' @describeIn fetch_family fetch the social support a given immigrant at a given time.
#' @export
#' @examples
#'
#'#### Simple example of fetch_support usage:
#' fetch_support_immigrants(ID = c("A-011", "A-100"), date = c("1997-01-04", "1997-06-30"))
#' ## ToDo: change IDs in the previous example
fetch_support_immigrants <- function(ID, date, debug = FALSE) {
  input <- tibble::tibble(ID = check_arg_ID(ID),
                          date = check_arg_date(date))

  input %>%
    dplyr::mutate(immigrant = fetch_is_immigrant(ID, date = date),
                  current_clan = fetch_clan(ID, date = date)) -> output

  if (any(!output$immigrant, na.rm = TRUE)) warning("Support based on tenure cannot be computed for non immigrants\n    -> Try filtering out natives from your data beforehand.")

  output %>%
    dplyr::filter(!is.na(current_clan), !is.na(immigrant)) %>%
    dplyr::mutate(adult_clan_size = fetch_clanadults(ID, date = date),
                  #immigrant_clan_size = purrr::pmap_int(list(current_clan, date), ~ count_immigrants(..1, ..2)),
                  tenure_focal = fetch_tenure(ID, date = date),
                  tenure_rank = purrr::pmap_int(list(current_clan, date, tenure_focal),
                                                ~ tibble::tibble(ID = find_immigrants(..1, ..2),
                                                                 tenure = fetch_tenure(ID, ..2)) %>%
                                                  summarise(longtenure_rank = sum(..3 > tenure)) %>%
                                                  pull(longtenure_rank)),
                  support = tenure_rank / (adult_clan_size - 1)) %>%
    dplyr::left_join(x = input, y= ., by = c("ID", "date")) -> output

  if (debug) return(output)

  birthclan <- current_clan <- immigrant <- tenure_focal <- tenure_rank <- adult_clan_size <- immigrant_clan_size <- NULL ## To please R CMD check

  output$support
}


#' @describeIn fetch_family fetch the social support a given individual at a given time.
#'
#' See [calculate_support] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#'#### Simple example of fetch_support usage:
#' fetch_support_natives(ID = c("A-001", "A-100"), date = c("1997-01-04", "1997-06-30"))
#' ## ToDo: change IDs in the previous example
#'
#' \dontrun{
#' #### Advanced example of fetch_support_natives usage:
#'  load_database(file.choose()) ## please select the full database
#'  if (require(dplyr)) { ## you need to load dplyr to run this example
#'    create_basetable() %>%
#'      mutate(date = "2015-01-01",
#'             support = fetch_support_natives(ID, date = date)) -> res_support
#'    res_support
#' }
#' }
fetch_support_natives <- function(ID, date, debug = FALSE) {
  time1 <- proc.time()
  mothersocial <- NULL

  ID <- check_arg_ID(ID)
  date <- check_arg_date(date)

  hyenas <- extract_database(tables = "hyenas") %>%
    dplyr::group_by(mothersocial) %>%
    dplyr::left_join(extract_database(tables = "deaths"), by = "ID")

  selections <- extract_database(tables = "selections")

  message("Fetching clans...")
  input <- tibble::tibble(ID = ID,
                          date = date) %>%
    dplyr::mutate(clan = fetch_clan(ID = ID, date = date))

  message("Extracting clan members...")
  clan_members <- purrr::map2(input$date, input$clan, ~
                                in_get_clan_members(date = .x,
                                                    clan = .y,
                                                    min_age = 2,
                                                    hyenas = hyenas,
                                                    selections = selections)[, c("ID", "currentclan", "date")],
                              #.options = furrr::future_options(globals = ".database"), ## for furrr::future_map2
                              #.progress = TRUE
  )

  message("Reformating data for next step...")
  input_list <- purrr::map2(clan_members, input$ID, ~ .x %>%
                            dplyr::mutate(focal_ID = .y) %>%
                            dplyr::filter(ID != focal_ID) %>%
                            dplyr::rename(focal = focal_ID, other = ID, clan = currentclan)#,
                            #.options = furrr::future_options(globals = ".database"), ## for furrr::future_map2
                            #.progress = TRUE
  )

  message("Calculating support...")
  out <- purrr::map(input_list, ~ calculate_support(interaction = .x, min_age =2,
                                                    table = FALSE,
                                                    generation = 5,
                                                    generation_b = 5)#,
                    #.options = furrr::future_options(globals = ".database"), ## for furrr::future_map
                    #.progress = TRUE
  )

  fn <- function(tbl) { ## ToDo Colin: rename this to make idea explicit
    if (nrow(tbl) == 0) return(NA)
    sum(tbl$indv_A > tbl$indv_B, na.rm = TRUE) / nrow(tbl)
  }

  out <- purrr::map(out, fn)
  out2 <- unlist(out)

  time2 <- proc.time()

  message(crayon::green("All done in", round(time2 - time1)[[3]], "seconds!"))
  if (suppressWarnings(is.null(out2))) out2 <- NA

  if (debug) {
    return(out)
  }

  out2
}


#' @describeIn fetch_family deprecated function! Use [fetch_is_alive()] instead.
#'
#' @export
fetch_survived <- function() .Deprecated("fetch_is_alive")


#' @describeIn fetch_family fetch the tenure duration a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_tenure usage:
#' fetch_tenure(ID = c("A-011", "A-040"), date = "1997-12-30") ## ToDo change ID and date
fetch_tenure <- function(ID, date, unit = "year", debug = FALSE) {

  tibble::tibble(ID = check_arg_ID(ID),
                 focal_date = check_arg_date(date)) %>%
    dplyr::mutate(sex = fetch_sex(ID)) -> input

  if (any(input$sex == "female")) warning("Tenure cannot be computed for females! \n    -> Try filtering out females from your data beforehand.")

  selection <- extract_database("selections")

  selection %>%
    dplyr::filter(ID %in% input$ID) -> selection

  if (nrow(selection) == 0) {
    input %>% mutate(tenure = lubridate::as.duration(NA)) -> output
  } else {
    selection %>%
      dplyr::left_join(input, by = "ID") %>%
      dplyr::mutate(birthclan = fetch_birthclan(ID),
                    focal_clan = fetch_clan(ID, focal_date)) %>%
      dplyr::filter(birthclan != focal_clan, focal_date > date) %>%
      dplyr::group_by(ID) %>%
      dplyr::summarise(date_last_selection = date[which.min(focal_date - date)]) %>% # perhaps we should do a fetch_last_selection(ID, date)
      dplyr::left_join(x = input, y = ., by = "ID") %>%
      dplyr::mutate(age_last_selection = fetch_age(ID, date_last_selection),
                    age_focal = fetch_age(ID, focal_date),
                    tenure = dplyr::case_when(
                      !is.na(age_focal) & !is.na(age_last_selection) ~ as.numeric(lubridate::interval(date_last_selection, focal_date) / lubridate::duration(1, units = check_arg_unit(unit)))
                      )) -> output
  }

  if (debug) return(output)

  focal_date <- date_last_selection <- birthclan <- focal_clan <- NULL ## To please R CMD check

  output$tenure
}


#' @describeIn fetch_family fetch if the individuals are genetically typed
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_is.sampled.dna usage:
#' fetch_id_is.sampled.dna(c("A-003", "A-002"))

fetch_id_is.sampled.dna <- function(ID) {
  ID <- check_arg_ID(ID)
  dna <- pull_column_from_table(column = "DNA", table = "hyenas", ID = ID)
  as.logical(dna) ## should be already reading TRUE/FALSE
}


#' @describeIn fetch_family fetch wheter the second argument is offspring of the first argument, according
#' to the filiation argument.
#'
#' @param ID A character vector.
#' @param offspring A character vector
#' @param filiation A character vector
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad.offspring_is.offspring usage:
#' fetch_dyad.offspring_is.offspring(ID = c("A-001", "A-001"), offspring = c("A-010", "A-049"))
#'
fetch_dyad.offspring_is.offspring <- function(ID, offspring, filiation = c("genetic_only", "social_and_genetic"), debug = FALSE) {
  ID <- check_arg_ID(ID)
  offspring <- check_arg_ID(offspring)
  filiation <- check_arg_filiation(filiation)
  input <- tibble::tibble(parent = ID, offspring = offspring)

  ## Note: we do note account for offspring that would have missing filiation (but that should probably not exist)
  create_offspringtable(unique(ID)) %>%
    dplyr::filter(.data$filiation %in% !!filiation | is.na(.data$filiation)) -> real_offspring

  input %>%
    dplyr::left_join(real_offspring, by = c("parent", "offspring")) %>%
    dplyr::mutate(is_offspring = ifelse(!is.na(.data$filiation), TRUE, FALSE)) -> output

  if (debug) return(output)

  output$is_offspring
}

#' @describeIn fetch_family fetch the type of filiation between the first argument and the second one.
#'
#' @param parent A character vector.
#' @param offspring A character vector.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad.offspring_filiation usage:
#' fetch_dyad.offspring_filiation(parent = c("A-001", "A-001"), offspring = c("A-010", "A-049"))
#'
fetch_dyad.offspring_filiation <- function(parent, offspring, debug = FALSE) {
  parent <- check_arg_ID(parent)
  offspring <- check_arg_ID(offspring)
  input <- tibble::tibble(parent = parent, offspring = offspring)

  offspring_table <- create_offspringtable(unique(parent))

  input %>%
    dplyr::left_join(offspring_table, by = c("parent", "offspring")) -> output

  if (debug) return(output)

  output$filiation

}


#' @describeIn fetch_family fetch the litter_ID from the ID of the mother/father and the offspring.
#'
#' @param parent A character vector.
#' @param offspring A character vector.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad.offspring_litter.ID usage:
#' fetch_dyad.offspring_litter.ID(parent = c("A-001", "A-001"), offspring = c("A-010", "A-049"))
#'
fetch_dyad.offspring_litter.ID <- function(parent, offspring, debug = FALSE)  {
  parent <- check_arg_ID(parent)
  offspring <- check_arg_ID(offspring)
  input <- tibble::tibble(parent = parent, offspring = offspring)

  offspring_litter <- create_id_offspring.litter.fulltable(unique(parent))

  input %>%
    dplyr::left_join(offspring_litter, by = c("parent", "offspring")) -> output

  if (debug) return(output)

  output$litter_ID

}

#' @describeIn fetch_family fetch the litter type for each given litter. Each litter is defined by a combination of letter,
#' (f = female, m = male, u = cub with unknown sex, preceded from 's' if the cub is social).
#'
#' @param litter_ID A character vector.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_litter.type usage:
#' fetch_litter_litter.type(litter_ID = "A-001_004")
#'
fetch_litter_litter.type <- function(litter_ID, debug = FALSE)  {

  litter_tb <- tibble::tibble(litter_ID = check_arg_litter.ID(litter_ID))
  litter_offspring.count <- create_litter_offspring.count(litter_ID)

  litter_tb %>%
    dplyr::left_join(litter_offspring.count, by = "litter_ID") -> input

  input %>%
    dplyr::mutate(type = recode_litters(.data$female,
                                        .data$male,
                                        .data$unknown,
                                        .data$social_female,
                                        .data$social_male,
                                        .data$social_unknown)) -> output

  if (debug) return(output)

  output$type

}

#' @describeIn fetch_family fetch if at least one member of the litter is genetically typed.
#' @param litter_ID A character vector.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_is.sampled.dna usage:
#' fetch_litter_is.sampled.dna(litter_ID = c("A-001_004", "A-001_001", "A-001_004"))
#'
fetch_litter_is.sampled.dna <- function(litter_ID, debug = FALSE) {
  parent <- unique(substr(litter_ID, 1, 5))
  litter <- tibble::tibble(litter_ID = litter_ID)
  all.litters <- create_id_offspring.litter.fulltable(unique(parent))
  litter %>%
    dplyr::left_join(all.litters, by = "litter_ID") %>%
    dplyr::select(.data$offspring, .data$litter_ID, .data$filiation) %>%
    dplyr::mutate(dna = fetch_id_is.sampled.dna(.data$offspring)) %>%
    dplyr::group_by(.data$litter_ID) %>%
    dplyr::mutate(litter_dna = any(.data$dna)) %>%
    dplyr::ungroup() %>%
    dplyr::select(.data$litter_ID, .data$litter_dna) %>%
    dplyr::distinct() %>%
    dplyr::ungroup() -> output_distinct

  litter %>%
    dplyr::left_join(output_distinct) -> output
  if (debug) return(output)
  output$litter_dna
}


#' @describeIn fetch_family fetch whether individuals have produced any offspring.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_has.reproduced usage:
#' fetch_id_has.reproduced(ID = c("A-001", "A-007"))
fetch_id_has.reproduced <- function(ID, from, to, at, debug = FALSE) {

  ## Note: we do not check the arguments, since they are checked in the following call.
  fetch_offspring_number(ID = ID, from = from, to = to, at = at) > 0 -> output

  if (debug) {

    return(output)

  }

  output

}

#' @describeIn fetch_family fetch whether individuals have produced a twin litter.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_had.twins usage:
#' fetch_id_has.twin.litter(ID = c("A-001", "A-007"))
fetch_id_has.twin.litter <- function(ID, from, to, at, debug = FALSE) {

  ## This function is somewhat redundant with create_littertable_count;
  ## however, create_littertable_count has no option to filter
  ## by date (from, to, at), which is needed for determining
  ## reproductive success over a given time scale

  ID <- check_arg_ID(ID)

  date_range <- check_arg_date.fromtoat(from, to, at)
  from       <- date_range$from
  to         <- date_range$to

  ## Make table of all focals individuals
  ## This is joined into our offspring table below so that
  ## no focal IDs are lost during filtering
  create_basetable_from_IDs(ID = ID) %>%
    dplyr::rename(parent = .data$ID) -> foundation_table

  create_id_offspring.litter.fulltable(parent = ID) %>%
    dplyr::mutate(birthdate = fetch_birthdate(ID = .data$offspring)) %>%
    dplyr::filter(between(.data$birthdate, from, to)) %>%
    dplyr::right_join(foundation_table, by = "parent") %>%
    dplyr::group_by(.data$parent, .data$litter_ID) %>%
    dplyr::summarise(litter_size = n()) %>% # Find litter size for each litter
    dplyr::summarise(twin = any(!is.na(.data$litter_ID) & .data$litter_size > 1)) -> output # Identify twins for each parent

  if (debug) {

    return(output)

  }

  output$twin
}
