#' Functions checking arguments
#'
#' These functions check that the input arguments are correct, correct them if
#' possible, and throw an error otherwise.
#'
#' More functions to come...
#'
#' @note Developers should add more functions here to check more arguments.
#'
#' @param path The path of a folder or a file.
#' @param unit The unit argument for functions working with durations.
#' @param strict Whether the test should be strict (TRUE: default) and fail if not satisfied, or
#'   less strict (FALSE) and drop unknown argument values.
#' @param max.length The maximal length of the argument (Inf: default).
#'
#' @name check_args
#'
#' @return The corrected arguments.
#'
#' @examples
#' ## Load the dummy dataset:
#' load_database()
NULL


#' @describeIn check_args Check the argument 'clan'
#'
#' This function should not be directly used by the user.
#'
#' @param clan A vector of clan letter(s) (quoted).
#' @param fill Wether to output all possibilities if the argument is missing (TRUE) or not (FALSE:
#'   default).
#' @export
#' @examples
#' check_arg_clan(c("A", "L"))
#' check_arg_clan(fill = TRUE)
#' \donttest{
#' check_arg_clan(c("A", "EEE"))
#' check_arg_clan(c("A", "EEE"), strict = FALSE)
#'}
#'
check_arg_clan <- function(clan = NULL, strict = TRUE, fill = FALSE) {
  possible_clans <- find_clans(only_main = FALSE)
  if (is.null(clan)) {
    if (fill) return(possible_clans)
    stop("The argument 'clan' has not been defined.")
  } else {
    if (any(!clan[!is.na(clan)] %in% possible_clans)) {
      if (strict) {
        stop(paste(c("The argument 'clan' contains clan(s) not corresponding to possible ones:",
                   unique(clan[!is.na(clan) & !clan %in% possible_clans])), collapse = " "))
      } else {
        warning("Clan(s) not corresponding to possible ones have been dropped.")
        clan <- clan[clan %in% possible_clans]
      }
    }
  }
  clan
}


#' @describeIn check_args Check the argument 'column' for extraction in the table hyenas.
#'
#' This function should not be directly used by the user.
#'
#' @param column The column name (quoted).
#' @param table The name of the table in which the column is supposed to be (quoted).
#' @export
#' @examples
#' check_arg_column("sex", table = "hyenas")
check_arg_column <- function(column, table) {
  if (length(column) != 1) {
    stop("The argument 'column' should be of length 1.")
  }
  if (length(table) != 1) {
    stop("The argument 'table' should be of length 1.")
  }
  table <- extract_database(tables = table)
  if (!column %in% colnames(table)) {
    stop("The argument 'column' does not correspond to a column name!")
  }
  column
}



#' @describeIn check_args Check arguments 'date'.
#'
#' This function should not be directly used by the user.
#'
#' @param date A vector of date(s) (quoted).
#' @param argument_name Name of date argument to allow for more informative errors.
#' @export
#' @examples
#' check_arg_date("1996/12/21")
check_arg_date <- function(date, argument_name = "date") {

  if (missing(date) || any(is.na(date))) {
    stop("Some dates have not been defined.")
  }

  error_msg <- paste0("The argument '", argument_name, "' should use one (and only one) proper date format ('2000/02/29' or '2000-02-29').")

  ## The following catches error associated with the first element only, but this
  ## matters since the first element shapes the formating of all elements:
  date <- tryCatch(as.Date(date), error = function(cond) {
    stop(error_msg)
  })
  min_date <-  as.Date("1979-04-14") ## oldest birth in records
  max_date <- find_lastsighting()

  ## The following catches all remaining errors:
  if (any(is.na(date))) {
    stop(error_msg)
  }

  if (any(date < min_date) || any(date > max_date)) {
    stop(paste("The argument 'date' is incorrect. All dates should be between",
               min_date, "(the first sighting date in the data) and", max_date,
               "(the last sighting date in the data)."))
  }
  date
}


#' @describeIn check_args Check arguments 'duration'.
#'
#' This function should not be directly used by the user.
#'
#' @param duration A vector of duration(s) (as class `numeric` or `Duration`).
#' @export
#' @examples
#' check_arg_duration(10)
#' check_arg_duration(lubridate::duration(10, "year"))
check_arg_duration <- function(duration) {
  if (missing(duration) | is.null(duration) | !class(duration) %in% c("numeric", "Duration")) {
    stop("The argument 'duration' has not been defined.")
  }
  duration
}


#' @describeIn check_args Check arguments 'filiation'.
#'
#' This function should not be directly used by the user.
#'
#' @param filiation A vector of filiation(s).
#' @export
#' @examples
#' check_arg_filiation("social_only")
check_arg_filiation <- function(filiation) {
  possible_filiation <- c("social_only", "genetic_only", "social_and_genetic")
  if (missing(filiation) || is.null(filiation) ||
      class(filiation) != "character" || !all(filiation %in% possible_filiation)) {
    stop("The argument 'filiation' has not been set correctly. It must be: 'social_only', 'genetic_only', 'social_and_genetic', or a combination of those.")
  }
  filiation
}

#' @describeIn check_args Check the argument 'ID'
#'
#' This function should not be directly used by the user.
#'
#' @param ID A vector of ID(s) (quoted).
#' @export
#' @examples
#' check_arg_ID("A-001")
#' check_arg_ID(fill = TRUE)
#' \donttest{
#' check_arg_ID(c("A-100", "Z-100"))
#' check_arg_ID(c("A-100", "Z-100"), strict = FALSE)
#' }
check_arg_ID <- function(ID = NULL, strict = TRUE, fill = FALSE) {
  possible_IDs <- find_IDs()
  if (is.null(ID)) {
    if (fill) return(possible_IDs)
    stop("The argument 'ID' has not been defined.")
  } else {
    if (any(!ID[!is.na(ID)] %in% possible_IDs)) {
      if (strict) {
        stop("The argument 'ID' contains ID(s) not corresponding to possible ones.")
      } else {
        warning("ID(s) not corresponding to possible ones have been dropped.")
        ID <- ID[ID %in% possible_IDs]
      }
    }
  }
  ID
}


#' @describeIn check_args Check the argument corresponding to folder paths
#' @param mustWork logical: if `TRUE` then an error is given if the path does not exist; if `NA` then a warning.
#' @export
#' @examples
#' check_arg_path("~/Download")
check_arg_path <- function(path, mustWork = FALSE) {
  path <- normalizePath(path, mustWork = mustWork)
  path
}


#' @describeIn check_args Check the argument 'period'
#' @param period  A vector of period(s) (as class `character` or `Period`)
#' @export
#' @examples
#' check_arg_period("90 days")
check_arg_period <- function(period){
  if (missing(period) | is.null(period) | is.na(lubridate::as.period(period)) | !class(period) %in% c("character", "Period")) {
    stop("The argument 'period' is incorrect, it should be of the same format as e.g. '10 days', '2 weeks', etc.")
  }
  lubridate::as.period(period)
}

#' @describeIn check_args Check the argument 'status'
#' @param status The selection status ("cub", "subadult", "natal", "philopatric", "disperser", "transient", "selector_2", "selector_3"...).
#' @export
#' @examples
#' check_arg_status("philopatric")
check_arg_status <- function(status) {
  if (length(status) != 1) {
    stop("The argument 'status' should be of length 1.")
  }
  if (missing(status) || is.null(status)) {
    stop("The argument 'status' has not been defined.")
  }
  if (class(status) != "character") {
    stop("The argument 'status' should be of class 'character'.")
  }
  possible <- c("cub", "subadult", "natal", "philopatric", "disperser", "transient",
                paste0("selector_", 2:5))
  if (!status %in% possible) {
    stop(paste(c("The argument 'status' should one of:\n ", paste0("'", possible, "' ")), collapse = ""))
  }
  status
}


#' @describeIn check_args Check the argument 'unit'
#' @export
#' @examples
#' check_arg_unit(c("day", "days", "week", "weeks"))
check_arg_unit <- function(unit, max.length = Inf) {
  if (length(unit) > max.length) {
    stop(paste("The function you are using can only handle", max.length, "unit(s)"))
  }
  unit %>% purrr::map_chr(~ case_when(
    .x == "days" ~ "day",
    .x == "weeks" ~ "week",
    .x == "months" ~ "month",
    .x == "years" ~ "year",
    TRUE ~ .x
  )) -> unit

  if (!all(unit %in% c("day", "week", "month", "year"))) {
    stop("The argument(s) 'unit' must be 'day', 'week', 'month', or 'year'!")
  }
  unit
}


#' Function checking if the database is loaded and if it is the dummy one
#'
#' This function should not be directly used by the user.
#'
#' Note for developers: this function triggers an error with an informative
#' message if there is no loaded database. It also displays a message if the
#' dummy database is the one that has been loaded by [load_database].
#'
#' @return This function returns nothing directly.
#' @export
#'
#' @seealso [load_database]
#'
#' @examples
#' load_database()
#' check_database()
check_database <- function() {
  if (!exists(".database")) {
    stop("No loaded database. See ?load_database")
  }

  if (attr(.database, "dummy")) {
    message("Using the dummy dataset!")
  }

  invisible(NULL)
}

#' Test for errors in the database
#'
#' Tests for integrity in the data/missing information including:
#' - All individuals die after being born
#' - All individuals give birth after 1yo
#' - All mothers/fathers are female/male
#'
#' @param debug Should the raw check results be returned?
#'
#' @return A boolean (has the database passed all tests)
#' @export
#' @examples
#'
#' # Check dummy database
#' # check_database_is.correct()

check_database_is.correct <- function(debug = FALSE) {

  # Extract all records for every existing individual
  # Do this first so it only needs to be done once.
  all_indv <- create_basetable() %>%
    dplyr::mutate(sex = fetch_sex(.data$ID),
                  birthdate = fetch_birthdate(.data$ID),
                  deathdate = fetch_deathdate(.data$ID),
                  surv = is.na(.data$deathdate),
                  mothergenetic = fetch_mothergenetic(.data$ID),
                  father = fetch_father(.data$ID))

  ################################
  # TEST: Birth is before death #
  ################################

  # Test to see if all individuals have a death date after their birth date
  flawed_deaths <- all_indv[!all_indv$surv & ymd(all_indv$birthdate) > ymd(all_indv$deathdate), ]

  number_flawed_deaths <- nrow(flawed_deaths)

  ###################################
  # TEST: Parents have correct sex #
  ###################################

  # Extract all individuals with a known mother
  flawed_maternity <- all_indv %>%
    filter(!is.na(.data$mothergenetic)) %>%
    # Check that mother is female
    mutate(mothersex = fetch_sex(ID = .data$mothergenetic),
           motherIsF = is.na(.data$mothersex) | .data$mothersex == "female") %>%
    filter(!.data$motherIsF)

  number_flawed_maternity <- nrow(flawed_maternity)

  # Extract all individuals with a known father
  flawed_paternity <- all_indv %>%
    filter(!is.na(.data$father)) %>%
    # Check that father is male
    mutate(fathersex = fetch_sex(ID = .data$father),
           fatherIsM = is.na(.data$fathersex) | .data$fathersex == "male") %>%
    filter(!.data$fatherIsM)

  number_flawed_paternity <- nrow(flawed_paternity)

  ################################
  # OUTPUT ALL INTEGRITY RESULTS #
  ################################

  tibble::tibble(
    integrity_issue = c("Flawed_death", "Flawed_maternity", "Flawed_paternity"),
    total_number = c(number_flawed_deaths, number_flawed_maternity, number_flawed_paternity),
    details = list(flawed_deaths, flawed_maternity, flawed_paternity)
  ) -> output

  if (debug) {
    message(paste("Individuals with death before birth:", number_flawed_deaths))
    message(paste("Males assigned as mothers:", number_flawed_maternity))
    message(paste("Females assigned as mothers:", number_flawed_paternity))
    message("See output for more details.")

    return(output)

  }

  all(output$total_number == 0)

}

#' @describeIn check_args Check that the arguments have the same length.
#'
#' @param female An integer vector.
#' @param male An integer vector.
#' @param unknown An integer vector.
#' @param social_female An integer vector.
#' @param social_male An integer vector.
#' @param  social_unknown An integer vector.
#' @export
#' @examples
#' check_arg_recode_litters(female = c(1, 0, 1), male = c(0, 2, 1), unknown = 0,
#' social_female = 0, social_male = 0, social_unknown = 0)
#'
check_arg_recode_litters <- function(female, male, unknown, social_female, social_male, social_unknown) {
  length_female  <- ifelse(length(female) == 1 && female == 0, 0, length(female))
  length_male    <- ifelse(length(male) == 1 && male == 0, 0, length(male))
  length_unknown <- ifelse(length(unknown) == 1 && unknown == 0, 0, length(unknown))
  length_social_female <- ifelse(length(social_female) == 1 && social_female == 0, 0, length(social_female))
  length_social_male <- ifelse(length(social_male) == 1 && social_male == 0, 0, length(social_male))
  length_social_unknown <- ifelse(length(social_unknown) == 1 && social_unknown == 0, 0, length(social_unknown))
  lengths <- unique(c(length_female, length_male, length_unknown, length_social_female, length_social_male,
                      length_social_unknown))
  lengths <- lengths[lengths != 0]
  ## check that lengths are good:
  if (length(lengths) > 1) {
    stop("recode_litters needs arguments of same length or of value 0")
  }
  ## replicate 0 if needed:
  if (length(lengths) == 1) { ## don't do anything if only 0s
    if (length_female == 0) female <- rep(0, lengths)
    if (length_male == 0) male <- rep(0, lengths)
    if (length_unknown == 0) unknown <- rep(0, lengths)
    if (length_social_female == 0) social_female <- rep(0, lengths)
    if (length_social_male == 0) social_male <- rep(0, lengths)
    if (length_social_unknown == 0) social_unknown <- rep(0, lengths)
  }
  list(female = female, male = male, unknown = unknown, social_female = social_female, social_male = social_male, social_unknown = social_unknown)
}

#' @describeIn check_args Check that litter argument is correct.
#'
#' @param litter_ID An character vector.
#' @export
#' @examples
#' check_arg_litter.ID(litter_ID = "A-001_004")
#' check_arg_litter.ID(fill = TRUE)
#'
check_arg_litter.ID <- function(litter_ID = NULL, strict = TRUE, fill = FALSE) {

  offspring_litter <- create_id_offspring.litter.fulltable(parent = find_IDs())
  possible_litters <- unique(offspring_litter$litter_ID[!is.na(offspring_litter$litter_ID)])

  if (is.null(litter_ID)) {
    if (fill) return(possible_litters)
    stop("The argument 'litter' has not been defined.")
  } else {
    if (any(!litter_ID[!is.na(litter_ID)] %in% possible_litters)) {
      if (strict) {
        stop("The argument 'litter' contains litter_ID(s) not corresponding to possible ones.")
      } else {
        warning("litter_ID(s) not corresponding to possible ones have been dropped.")
        litter_ID <- litter_ID[litter_ID %in% possible_litters]
      }
    }
  }
if (length(litter_ID) == 0) {
    return(NA_character_)
}
litter_ID
}

#' @describeIn check_args Check arguments 'from', 'to', 'at'.
#'
#' This function should not be directly used by the user.
#'
#' @param from A single date (quoted).
#' @param to A single date (quoted)
#' @param at A single date (quoted)
#' @export
#' @examples
#' #Check when both from and to are provided
#' check_arg_date.fromtoat(from = "1996/12/21", to = "1997/12/21")
#'
#' #When either from or to are not provided, they will return
#' #the earliest/latest observation date respectively
#' check_arg_date.fromtoat(to = "1997/12/21")
#'
#' #When at is provided, from/to have the same value
#' check_arg_date.fromtoat(at = "1997/12/21")
#'
#' #from/to and at cannot be provided together
#' #this will throw an error
#' \dontrun{
#' check_arg_date.fromtoat(from = "1995/12/21", at = "1996/12/21")
#' }
check_arg_date.fromtoat <- function(from, to, at) {

  if ((!missing(from) || !missing(to)) && !missing(at)) { # Users can only use from/to or at, not both

    stop("Provide either a single date using argument `at` or
         a date range by providing one or both arguments `from` or `to`.")

  }

  if (!missing(at)) { # from and to are the same when using at
    from <- check_arg_date(at, argument_name = "at")
    to   <- check_arg_date(at, argument_name = "at")
  } else {# from and to will default to earliest/latest date unless otherwise specified
    if (missing(from)) {
      from <- find_firstsighting()
    } else {
      from <- check_arg_date(from, argument_name = "from")
    }
    if (missing(to)) {
      to <- find_lastsighting()
    } else {
      to <- check_arg_date(to, argument_name = "to")
    }
  }

  if (from > to) {

    stop("'from' date must be earlier than (or the same as) 'to' date")

  }

  list(from = from, to = to)
}


#' @describeIn check_args Check arguments 'lineage'.
#'
#' This function should not be directly used by the user.
#'
#' @param lineage A vector of filiation(s).
#' @export
#' @examples
#' check_arg_lineage("mothersocial")
#'
check_arg_lineage <- function(lineage) {
  possible_lineage <- c("mothersocial", "mothergenetic", "father")
  if (missing(lineage) || is.null(lineage) ||
      class(lineage) != "character" || !all(lineage %in% possible_lineage)) {
    stop("The argument 'lineage' has not been set correctly. It must be: 'mothersocial', 'mothergenetic' or 'father'")
  }
  lineage
}
