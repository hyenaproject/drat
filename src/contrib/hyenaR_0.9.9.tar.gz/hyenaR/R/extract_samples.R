#' Extract sample data with information on individuals
#'
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#'
#' @return Return a tibble with sample and individual information
#' @export
#'
#' @examples
#'
#' # Load database(use dummy database)
#' load_database()
#' # Extract information in 2016
#' extract_samples(start_date = "1996-05-01", end_date = "1996-12-31")
#'
extract_samples <- function(start_date = -Inf, end_date = Inf) {
  collectiondate <- . <- species <- ID <- sex <- birthclan <- birthdate <- deathdate <- NULL
  stored1 <- sample_code <- type <- treatment <- age <- status <- left <- date_time <- NULL
  code <- current_clan <- NULL

  # Get access to hyenas and deaths table
  hyenas <- extract_database(tables = "hyenas")
  deaths <- extract_database(tables = "deaths")
  selections <- extract_database(tables = "selections")
  samples <- extract_database(tables = "samples")
  sightings <- extract_database(tables = "sightings")

  # We need to know the latest date in the database.
  # This will be the end_date if Inf is provided
  # We need an actual value (rather than Inf) to calculate age
  latest_date <- sightings %>%
    dplyr::summarise(latest_date = max(as.Date(date_time), na.rm = TRUE)) %>%
    pull(latest_date)

  # If end date is Inf then convert to latest date...
  if (is.infinite(end_date)) {
    end_date <- latest_date
  } else {

    # Otherwise, make sure it's a date objecct
    end_date <- lubridate::ymd(end_date)
  }

  # We need to know the first date in the database.
  # This will be the start_date if -Inf is provided
  # We need an actual value (rather than -Inf) to calculate age
  start_date <- sightings %>%
    dplyr::summarise(start_date = min(as.Date(date_time), na.rm = TRUE)) %>%
    pull(start_date)

  # If start date is not Inf make sure that it's a date object
  if (!is.infinite(start_date)) {
    start_date <- lubridate::ymd(start_date)
  }

  # Subset the samples table to just include most important info.
  output_table <- samples %>%
    # Just include hyenas and samples collected within specified dates
    filter(species == "hy" & between(collectiondate, start_date, end_date)) %>%
    # Join in birthdate of every individual
    left_join(select(hyenas, ID, sex, birthclan, birthdate), by = "ID") %>%
    # Join in deathdate as well
    left_join(select(deaths, ID, deathdate), by = "ID") %>%
    collect() %>%
    mutate(
      collectiondate = lubridate::ymd(collectiondate),
      birthdate = lubridate::ymd(birthdate), deathdate = lubridate::ymd(deathdate),
      sex = ifelse(sex == 1, "Male", ifelse(sex == 2, "Female", NA))
    )

  pb <- progress::progress_bar$new(total = nrow(output_table))

  output_table <- output_table %>%
    # Determine the age of each individual in months when the sample was taken
    mutate(age = pmap_dbl(
      .l = list(
        age_units = "months",
        birthdate = as.character(birthdate),
        deathdate = as.character(deathdate),
        end_date = as.character(collectiondate)
      ),
      .f = calc_age
    )) %>%
    # Include dispersal/clan info ## ToDo: make this readable and prety!
    bind_cols(pmap_df(
      .l = list(
        focal_indv = .$ID,
        sex = .$sex,
        start_date = as.character(.$collectiondate), end_date = as.character(.$collectiondate), birthclan = .$birthclan
      ),
      .f = calc_currentclan, pb = pb, selections = selections
    ) %>% select(-ID)) %>%
    mutate(sample_code = paste(ID, collectiondate, stored1, sep = "_")) %>%
    select(sample_code, subsample_code = code, ID, collectiondate, deathdate, collectiontime = stored1, clan = current_clan, type, treatment, sex, age, birthclan, dispersal_status = status, left)
  ### add rank

  input_file <- output_table %>%
    dplyr::select(ID, collectiondate) %>%
    dplyr::mutate(date = collectiondate - lubridate::days(1)) %>%
    stats::na.omit()

  rank <- calculate_rank(input_file)[, c("ID", "date", "rank_std")] %>%
    mutate(date = ymd(date))
  output_table <- left_join(output_table, rank, by = c("ID" = "ID", "collectiondate" = "date"))

  return(output_table)
}
