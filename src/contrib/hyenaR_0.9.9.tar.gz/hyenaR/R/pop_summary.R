#' Return a summary of the whole population on given date(s)
#'
#' Provides summary statistics of a population from a provided database.
#' @param date Date at which the summary is taken.
#' If date is not provided, will use most recent date in the sightings table of the database.
#' Format should be YYYY-MM-DD
#'
#' @return Returns a tibble of population summaries on each given date.
#' @export
#' @import DBI
#' @import RSQLite
#' @import dplyr
#' @importFrom lubridate ymd
#'
#' @examples
#'
#' # Load data (use dummy dataset)
#' load_database()
#'
#' # Extract a population summary for January and February 1997
#' pop_summary(date = c("1997-01-01", "1997-02-01"))
pop_summary <- function(date = NULL) {

  # Assign NULL to avoid global variable NOTE in R CMD Check
  clan_size <- date_time <- NULL

  # Make sure that date is a character string.
  # This is required to work with Iljas python code.
  if (class(date) == "Date") {
    date <- as.character(date)
  }

  sightings <- extract_database(tables = "sightings") %>%
    dplyr::mutate(date = as.Date(date_time))

  # Determine latest date in the current database
  latest_date <- max(sightings$date, na.rm = TRUE)

  # If date is not provided, use current system date.
  if (is.null(date)) {
    date <- as.character(latest_date)

    # Otherwise, if any date is provided BUT it is more recent than the most recent date
    # Simply change the date to the most recent date (and give a message)
  } else if (any(ymd(date) > latest_date)) {
    error_date <- date[which(ymd(date) > latest_date)]

    date[which(ymd(date) > latest_date)] <- as.character(latest_date)
    message(paste("Date:", error_date, "is too recent. \n It has been set to the most recent date in the database (", latest_date, ") \n"))
  }

  # Run python code to include my extra functions AND Ilja's function library
  reticulate::py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))
  reticulate::py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))

  # Run clan_summary internally to produce a list item
  clan_output <- clan_summary(date = date, internal = TRUE)

  # Map through the list and determine:
  #- Number of active clans (i.e. size > 0)
  #- Average clan size
  #- Total population size
  output_file <- map_df(.x = clan_output, .f = function(input) {
    return(tibble::tibble(
      date = input$date[1],
      pop_size = sum(input$clan_size),
      active_clans = sum(input$clan_size > 0),
      average_size = mean(subset(input, clan_size > 0)$clan_size)
    ))
  })

  return(output_file)
}
