#' Display welcome message
#'
#' This function should not be called by the user.
#' It displays a message when the package is being loaded.
#'
#' @param libname argument needed but automatically defined.
#' @param pkgname argument needed but automatically defined.
#'
#' @export
#'
.onAttach <- function(libname, pkgname) {
  packageStartupMessage( ## display message
    "\n",
    "Welcome to hyenaR v", utils::packageDescription("hyenaR")$Version,
    "\n",
    "Mind that the package is still highly experimental!!!",
    "\n",
    "\n",
    "Run:",
    "\n",
    " - help(package = 'hyenaR') to access all help files",
    "\n",
    " - vignette('news', package = 'hyenaR') for news about the package",
    "\n",
    " - vignette('grammar', package = 'hyenaR') for info on the grammar",
    "\n",
    " - vignette('devel', package = 'hyenaR') for info for developers",
    "\n",
    " - build_optional_vignette(file = 'data_summary.Rmd')",
    "\n",
    "    for a summary of the population",
    "\n",
    " - build_optional_vignette(file = 'effect_of_ranks.Rmd')",
    "\n",
    "    for another example of application using the real database",
    "\n",
    "\n",
    tips()
  )
}



#' Provide some basic information about the code of the package
#'
#' This is a function for development purpose only. This function provides the
#' number of functions and lines of code of the package. The results depend on
#' whether the function is called from the compiled or the raw package. When
#' called from the compiled package, the number of functions only gives the
#' number of exported functions, and the number of lines of code no longer
#' includes documentation and examples.
#'
#' @note This function does not work with `devtools::load_all(".")`.
#'
#' @export
#'
info_package <- function() {
  print(paste("number of functions =", length(ls("package:hyenaR"))))
  if (requireNamespace("R.utils", quietly = TRUE)) {
    files <- dir(paste0(system.file(package = "hyenaR"), "/R/"))
    filenames_R <- paste0(system.file(package = "hyenaR"), "/R/", files)
    lines_code <- sum(sapply(filenames_R, function(file) R.utils::countLines(file)))
    print(paste("number of lines of code =", lines_code))
  } else {
    message("Install the package R.utils for more info.")
  }
  return(invisible(NULL))
}


#' Display tips about how to use the package
#'
#' This function returns one tip about how to use the package.
#'
#' Note for developers: let's try to write many tips for hyenaR!
#'
#' @export
#'
#' @examples
#' tips()
#'

tips <- function() {
  alltips <- c("a call to 'rm(list = ls())' will remove all the R objects created in your R session, but not the loaded database. \n This is because the loaded database is hidden.",
               "knowing well how to use the tidyverse package 'dplyr' will greatly help you to use 'hyenaR' efficiently. \n The best place to learn about it is probably https://r4ds.had.co.nz/transform.html",
               "it is good practice to update your R packages frequently using 'update.packages(ask = FALSE, checkBuild = TRUE)' or similar.",
               "a call to 'find_IDs()' gives you all the ids present in loaded database.",
               "you can suggest developers many more tips you would like to see here.\n Fill in an issue on GitHub for that or just talk to the developers.")
  tip <- sample(alltips, size = 1)
  paste0("Tip:\n Did you know that ", tip)
}
