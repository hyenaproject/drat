#' A wrapper around utils:::stack.default to solve limitations around factors
#'
#' @inheritParams utils::stack
#' @inheritParams base::data.frame
#'
#' @return a `data.frame`
#' @export
#'
#' @examples
#' str(stack_list_to_df(list(a = "a", b = "b")))
#' str(stack_list_to_df(list(a = "a", b = "b"), stringsAsFactors = FALSE))
#'
stack_list_to_df <- function(x, drop = FALSE, stringsAsFactors = TRUE, ...) { ## new argument stringsAsFactors
  ## workaround utils:::stack.default to solve limitations around factors.
  ## issue reported on BugZilla, so it may change in R itself in the future.
  x <- as.list(x)
  keep <- unlist(lapply(x, is.vector))
  if (!sum(keep))
    stop("at least one vector element is required")
  if (!all(keep))
    warning("non-vector elements will be ignored")
  x <- x[keep]
  #ind <- rep.int(factor(names(x), unique(names(x))), lengths(x))
  ind <- rep.int(names(x), lengths(x)) ## ALEX
  if (stringsAsFactors) ind <- as.factor(ind) ## ALEX
  if (drop) {
    ind <- droplevels(ind)
  }
  #data.frame(values = unlist(unname(x)), ind, stringsAsFactors = FALSE)
  data.frame(values = unlist(unname(x)), ind, stringsAsFactors = stringsAsFactors) ## ALEX
  }
