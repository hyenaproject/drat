context("Test check_ functions")

test_that("check_database works as intended", {
  expect_message(check_database())

  rm(list = ".database", envir = .GlobalEnv)
  expect_error(check_database())

  load_database()

})

test_that("check_database_is.correct returns a boolean", {

  job1 <- check_database_is.correct()

  expect_true(job1)

})
