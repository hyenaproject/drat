
## create_dyad_relatedness.table
test_that("create_dyad_relatedness.table returns the correct ouput", {
  ref <-
    structure(
      list(
        ID1 = c("A-001", "A-001", "A-001", "L-003", "L-003", "A-098"),
        ID2 = c("L-003", "A-098", "L-003", "A-098", "L-003", "L-003"),
        relatedness = c(NA, 0.25, NA, NA, 1.00, NA)),
      row.names = c(NA,-6L),
      class = c("tbl_df", "tbl", "data.frame")
    )


  job <- create_dyad_relatedness.table(c("A-001", "L-003", "A-098", "L-003"))
  expect_equal(ref, job)
})

## find_dyad_id.ancestor.MRCA
test_that("find_dyad_id.ancestor.MRCA returns the correct ouput", {
  ref <- as.character("A-001")
  job <- find_dyad_id.ancestor.MRCA("A-001", "A-098")
  expect_equal(ref, job)
})

## find_id_id.ancestor.all
test_that("find_id_id.ancestor.all returns the correct ouput", {
  ref <- as.character(c("A-001", "A-098", "A-010", "A-001"))
  job <- find_id_id.ancestor.all(ID = c("A-001", "A-098"), lineage = "mothersocial")
  expect_equal(ref, job)
})

## fetch_dyad_relatedness
test_that("fetch_dyad_relatedness returns the correct ouput", {

  ref <-  structure(
    list(
      ID1 = c("A-001", "A-098", "A-010"),
      ID2 = c("A-098", "A-098", "A-001"),
      relat = c(0.25, 1, 0.5)),
    row.names = c(NA,-3L),
    class = c("tbl_df", "tbl", "data.frame"))

  job <- tibble(ID1 = c("A-001", "A-098", "A-010"),
                ID2 = c("A-098", "A-098", "A-001")) %>%
         mutate(relat = fetch_dyad_relatedness(ID1 = ID1, ID2 = ID2, lineage = "mothersocial"))
  expect_equal(ref, job)
})
