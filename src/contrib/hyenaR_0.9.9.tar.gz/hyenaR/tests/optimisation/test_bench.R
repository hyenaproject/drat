names <- .GlobalEnv$database$data$hyenas$name

bench::mark(
  fetch_sex(name = names), {
    .GlobalEnv$database$data$hyenas %>%
      filter(name %in% names) %>%
      select(name, sex)
  },
  .GlobalEnv$database$data$hyenas[.GlobalEnv$database$data$hyenas$name %in% names, c("name", "sex")]
) %>% plot()
