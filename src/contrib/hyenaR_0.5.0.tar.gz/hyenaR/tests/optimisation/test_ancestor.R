get_source_csvs(destfolder = "~/Downloads/CSV")
build_database(path = "~/Downloads/CSV")

rm(list = ls())
load_database("~/Downloads/CSV/Fisidata.sqlite")

clan_members <- get_clan_members(date = "2017-08-16", clan = "F")

test1 <- function(clan_members) {
  d <- list(database$data$hyenas[match(clan_members$name, database$data$hyenas$name), "mothersocial"])
  i <- 1
  while (sum(!is.na(d[[i]]$mothersocial)) > 0) {
    i <- i + 1
    d[[i]] <- database$data$hyenas[match(d[[i - 1]]$mothersocial, database$data$hyenas$name), "mothersocial"]
  }
  d[[i]] <- NULL
  as.data.frame(d)
}

a <- test1(clan_members)

library(microbenchmark)
(m <- microbenchmark(get_ancestry(clan_members = clan_members),
  test1(clan_members = clan_members),
  times = 1000
))
autoplot(m)
# autoplot(m, log = FALSE) + ggplot2::coord_cartesian(ylim = c(200, 8000))
