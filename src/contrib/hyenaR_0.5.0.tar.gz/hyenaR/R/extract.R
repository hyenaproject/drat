## Note: extract is probably a poor name for these functions and it does not match
## the other extract functions. We need to think of something better but these
## functions may disappear if the Python code is revised.

#' Extract all ranks
#'
#' This function allows for computing all rank information. It is a user level
#' function that calls [calculate_rank()]. Before calling [calculate_rank()], the
#' function filter out individuals not alive at the requested date.
#'
#' Note for developers: this function is also used as companion function for
#' all the ```fetch_xxx``` calls that are internally rely on a call to
#' [calculate_rank()].
#'
#' @inheritParams fetch_family
#' @export
#' @examples
#' #### Simple example of extract_allrankinfo usage:
#' load_database()
#' extract_allrankinfo(ID = c("A-080", "M-094"), date = c("1996-10-04", "1996-07-01"))
#' extract_allrankinfo(ID = c("A-080"), date = c("1996-10-04", "1996-07-01"))
#'
#' #### Example with missing information:
#' extract_allrankinfo(ID = c("A-001", "A-100"), date = c("1988-05-21", "1997-08-15"))
extract_allrankinfo <- function(ID, date) {
  tibble::tibble(ID = ID, date = as.Date(date)) %>%
    dplyr::mutate(
      surv = fetch_is_alive(ID = ID, date = date),
      date = date
    ) -> input

  input %>%
    dplyr::group_by(ID, date) %>%
    dplyr::slice(1) %>%
    dplyr::ungroup() %>%
    dplyr::filter(surv) -> input_alive

  if(nrow(input_alive) == 0){

    stop("None of the selected individuals are alive on these dates")

  }

  message(paste("Extracting info for", nrow(input_alive), "cases that are alive and unique at the requested date..."))

  info <- calculate_rank(input = input_alive)

  if (length(info) == 0) {
    return(input)
  }

  info %>%
    dplyr::mutate(date = as.Date(date)) %>%
    dplyr::right_join(input, by = c("ID", "date")) -> output

  surv <- NULL ## to please R CMD check

  return(output)
}
