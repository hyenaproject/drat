#' Extract a column in a table.
#'
#' This function is used internally to pull columns from a table without droping NAs.
#' It should not be directly used by the user.
#'
#' @inheritParams check_arg_column
#' @inheritParams fetch_family
#'
#' @return a vector.
#' @export
#' @examples
#'
#' ######## Load the dummy dataset:
#' load_database()
#'
#' ######## pull sex from hyenas table for 2 individuals:
#' pull_column_from_table(column = "sex", table = "hyenas", ID = c("A-080", "M-094", NA))
#'
#' ######## pull sex from hyenas table for all individuals:
#' pull_column_from_table(column = "sex", table = "hyenas")
#'
#'
#' ######## pull deathdate from hyenas table for 2 individuals:
#' pull_column_from_table(column = "deathdate", table = "deaths", ID = c("A-080", "M-094", NA))
pull_column_from_table <- function(column, table, ID = NULL) {
  column <- check_arg_column(column = column, table = table)
  table <- extract_database(tables = table)
  if (is.null(ID)) {
    return(table[, column, drop = TRUE])
  }
  table[match(ID, table$ID), column, drop = TRUE]
}
