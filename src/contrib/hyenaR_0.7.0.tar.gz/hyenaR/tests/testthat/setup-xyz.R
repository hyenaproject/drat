# Load the dummy dataset
load_database()
