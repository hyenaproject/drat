context("Test reproduction functions")

test_that("all count functions return the correct type", {
  expect_equal(class(calculate_offspring(c("A-001", "L-001"))), "list")
})
