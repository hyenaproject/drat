# Remove .database object
rm(list = ".database", envir = .GlobalEnv)

# Remove example database built for test_build_database
# file.remove("../../inst/extdata/example_db.sqlite")
