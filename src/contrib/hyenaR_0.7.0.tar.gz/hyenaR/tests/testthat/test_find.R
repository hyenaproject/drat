context("Test find_xxx functions")

test_that("all find functions return the correct type", {
  expect_equal(class(find_IDs(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_IDs(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_IDs(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_IDs(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_males(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_males(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_males(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_males(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_females(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_females(clan = c("A", "L"), date = c("1997/01/01", "1996/12/01")))[1], "character")
  expect_equal(class(find_females(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_females(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_adults(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_adults(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_adults(clan = NULL, date = "1997/01/01"))[1], "character")

  expect_equal(class(find_immigrants(clan = c("A", "L"), date = "1997/01/01"))[1], "character")
  expect_equal(class(find_immigrants(clan = "A", date = "1997/01/01"))[1], "character")
  expect_equal(class(find_immigrants(clan = NULL, date = "1997/01/01"))[1], "character")
})
