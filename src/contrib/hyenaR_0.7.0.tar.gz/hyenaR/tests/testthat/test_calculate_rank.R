context("Test calculate_rank behaviour")

test_that("calculate_rank returns a tibble with data frame, tibble and named list input", {
  output <- calculate_rank(input = data.frame(ID = "A-080", date = "1997-01-01"))

  expect_equal(class(output)[1], "tbl_df")
  expect_equal(class(output)[1], "tbl_df")
  expect_equal(class(output)[1], "tbl_df")
})

test_that("Providing a matrix or vector returns an error", {
  input <- matrix(nrow = 2, ncol = 2, data = c("A-080", "L-001", "1997-01-01", "1996-07-01"))
  colnames(input) <- c("ID", "date")

  expect_error(calculate_rank(input = z))
  expect_error(calculate_rank(input = c("A-080", "L-001", "1997-01-01", "1996-07-01")))
})

test_that("Providing a wrong name and/or date returns a warning", {
  expect_warning(calculate_rank(input = data.frame(ID = "A-AAA", date = "1997-01-01")))
  expect_warning(calculate_rank(input = data.frame(ID = "A-001", date = "0001-01-01")))
  expect_warning(calculate_rank(input = data.frame(ID = "A-AAA", date = "0001-01-01")))

  expect_warning(calculate_rank(input = data.frame(ID = "A-AAA", date = "1997-01-01")))
  expect_warning(calculate_rank(input = data.frame(ID = "A-001", date = "0001-01-01")))
  expect_warning(calculate_rank(input = data.frame(ID = "A-AAA", date = "0001-01-01")))
})
