library(testthat)
library(hyenaR)

test_check("hyenaR")
