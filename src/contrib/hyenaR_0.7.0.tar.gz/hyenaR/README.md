# hyenaR

The goal of hyenaR is to provide a toolkit to work with the data of the [hyena project](https://hyena-project.com/).


## Installation

Installation from the current GitHub page is not recommended for this project.

Users should instead install the package for the [drat page](https://github.com/hyenaproject/drat) and __NOT__ from here.

Developers should clone the repos and work in their local clone.


## Usage

See https://github.com/hyenaproject/hyenaR/wiki for some help on how to use this package.


## Code of conduct

Please note that the 'hyenaR' project is released with a
[Contributor Code of Conduct](.github/CODE_OF_CONDUCT.md).

By contributing to this project, you agree to abide by its terms.
