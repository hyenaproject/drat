#' Extract summary of an individual hyena(s) life at a given date
#'
#' This function will extract information on:
#' - Birth (sex, clan, parentage, date)
#' - Death (date, age)
#' - Reproduction (lifetime reproductive success)
#'
#' on a specified date.
#'
#' This is a compilation of data across multiple tables from the database.
#' Note that age will be either the current age (from latest date in sightings table)
#' OR age of death.
#'
#' @param db Location of database. If unspecified, will use dummy database for examples.
#' @param indv Vector of hyena names to extract summary.
#' If not provided, will return a summary of all individuals.
#' @param age_units The units of measurement used for age. Can be years (default), months,
#' weeks, or days.
#' Other units specified by \code{\link{difftime}} (e.g. hours) are meaningless in this context
#' and will return an error.
#' @param date Date at which the summary is taken.
#' If date is not provided, will use most recent date in the sightings table of the database.
#' Format should be YYYY-MM-DD
#' @param status Determines how dead individuals should be treated. If 'both', all individuals that
#' have been in the population up to the given date will be returned, even if they are now dead.
#' If 'alive', only individuals alive at the given date will be returned, dead individuals will be removed..
#' If 'dead', only individuals that died before the given date will be returned, individuals currently alive will be removed.
#' @param verbose Should messages be given? e.g. Show individuals that were excluded with the given date.
#'
#' @return A tibble with information for each hyena provided.
#' @export
#' @import DBI
#' @import RSQLite
#' @import dplyr
#' @importFrom lubridate ymd
#'
#' @examples
#'
#' #Find information for some of the oldest individuals and some of the younger
#' #Individual names
#' indv = c("F-001", "B-002")
#' indv_summary(indv = indv)
#'
#' #Find information on all individuals born before a given date
#' indv_summary(date = "1999-01-01")

indv_summary <- function(db = NULL, indv = NULL, date = NULL, status = "both", age_units = "years", verbose = TRUE){

  #Assign variables to NULL to prevent global binding NOTE in R CMD Check
  name <- . <- sex <- birthclan <- currentclan <- birthdate <- mothergenetic <- mothersocial <- NULL
  father <- deathdate <- recentdate <- last_sighting <- alive <- age <- RS <- first_rank <- NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Make sure that date is a character string.
  #This is required to work with Iljas python code.
  if(class(date) == "Date"){

    date <- as.character(date)

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Check that units of age are usable
  #Define all possible units
  possible_units <- c("years", "months", "days", "weeks")
  if(!age_units %in% possible_units){

    stop("The units you have specified for age are unsuitable. \n
          Please specify years, months, days or weeks.")

  }


  #Determine latest date in the current database
  latest_date <- ymd(tbl(connection, "sightings") %>%
                       select(date) %>%
                       summarise(latest_date = max(date, na.rm = T)) %>%
                       collect())

  #If date is not provided, use current system date.
  if(is.null(date)){

    date = latest_date

    #Otherwise, if any date is provided BUT it is more recent than the most recent date
    #Simply change the date to the most recent date (and give a message)
  } else if(any(ymd(date) > latest_date)){

    error_date <- date[which(ymd(date) > latest_date)]

    date[which(ymd(date) > latest_date)] = latest_date
    message(paste("Date:", error_date, "is too recent. \n It has been set to the most recent date in the database (", latest_date, ") \n"))

  } else {

    date = ymd(date)

  }

  #Get access to hyenas table
  hyena <- tbl(connection, "hyenas")

  #If individual ID is not provided, just make a vector of all individual names
  if(is.null(indv)){

    indv_provided <- FALSE

    indv <- hyena %>%
      select(name) %>%
      collect() %>%
      as.data.frame() %>%
      .$name

  } else {

    indv_provided <- TRUE

  }

  #Subset the hyena and death table to include the named individual(s) only.
  output_table <- hyena %>%
    #Filter just the wanted individual(s) and the important columns
    filter(name %in% indv) %>%
    select(name, sex, birthclan, birthdate, mothergenetic, mothersocial, father) %>%
    #Make sex into M/F and birthdate into datetime object
    mutate(sex = ifelse(sex == 1, "Male", ifelse(sex == 2, "Female", NA))) %>%
    #Filter any individual that was born after the current date
    filter(birthdate <= date) %>%
    #Subset death table to include the named individuals only.
    #Use left join to join death data into the hyena data.
    left_join(tbl(connection, "deaths") %>%
                filter(name %in% indv), by = "name")

  #Check to see if they want only live individuals.
  #If they do, then remove those where death date was before given date.
  if(status == 'alive'){

    if(verbose){

      message("Note: Only living individuals will be summarised.")

    }

    output_table <- output_table %>%
      filter(is.na(deathdate))

  } else if(status == 'dead'){

    if(verbose){

      message("Note: Only dead individuals will be summarised.")

    }

    output_table <- output_table %>%
      filter(!is.na(deathdate))

  } else if(status != "both"){

    stop("status should be either 'alive', 'dead', or 'both'")

  }

  output_table <- output_table %>%
    #Subset sightings table to include the named individual(s) only.
    #This will tell use the most recent date that the individual was sighted.
    #Use left join to join this in.
    left_join(tbl(connection, "sightings") %>%
                filter(name %in% indv) %>%
                select(date, name) %>%
                group_by(name) %>%
                summarise(recentdate = max(date, na.rm = T)), by = "name") %>%
    collect() %>%
    #Determine age of death using calc_age function (in otherfunctions.R).
    #For years, divide by 365 and include remainder.
    #For months just return a value of months (no remainder) using lubridate interval.
    #For other units (days and weeks) just make a difftime object of the given units
    mutate(age = pmap_dbl(.l = list(age_units = age_units,
                                    birthdate = ymd(birthdate),
                                    deathdate = ymd(deathdate),
                                    recentdate = ymd(recentdate)),
                          .f = calc_age),
           #Determine current clan using calc_currentclan function (in otherfunctions.R)
           currentclan = pmap_chr(.l = list(indv = name,
                                            date = date,
                                            birthclan = birthclan),
                                  .f = calc_currentclan, tbl(connection, "selections")),
           #Determine whether the individual is alive (i.e. is there a deathdate recorded)
           alive = map_lgl(.x = deathdate,
                           .f = ~ifelse(is.na(.x), TRUE, FALSE)),
           #If there is no deathdate recorded, the most recent date is the max date in sightings
           #Otherwise, just include the deathdate as the most recent date.
           last_sighting = ymd(map2_chr(.x = deathdate, .y = recentdate,
                                          .f = ~ifelse(is.na(.x), .y, .x))),
           RS = map_dbl(.x = name,
                        .f = ~nrow(tbl(connection, "hyenas") %>%
                                     filter(mothergenetic == .x | father == .x) %>%
                                     collect())),
           birthdate = ymd(birthdate)) %>%
    #Rearrange column order to make it more reasonable and remove extra variables.
    select(name, sex, birthclan, currentclan, birthdate, last_sighting, alive, age, RS, mothergenetic, mothersocial, father)

  if(verbose){

    #Print a message to say which individuals were excluded on a given date
    if(indv_provided){

      unborn_hyena <- hyena %>%
        filter(name %in% indv) %>%
        collect() %>%
        filter(ymd(birthdate) > date)

      if(nrow(unborn_hyena) > 0){

        map(.x = unborn_hyena$name, .f = ~message(paste(.x, " was excluded because it was born after the given date.")))

      }

    }

  }

  dbDisconnect(connection)

  return(output_table)

}
