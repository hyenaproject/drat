##FUNCTIONS USED FOR ESTIMATING DEMOGRAPHY

#' Determine age of a specific individual for \code{\link{indv_summary}}.
#'
#' @param age_units Units with which age should be measured.
#' @param birthdate Birthdate of individual.
#' @param deathdate Deathdate of individual (if it exists).
#' @param recentdate Most recent date in the database.
#'
#' @return Returns the age of an individual in specified units.

calc_age <- function(age_units, birthdate, deathdate, recentdate){

  lastdate <- ifelse(is.na(deathdate), recentdate, deathdate)

  if(age_units == "years"){

    return(as.numeric(lastdate - birthdate)/365)

  } else if(age_units == "months"){

    return(interval(birthdate, lastdate)%/%months(1))

  } else {

    return(round(as.numeric(difftime(lastdate, birthdate, units = age_units))))

  }

}

#' Determine current clan for an individual for \code{\link{indv_summary}}.
#'
#' @param indv Name of individual.
#' @param date Date of interest.
#' @param selections Selections table in the database
#' @param birthclan Clan where the individual was born.
#'
#' @import dplyr
#'
#' @return Returns a character string with code of current clan.

calc_currentclan <- function(indv, date, selections, birthclan){

  #Assign NULL to avoid global binding NOTE
  name <- destination <- NULL

  indv_selections <-  selections %>%
    #Subset selections to just include the current individual.
    filter(name == indv) %>%
    collect()

  if(nrow(indv_selections) > 0){

    return(as.character(selections %>%
      #Subset selections to just include the current individual.
      filter(name == indv) %>%
      collect() %>%
      #Subset to include the most recent selection
      #We need to do this separately because using max inside filter is not supported with sqlite
      filter(date == max(date)) %>%
      select(destination)))

  } else {

    return(birthclan)

  }

}

#################################################################################

##FUNCTIONS USED TO CONVERT ITEM TYPES WHEN USING RETICULATE AND PYTHON.

#' Convert a dataframe to a list with items for each dataframe column.
#'
#' @param x First column
#' @param y Second column
#'
#' @return Returns a list with two items for column 1 and 2.

df_to_list <- function(x, y){

  return(list(name = x[1], date = y[1]))

}

#' Convert a dictionary output by python to a dataframe.
#'
#' @param x Vector of dictionary keys
#' @param dict Dictionary object output by python.
#'
#' @return A dataframe with one column for each dictionary key.

dict_to_df <- function(x, dict){

  return(dict[x])

}

#################################################################################

#EXTRACT RAW CLAN SUMMARIES WITH GEN_STATE IN PYTHON

#' Extract raw clan summary for \code{\link{clan_summary}}.
#'
#' @param db Location of database provided by \code{\link{clan_summary}}.
#' @param clan Code of clan.
#' @param date Date of summary. YYYY-MM-DD
#' @param python_loc Location of python on the computer. If unspecified,
#' will search in PATH.
#'
#' @import DBI
#' @import RSQLite
#' @import dplyr
#'
#' @return A tibble with raw clan information.

get_rawclan_summary <- function(db = NULL, clan = NULL, date = NULL, python_loc = NA){

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Specify location of python on your system
  use_python(python_loc)

  #Run python code to include my extra functions AND Ilya's function library
  py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))
  py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))

  #Generate state of clans on each date
  output_file <- py$clan_summary(db, dates = date)

  dbDisconnect(connection)

  return(output_file)

}
