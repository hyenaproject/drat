import csv
import sqlite3
import datetime as dtm
import itertools as it
from collections import defaultdict, namedtuple


Animal = namedtuple('Animal', ['name', 'birthdate', 'male', 'native', 'selection'])


def load_snapshot(db, filename):
    """Read in a snapshot file and feed it into the database."""

    db.execute('CREATE TABLE IF NOT EXISTS snapshots (date TEXT, clan TEXT, rank INT, name TEXT, selection TEXT)')
    snapshot_dates = set()
    clan_counter = defaultdict(int)
    names = set()
    with db, open(filename, 'r', newline='') as infile:
        csvfile = csv.DictReader(infile)
        for item in csvfile:
            if not item['selection']:
                item['selection'] = None
            # check for update of snapshot and delete the old data
            if item['date'] not in snapshot_dates:
                db.execute("""DELETE FROM snapshots
                               WHERE date >= date(?)""",
                           (item['date'],))
                snapshot_dates.add(item['date'])

            assert int(item['rank']) == clan_counter[item['clan']] + 1, 'Rank of animal {} is incorrect'.format(item['name'])
            assert item['name'] not in names, 'Duplicate entry for animal {}'.format(item['name'])

            db.execute("""INSERT INTO snapshots
                          VALUES (?, ?, ?, ?, ?) """,
                       (item['date'], item['clan'], item['rank'], item['name'], item['selection']))
            clan_counter[item['clan']] += 1
            names.add(item['name'])


def load_snapshot2(db, filename):
    """Read in a snapshot file and feed it into the database."""

    # pull in all data from snapshot file, all dates and clans
    snapshots = defaultdict(lambda: defaultdict(list))
    clan_counter = defaultdict(int)
    names = set()
    with open(filename, 'rb') as infile:
        csvfile = csv.DictReader(infile)
        for item in csvfile:
            if not item['selection']:
                item['selection'] = None

            assert int(item['rank']) == clan_counter[item['clan']] + 1, 'Rank of animal {} is incorrect'.format(item['name'])
            assert item['name'] not in names, 'Duplicate entry for animal {}'.format(item['name'])

            date = parse_date(item['date'])
            snapshots[date][item['clan']].append({'name': item['name'],
                                                 'rank': item['rank'],
                                                 'selection': item['selection']})
            clan_counter[item['clan']] += 1
            names.add(item['name'])

    if not snapshots:
        return

    with db:
        # delete all snapshot data which is not before first loaded snapshot
        first_date = sorted(snapshots.keys())[0]
        db.execute("""DELETE FROM snapshots
                       WHERE date >= date(?)""", (first_date,))

        # process snapshots
        for snapdate, snapnew in snapshots.iteritems():
            # get known state for the date of snapshot
            snapold = get_ranks(db, str(snapdate), verbose=False)
            if snapold is not None:
                # replace the state of clans in snapold with the new one.
                for clan in snapold:
                    if clan not in snapnew:
                        # transfer data for clans which are not in snapshot
                        snapnew[clan] = [{'name': ai.name,
                                          'rank': rank + 1,
                                          'selection': ai.selection} for rank, ai in enumerate(snapold[clan])]

            for clan in sorted(snapnew.keys()):
                for item in snapnew[clan]:
                    db.execute("""INSERT INTO snapshots
                                  VALUES (?, ?, ?, ?, ?) """,
                               (snapdate, clan, item['rank'], item['name'], item['selection']))


def parse_date(date):
    """Convert date string into a datetime object."""

    return dtm.datetime.strptime(date, '%Y-%m-%d').date()


def get_snapdate(db, date):
    """Return date of the snapshot immediately preceding requested date."""

    snapdate = db.execute("""SELECT DISTINCT(date)
                               FROM snapshots
                              WHERE date <= ?
                              ORDER BY date DESC
                              LIMIT 1 """,
                          (date,)).fetchone()
    if not snapdate:
        return None
    else:
        return snapdate[0]
        # return dtm.datetime.strptime(str(snapdate[0]), '%Y-%m-%d').date().strftime('%Y-%m-%d')


def get_snapshot(db, snapdate):
    """Return the last snapshot before the specified date."""
    # result {clan: [Animal]}, {name: clan}

    animals = defaultdict(list)
    index = {}  # name -> clanname
    snapshot = db.execute("""SELECT clan,
                                    name,
                                    sex,
                                    birthdate,
                                    selection
                               FROM snapshots
                               LEFT JOIN hyenas USING (name)
                              WHERE date = date(?)
                              ORDER BY clan, rank ASC """,
                          [snapdate]).fetchall()
    if len(snapshot) > 0:  #, 'There is no snapshot for this date: {}'.format(snapdate)
        for clan, name, sex, bdate, selection in snapshot:
            animals[clan].append(Animal(name=name,
                                        birthdate=parse_date(bdate),
                                        male=None if sex is None else sex == 1,
                                        native=(selection is None) or (selection == 'philopatric'),
                                        selection=selection))
            index[name] = clan
    return animals, index


def get_births(db, start, end):
    """Return all births for the specified date range."""

    births = db.execute("""SELECT birthclan,
                                  mothersocial,
                                  date(birthdate, '-1 day') as bdate,
                                  name,
                                  sex
                             FROM hyenas
                            WHERE ? <= bdate AND bdate < ?
                            ORDER BY mothersocial, birthdate, litterdominance """,
                        (start, end))
    result = []
    # group newborns by mother and date
    for key, group in it.groupby(births, lambda x: (x[0], x[1], x[2])):
        clan, mother, date = key
        date = parse_date(date)
        cubs = [Animal(name=name,
                       birthdate=date,
                       male=None if sex is None else sex == 1,
                       native=True,
                       selection=None) for clan, mom, bdate, name, sex in group]
        result.append({'date': date,
                       'mother': mother,
                       'cubs': cubs,
                       'type': 'birth'})
    return result


def get_deaths(db, start, end):
    """Return all deaths for the specified date range."""

    deaths = db.execute("""SELECT name, deathdate
                             FROM deaths
                            WHERE ? <= deathdate AND deathdate < ? """,
                        (start, end))
    return [{'name': name,
             'date': parse_date(date),
             'type': 'death'} for name, date in deaths]


def get_migrants(db, start, end):
    """Return all selection events for the specified date range."""

    # we subtract one day from the date since the recorded date is that of the
    # first sighting in the new clan, and the migration has already happened
    migrants = db.execute("""SELECT selections.name,
                                    date(date, '-1 day') as migdate,
                                    destination,
                                    sex
                               FROM selections
                               LEFT JOIN hyenas
                              USING (name)
                              WHERE ? <= migdate AND migdate < ?
                              ORDER BY migdate """,
                          (start, end))
    return [{'name': name,
             'date': parse_date(date),
             'clan': clanname,
             'male': None if sex is None else sex == 1,
             'type': 'migrant'} for name, date, clanname, sex in migrants]


def index_of_name(clan, name):
    """Return the index of an animal in a clan."""

    for i, item in enumerate(clan):
        if item.name == name:
            return i
    return None


def event_str(event):
    """Return a string describing the event."""

    etype = {'birth': '+', 'death': '.', 'migrant': '>'}[event['type']]
    fields = [str(event['date']), etype]
    if event['type'] == 'death':
        fields.append(event['name'])
    elif event['type'] == 'migrant':
        fields.append('{} -> {}'.format(event['name'], event['clan']))
    elif event['type'] == 'birth':
        text = '{} -> {}'.format(event['mother'] if event['mother'] is not None else ' ??? ',
                                 ','.join(cub.name for cub in event['cubs']))
        fields.append(text)
    return '  '.join(fields)


def last_native(clan):
    """Return index of the last resident individual in a clan."""

    return list(reversed([i for i, x in enumerate(clan) if x.native]))[0]


def get_selection(old_sel, old_clan, new_clan):
    """Return new selection status given a migration and the old status."""

    if old_sel is None:
        if old_clan == new_clan:
            return 'philopatric'
        else:
            return 'disperser'
    else:
        assert old_clan != new_clan
        # equality can only happen for first choice, which will have
        # old_sel == None and is handled above

        if old_sel in {'philopatric', 'disperser'}:
            return 'selector2'
        else:
            assert old_sel[:8] == 'selector', "Selection is " + old_sel
            return 'selector' + str(int(old_sel[8:]) + 1)


def process_birth(animals, clan_index, event):
    """Insert new cubs below their mother into her clan."""

    try:
        clanname = clan_index[event['mother']]
    except KeyError:
        clanname = event['cubs'][0].name[0]

    cubs = event['cubs']
    clan = animals[clanname]

    if event['mother'] is None:
        # mother unknown, insert after last native animal
        try:
            insert_id = last_native(clan) + 1
        except IndexError:
            # no natives, put it at the start
            insert_id = 0
    else:
        # insert right after mother
        insert_id = index_of_name(clan, event['mother']) + 1
    clan[insert_id : insert_id] = cubs

    # record new arrivals in the index
    for cub in cubs:
        clan_index[cub.name] = clanname


def process_death(animals, clan_index, event):
    """Remove references to the deceased animal."""

    name = event['name']
    clan = animals[clan_index[name]]
    del clan[index_of_name(clan, name)]
    del clan_index[name]


def process_migration(animals, clan_index, event):
    """Transfer animal to a new clan and update its selection status."""

    name = event['name']
    old_clan_name = clan_index[name]
    new_clan_name = event['clan']
    old_clan = animals[old_clan_name]
    migrant_id = index_of_name(old_clan, name)
    migrant = old_clan[migrant_id]

    if migrant.male and (old_clan_name == new_clan_name):
        # philopatric, replace old entry in list with new one
        migrant = Animal(name=migrant.name,
                         birthdate=migrant.birthdate,
                         male=migrant.male,
                         native=True,
                         selection=get_selection(migrant.selection, old_clan_name, new_clan_name))
        old_clan[migrant_id] = migrant
    else:
        # true migrant, move from one clan to the other
        old_clan.pop(migrant_id)
        selection = None if not migrant.male else get_selection(migrant.selection, old_clan_name, new_clan_name)
        migrant = Animal(name=migrant.name,
                         birthdate=migrant.birthdate,
                         male=migrant.male,
                         native=(not migrant.male),  # False for males, True for females
                         selection=selection)
        if migrant.male:
            # insert at the bottom
            insert_id = len(animals[new_clan_name])
        else:
            # insert after last native
            try:
                insert_id = last_native(animals[new_clan_name]) + 1
            except IndexError:
                # no natives found, put her on top
                insert_id = 0
        animals[new_clan_name][insert_id : insert_id] = [migrant]
        clan_index[name] = new_clan_name


def gen_states(db, dates, verbose=True, diag=False):
    """Return the hierarchies of all clans for the specified dates.

    Result is (date, state, index):
        date: dtm.datetime,
        state: {clanname: [Animal]},
        index: {name: clanname}
    """

    dates = sorted(dates)
    event_handlers = {'birth': process_birth,
                      'death': process_death,
                      'migrant': process_migration}

    for snapdate, date_group in it.groupby(dates, lambda x: get_snapdate(db, x)):
        date_group = list(date_group)
        animals, clan_index = get_snapshot(db, snapdate)

        # collect changes from snapdate to the last date within this group/snapshot
        deaths = get_deaths(db, snapdate, date_group[-1])
        births = get_births(db, snapdate, date_group[-1])
        migrants = get_migrants(db, snapdate, date_group[-1])

        events = deaths + births + migrants
        events.sort(key=lambda x: x['date'])

        if diag:
            print('{}:'.format(snapdate))

        # process events
        for ei in events:
            while ei['date'] > date_group[0]:  # TODO think about equality in the comparison
                # arrived at one of the requested dates, yield data
                yield (date_group[0], animals, clan_index)
                date_group.pop(0)

            # print summary of event
            if verbose:
                print(event_str(ei))

            # process event
            if diag:
                try:
                    event_handlers[ei['type']](animals, clan_index, ei)
                except (KeyError, TypeError):
                    if not verbose:
                        # with verbose on, event has already been printed
                        print(event_str(ei))
            else:
                event_handlers[ei['type']](animals, clan_index, ei)

        # the remaining date(s) lie after the last event
        assert len(date_group) > 0, date_group
        for date in date_group:
            yield (date, animals, clan_index)


def agesex(animal, date):
    """Return a string describing an animal's age and sex at a given date."""

    age = (date - animal.birthdate).days
    sex = 'm' if animal.male else 'f' if animal.male is not None else '?'
    if age < 365:
        return 'cub'
    elif age < 365 * 2:
        return 'sad' + sex
    else:
        return 'ad' + sex


def rank_clan(clan, pred):
    """Return absolute and standard ranks for animals selected by predicate."""

    n = [0]
    def count():
        n[0] += 1
        return n[0]

    ranks = [count() if pred(animal) else None for animal in clan]
    if n[0] == 0:
        std_ranks = [None for ri in ranks]
    elif n[0] == 1:
        # just one entry, give it a 1
        std_ranks = [None if ri is None else 1 for ri in ranks]
    else:
        std_ranks = [None if ri is None else (-2.0 * (ri - 1)) / (n[0] - 1) + 1 for ri in ranks]
    return ranks, std_ranks


def merge_ranks(r1, r2):
    """Combine two rank lists, keeping non-None values from both."""

    assert len(r1) == len(r2)
    result = []
    for i, (ri1, ri2) in enumerate(zip(r1, r2)):
        if ri1 is None:
            result.append(ri2)
        elif ri2 is None:
            result.append(ri1)
        else:
            raise ValueError('Conflicting values at position {}'.format(i))
    return result


def merge_rank_pairs(p1, p2):
    """Merge two pairs on non-overlapping rank lists into one."""

    return (merge_ranks(p1[0], p2[0]), merge_ranks(p1[1], p2[1]))


def is_adult(animal, date):
    """Return whether an animal is at least two years old."""

    age = (date - animal.birthdate).days
    return age >= 365 * 2


def is_cub(animal, date):
    """Return whether an animal is less than one year old."""

    age = (date - animal.birthdate).days
    return age < 365


def format_rank(val):
    """Convert a float into a string with three decimal places."""

    return '' if val is None else '{0:.3f}'.format(val)


def write_state(states, ranks=True):
    """Write the complete state of the population into a file."""

    for date, animals, _ in states:
        filename = 'state_{:%Y-%m-%d}.csv'.format(date)

        with open(filename, 'w', newline='') as outfile:
            header = ['date', 'clan', 'name', 'selection', 'rank']
            if ranks:
                header += ['agesex', 'gender_rank', 'gender_rank_std', 'nat_rank', 'nat_rank_std', 'adnat_rank',
                           'adnat_rank_std', 'sel_rank', 'sel_rank_std']

            csvfile = csv.DictWriter(outfile, fieldnames=header, extrasaction='ignore')
            csvfile.writeheader()
            for clanname in sorted(animals.keys()):
                clan = animals[clanname]

                gender_rank, gender_rank_std = merge_rank_pairs(rank_clan(clan, lambda x: is_adult(x, date) and (x.male is True)),
                                                                rank_clan(clan, lambda x: is_adult(x, date) and (x.male is False)))
                nat_rank, nat_rank_std = rank_clan(clan, lambda x: (not is_cub(x, date)) and x.native)
                adnat_rank, adnat_rank_std = rank_clan(clan, lambda x: is_adult(x, date) and x.native)
                sel_rank, sel_rank_std = rank_clan(clan, lambda x: x.selection is not None)

                for rank, (animal, gr, grs, nr, nrs, ar, ars, sr, srs) in enumerate(zip(clan, gender_rank, gender_rank_std,
                                                                                     nat_rank, nat_rank_std, adnat_rank, adnat_rank_std,
                                                                                     sel_rank, sel_rank_std)):
                    line = {'date': str(date),
                            'clan': clanname,
                            'name': animal.name,
                            'selection': animal.selection if animal.selection else '',
                            'rank': rank + 1,
                            'agesex': agesex(animal, date),
                            'gender_rank': gr,
                            'gender_rank_std': format_rank(grs),
                            'nat_rank': nr,
                            'nat_rank_std': format_rank(nrs),
                            'adnat_rank': ar,
                            'adnat_rank_std': format_rank(ars),
                            'sel_rank': sr,
                            'sel_rank_std': format_rank(srs)}
                    csvfile.writerow(line)


def get_state(db, date, ranks=True, verbose=True):
    states = gen_states(db, [parse_date(date)], verbose=verbose)
    write_state(states, ranks)


def check_consistency(db):
    query = """SELECT DISTINCT date(date, "-1 day")
                 FROM snapshots
                ORDER BY date"""
    dates = [parse_date(row[0]) for row in db.execute(query)][1:]
    dates.append(dtm.date.today())

    for _, _, _ in gen_states(db, dates, verbose=False, diag=True):
        pass


# if __name__ == '__main__':
#     dbfile = 'Fisidata.sqlite'
#     db = sqlite3.connect(dbfile)
#     date = '1996-06-17'

#     get_state(db, date)
    # load_snapshot2(db, 'snapshot_1996-04-12.csv')
    # check_consistency(db)
