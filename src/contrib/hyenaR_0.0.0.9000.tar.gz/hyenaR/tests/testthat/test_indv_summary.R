context("Test indv_summary function")

test_that("indv_summary works when no date is provided", {
  
  output_summary <- indv_summary(indv = "F-001")
  
  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))
  
  
})

test_that("indv_summary works when no individuals are provided", {
  
  output_summary <- indv_summary(date = "1999-01-01")
  
  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))
  
  
})

test_that("indv_summary works when no arguments are provided", {
  
  output_summary <- indv_summary()
  
  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$birthdate), "Date")
  #Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$age)
              & is.numeric(output_summary$RS)
              & is.character(output_summary$mothergenetic))
  
  
})