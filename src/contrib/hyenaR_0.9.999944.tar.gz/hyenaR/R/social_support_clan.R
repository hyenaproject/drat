
#` create a table with rank based on social support
#'
#' The function runs the social support algorithm to sort individual of a clan at a given time. Taking advantage
#' of the transitivity of the hierarchy, it ranks individuals using a merge-sort algorithm. This means
#' that not all possible interactions are "simulated". To solve possible ties, each rank is compared against the rank
#' just below it (for example rank1 against rank2). If no clear winner emerges from this interaction the two individuals
#' take the rank of the best-ranked one.
#'
#' Note: the sorting function can be modified and thus if new algorithm need to be tested this can be done given that the new algorithm is transitive.
#'
#' @inheritParams arguments
#' @export
#' @examples
#' \dontrun{
#' create_clan_rank.social(clan = "A", at = "1997-01-01")
#' }
create_clan_rank.social <- function(clan, at, sorting.fn = find_dyad_interaction.winner.from.tbl){

  tbl <- create_id_table.ancestors(clan, at) %>%
    dplyr::mutate(date = !!at) ## date is used within sorting function!

  sorted <- recode_vector_merge.sort(ID = tbl$ID, sorting.fn = sorting.fn, tbl = tbl)

  sorted_tied <- recode_rank.socialsupport_to_include.ties(sorted, tbl)

  tibble::tibble(ID = sorted,
                 rank = sorted_tied)

}


#' Compare each sorted ID against the one just above it.
#'
#' This function is need because the output of `recode_vector_sort()` does not deal with ties which are expected based on the computation of social support.
#' For examples between twins or between descendant of twins. It runs a comparison between them.
#' The input tibble must here be the one produced by [create_id_table.ancestors].
#'
#' @return An vector of Rank.
#' @inheritParams arguments
#' @export
recode_rank.socialsupport_to_include.ties <- function(ID, tbl){
  out <- numeric(length(ID))
  out[1] <- 1

  if(length(ID) < 2) {
   out <- ID
  } else {
  for (i in 2:length(ID)) {

    tt <- find_dyad_interaction.winner.from.tbl(ID[i - 1], ID[i], tbl)

    if (is.na(tt)) {
  out[i] <- out[i - 1]
    } else {
      out[i] <- i
    }
  }

  }
out
}


#' Compare and sort 2 vectors of ID.
#'
#' Merge and order two vector of IDs, by sequentially comparing the element of the first vector to the one of the second.
#' The sorting function can be modified. It does not deal with ties and will always order the ID of the first vector first.
#'
#'
#' @name recode_vector_sort
#' @return An ordered vector.
#' @inheritParams arguments
#' @param ... Arguments to pass to sorting.fn.
#' @export
recode_vector_sort <- function(ID.1, ID.2, sorting.fn, ...) {

    output <- numeric(length(ID.1) + length(ID.2))
    ai <- bi <- j <- 1

    for (j in seq_len(length(output))) {  ## iterate on output

            ## first deal with the cased when one side is fully sorted... don´t need to run the comparison anymore
      if  (bi > length(ID.2)) { ## if ID.2 is sorted

        output[j] <- ID.1[ai]
        ai <- ai + 1

      } else if  (ai > length(ID.1)) {  ## if ID.1 is sorted
        output[j] <- ID.2[bi]
        bi <- bi + 1

      } else {## compare

        comp <- sorting.fn(ID.1 = ID.1[ai], ID.2 = ID.2[bi], ...)
        comp <- comp == ID.1[ai] || is.na(comp)

        if (comp) {
           output[j] <- ID.1[ai]
           ai <- ai + 1

        } else {
            output[j] <- ID.2[bi]
            bi <- bi + 1
        }
      }

    }
    output
}

#' Recursive function to order a vector of ID.
#'
#' Use a merge-sort algorithm adapted from the code of MrFlick \url{https://stackoverflow.com/questions/26080716/merge-sort-in-r}
#'
#' @name recode_vector_merge.sort
#' @return An ordered vector.
#' @inheritParams arguments
#' @inheritParams recode_vector_sort
#' @export
recode_vector_merge.sort <- function(ID, sorting.fn, ...) { ## split and loop

    if (length(ID) > 1) {
        q <- ceiling(length(ID)/2) ## split the vectors

        ID.1 <- Recall(ID[1:q], sorting.fn, ...)
        ID.2 <- Recall(ID[(q + 1):length(ID)], sorting.fn, ...)

        recode_vector_sort(ID.1, ID.2, sorting.fn, ...)

    } else {
        ID
    }
}

#' Create a table with clan members and their ancestors.
#'
#' @describeIn create_family create a table with all clan members / ancestors / migrant status and lifestage.
#' @return Returns a 6 columns data frame with ID, clan, date, migrant, ancestors and lifestage
#' @export
#' @examples
#' create_id_table.ancestors(clan = "A", at = "1997-04-01")
create_id_table.ancestors <- function(clan, at) {  ### will need either to rename it or to make if vector compatible or

  clan <- check_function_arg.clan(clan)
  date <- check_function_arg.date(at)

  ### get all clan members and their ancestors and life_stage
  create_id_starting.table(clan = clan, at = date) %>%
    dplyr::mutate(date = !!date) %>%
    dplyr::mutate(migrant = fetch_id_is.migrant(.data$ID, !!date, migrant.mother.as.native = TRUE),
                  lifestage = fetch_id_lifestage(.data$ID, !!date)) %>%
    dplyr::rowwise() %>%
    dplyr::mutate(ancestors = list(find_id_id.ancestor.all(.data$ID, filiation = "mother_social"))) %>%
    dplyr::ungroup()
}


#################################################################################

#' @describeIn find_family fetch the winner of an interaction based on a clan table created by [create_id_table.ancestors]
#'
#' Social function to be used only with the output of [create_id_table.ancestors]. Clan specific version of the more
#' general function [fetch_dyad_interaction.winner]. The input tibble used here must have beed created with [create_id_table.ancestors].
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_interaction.winner.from.tbl <- function(ID.1, ID.2, tbl){

  date <- tbl$date[1]

  mig_ID.1 <- tbl$migrant[tbl$ID == ID.1]
  mig_ID.2 <- tbl$migrant[tbl$ID == ID.2]

  line_ID.1 <- tbl$ancestors[tbl$ID == ID.1][[1]]
  line_ID.2 <- tbl$ancestors[tbl$ID == ID.2][[1]]


    if (mig_ID.1 & mig_ID.2) { ## migrant // migrant
    find_dyad_winner.migrant(ID.1, ID.2, date)
  } else if (mig_ID.1 & !mig_ID.2) { ## migrant // native
    find_dyad_winner.native.migrant(ID.2, ID.1)
  } else if (!mig_ID.1 & mig_ID.2) { ## native // migrant
    find_dyad_winner.native.migrant(ID.1, ID.2)
  } else if (!mig_ID.1 & !mig_ID.2 & any(line_ID.1 %in% line_ID.2)) { ## native // related
    find_dyad_winner.native.related(ID.1, ID.2)
  } else if (!mig_ID.1 & !mig_ID.2 & !any(line_ID.1 %in% line_ID.2)) { ## native // unrelated
    find_dyad_winner.native.unrelated.tbl(ID.1, ID.2, tbl)
  } else {
    NA
  }
}


#################################################################################

#' @describeIn find_family fetch the winner of an interaction between two unrelated natives based on a clan table created by [create_id_table.ancestors]
#'
#' Simplified version of the function [find_dyad_winner.native.unrelated] to be used with the table created with
#' [create_id_table.ancestors] and with individuals from the same clan. The input tibble used here must have beed created with [create_id_table.ancestors].
#'
#' @return A character string. The winner of the interaction.
#' @export
find_dyad_winner.native.unrelated.tbl <- function(ID.1, ID.2, tbl){

  line_ID.1 <- tbl$ancestors[tbl$ID == ID.1][[1]]
  line_ID.2 <- tbl$ancestors[tbl$ID == ID.2][[1]]

      output <- tbl %>%
        dplyr::filter(!(.data$lifestage %in% c("cub"))) %>%
        dplyr::rowwise() %>%
        dplyr::mutate(relat_ID.1 = any(.data$ancestors %in% line_ID.1),
                      relat_ID.2 = any(.data$ancestors %in% line_ID.2))

      ID.1_sup <- sum(output$relat_ID.1)
      ID.2_sup <- sum(output$relat_ID.2)

      if (ID.1_sup > ID.2_sup) winner <- ID.1  ## the one with the most relatives wins
      else if (ID.1_sup < ID.2_sup) winner <- ID.2
      else winner <- NA

      winner
}


#' Compute the number of social supporter for all individuals in a clan
#'
#' The function assess the social support of all individuals in a clan at a given time.
#' It considers that each clan member interacts with all other clan member.
#' The number of social supporters is reported for `ID.1` in the context of an interaction between `ID.1` and `ID.2`.
#'
#' @inheritParams arguments
#'
#' @return A tibble with all pairwise combination of clan number and their social support.
#' @export
#'
#' @examples
#' \dontrun{
#' load_package_database.dummy()
#' test <- create_clan_number.supporter(clan = "A", at = "1997-10-01")
#' recode_df.supporter_matrix(test)
#' }
create_clan_number.supporter <- function(clan, at, verbose = TRUE) {

  clan <- check_function_arg.clan(clan)
  date <- check_function_arg.date(at)

  IDs <- find_clan_id(clan = clan, at = date)

  expand.grid(ID.1 = IDs, ID.2 = IDs, stringsAsFactors = FALSE) |>
    as.data.frame() |>
    tibble::as_tibble() -> tbl

  if (verbose) message(paste("Computing social support for", nrow(tbl), "pairs of individuals... (be patient)"))

  ## rowwise version: 10-20% faster but no progress bar
  # tbl |>
  #   dplyr::rowwise() |>
  #   dplyr::mutate(n.supporters = find_dyad_number.supporter(ID.1 = .data$ID.1, ID.2 = .data$ID.2, at = !!date, verbose = FALSE)) |> ## or v(.data$ID.1), ID.2 = v(.data$ID.2)
  #   dplyr::ungroup() -> tbl

  ## map version: 10-20% slower but with progress bar
  tbl$n.supporters <- purrr::map2_vec(.x = tbl$ID.1, .y = tbl$ID.2, .f = find_dyad_number.supporter, # or v(tbl$ID.1), .y = v(tbl$ID.2)
                                      at = date, verbose = FALSE, .progress = TRUE) ## slower
  tbl
}

#' @describeIn create_clan_number.supporter turn the dataframe into a matrix
#' @export
recode_df.supporter_matrix <- function(df) {
  df_wide <- tidyr::pivot_wider(df, names_from = "ID.2", values_from = "n.supporters")
  df_matrix <- as.matrix(df_wide[, -1])
  rownames(df_matrix) <- df_wide[, 1, drop = TRUE]
  df_matrix
}
