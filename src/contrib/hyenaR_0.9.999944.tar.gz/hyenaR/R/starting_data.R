#' Generate starting data for the downstream analysis
#'
#' These functions generate the starting data according to
#' the clan, time, or life stage specified.
#'
#' @inheritParams arguments
#' @name starting_data
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL



#' @describeIn starting_data Create a table of unique hyenas based on their ID or clan, life stage, and time.
#'
#' To recreate previous behaviour of `create_id_starting.table()` from hyenaR v. 0.9.99993 use `create_id_starting.table.historic()`
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_id_starting.table usage:
#'
#' ## THESE FIRST EXAMPLES SIMPLY QUERY THE HYENAS DATA TABLE.
#' ## THEY ARE *FAST* BUT LIMITED BECAUSE THEY ONLY CONSIDER SEX AND
#' ## BIRTH CLAN. ANY QUERIES THAT CONSIDER PARTICULAR LIFESTAGES OR
#' ## MALE DISPERSAL ARE MORE COMPLEX.
#'
#' # create table with specific individuals
#' create_id_starting.table(c("A-001", "L-003", "A-100"))
#'
#' # create table with all the individuals (in main and non-main clans)
#' create_id_starting.table()
#'
#' # create table with all the individuals born ONLY in main clans
#' create_id_starting.table(main.clans.birth = TRUE)
#'
#' # create table with all the individuals that were born in specific clan(s)
#' create_id_starting.table(clan.birth = c("A", "X"))
#'
#' # create a table with all the females that were born in specific clan(s)
#' create_id_starting.table(sex = "female", clan.birth = c("A", "X"))
#'
#' ## WHEN WE START LOOKING FOR SPECIFIC LIFE STAGES AND DATE RANGES WE NEED TO
#' ## QUERY THE LIFE HISTORY TABLE, WHICH NECESSARILY WILL TAKE LONGER TO PROCESS.
#'
#' # create table with individuals that were philopatric in clan A and L on 1996-04-12
#' create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
#'
#' # create table with individuals that started their membership in clan A between
#' # 1996-04-12 and 1997-12-30
#' create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30",
#'                          clan.overlap = "start")
#'
#' # create table with individuals that made their FIRST selection (i.e. philo or disperser)
#' #between 1996-04-12 and 1997-12-30
#' create_id_starting.table(lifestage = c("philopatric", "disperser"),
#'                          from = "1996-04-12", to = "1997-12-30",
#'                          lifestage.overlap = "start")
#'
#' # create table with individuals that were philopatric in clan A for the whole period from
#' # 1996-12-01 to 1997-10-30
#' create_id_starting.table(clan = "A", lifestage = "philopatric",
#'                          from = "1996-12-01", to = "1997-10-30",
#'                          clan.overlap = "always", lifestage.overlap = "always")
#'
#' # create table with individuals that were present as philopatric in clan A for
#' # sometime during 2000-01-01 to 2002-02-01
#' create_id_starting.table(clan = "A", lifestage = "philopatric",
#'                          from = "1996-04-12", to = "1997-12-30",
#'                          clan.overlap = "any", lifestage.overlap = "any")
#'
#' # create table with individuals that were born in clan A during 1996-04-12 to 1997-12-30.
#' # By searching for lifestage = "cub" and lifestage.overlap = "start"
#' # we find individuals that were born
#' create_id_starting.table(clan = "A", lifestage = "cub", lifestage.overlap = "start",
#'                          from = "1996-04-12", to = "1997-12-30")
#'
#' # create table with individuals that were born in clan A and were dispersers in clan L during 1997
#' create_id_starting.table(clan.birth = "A",
#'                          clan = "L", lifestage = "disperser",
#'                          from = "1997-01-01", to = "1997-12-31")
#'
#' # create table with individuals that were born in any of the the main clans
#' # and were dispersers in clan L during 1997
#' create_id_starting.table(main.clans.birth = TRUE,
#'                          clan = "L", lifestage = "disperser",
#'                          from = "1997-01-01", to = "1997-12-31")
#'
#' # create a table with all individuals that have died up to and including the period
#' # 1996-08-01 and 1996-09-01
#' create_id_starting.table(clan = "A", from = "1996-08-01", to = "1996-09-01", lifestage = "dead")
#'
#' # Generally, we are interested only in individuals that died during the focal period.
#' # Therefore, we use lifestage.overlap = "start" to return individuals that died in clan A
#' # between 1996-08-01 and 1996-09-01
#' create_id_starting.table(clan = "A", from = "1996-08-01", to = "1996-09-01", lifestage = "dead",
#'                          lifestage.overlap = "start")

create_id_starting.table <- function(ID = NULL, sex = NULL, clan = NULL, clan.birth = NULL, lifestage = NULL, from = NULL, to = NULL, at = NULL,
                                     clan.overlap = 'any', lifestage.overlap = 'any',
                                     main.clans.birth = FALSE,
                                     verbose = TRUE) {

  messages <- vector()

  #If ID is provided, just return directly.
  if (!is.null(ID)) {

    if (!(is.null(c(sex, clan, clan.birth, lifestage, from, to, at)) && clan.overlap == 'any' && lifestage.overlap == 'any')) {

      messages <- append(messages, "When ID is provided other arguments are ignored. \n")

    }

    tibble::tibble(ID = check_function_arg.ID(ID)) -> output

    #If only sex or clan.birth are provided then just filter the hyenas table...
    ## TODO: Other scenarios where we could use shortcuts
    ## 1. lifestage = dead: Just match deathdate in the deaths
    ## 2. lifestage = cub & overlap = "start": Same as calling clan.birth
  } else if (all(is.null(ID), is.null(clan), is.null(lifestage), is.null(from), is.null(to), is.null(at), clan.overlap == "any", lifestage.overlap == "any")) {

    ## Check sex
    sex <- check_function_arg.sex(sex, .fill = TRUE)

    ## Check clan.birth is valid
    clan.birth_null <- is.null(clan.birth)
    clan.birth      <- check_function_arg.clan(clan.birth, .fill = TRUE, main.clans = main.clans.birth)

    if (clan.birth_null) {
      if (main.clans.birth) {
        messages <- append(messages, glue::glue("Returning all individuals born in main clans with sex: {allsex}. \n",
                                                allsex = paste(sex, collapse = ", ")))
      } else {
        messages <- append(messages, glue::glue("Returning all known individuals with sex: {allsex}. \n",
                                                allsex = paste(sex, collapse = ", ")))
      }

    } else {
      messages <- append(messages, glue::glue("Returning all individuals born in focal clans with sex: {allsex}. \n",
                                              allsex = paste(sex, collapse = ", ")))
    }

    extract_database_table("hyenas") %>%
      dplyr::filter(.data$sex %in% !!sex & .data$birthclan %in% !!clan.birth) -> output

  } else {

    ## Check sex
    sex <- check_function_arg.sex(sex, .fill = TRUE)

    ## Check current clan
    if (is.null(clan)) {
      #If clan is NULL, fill in all clans...
      clan <- check_function_arg.clan(clan, .fill = TRUE, main.clans = FALSE)
    } else {
      #Otherwise, use clans provided
      clan <- check_function_arg.clan(clan)
    }

    ## Check clan.birth
    if (is.null(clan.birth)) {
      #If clan.birth is NULL:
      ##By default main.clans.birth = FALSE so we consider individuals born in any clans (i.e. we effectively ignore clan.birth)
      ##User can change this default behaviour using main.clans.birth argument
      clan.birth <- check_function_arg.clan(clan.birth,
                                            .fill = TRUE,
                                            main.clans = main.clans.birth)
    } else {
      #Otherwise, use birth clan provided
      clan.birth <- check_function_arg.clan(clan.birth)
    }




    #If date information is provided, other arguments are relevant
    lifestage <- check_function_arg.lifestage(lifestage, .fill = TRUE)

    if ("dead" %in% lifestage) {

      messages <- append(messages, "lifestage dead will return all individuals that have died up until this point. If you want to return only individuals that died during this period use lifestage.overlap = 'start' \n")

    }

    clan.overlap        <- check_function_arg.overlap(clan.overlap)
    lifestage.overlap   <- check_function_arg.overlap(lifestage.overlap)
    date_range          <- check_function_arg.date.fromtoat(from = from, to = to, at = at, .fill = TRUE,
                                                            max.date = find_pop_date.observation.last(),
                                                            min.date = find_pop_date.birth.first(), arg.max.length = 1)
    from                 <- date_range$from
    to                   <- date_range$to

    #If users are searching for 'dead' lifestage, flag that not all overlap are suitable
    if ("dead" %in% lifestage & any(c("end", "within") %in% lifestage.overlap)) {

      messages <- append(messages, "lifestage.overlap 'end' and 'within' make no sense when searching for dead individuals. \n If you want to know if individuals died between 'from' and 'to', use 'lifestage.overlap = start' \n")

    }

    #Life history data for our focal sexes (these are unchanged over time so this is fine to do for everything)
    life_history_full <- create_id_life.history.table(censored.to.last.sighting = FALSE) %>%
      dplyr::filter(fetch_id_sex(.data$ID) %in% !!sex & fetch_id_clan.birth(.data$ID) %in% !!clan.birth)

    #Create cols where lifestage, clan, and both lifestage and clan are met.
    life_history_grouped <- life_history_full %>%
      #Create a summary lifestage that includes all desired lifestages
      dplyr::mutate(grouped_lifestage = .data$life_stage %in% !!lifestage,
                    grouped_clan = .data$clan %in% !!clan,
                    grouped_both = .data$life_stage %in% !!lifestage & .data$clan %in% !!clan)

    #Create separate grouped data for each of these categories
    life_history_lifestage <- life_history_grouped %>%
      #Each time we move from a focal lifestage to non-focal we increase the group value by 1.
      dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_lifestage) != 0))) %>%
      #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
      dplyr::filter(.data$grouped_lifestage) %>%
      {if (nrow(.) > 0) {
        #Now, for each individual and unique group determine a new start and end data
        dplyr::group_by(., .data$ID, .data$group_val) %>%
          dplyr::summarise(starting_date = min(.data$starting_date),
                           ending_date   = max(.data$ending_date),
                           .groups = "drop")
      } else {
        .
      }}

    life_history_clan <- life_history_grouped %>%
      #Each time we move from a focal lifestage to non-focal we increase the group value by 1.
      dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
      #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
      dplyr::filter(.data$grouped_clan) %>%
      {if (nrow(.) > 0) {
        #Now, for each individual and unique group determine a new start and end data
        dplyr::group_by(., .data$ID, .data$group_val) %>%
          dplyr::summarise(starting_date = min(.data$starting_date),
                           ending_date   = max(.data$ending_date),
                           .groups = "drop")
      } else {
        .
      }}

    life_history_both <- life_history_grouped %>%
      #Each time we move from a focal lifestage to non-focal we increase the group value by 1.
      dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_both) != 0))) %>%
      #Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
      dplyr::filter(.data$grouped_both) %>%
      {if (nrow(.) > 0) {
        #Now, for each individual and unique group determine a new start and end data
        dplyr::group_by(., .data$ID, .data$group_val) %>%
          dplyr::summarise(starting_date = min(.data$starting_date),
                           ending_date   = max(.data$ending_date),
                           .groups = "drop")
      } else {
        .
      }}

    #If at is provided (or from and to are the same) then we ignore the overlap arguments
    if (from == to && (lifestage.overlap != "any" || clan.overlap != "any")) {

      messages <- append(messages, "'clan.overlap' or 'lifestage.overlap' is ignored because 'at' is specified \n")

      lifestage.overlap <- "any"
      clan.overlap      <- "any"

    }

    #All options require us to check lifestage
    output_lifestage_overlap <- create_id_overlap.table(life_history_lifestage,
                                                        from = from, to = to,
                                                        overlap = lifestage.overlap, .internal = TRUE)

    output_clan_overlap <- create_id_overlap.table(life_history_both,
                                                   from = from, to = to,
                                                   overlap = clan.overlap, .internal = TRUE)

    allID <- unique(c(output_lifestage_overlap$ID, output_clan_overlap$ID))

    output <- tibble(ID = allID[allID %in% output_lifestage_overlap$ID & allID %in% output_clan_overlap$ID])

  }

  if (verbose && length(messages) > 0) { message(messages, appendLF = FALSE) }

  output %>%
    dplyr::select("ID") %>%
    dplyr::arrange(.data$ID) %>%
    dplyr::distinct(.data$ID) |>
    dplyr::mutate(ID = .data$ID) ## or v(.data$ID)

}




#' Fetch the individuals in a given clan fulfilling multiple conditions
#'
#' This function is a flexible function to retrieve individuals fulfilling
#' a wide range of criterion.
#'
#' @inheritParams arguments
#' @return a list of IDs
#' @export
#'
#' @examples
#' load_package_database.dummy()
#' fetch_clan_id(clan = c("A", "A"), lifestage = c("philopatric", "cub"),
#'              from = "1996-04-12", to = "1997-12-30",
#'              clan.overlap = "any", lifestage.overlap = "any")
#'
#' if (require("dplyr")) {
#' tibble(clan = c("A", "A"),
#'       lifestage = c("philopatric", "cub"),
#'       from = "1996-04-12", to = "1997-12-30",
#'       clan.overlap = "any",
#'       lifestage.overlap = "any") %>%
#'       mutate(id = fetch_clan_id(clan = clan, lifestage = lifestage,
#'                                 from = from, to = to,
#'                                 clan.overlap = clan.overlap,
#'                                 lifestage.overlap = lifestage.overlap))
#' }
#'
#' ## Note that the previous examples create different ID vectors for
#' ## philopatric and cub.
#' ## If instead you want for example ID for both philopatric and cub lifestages
#' ## combined within clans, you need to define a list column for defining the
#' ## lifestage:
#'
#' fetch_clan_id(clan = c("A", "L"),
#'              lifestage = list(c("philopatric", "cub"),
#'                               c("philopatric", "cub")),
#'              from = "1996-04-12", to = "1997-12-30",
#'              clan.overlap = "any", lifestage.overlap = "any")
#'
fetch_clan_id <- function(clan = NULL, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                          clan.overlap = "any", lifestage.overlap = "any", CPUcores = NULL,
                          .parallel.min = 1000) {

  ## no test needed as tested within find_clan_id which is called below

  input <- tibble::tibble(clan = !!clan,
                          sex = !!sex,
                          lifestage = !!lifestage,
                          at = !!at,
                          from = !!from,
                          to = !!to,
                          clan.overlap = !!clan.overlap,
                          lifestage.overlap = !!lifestage.overlap,
                          verbose = FALSE)

  input_unique <- unique(input)

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input_unique) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if(is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## Before we loop, we want to make sure the cache exists, otherwise, each iteration of a parallel loop would build its own cache.
  if (!"life_history" %in% find_package_cached.table()) {
    create_id_life.history.table() ## trigger caching
  }

  ## We loop
  if (CPUcores > 1 && nrow(input_unique) >= .parallel.min) {
    out <- furrr::future_pmap(input_unique, find_clan_id,
                              .progress = TRUE,
                              .options = furrr::furrr_options(globals = ".database"))
    future::plan("sequential") ## close connections (see https://cran.r-project.org/web/packages/future/vignettes/future-7-for-package-developers.html)
  } else {
    if (CPUcores > 1 && (nrow(input_unique) < .parallel.min)) {
      message(paste0("Argument CPUcores ignored as less than", .parallel.min, "cases to compute."))
    }
    out <- purrr::pmap(input_unique, find_clan_id)
  }

  input_unique %>%
    dplyr::mutate(ID = out) -> out_table

  out <- check_function_output(input.tbl = input, output.tbl = out_table,
                               join.by = colnames(input),
                               duplicates = "input",
                               output.IDcolumn = "ID")

  ## return
  out
}


