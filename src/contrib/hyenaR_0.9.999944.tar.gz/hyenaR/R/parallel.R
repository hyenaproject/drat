#' Activate parallel processing functionalities
#'
#' This function is used internally to activate the parallel processing.
#'
#' @inheritParams arguments
#' @return The number of cores to be used.
#' @export
#'
#' @examples
#' load_parallel_processing(CPUcores = 1)
#'
load_parallel_processing <- function(CPUcores = 1) {
  orginal_CPUcores <- getOption("hyenaR_CPUcores")
  max_cores <- parallel::detectCores()
  verbose <- ifelse(!is.null(CPUcores), CPUcores < max_cores, orginal_CPUcores < max_cores)
  new_CPUcores <- check_function_arg.CPUcores(CPUcores, verbose = verbose)
  if (new_CPUcores > 1) future::plan(future::multisession, workers = new_CPUcores)
  if (new_CPUcores == orginal_CPUcores) return(orginal_CPUcores)
  message(paste0("Parallelisation will use ", new_CPUcores, " (out of your ", max_cores, " available cores).\n Run options(hyenaR_CPUcores = ",new_CPUcores, ") if you want to make this setting permanent"))
  new_CPUcores
}
