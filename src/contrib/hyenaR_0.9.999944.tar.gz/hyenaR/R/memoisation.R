#' Functions to handle memoisation in hyenaR
#'
#' Memoisation is a technique used to speed up the computation of a function by
#' caching its results. This is useful when a function is called multiple times
#' with the same arguments. We rely on memoisation mainly for the purpose of
#' speeding up the computation related to the social support, which are
#' otherwise very slow. The function `load_package_memoisation()` is
#' automatically called when the hyenaR is loaded. When the database is updated,
#' the memoisation is automatically reset with `reset_package_memoisation()`.
#' The package we rely on to perform the memoisation is simple but not flawless,
#' it may not be compatible with parallel processing (see
#' [this issue](https://github.com/r-lib/memoise/issues/29)). It also does not seem to be
#' possible to start or stop the memoisation while the package is running.
#' Please contact the maintainer (Alex), in case of weird behaviour.
#'
#' @name load_package_memoisation
#' @aliases load_package_memoisation reset_package_memoisation check_package_memoisation memoisation memoization
#'
NULL

#' @describeIn load_package_memoisation initialise memoisation
#' @export
#'
load_package_memoisation <- function() {
  ## memoisation to speed up social support computation
  ## note: if more, don't forget to add the fn to unload_package_memoisation() and check_package_memoisation() below
  ## note: does not seem to be compatible with parallel processing...
  fetch_id_is.migrant <<- memoise::memoise(fetch_id_is.migrant)
  fetch_id_is.alive <<- memoise::memoise(fetch_id_is.alive)
  find_dyad_relatedness.via.filiation <<- memoise::memoise(find_dyad_relatedness.via.filiation)
  create_id_starting.table <<- memoise::memoise(create_id_starting.table)
  create_id_offspring.table <<- memoise::memoise(create_id_offspring.table)
  extract_database_table <<- memoise::memoise(extract_database_table)
}

#' @describeIn load_package_memoisation stop memoisation
#' @export
#'
reset_package_memoisation <- function() {
  memoise::forget(fetch_id_is.migrant)
  memoise::forget(fetch_id_is.alive)
  memoise::forget(find_dyad_relatedness.via.filiation)
  memoise::forget(create_id_starting.table)
  memoise::forget(create_id_offspring.table)
  memoise::forget(extract_database_table)
}

#' @describeIn load_package_memoisation check if memoisation is active
#' @export
#'
check_package_memoisation <- function() {
  any(c(memoise::is.memoised(fetch_id_is.migrant),
        memoise::is.memoised(fetch_id_is.alive),
        memoise::is.memoised(find_dyad_relatedness.via.filiation),
        memoise::is.memoised(create_id_starting.table),
        memoise::is.memoised(create_id_offspring.table),
        memoise::is.memoised(extract_database_table)))
}
