# UPDATE AND PRUNE DRAT REPOSITORY

#' Update the version of hyenaR in the drat folder.
#'
#' __This is an internal function__. Updates the version of hyenaR in the drat folder.
#' First update the version number in DESCRIPTION.
#' @inheritParams arguments
#' @export

build_drat_update <- function(drat.folder = NULL) {
  if (is.null(drat.folder)) {
    if (.Platform$OS.type == "windows") {
      drat.folder <- utils::choose.dir()
      print("Please select the location of the drat folder...")
    } else  stop("choose.dir does not exist in unix, so please specify the path manually") #
  }

  print("Build package...")
  devtools::build()

  print("Update in drat...")
  targz <- rev(list.files(pattern = "tar.gz", path = "..", full.names = TRUE))[1]
  drat::insertPackage(targz, repodir = drat.folder)

  print("Prune out old version...")
  drat::pruneRepo(repopath = drat.folder, remove = TRUE)

  print("Do not forget to commit and push your drat!")
}
