#' Validate function arguments
#'
#' These functions should not be directly used by the user. There are used to
#' use a metadata attribute "checked" to avoid checking multiple times the very
#' same arguments, which can otherwise be very costly when functions are called
#' internally multiple times. We are not using this feature yet, but it could
#' be useful in the future.
#'
#' @name validate_function_vec
#' @aliases validate_function_vec v check_function_arg.is.validated
#' @inheritParams arguments
#'
NULL

#' @describeIn validate_function_vec add an attribute to a vector to indicate its content has been validated.
#' @return The input augmented with an attribute "checked" set to TRUE.
#' @export
#'
validate_function_vec <- function(vec) {
  attr(vec, "checked") <- TRUE
  vec
}

#' @describeIn validate_function_vec syntactic sugar equivalent to [validate_function_vec].
#' @return The input augmented with an attribute "checked" set to TRUE.
#' @export
#'
v <- function(vec) {
  attr(vec, "checked") <- TRUE
  vec
}

#' @describeIn validate_function_vec check if an argument has been validated.
#' @return A boolean
#' @export
check_function_arg.is.validated <- function(arg) {
  isTRUE(attr(arg, "checked"))
}


