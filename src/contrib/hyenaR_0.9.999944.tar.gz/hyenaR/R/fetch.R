#' Fetch information about given hyena(s)
#'
#' These functions allows for the extraction of individual-level information
#' that either remain constant for a hyena over time, or that varies. The
#' ```fetch_xxx``` functions have not been designed to be particularly
#' efficient, so they should not be used by an intensive procedures (e.g.
#' simulations). Instead they have been designed to be particularly robust so
#' that they can be safely used directly by users.
#'
#' These functions can be used with inputs of length 1 or using vector. They
#' produce a vector of the same length and order than the hyenas name given.
#' Such vectors can easily be added to existing tables using e.g.
#' [dplyr::mutate()] (see example).
#'
#' Note for developers: if ```debug``` is set to ```TRUE``` the functions
#' output a `tibble` (instead of a vector), with detailed information on what is
#' used for the computation. This is only possible for some but not all
#' functions.
#'
#' @inheritParams arguments
#' @name fetch_family
#' @aliases fetch_family fetch
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL


#' @describeIn fetch_family companion function for fetch functions; it cleans the input
#'  and reformat it as a `tibble`.
#'
#' This function should not be directly used by the user.
#' @examples
#'
#' # clean_input_fetch_xxx_at(ID = c("A-080", "L-012"), age = c(2, 3))
clean_input_fetch_xxx_at <- function(ID, age) {
  dplyr::tibble(ID = ID, age = age)
}


#' @describeIn fetch_family fetch the age of a hyena on a given day.
#'
#' Note that if the hyena is dead, the age will be ```NA```.
#' @export
#' @examples
#'
#'
#'
#' ################ examples for time varying fetch_xx functions ################
#'
#'
#' #### Detailed example of fetch_id_age usage:
#'
#' ### fetch age of 2 individuals at 2 dates:
#' fetch_id_age(ID = c("A-080", "L-012"), at = c("1997-10-04", "1996-07-01"))
#'
#' ### fetch age of 1 individual at 2 dates:
#' fetch_id_age(ID = "A-080", at = c("1996-10-04", "1997-01-04"))
#'
#' ### fetch age of 2 individuals at 1 date:
#' fetch_id_age(ID = c("A-080", "L-012"), at = "1996-07-01")
#'
#' ### more advanced usage (add a new column in the hyena table containing lifespan):
#' ## note: this is more easily done using fetch_id_duration.lifespan (see above)
#'
#' ## step 1. extract the hyena table:
#' hyena_table <- extract_database_table(tbl.names = "hyenas")
#'
#' ## step 2. add date of death and lifespan to a new table:
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#' hyena_table %>%
#'   mutate(
#'     death_date = fetch_id_date.death(ID = ID),
#'     lifespan = fetch_id_age(ID = ID, at = death_date)
#'   ) -> lifespan_table
#' }
#'
#' ## step 3. view the outcome
#' lifespan_table
#' # note: all existing columns may not show on your screen unless you run
#' # options(tibble.width = Inf)
fetch_id_age <- function(ID, at, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         date = check_function_arg.date(at))

  hyenas <- extract_database_table(tbl.names = "hyenas")
  deaths <- extract_database_table(tbl.names = "deaths")

  input %>%
    dplyr::left_join(relationship = "many-to-many", hyenas, by = "ID") %>%
    dplyr::left_join(relationship = "many-to-many", deaths, by = "ID") %>%
    dplyr::select("ID", "birthdate", "deathdate") %>%
    dplyr::mutate(
      age = lubridate::interval(.data$birthdate, !!at) / lubridate::duration(1, units = check_function_arg.unit(!!unit))
    ) %>%
    dplyr::mutate(age = dplyr::case_when( ## give no focal age if dead!
      is.infinite(.data$age) ~ NA_real_,
      is.na(.data$deathdate) ~ .data$age,
      !!at <= .data$deathdate ~ .data$age,
      !!at > .data$deathdate ~ NA_real_
    )) -> output

  if (debug) {
    return(output)
  }

  output$age
}


#' @describeIn fetch_family fetch the birth clan of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_clan.birth usage:
#' fetch_id_clan.birth(ID = c("A-001", "A-007"))
fetch_id_clan.birth <- function(ID) {
  fetch_database_column(column = "birthclan", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the birthday of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.birth usage:
#' fetch_id_date.birth(ID = c("A-001", "A-007"))
fetch_id_date.birth <- function(ID) {
  fetch_database_column(column = "birthdate", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the birthday of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.conception usage:
#' fetch_id_date.conception(ID = c("A-001", "A-007"))
fetch_id_date.conception <- function(ID) {
  fetch_database_column(column = "birthdate", tbl.name = "hyenas", ID = ID) - 110
}


#' @describeIn fetch_family fetch the social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.birth usage:
#' fetch_id_rank.birth(ID = c("A-080", "A-100"))

fetch_id_rank.birth <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_id_date.birth(ID),
    birth_rank = fetch_id_rank(ID = ID, at = .data$birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  output$birth_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given hyena at its birth.
#'
#' Note that birth ranks can only be calculated for individuals born after 1996-04-12.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.birth usage:
#' fetch_id_rank.birth.std(ID = c("A-080", "L-012"))
#'
#' #### Example with missing information
#' fetch_id_rank.birth.std(ID = c("A-001", "A-100"))

fetch_id_rank.birth.std <- function(ID, debug = FALSE) {
  dplyr::tibble(
    ID = ID,
    birth_date = fetch_id_date.birth(ID),
    birth_rank = fetch_id_rank.std(ID = ID, at = .data$birth_date)
  ) -> output

  if (debug) {
    return(output)
  }

  output$birth_rank
}


#' @describeIn fetch_family fetch the clan of a given individual on a given date.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_clan.current usage:
#' fetch_id_clan.current(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_clan.current <- function(ID, at, censored.to.last.clan = TRUE, debug = FALSE) {
  ## TODO? instead of censored.to.last.clan we could have an argument
  ## setting a time cut-off for the extrapolation, but note that individuals not
  ## seen for a year are considered dead, so such a cut-off would only mater if
  ## there is a need to choose something between 0 and 1 year... The cut-off
  ## could also be made age and sex dependent, but again that introduces
  ## complexity that is perhaps not required...

  check_function_arg.logical(censored.to.last.clan)
  check_function_arg.logical(debug)

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          date = check_function_arg.date(at))

  life_history_tbl <- create_id_life.history.table(ID = unique(input$ID), # or v(unique(input$ID))
                                                   censored.to.last.sighting = FALSE) ## keep FALSE as filtering occurs below via isrightcensored

  input |>
    dplyr::full_join(relationship = "many-to-many", life_history_tbl, by = "ID") |>
    dplyr::distinct() -> life_history_tbl_with_date

  life_history_tbl_with_date |>
    dplyr::filter(.data$date >= .data$starting_date & .data$date <= .data$ending_date) -> output

  if (!censored.to.last.clan) {
    output |>
      dplyr::filter(!.data$isrightcensored) -> output
  }

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = c("ID", "date"),
                        duplicates = "input",
                        output.IDcolumn = "clan",
                        debug = debug)

}

#' @describeIn fetch_family fetch the date at which a given hyena has reached
#' a given age.
#'
#' Note that if the hyena is _known_ to be dead or censored, a date will still be given.
#' You can combine [fetch_id_age()] with [fetch_id_is.alive()] if it is not what you want.
#' @export
#'
#' @examples
#'
#' #### Detailed example of fetch_id_date.at.age usage:
#'
#' ### fetch date of 1 individual at 2 ages:
#' fetch_id_date.at.age(ID = c("A-080"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 1 age:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = 2)
#'
#' ### fetch date of 2 individuals at 2 ages in years:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = c(2, 3))
#'
#' ### fetch date of 2 individuals at 2 ages in weeks:
#' fetch_id_date.at.age(ID = c("A-080", "L-012"), age = c(2, 3), unit = "week")

fetch_id_date.at.age <- function(ID, age, unit = "year", debug = FALSE, na.if.dead = FALSE, na.if.censored = FALSE) {

  na.if.dead <- check_function_arg.logical(na.if.dead, arg.max.length = 1L)
  na.if.censored <- check_function_arg.logical(na.if.censored, arg.max.length = 1L)

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          age = age,
                          unit = check_function_arg.unit(unit, arg.max.length = 1L))

  input |>
    dplyr::mutate(birthdate = fetch_id_date.birth(ID),
           date = as.Date(.data$birthdate + lubridate::duration(.data$age, units = .data$unit[1]))) -> output

  #browser()
  if (na.if.dead || na.if.censored) {
    output |>
      dplyr::mutate(alive = fetch_id_is.alive(ID = .data$ID, at = .data$date),
                    max.date = pmin(find_pop_date.observation.last(), .data$date),
                    censored = fetch_id_is.censored.right(ID = .data$ID, at = .data$max.date),
                    date = dplyr::case_when(!.data$alive & na.if.dead ~ as.Date(NA),
                                            !.data$alive & !na.if.dead ~ .data$date,
                                            .data$alive & !.data$censored ~ .data$date,
                                            .data$alive & .data$censored & na.if.censored ~ as.Date(NA),
                                            .data$alive & .data$censored & !na.if.censored ~ .data$date,
                                            is.na(.data$alive) & .data$censored & na.if.censored ~ as.Date(NA),
                                            is.na(.data$alive) & .data$censored & !na.if.censored ~ .data$date
                                            )) |>
      dplyr::select(-"alive", -"censored") -> output
  }

  if (debug) {
    return(output)
  }

  output$date
}


#' @describeIn fetch_family fetch the date at first selection a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.genetic usage:
#' fetch_id_date.selection.first(ID = c("A-011", "A-040"))

fetch_id_date.selection.first <- function(ID, debug = FALSE) {

  ID <- check_function_arg.ID(ID)
  input <- tibble::tibble(ID = !!ID)

  create_id_life.transition.table(ID = unique(ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(2) %>%
    dplyr::left_join(relationship = "many-to-many", x = input, y = ., by = "ID") -> output

  if (debug) return(output)

  output$date

}


#' @describeIn fetch_family fetch the date of a given hyena at its death.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.death usage:
#' fetch_id_date.death(ID = c("L-012", "A-007"))

fetch_id_date.death <- function(ID) {
  fetch_database_column(column = "deathdate", tbl.name = "deaths", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the (genetic) father of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.father usage:
#' fetch_id_id.father(ID = c("A-080", "L-012"))

fetch_id_id.father <- function(ID) {
  fetch_database_column(column = "father", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the first date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the first sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.observation.first usage:
#' fetch_id_date.observation.first(ID = c("A-080", "L-012"))

fetch_id_date.observation.first <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  extract_database_table(tbl.names = "sightings") %>%
    dplyr::mutate(sighting_date = recode_x_date(.data$date_time)) -> sightings

  input %>%
    dplyr::left_join(relationship = "many-to-many", sightings, by = "ID") %>%
    dplyr::select("ID", "sighting_date") %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(first_obs_date = min(.data$sighting_date)) %>%
    dplyr::ungroup() %>%
    dplyr::left_join(relationship = "many-to-many", x = input, y = ., by = "ID") -> output
  ## Note: the last left_join is important because otherwise summarise changes the order of the rows!!!!!

  if (debug) {
    return(output)
  }

  output$first_obs_date
}


#' @describeIn fetch_family fetch the social rank within sex of a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.sex usage:
#' fetch_id_rank.sex(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.sex <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$gender_rank))) output %>% dplyr::mutate(gender_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank
}


#' @describeIn fetch_family fetch the standardized social rank within sex of a given
#'   individual on a given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.sex.std usage:
#' fetch_id_rank.sex.std(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.sex.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$gender_rank_std))) output %>% dplyr::mutate(gender_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$gender_rank_std
}


#' @describeIn fetch_family fetch if a given individual was alive on a given
#'   date.
#'
#'   The functions simply check if a given date falls between the birth and
#'   death date of a given hyena. It does not consider any other complexity.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.alive usage:
#' fetch_id_is.alive(ID = c("A-080", "L-012"), at = c("1997-10-04", "1997-10-04"))

fetch_id_is.alive <- function(ID, at, debug = FALSE) {

  input <- dplyr::tibble(ID = ID, date = as.Date(at))

  input %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(.data$ID),
                  deathdate = fetch_id_date.death(.data$ID),
                  surv = dplyr::case_when(.data$date > find_pop_date.observation.last() ~ NA,
                                          (is.na(.data$deathdate) | .data$deathdate > .data$date) & (.data$date >= .data$birthdate) ~ TRUE,
                                          .default = FALSE)) -> output

  if (debug) {
    return(output)
  }

  output$surv
}


#' @describeIn fetch_family fetch whether an individual's deathdate is confirmed.
#'
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_id_is.death.confirmed usage:
#' fetch_id_is.death.confirmed(c("A-100", "L-003"))

fetch_id_is.death.confirmed <- function(ID) {

  input <- check_function_arg.ID(ID)

  confirmed_death_date <- fetch_database_column(column = "deathconfirmed", tbl.name = "hyenas", ID = input)

  !is.na(confirmed_death_date)

}


#' @describeIn fetch_family fetch if a given hyena is a non-native (i.e. not in their birthclan)
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.nonnative usage:
#' fetch_id_is.nonnative(ID = c("A-001", "A-002"), at = "1997-11-01")

fetch_id_is.nonnative <- function(ID, at, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          at = check_function_arg.date(at))

  input %>%
    dplyr::mutate(native = fetch_id_is.native(ID, at)) -> output

  if (debug) return(output)

  !output$native
}


#' @describeIn fetch_family fetch if a given hyena is a native
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.native usage:
#' fetch_id_is.native(ID = c("A-001", "A-002"), at = "1997-11-01")

fetch_id_is.native <- function(ID, at, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          at = check_function_arg.date(at))

  input %>%
    dplyr::mutate(birthclan = fetch_id_clan.birth(ID),
                  current_clan = fetch_id_clan.current(ID, at = at),
                  native = .data$birthclan == .data$current_clan) -> output

  if (debug) return(output)

  output$native
}


#' @describeIn fetch_family fetch whether an individual could have _potentially_ be observed for a given duration.
#'
#' Note that the actual time of death of the hyena is irrelevant for this function.
#' @export
#'
#' @examples
#'
#' #### Simple example of fetch_id_is.observable usage:
#' fetch_id_is.observable(c("A-100", "L-003"), duration = 3, unit = "week")

fetch_id_is.observable <- function(ID, duration = NULL, unit = "year", debug = FALSE) {

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         duration = check_function_arg.duration(duration),
                         unit = check_function_arg.unit(unit))

  hyenas <- extract_database_table("hyenas")

  input %>%
    dplyr::left_join(relationship = "many-to-many", hyenas, by = "ID") %>%
    dplyr::mutate(birthdate = fetch_id_date.birth(ID),
                  date_firstsighting = find_pop_date.observation.first(),
                  date_lastsighting = find_pop_date.observation.last(),
                  followup = furrr::future_pmap(list(duration, unit),
                                                ~ lubridate::duration(..1, units = ..2))
    ) -> output

  output$followup <- do.call("c", output$followup) ## Workaround tidyr::unnest(followup) which is way too slow

  output %>%
    dplyr::mutate(left_censored = .data$birthdate < .data$date_firstsighting,
                  right_censored = .data$birthdate + .data$followup > .data$date_lastsighting, ## not compared to death (this is important!)
                  ## so perhaps calling that right_censored is misleading
                  observable = !.data$left_censored & !.data$right_censored) -> output

  if (debug) {
    return(output)
  }

  output$observable
}


#' @describeIn fetch_family fetch if the focal individual(s) have selected given clan(s) at given date(s).
#' @export
#'
#' @examples
#'
#'
#' #### Simple example of fetch_id_is.selector usage:
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"))
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040" ),
#'                      clan = c("A", "A", "A") ,
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error.margin.selection = "30 days")
#' fetch_id_is.selector(ID = c("A-040", "A-040", "A-040"),
#'                      clan = c("A", "A", "A"),
#'                      at = c("1996-07-10", "1996-07-12", "1996-04-13"),
#'                      error.margin.selection = "90 days")

fetch_id_is.selector <- function(ID, clan, at, error.margin.selection = "0 days", debug = FALSE){

  input <- tibble::tibble(ID = check_function_arg.ID(ID), clan = check_function_arg.clan(clan), date = check_function_arg.date(at))
  error.margin.selection <- check_function_arg.period(error.margin.selection)

  life_history <- create_id_life.history.table(unique(ID), censored.to.last.sighting = FALSE) %>%
    dplyr::filter(.data$life_stage != "dead")

  dplyr::left_join(relationship = "many-to-many", input, life_history, by = c("ID", "clan")) %>%
    dplyr::mutate(
      starting_date_approx = .data$starting_date - !!error.margin.selection,
      ending_date_approx = .data$ending_date + !!error.margin.selection,
      overlap = .data$date >= .data$starting_date_approx & .data$date <= .data$ending_date_approx,
      is_selector = .data$overlap & !(.data$life_stage %in% c("cub", "subadult", "natal", "transient", "unknown")),
      death_confirmed = fetch_id_is.death.confirmed(.data$ID),
      deathdate = fetch_id_date.death(.data$ID),
      # if really dead, then it is not a selector:
      is_selector = ifelse(.data$death_confirmed & .data$date > .data$deathdate, FALSE, .data$is_selector))  -> output

  if (debug) {
    return(output)
  }

  output %>%
    dplyr::group_by(.data$ID, .data$clan, .data$date) %>%
    dplyr::summarise(is_selector = any(.data$is_selector)) %>%
    dplyr::left_join(relationship = "many-to-many", input, ., by = c("ID", "clan", "date")) -> output2

  output2$is_selector
}


#' @describeIn fetch_family fetch if individuals could have been observed on
#'   a given date.
#'
#'   The functions simply check if a given date falls between the first and the
#'   last sighting. It does not consider any other complexity, such as if
#'   someone was actually in the field at this particular date.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.observed usage:
#'fetch_id_is.observed(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-07-01"))

fetch_id_is.observed <- function(ID, at, debug = FALSE) {
  input <- dplyr::tibble(ID = ID, date = as.Date(at))

  input %>%
    dplyr::mutate(
      first_obs_date = fetch_id_date.observation.first(ID = ID),
      last_obs_date = fetch_id_date.observation.last(ID = ID),
      obs = (date >= .data$first_obs_date) & (date <= .data$last_obs_date)
    ) -> output
  ## Note: we do not use between() because it is not a fully vectorized function.

  if (debug) {
    return(output)
  }

  output$obs
}

#' @describeIn fetch_family fetch if a given hyena is pregnant
#'
#' @export
#' @return For females, returns logical. For males, returns NA.
#' @examples
#'
#' #### Simple example of fetch_id_is.pregnant usage:
#' #### A-001 is pregnant in late 1996 but not early 1996
#' #### A-011 is male and returns NA
#' fetch_id_is.pregnant(ID = c("A-001", "A-001", "A-011"),
#'                      at = c("1996-01-01", "1996-12-01", "1996-01-01"))

fetch_id_is.pregnant <- function(ID, at, debug = FALSE) {

  input <- tibble::tibble(ID = check_function_arg.ID(ID),
                          at = check_function_arg.date(at))

  #Identify females.
  input %>%
    dplyr::filter(!is.na(.data$ID)) %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID)) %>%
    #Males will always return NA for is.pregnant so can be ignored
    #Individuals with unknown sex could be pregnant (we can't rule it out)
    dplyr::filter(is.na(.data$sex) | .data$sex == "female") -> females

  if (nrow(females) == 0) {

    message("Cannot calculate pregnancy for males or unknown individuals. Returning NA.")

    input %>%
      dplyr::mutate(is.pregnant = NA) -> debug_output

  } else {

    #Return litters for all unique females
    create_litter_starting.table(unique(females$ID)) %>%
      dplyr::mutate(birth_date = fetch_litter_date.birth(.data$litterID),
                    conception_date = .data$birth_date - lubridate::days(110L)) -> litters

    input %>%
      dplyr::left_join(relationship = "many-to-many", litters, by = c("ID" = "parentID")) %>%
      dplyr::mutate(is.pregnant = .data$at >= .data$conception_date & .data$at < .data$birth_date) -> debug_output

  }

  if (debug) return(debug_output)

  debug_output %>%
    dplyr::group_by(.data$ID, .data$at) %>%
    dplyr::summarise(is.pregnant = any(.data$is.pregnant), .groups = "drop") -> output

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = c("ID", "at"),
                        duplicates = "input",
                        debug = debug) -> output

  output$is.pregnant

}


#' @describeIn fetch_family fetch the last date at which a given individual has been observed.
#'
#'   The functions simply check retrieve the last sighting from the sighting table.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_date.observation.last usage:
#' fetch_id_date.observation.last(ID = c("A-080", "L-012"))
fetch_id_date.observation.last <- function(ID, debug = FALSE) {
  input <- dplyr::tibble(ID = check_function_arg.ID(ID))

  extract_database_table(tbl.names = "sightings") %>%
    dplyr::mutate(sighting_date = recode_x_date(.data$date_time)) -> sightings

  input %>%
    dplyr::distinct() %>%
    dplyr::left_join(relationship = "many-to-many", sightings, by = "ID") %>%
    dplyr::select("ID", "sighting_date") %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(last_obs_date = find_vector_max(.data$sighting_date, keep.class = FALSE)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(last_obs_date = as.Date(.data$last_obs_date)) -> output

  ## Note (Alex, 2020/06/19) to handle NAs such as produced by A-100 in the dummy data we need to avoid
  ## having NA of class Date within the summarise call. For some reason it makes dplyr crash.
  ## This is why we coerce at the end

  check_function_output(input.tbl = input,
                        output.tbl = output,
                        join.by = "ID",
                        duplicates = "input",
                        output.IDcolumn = "last_obs_date",
                        debug = debug)

}


#' @describeIn fetch_family fetch the lifespan of a given hyena at its death.
#' @export
#' @examples
#'
#' ################### examples for fetch_xx functions ###################
#'
#'
#' #### Detailed example of fetch_id_duration.lifespan usage:
#' ### note: what is shown here also applies to all other fetch_xx_yy functions
#'
#' ### fetch the lifespan of all individuals:
#' fetch_id_duration.lifespan(ID = find_pop_id())
#'
#' ### fetch the lifespan of two individuals:
#' fetch_id_duration.lifespan(ID = c("A-007", "A-043"))

fetch_id_duration.lifespan <- function(ID, unit = "year", debug = FALSE) {
  input <- dplyr::tibble(ID = ID)

  hyenas <- extract_database_table(tbl.names = "hyenas")
  deaths <- extract_database_table(tbl.names = "deaths")

  input %>%
    dplyr::left_join(relationship = "many-to-many", hyenas, by = "ID") %>%
    dplyr::left_join(relationship = "many-to-many", deaths, by = "ID") %>%
    dplyr::select("ID", "birthdate", "deathdate") %>%
    dplyr::mutate(lifespan = lubridate::interval(.data$birthdate, .data$deathdate) / lubridate::duration(1, units = check_function_arg.unit(unit))) -> output

  if (debug) {
    return(output)
  }

  output$lifespan
}


#' @describeIn fetch_family fetch the life stage of given individual(s) on given date(s).
#' @export
#' @examples
#'
#'
#' #### Simple example of fetch_id_lifestage usage:
#' fetch_id_lifestage(ID = c("A-001"), at = c("1997-01-01"))

fetch_id_lifestage <- function(ID, at, debug = FALSE) {

  input_full <- dplyr::tibble(ID = check_function_arg.ID(ID),
                              date = check_function_arg.date(at))
  input <-  unique(input_full)

  ## reduce to unique case for speed up:
  life_history <- create_id_life.history.table(unique(ID), censored.to.last.sighting = FALSE) ## or v(unique(ID))

  dplyr::left_join(relationship = "many-to-many", input, life_history, by = "ID") %>%
    dplyr::filter(.data$date >= .data$starting_date  &
                    (.data$date <= .data$ending_date | is.na(.data$ending_date))) -> life_stage

  ## left joins will return NA for unmatched dates
  check_function_output(input.tbl = input_full, duplicates = "input", output.tbl = life_stage,
                        join.by = c("ID", "date"),
                        output.IDcolumn = "life_stage", debug = debug)
}



#' @describeIn fetch_family fetch the ID of the dominance status in the litter of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.litter usage:
#' fetch_id_rank.litter(ID = c("A-018", "A-046"))
fetch_id_rank.litter <- function(ID) {
  fetch_database_column(column = "litterdominance", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the genetic mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.genetic usage:
#' fetch_id_id.mother.genetic(ID = c("A-080", "L-012"))
fetch_id_id.mother.genetic <- function(ID) {
  fetch_database_column(column = "mothergenetic", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the ID of the social mother of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mother.social usage:
#' fetch_id_id.mother.social(ID = c("A-080", "L-012"))
fetch_id_id.mother.social <- function(ID) {
  fetch_database_column(column = "mothersocial", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the social rank within native for a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.native usage:
#' fetch_id_rank.native(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))
fetch_id_rank.native <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$nat_rank))) output %>% dplyr::mutate(nat_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank
}


#' @describeIn fetch_family fetch the standardised social rank within native for a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.native usage:
#' fetch_id_rank.native.std(ID = c("A-001", "A-002"), at = c("1997-01-04", "1996-06-30"))
fetch_id_rank.native.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$nat_rank_std))) output %>% dplyr::mutate(nat_rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$nat_rank_std
}


#' @describeIn fetch_family fetch the social rank of a given individual on a
#'   given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank usage:
#' fetch_id_rank(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank <- function(ID, at, debug = FALSE) {

  if (is.null(ID) || is.null(at)) {
    return(NULL)
  }
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$rank))) output %>% dplyr::mutate(rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on
#'   a given date.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.std usage
#' fetch_id_rank.std(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.std <- function(ID, at, debug = FALSE) {

  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$rank_std))) output %>% dplyr::mutate(rank_std = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$rank_std

}


#' @describeIn fetch_family fetch the social rank of a given individual on a given date within males
#'   that selected their clan.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retrieve such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.selector.male usage:
#' fetch_id_rank.selector.male(ID = c("A-080", "L-012"),
#'                             at = c("1997-01-04", "1996-06-30")) ## TODO: change ID
fetch_id_rank.selector.male <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$sel_rank))) {
    output %>% dplyr::mutate(sel_rank = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank
}


#' @describeIn fetch_family fetch the standardized social rank of a given individual on a given date
#'   within males that selected their clan.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retrieve such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.selector.male.std usage:
#' fetch_id_rank.selector.male.std(ID = c("A-001", "A-002"),
#'                                 at = c("1997-01-04", "1996-06-30"))  ## TODO: change ID
fetch_id_rank.selector.male.std <- function(ID, at, debug = FALSE) {
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$sel_rank_std))) {
    output %>% dplyr::mutate(sel_rank_std = NA_real_) -> output
  }

  if (debug) {
    return(output)
  }

  output$sel_rank_std
}


#' @describeIn fetch_family fetch the social rank of a given individual on a
#'   given date compared to the native adult individuals in the clan.
#'
#'   See [create_rank_python.table] for details on the lower level function used to retreive such information.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_rank.native.adult usage:
#' fetch_id_rank.native.adult(ID = c("A-080", "L-012"), at = c("1997-01-04", "1996-06-30"))

fetch_id_rank.native.adult <- function(ID, at, debug = FALSE) {

  if (is.null(ID) || is.null(at)) {
    return(NULL)
  }
  output <- create_id_rank.table(ID = ID, at = at)

  if (suppressWarnings(is.null(output$adnat_rank))) output %>% dplyr::mutate(adnat_rank = NA_real_) -> output

  if (debug) {
    return(output)
  }

  output$adnat_rank
}


#' @describeIn fetch_family fetch the sex of a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_sex usage:
#' fetch_id_sex(ID = c("A-001", "A-007"))
fetch_id_sex <- function(ID) {
  ID <-  check_function_arg.ID(ID)
  fetch_database_column("sex", tbl.name = "hyenas", ID = ID)
}


#' @describeIn fetch_family fetch the tenure duration a given hyena.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_duration.tenure usage:
#' fetch_id_duration.tenure(ID = c("A-011", "A-040"), at = "1997-12-30") ## TODO change ID and date
fetch_id_duration.tenure <- function(ID, at, unit = "year", debug = FALSE) {


  ID <-  check_function_arg.ID(ID)
  at <-  check_function_arg.date(at)
  input <- tibble::tibble(ID, at)

  create_id_life.history.table(ID = unique(ID), censored.to.last.sighting = FALSE) %>%
    dplyr::mutate(sex = fetch_id_sex(.data$ID)) %>%
    # add date of interest in the life history table
    # use unique in order to avoid creating duplicated rows
    dplyr::left_join(relationship = "many-to-many", x = ., y = unique(input), by = "ID") %>%
    # for non-selectors and cases when focal date does not fall into the tenureship in a clan, returns NA
    dplyr::filter(.data$at >= .data$starting_date & .data$at <= .data$ending_date & !(.data$life_stage %in% c("cub", "subadult", "natal", "transient", "unknown", "dead"))) %>%
    dplyr::mutate(tenure = as.numeric(lubridate::interval(.data$starting_date, .data$at) / lubridate::duration(1, units = check_function_arg.unit(unit)))) -> output

  output <- check_function_output(input.tbl = input,
                                  output.tbl = output,
                                  join.by = c("ID", "at"),
                                  duplicates = "input",
                                  output.IDcolumn = "tenure",
                                  debug = debug)
  output
}


#' @describeIn fetch_family fetch if the individuals are genetically typed
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_is.sampled.dna usage:
#' fetch_id_is.sampled.dna(c("A-003", "A-002"))

fetch_id_is.sampled.dna <- function(ID) {
  ID <- check_function_arg.ID(ID)
  dna <- fetch_database_column(column = "DNA", tbl.name = "hyenas", ID = ID)
  as.logical(dna) ## should be already reading TRUE/FALSE
}


#' @describeIn fetch_family fetch whether the second argument is offspring of the first argument, according
#' to the filiation argument.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad_is.offspring usage:
#' fetch_dyad_is.offspring(ID = c("A-001", "A-001"), offspringID = c("A-010", "A-049"))
#'
fetch_dyad_is.offspring <- function(ID, offspringID, filiation = c("mother_genetic", "mother_social_genetic", "father"), debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  offspringID <- check_function_arg.ID(offspringID, argument.name = 'offspringID')
  filiation <- check_function_arg.filiation(filiation)
  input <- tibble::tibble(parentID = ID, offspringID = offspringID)

  ## Note: we do note account for offspring that would have missing filiation (but that should probably not exist)
  create_id_offspring.table(unique(ID)) %>%
    dplyr::filter(.data$filiation %in% !!filiation | is.na(.data$filiation)) -> real_offspring

  input %>%
    dplyr::left_join(relationship = "many-to-many", real_offspring, by = c("parentID", "offspringID")) %>%
    dplyr::mutate(is_offspring = ifelse(!is.na(.data$filiation), TRUE, FALSE)) -> output

  if (debug) return(output)

  output$is_offspring
}

#' @describeIn fetch_family fetch the type of filiation between the first argument and the second one.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_dyad_filiation usage:
#' fetch_dyad_filiation(parentID = c("A-001", "A-001"), offspringID = c("A-010", "A-049"))
#'
fetch_dyad_filiation <- function(parentID, offspringID, debug = FALSE) {
  parentID <- check_function_arg.ID(parentID, argument.name = 'parentID')
  offspringID <- check_function_arg.ID(offspringID, argument.name = 'offspringID')
  input <- tibble::tibble(parentID = parentID, offspringID = offspringID)

  offspring_table <- create_id_offspring.table(unique(parentID))

  input %>%
    dplyr::left_join(relationship = "many-to-many", offspring_table, by = c("parentID", "offspringID")) -> output

  if (debug) return(output)

  output$filiation

}


#' @describeIn fetch_family fetch the litterID of the given IDs according to filiation argument. If filiation is 'mother_genetic'
#' the function will retrieve the genetic litter. If filiation is 'mother_social' the function will retrieve the social litters
#' where cubs have been adopted. If the cub has never been adopted and filiation is 'mother_social' the function will return NA.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_litterID usage:
#'fetch_id_litterID(ID = c("A-010", "A-049"))
#' fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_social")
#' fetch_id_litterID(ID = "A-054")
#'
fetch_id_litterID <- function(ID, filiation = "mother_genetic", debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation)
  ## The function accepts only 'mother_genetic' and 'mother_social'
  if (!(filiation %in% c("mother_genetic", "mother_social"))) stop("The function works only with 'mother_genetic' or 'mother_social'. 'mother_social_genetic' in this case is included in 'mother_genetic")
  offspring <- tibble::tibble(offspringID = ID)

  if (filiation ==  "mother_genetic") {
    ## We keep only the genetic mothers to retrieve the genetic litters.
    offspring %>%
      dplyr::mutate(mother = fetch_id_id.mother.genetic(.data$offspringID)) -> mother.offspring
    ## create_offspring_litterID.from.mother is based on create_id_offspring.table that returns all
    ## offsprings, both genetic and social. A cub could then a duplicate in the output.tbl, because genetic
    ## offspring of a female in 'mother' column but also social offspring of another female in 'mother' column.
    ## To avoid this we filter the correct filiation.
    create_offspring_litterID.from.mother(unique(mother.offspring$mother)) %>%
      dplyr::filter(.data$filiation %in% c("mother_genetic", "mother_social_genetic")) -> litters.mother
  } else {
    offspring %>%
      ## We keep only the social mothers who adopted for real the offspring to retrieve the social litters.
      dplyr::mutate(motherID = fetch_id_id.mother.social(.data$offspringID),
                    gen.mumID = fetch_id_id.mother.genetic(.data$offspringID)) %>%
      dplyr::filter(.data$gen.mumID != .data$motherID) %>%
      dplyr::select("offspringID", "motherID") -> mother.offspring
    create_offspring_litterID.from.mother(unique(mother.offspring$motherID)) %>%
      dplyr::filter(.data$filiation == "mother_social") -> litters.mother
  }

  check_function_output(input.tbl = offspring, output.tbl = litters.mother, join.by = "offspringID",
                        duplicates = "input", output.IDcolumn = "litterID", debug = debug)
}

#' @describeIn fetch_family fetch the litter type for each given litter. Each litter is defined by a combination of letter,
#' (f = female, m = male, u = cub with unknown sex, preceded from 's' if the cub is social).
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_litter.type usage:
#' fetch_litter_litter.type(litterID = "A-001_003")
#'
fetch_litter_litter.type <- function(litterID, debug = FALSE)  {

  litterID <- check_function_arg.litter.ID(litterID)

  create_litter_offspring.count(litterID) %>%
    dplyr::mutate(type = recode_offspring.sex_litter.type(.data$female,
                                                          .data$male,
                                                          .data$unknown,
                                                          .data$social.female,
                                                          .data$social.male,
                                                          .data$social.unknown)) -> output

  if (debug) return(output)

  output$type

}

#' @describeIn fetch_family fetch if at least one member of the litter is genetically typed.
#'
#' @export
#' @examples
#'
#'#### Simple example of fetch_litter_is.sampled.dna usage:
#' fetch_litter_is.sampled.dna(litterID = c("A-001_003", "A-001_001", "A-001_003"))
#'
fetch_litter_is.sampled.dna <- function(litterID, debug = FALSE) {
  parentID <- unique(substr(litterID, 1, 5))
  litter <- tibble::tibble(litterID = litterID)
  all.litters <- create_offspring_litterID.from.all(unique(parentID))
  litter %>%
    dplyr::left_join(relationship = "many-to-many", all.litters, by = "litterID") %>%
    dplyr::select("offspringID", "litterID", "filiation") %>%
    dplyr::mutate(dna = fetch_id_is.sampled.dna(.data$offspringID)) %>%
    dplyr::group_by(.data$litterID) %>%
    dplyr::mutate(litter_dna = any(.data$dna)) %>%
    dplyr::ungroup() %>%
    dplyr::select("litterID", "litter_dna") %>%
    dplyr::distinct() %>%
    dplyr::ungroup() -> output_distinct

  litter %>%
    dplyr::left_join(relationship = "many-to-many", output_distinct) -> output
  if (debug) return(output)
  output$litter_dna
}


#' @describeIn fetch_family fetch whether individuals have produced any offspring.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_has.reproduced usage:
#' fetch_id_has.reproduced(ID = c("A-001", "A-007"))
fetch_id_has.reproduced <- function(ID, from = NULL, to = NULL, at = NULL, first.event = "birthdate", debug = FALSE) {

  ## Note: we do not check the arguments, since they are checked in the following call.
  fetch_id_number.offspring(ID = ID, from = from, to = to, at = at, first.event = first.event) > 0 -> output

  if (debug) {

    return(output)

  }

  output

}

#' @describeIn fetch_family fetch whether individuals have produced a twin litter.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_had.twins usage:
#' fetch_id_has.twin.litter(ID = c("A-001", "A-007"))
fetch_id_has.twin.litter <- function(ID, from = NULL, to = NULL, at = NULL,
                                     .fill = TRUE, first.event = "birthdate", debug = FALSE) {

  ## This function is somewhat redundant with create_littertable_count;
  ## however, create_littertable_count has no option to filter
  ## by date (from, to, at), which is needed for determining
  ## reproductive success over a given time scale

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ID         <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 .fill = .fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(parentID = ID,
                         from = from, to = to)

  unique_input <- input %>%
    dplyr::distinct()

  create_offspring_litterID.from.all(unique(ID)) %>%
    dplyr::left_join(relationship = "many-to-many", ., unique_input, by = "parentID") %>% #Join in from/to to allow for a vector of different from/to dates
    dplyr::filter(.data$birthdate >= .data$from & .data$birthdate <= .data$to) %>%
    dplyr::group_by(.data$parentID, .data$from, .data$to, .data$litterID) %>%
    dplyr::summarise(litter_size = dplyr::n(), .groups = "drop_last") %>% # Find litter size for each litter
    dplyr::summarise(twin = any(!is.na(.data$litterID) & .data$litter_size > 1)) -> output_raw

  check_function_output(input, output_raw, join.by = c("parentID", "from", "to"),
                        debug = debug, duplicates = "input", output.IDcolumn = "twin")

}

#' @describeIn fetch_family fetch the adult sex ratio (female/all adults) in a clan at a given
#'   date.
#' @export
#' @examples
#' fetch_clan_sex.ratio.adult(clan = "A", at = "1996/01/01")
fetch_clan_sex.ratio.adult <- function(clan = NULL, at, debug = FALSE) {

  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         date = check_function_arg.date(at))

  input %>%
    dplyr::mutate(nradultmale = fetch_clan_number.male.adult(clan = .data$clan, at = .data$date),
                  nradult = fetch_clan_number.anysex.adult(clan = .data$clan, at = .data$date),
                  sexratio = .data$nradultmale/.data$nradult) -> output

  if (debug) {

    return(output)

  }

  if (any(output$nradult == 0)) {

    message("Some clans have no adults on the given date. These will return a sex ratio 'NA'")

  }

  output$sexratio

}

#' @describeIn fetch_family fetch the adult sex ratio (female/all adults) in the whole population
#' at a given date.
#' @export
#' @examples
#' fetch_pop_sex.ratio.adult(at = "1996/01/01")
fetch_pop_sex.ratio.adult <- function(at, main.clans = TRUE, debug = FALSE) {

  input <- dplyr::tibble(date = check_function_arg.date(at))
  clans <- find_clan_name.all(main.clans = main.clans)

  combos <- expand.grid(date = unique(input$date), clan = clans, stringsAsFactors = FALSE)

  # Need to call `fetch_clan` with debug because we can't determine pop ratio from clan ratios
  fetch_clan_sex.ratio.adult(clan = combos$clan, at = combos$date, debug = TRUE) %>%
    dplyr::group_by(.data$date) %>%
    dplyr::summarise(nradultmale = sum(.data$nradultmale),
                     nradult = sum(.data$nradult),
                     sexratio = .data$nradultmale/.data$nradult) %>%
    dplyr::left_join(relationship = "many-to-many", input, ., by = "date") -> output

  if (debug) {

    return(output)

  }

  output$sexratio

}

#' @describeIn fetch_family fetch the age ratio (adult/clan size) in a clan at a given
#'   date.
#' @export
#' @examples
#' fetch_clan_adult.ratio(clan = "A", at = "1996/01/01")
fetch_clan_adult.ratio <- function(clan = NULL, at, debug = FALSE) {

  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         date = check_function_arg.date(at))

  input %>%
    dplyr::mutate(nradult = fetch_clan_number.anysex.adult(clan = .data$clan, at = .data$date),
                  nrindv = fetch_clan_number.anysex.all(clan = .data$clan, at = .data$date),
                  ageratio = .data$nradult/.data$nrindv) -> output

  if (debug) {

    return(output)

  }

  if (any(output$nrindv == 0)) {

    message("Some clans have no individuals on the given date. These will return an age ratio 'NA'")

  }

  output$ageratio

}

#' @describeIn fetch_family fetch the age ratio (adult/clan size) in the whole population
#' at a given date.
#' @export
#' @examples
#' fetch_pop_adult.ratio(at = "1996/01/01")
fetch_pop_adult.ratio <- function(at, main.clans = TRUE, debug = FALSE) {

  input <- dplyr::tibble(date = check_function_arg.date(at))
  clans <- find_clan_name.all(main.clans = main.clans)

  combos <- expand.grid(date = unique(input$date), clan = clans, stringsAsFactors = FALSE)

  # Need to call `fetch_clan` with debug because we can't determine pop ratio from clan ratios
  fetch_clan_adult.ratio(clan = combos$clan, at = combos$date, debug = TRUE) %>%
    dplyr::group_by(.data$date) %>%
    dplyr::summarise(nradult = sum(.data$nradult),
                     nrindv = sum(.data$nrindv),
                     ageratio = .data$nradult/.data$nrindv) %>%
    dplyr::left_join(relationship = "many-to-many", input, ., by = "date") -> output

  if (debug) {

    return(output)

  }

  output$ageratio

}

#' @describeIn fetch_family fetch if the individuals are adults at a given date
#' @export
#' @examples
#'
#'#### Simple example of fetch_id_is.adult usage:
#' fetch_id_is.adult(ID = c("A-003", "A-002"), at = "1997-01-01")
#'
fetch_id_is.adult <- function(ID, at, debug = FALSE) {

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         date = check_function_arg.date(at)) %>%
    dplyr::mutate(isalive = fetch_id_is.alive(ID = .data$ID, at = .data$date))

  if (!all(input$isalive)) {

    #Do we want this to be a warning or an error?
    warning("Some individuals were not alive at this date. These individuals will return NA")

  }

  input %>%
    dplyr::mutate(age = fetch_id_age(ID = .data$ID, at = .data$date),
                  isadult = .data$age > 2) -> output

  if (debug) {
    return(output)
  }

  output$isadult

}

#' @describeIn fetch_family fetch whether individuals are left/right or both censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored usage:
#' fetch_id_is.censored(ID = c("A-001", "A-007"), censored.left = TRUE, censored.right = FALSE)
#' fetch_id_is.censored(ID = c("A-001", "A-007"), from = "1980-03-04", to = "1988-07-09")
fetch_id_is.censored <- function(ID, censored.left = TRUE, censored.right = TRUE,
                                 from = find_pop_date.observation.first(), to = find_pop_date.observation.last(), debug = FALSE) {
  if (censored.left == FALSE & censored.right == FALSE) {
    stop("'censored.left' and 'censored.right' arguments are both FALSE, so no ID can possibly censored under this setting. You must set at least one argument to TRUE.")
  }
  ID <- check_function_arg.ID(ID)
  from <- check_function_arg.date(from)
  to <- check_function_arg.date(to)

  dates.ID <- tibble::tibble(ID = ID,
                             from = from,
                             to = to,
                             #Check alive 1 day before
                             #This ensures that individuals born on from date are not considered censored
                             alive.from = fetch_id_is.alive(ID, at = from - lubridate::days(1)),
                             alive.to = fetch_id_is.alive(ID, at = to))
  dates.ID %>%
    dplyr::mutate(is.censored = dplyr::case_when(censored.left == TRUE & is.na(.data$from) ~ NA,
                                                 censored.right == TRUE & is.na(.data$to) ~ NA,
                                                 censored.left == TRUE & .data$alive.from ~ TRUE,
                                                 censored.right == TRUE & .data$alive.to ~ TRUE,
                                                 .default = FALSE)) -> censored.ID
  if (debug) return(censored.ID)
  censored.ID$is.censored
}


#' @describeIn fetch_family fetch whether individuals are right-censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored.left usage:
#' fetch_id_is.censored.left(ID = c("A-001", "A-007"))
#' fetch_id_is.censored.left(ID = c("A-001", "A-007"), at = "1980-03-04")
#'
fetch_id_is.censored.left <- function(ID, at = find_pop_date.observation.first(), debug = FALSE) {
  fetch_id_is.censored(ID, from = at, censored.left = TRUE, censored.right = FALSE, debug = debug)
}


#' @describeIn fetch_family fetch whether individuals are left-censored.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.censored.right usage:
#' fetch_id_is.censored.right(ID = c("A-001", "A-007"))
#' fetch_id_is.censored.right(ID = c("A-001", "A-007"), at = "1980-03-04")
#'
fetch_id_is.censored.right <- function(ID, at = find_pop_date.observation.last(), debug = FALSE) {
  fetch_id_is.censored(ID, to = at, censored.left = FALSE, censored.right = TRUE, debug = debug)
}


#' @describeIn fetch_family fetch the birthday of a given litter.
#' @export
#' @examples
#'
#' #### Simple example of fetch_litter_date.birth usage:
#' fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
fetch_litter_date.birth <- function(litterID, debug = FALSE) {
  litterID <- check_function_arg.litter.ID(litterID)
  litter.table <- tibble::tibble(litterID = litterID)
  parentID <- substring(litterID, first = 1, last = 5)

  create_offspring_litterID.from.all(parentID = unique(parentID)) %>%
    dplyr::group_by(litterID) %>%
    dplyr::mutate(n.cubs = dplyr::n(),
                  n.birthdates = length(unique(.data$birthdate)),
                  any.genetic = any(.data$filiation %in% c("mother_social_genetic", "mother_genetic")),
                  not.genetic.sibs = !.data$any.genetic & .data$n.cubs > 1 & .data$n.birthdates > 1,
                  anygenetic_bday = .data$birthdate[.data$filiation %in% c("mother_social_genetic", "mother_genetic")][1],
                  notgenetic_bday = min(.data$birthdate)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(litter.birthdate = dplyr::case_when(.data$any.genetic ~ .data$anygenetic_bday,
                                                      .data$not.genetic.sibs ~ .data$notgenetic_bday,
                                                      .default = .data$birthdate)) %>%
    dplyr::distinct(.data$litterID, .data$litter.birthdate, .keep_all = TRUE) -> litter_birthdate

  if (any(litter_birthdate$not.genetic.sibs)) message("Some litters contained only social cubs born at different dates. For those 'fetch_litter_date.birth()' returned the birth date of the oldest cub.")

  litter.table %>%
    dplyr::left_join(relationship = "many-to-many", litter_birthdate, by = "litterID") -> output

  if (debug) return(output)

  output$litter.birthdate
}


#' @describeIn fetch_family fetch the sighting tables for individuals (similar to `create_sighting_starting.table()` but can work with multiple from/to/at).
#'
#' `ID`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_sighting.table usage:
#' fetch_id_sighting.table(ID = c("A-001", "A-007"))
#'
fetch_id_sighting.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                    .fill = TRUE, first.event = "observation",
                                    include.conception = FALSE,
                                    include.na = TRUE,
                                    debug = FALSE) {

  ## TODO: what comes next should be done within check_function_arg.date.fromtoat() and made available to any function using from/to/at
  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 .fill = .fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(ID = check_function_arg.ID(ID),
                         from = from, to = to)

  input %>%
    dplyr::distinct() %>%
    dplyr::group_by(from, to) %>%
    dplyr::summarise(all_indv = list(ID)) -> unique_input #Save us from calling create_sighting_starting.table() redundantly

  purrr::pmap_df(.l = unique_input,
                 .f = function(all_indv, from, to){
                   create_sighting_starting.table(ID = all_indv, from = from, to = to,
                                                  include.conception = include.conception,
                                                  include.na = include.na) %>%
                     dplyr::mutate(from = from, to = to)
                 }) %>%
    dplyr::group_nest(.data$ID, .data$from, .data$to, keep = TRUE) -> output

  job <- check_function_output(input.tbl = input, output.tbl = output,
                               join.by = c("ID", "from", "to"),
                               duplicates = "input", output.IDcolumn = "data", debug = debug)

  ## replace NULL by empty tables:
  for (i in seq_along(job)) {
    if (is.null(job[[i]])) {
      job[[i]] <-  tibble::tibble()
    }
  }

  names(job) <- input$ID
  job
}


#' @describeIn fetch_family fetch the sighting tables for clans.
#'
#' `clan`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_sighting.table usage:
#' fetch_clan_sighting.table(clan = "A", from = c("1996/01/01", "1997/01/01"))
#'
fetch_clan_sighting.table <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                      at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      .fill = TRUE, first.event = "observation",
                                      include.conception = FALSE,
                                      include.na = TRUE,
                                      debug = FALSE) {

  ## TODO: what comes next should be done within check_function_arg.date.fromtoat() and made available to any function using from/to/at
  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 .fill = .fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  input <- dplyr::tibble(clan = check_function_arg.clan(clan),
                         from = from,
                         to = to)

  input %>%
    dplyr::distinct() -> unique_input #Save us from calling create_sighting_starting.table() redundantly

  purrr::pmap_df(.l = unique_input,
                 .f = function(clan, from, to){
                   all_indv <- find_clan_id(clan = clan, sex = sex, lifestage = lifestage,
                                            at = at, from = from, to = to,
                                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                            verbose = FALSE)
                   create_sighting_starting.table(ID = all_indv, from = from, to = to,
                                                  include.conception = include.conception,
                                                  include.na = include.na) %>%
                     dplyr::mutate(clan = clan, from = from, to = to)
                 }) %>%
    dplyr::group_nest(.data$clan, .data$from, .data$to, keep = TRUE) -> output

  job <- check_function_output(input.tbl = input, output.tbl = output,
                               join.by = c("clan", "from", "to"),
                               duplicates = "input", output.IDcolumn = "data", debug = debug)

  ## replace NULL by empty tables:
  for (i in seq_along(job)) {
    if (is.null(job[[i]])) {
      job[[i]] <-  tibble::tibble()
    }
  }

  names(job) <- input$clan
  job
}


#' @describeIn fetch_family fetch the sighting points for individuals.
#'
#' `ID`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_sighting.point usage:
#' fetch_id_sighting.point(ID = c("A-001", "A-007"))
#'
fetch_id_sighting.point <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                    .fill = TRUE, first.event = "observation",
                                    include.conception = FALSE,
                                    debug = FALSE,
                                    crs = 4326) {

  #Check using legit CRS
  crs <- load_package_crs()

  list_sightings <- fetch_id_sighting.table(ID = ID, from = from, to = to, at = at,
                                            .fill = .fill, first.event = first.event,
                                            include.conception = include.conception,
                                            #Sightings with no lat/long are unusable here
                                            include.na = FALSE,
                                            debug = debug)

  list_sightings <- purrr::map(list_sightings,
                               ~{
                                 #If we have data with alternative crs...
                                 if (nrow(.x) > 1 & crs != 4326) {
                                   dplyr::bind_cols(.x, recode_df_sf(.x, crs = crs) %>%
                                                      sf::st_coordinates() %>%
                                                      dplyr::as_tibble())
                                   #When crs is standard (or df is empty) just convert col names
                                 } else {
                                   .x %>%
                                     dplyr::rename(X = "longitude", Y = "latitude")
                                 }

                               })

  output <- purrr::map(list_sightings, ~ if (nrow(.x) > 0) {sf::st_multipoint(cbind(.x$X, .x$Y))} else sf::st_multipoint())
  sf::st_sfc(output, crs = crs)
}


#' @describeIn fetch_family fetch the sighting points for clans.
#'
#' `clan`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_sighting.point usage:
#' fetch_clan_sighting.point(clan = "A", from = c("1996/01/01", "1997/01/01"))
#'
fetch_clan_sighting.point <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                      at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      .fill = TRUE, first.event = "observation",
                                      include.conception = FALSE,
                                      debug = FALSE) {

  #Check using legit CRS
  crs <- load_package_crs()

  list_sightings <- fetch_clan_sighting.table(clan = clan, sex = sex, lifestage = lifestage,
                                              at = at, from = from, to = to,
                                              clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                              .fill = .fill, first.event = first.event,
                                              include.conception = include.conception,
                                              #Sightings without lat/long are unusable
                                              include.na = FALSE,
                                              debug = debug)

  list_sightings <- purrr::map(list_sightings,
                               ~{
                                 #If we have data with alternative crs...
                                 if (nrow(.x) > 1 & crs != sf::st_crs(4326)) {
                                   dplyr::bind_cols(.x, recode_df_sf(.x, crs = crs) %>%
                                                      sf::st_coordinates() %>%
                                                      dplyr::as_tibble())
                                   #When crs is standard (or df is empty) just convert col names
                                 } else {
                                   .x %>%
                                     dplyr::rename(X = "longitude", Y = "latitude")
                                 }

                               })

  output <- purrr::map(list_sightings, ~ if (nrow(.x) > 0) {sf::st_multipoint(cbind(.x$X, .x$Y))} else sf::st_multipoint())
  sf::st_sfc(output, crs = crs)
}


#' @describeIn fetch_family fetch how many times individual(s) are sighted.
#'
#' `ID`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_number.sighting usage:
#' fetch_id_number.sighting(ID = c("A-001", "A-007"))
#'
fetch_id_number.sighting <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                     .fill = TRUE, first.event = "observation",
                                     include.conception = FALSE,
                                     include.na = TRUE,
                                     debug = FALSE) {

  list_sightings <- fetch_id_sighting.table(ID = ID, from = from, to = to, at = at,
                                            .fill = .fill, first.event = first.event,
                                            include.conception = include.conception,
                                            #In this case, we might want to count sightings
                                            #without lat/long
                                            include.na = include.na,
                                            debug = debug)

  unlist(lapply(list_sightings, nrow))
}


#' @describeIn fetch_family fetch how many sightings there is within clan(s).
#'
#' `clan`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_number.sighting usage:
#' fetch_clan_number.sighting(clan = c("A", "L"))
#'
fetch_clan_number.sighting <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                       at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       .fill = TRUE, first.event = "observation",
                                       include.conception = FALSE,
                                       include.na = TRUE,
                                       debug = FALSE) {

  list_sightings <- fetch_clan_sighting.table(clan = clan, sex = sex, lifestage = lifestage,
                                              at = at, from = from, to = to,
                                              clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                                              .fill = .fill, first.event = first.event,
                                              include.conception = include.conception,
                                              #In this case, we might want to count sightings with no lat/long
                                              include.na = include.na,
                                              debug = debug)

  unlist(lapply(list_sightings, nrow))
}

#' @describeIn fetch_family fetch if an individual(s) was sighted.
#'
#' `ID`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_has.sighting usage:
#' fetch_id_has.sighting(ID = c("A-001", "A-007"))
#'
fetch_id_has.sighting <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                  .fill = TRUE, first.event = "observation",
                                  include.conception = FALSE,
                                  include.na = TRUE, debug = FALSE) {

  fetch_id_number.sighting(ID = ID, from = from, to = to, at = at,
                           .fill = .fill, first.event = first.event,
                           include.conception = include.conception, debug = debug) > 0
}


#' @describeIn fetch_family fetch if there is any sighting in clan(s).
#'
#' `clan`, `from`, `to` and `at` can be vectors of same length.
#' Other parameters will be considered fixed.
#'
#' @export
#' @examples
#'
#' #### Simple example of fetch_clan_has.sighting usage:
#' fetch_clan_has.sighting(clan = c("A", "L"))
#'
fetch_clan_has.sighting <- function(clan = NULL, sex = NULL, lifestage = NULL,
                                    at = NULL, from = NULL, to = NULL,
                                    clan.overlap = "any", lifestage.overlap = "any",
                                    .fill = TRUE, first.event = "observation",
                                    include.na = TRUE,
                                    debug = FALSE) {

  fetch_clan_number.sighting(clan = clan, sex = sex, lifestage = lifestage,
                             at = at, from = from, to = to,
                             clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                             .fill = .fill, first.event = first.event,
                             debug = debug) > 0
}


#' @describeIn fetch_family fetch the number of litters of each individual during a given period of time.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_number.litter:
#'
#' fetch_id_number.litter(ID = c("A-001", "A-001"), first.event = "observation")
#' fetch_id_number.litter(ID = c("A-001", "A-008"))
#' fetch_id_number.litter(ID = "A-008")
#'
fetch_id_number.litter <- function(ID, from = NULL, to = NULL, at = NULL,
                                   .fill = TRUE, first.event = "birthdate", debug = FALSE) {

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ID <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 .fill = .fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to
  input <- tibble::tibble(parentID = ID)

  create_id_offspring.table(ID = unique(ID), from = from, to = to) %>%
    dplyr::mutate(litterID = dplyr::if_else(.data$filiation %in% c("mother_genetic", "mother_social_genetic", "father"),
                                            fetch_id_litterID(.data$offspringID, filiation = "mother_genetic"),
                                            fetch_id_litterID(.data$offspringID, filiation = "mother_social"))) %>%
    dplyr::group_by(.data$parentID) %>%
    dplyr::mutate(litters.count = dplyr::if_else(!is.na(.data$offspringID), dplyr::n_distinct(.data$litterID), as.integer(0))) %>%
    dplyr::ungroup() %>%
    dplyr::distinct(.data$parentID, .data$litters.count) -> litters.tbl

  check_function_output(input.tbl = input, output.tbl = litters.tbl,
                        join.by = "parentID", duplicates = "input", output.IDcolumn = "litters.count", debug = debug)

}


#' @describeIn fetch_family fetch if some individuals are included in the dummy dataset or not.
#' @export
#' @examples
#' table(fetch_id_is.dummy(find_pop_id()))

fetch_id_is.dummy <- function(ID) {
  ID.possible <- find_pop_id.dummy()
  ID <- check_function_arg.ID(ID)
  ID %in% ID.possible
}


#' @describeIn fetch_family fetch the reproductive mates of each individuals.
#'
#' If there are several mates per individual, the funcion returns a list.
#'
#' @inheritParams fetch_clan_id
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_id.mate usage:
#'
#' fetch_id_id.mate(c("A-001", "L-003", "A-100", "L-003"))
#'
#' if (require("dplyr") & require("tidyr")){
#' tibble(ID = c("A-001", "L-003", "A-100", "L-003")) %>%
#'   mutate(mates = fetch_id_id.mate(ID)) %>%
#'   unnest_longer(col = mates)
#' }
#'
fetch_id_id.mate <- function(ID = NULL, CPUcores = NULL, .parallel.min = 1000) {

  input <- tibble::tibble(ID = !!ID)  ## Checked internally, so no need to do it here

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if (is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## We loop ## TODO: we should loop only on unique combination, but we need a general wrapper for that...
  if (CPUcores > 1 && nrow(input) >= .parallel.min) {
    output <- furrr::future_pmap(input, ~ do.call("find_id_id.mate", list(...)),
                                 .progress = TRUE,
                                 .options = furrr::furrr_options(globals = ".database"))
    future::plan("sequential") ## close connections (see https://cran.r-project.org/web/packages/future/vignettes/future-7-for-package-developers.html)
  } else {
    if (CPUcores > 1 && (nrow(input) < .parallel.min)) message(paste("Argument CPUcores ignored as less than", .parallel.min, "case(s) to compute."))
    output <- purrr::pmap(input, ~ unique(do.call("find_id_id.mate", list(...))))
  }

  names(output) <- ID

  output
}


#' @describeIn fetch_family fetch if functions are defunct or not
#' @export
#' @examples
#' fetch_function_is.defunct(c(fetch_sex, fetch_id_sex))
#' fetch_function_is.defunct(c("fetch_sex", "fetch_id_sex"))
#'
fetch_function_is.defunct <- function(fn) {
  sapply(fn, function(fn) any(grepl("Defunct", body(fn))))
}


#' @describeIn fetch_family Generate summary statistics column(s) for weather variable(s).
#'
#' NOTE: This function is best suited for applying custom functions, or apply a single function to multiple.
#' weather variables. For common statistics (mean, min, max, sd)
#' applied to temperature and rainfall see wrapper functions like [hyenaR::fetch_weather_temp.mean()].
#'
#' @return A tibble with summary statistic column(s).
#' Summary statistics are calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_fn(from = from, to = to, station = station,
#'                          variable = c("temp", "rain"), fn = mean, suffix = "mean"))
#'
#' #Apply a custom function to find difference between temperature min/max
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_fn(from = from, to = to, station = station,
#'                          variable = "temp", fn = ~{max(.) - min(.)}, suffix = "diff"))
fetch_weather_fn <- function(from = NULL, to = NULL, at = NULL,
                             station = NULL, location = NULL,
                             variable = NULL, fn = NULL, suffix = NULL) {

  #FIXME: This can be both a multi-fetch or regular fetch...so I've just kept calling it fetch
  #First, check the dates. Convert everything into from/to (i.e. no issue if some of the cols are NULL)
  date_range <- check_function_arg.date.fromtoat(from = from, to = to, at = at,
                                                 data.type = "weather")

  from       <- date_range$from
  to         <- date_range$to

  #Identify the unique date combinations we need to find
  input_full <- dplyr::tibble(from = from, to = to)
  input <- unique(input_full)

  #Check variables are correct
  variable_realcol <- check_function_arg.variable.weather(variable)

  #Requires a suffix to make it clear that we applied some summary stat
  #TODO: Create a check function for this
  if (is.null(suffix)) {

    stop("You must provide a suffix to define your new summary column.")

  }

  input %>%
    dplyr::mutate(purrr::pmap_df(.l = .,
                                 .f = ~{

                                   create_weather_starting.table(from = ..1, to = ..2, variable = variable,
                                                                 station = station, location = location) %>%
                                     dplyr::group_by(.data$site_name) %>%
                                     dplyr::summarise(across(.cols = {{variable_realcol}}, .fns = fn, .names = paste0("{.col}_", suffix))) %>%
                                     tidyr::pivot_wider(names_from = site_name,
                                                        values_from = -"site_name", names_glue = "{site_name}_{.value}")

                                 })) -> output

  check_function_output(input.tbl = input_full, output.tbl = output, join.by = c("from", "to")) %>%
    #Can't use output.IDcolumn because it only allows one col (and we need to know the name)
    dplyr::select(-"from", -"to")

}

#' @describeIn fetch_family Fetch mean temperature from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with mean temperature. Mean temperature is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_temp.mean(from = from, to = to, station = station))
fetch_weather_temp.mean <- function(from = NULL, to = NULL, at = NULL,
                                    station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = mean, variable = "temp", suffix = "mean")

}

#' @describeIn fetch_family Fetch max temperature from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with max temperature. Max temperature is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_temp.max(from = from, to = to, station = station))
fetch_weather_temp.max <- function(from = NULL, to = NULL, at = NULL,
                                   station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = max, variable = "temp", suffix = "max")

}

#' @describeIn fetch_family Fetch min temperature from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with min temperature. Min temperature is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_temp.min(from = from, to = to, station = station))
fetch_weather_temp.min <- function(from = NULL, to = NULL, at = NULL,
                                   station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = min, variable = "temp", suffix = "min")

}

#' @describeIn fetch_family Fetch standard deviation of temperature from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with standard deviation of temperature.
#' Standard deviation is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Determine mean of temperature and rainfall from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_temp.sd(from = from, to = to, station = station))
fetch_weather_temp.sd <- function(from = NULL, to = NULL, at = NULL,
                                  station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = stats::sd, variable = "temp", suffix = "sd")

}

#' @describeIn fetch_family Fetch mean rainfall from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with mean rainfall Mean rainfall is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_rain.mean(from = from, to = to, station = station))
fetch_weather_rain.mean <- function(from = NULL, to = NULL, at = NULL,
                                    station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = mean, variable = "rain", suffix = "mean")

}

#' @describeIn fetch_family Fetch max rainfall from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with max rainfall. Max rainfall is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_rain.max(from = from, to = to, station = station))
fetch_weather_rain.max <- function(from = NULL, to = NULL, at = NULL,
                                   station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = max, variable = "rain", suffix = "max")

}

#' @describeIn fetch_family Fetch min rainfall from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with min rainfall. Min rainfall is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_rain.min(from = from, to = to, station = station))
fetch_weather_rain.min <- function(from = NULL, to = NULL, at = NULL,
                                   station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = min, variable = "rain", suffix = "min")

}

#' @describeIn fetch_family Fetch standard deviation of rainfall from a weather station during a given period
#'
#' NOTE: To apply custom functions please see [hyenaR::fetch_weather_fn()].
#'
#' @return A tibble with standard deviation of rainfall.
#' Standard deviation is calculated separately for each station/location.
#' @export
#'
#' @examples
#' #Summary stat from station jua in October 2021
#' data.frame(from = "2021-10-01", to = "2021-10-31",
#'            station = "jua") %>%
#'            dplyr::mutate(fetch_weather_rain.sd(from = from, to = to, station = station))
fetch_weather_rain.sd <- function(from = NULL, to = NULL, at = NULL,
                                  station = NULL, location = NULL) {

  fetch_weather_fn(from = from, to = to, at = at, station = station, location = location,
                   fn = stats::sd, variable = "rain", suffix = "sd")

}

#' @describeIn fetch_family fetch if a given individual was alive before the start
#'  of the study period (first observation).
#'
#' The function is a wrapper around `fetch_id_is.censored()` that checks if individuals
#' are left censored at the start of the study period.
#' @export
#' @examples
#'
#' #### Simple example of fetch_id_is.alive usage:
#' fetch_id_is.founder(ID = c("A-001", "A-011", "A-080"))
fetch_id_is.founder <- function(ID, debug = FALSE){

  fetch_id_is.censored(ID = ID, censored.right = FALSE,
                       from = find_pop_date.observation.first())

}
