#' Extract or compute information about offspring and reproduction
#'
#' These functions extract and compute information about the reproductive output
#' of individuals. All functions listed below (see section **Functions**) return
#' information on reproduction after applying selection criteria to offspring
#' (see section **Selection criteria**).
#'
#' @section Selection criteria:
#'
#' ## Age
#'
#' To select offspring based on their age, you must use a combination of the
#' arguments `age.min`, `age.max`, `from/to/at` and `age.overlap`.
#'
#' The arguments `from/to/at` enables you to define a focal date or an interval
#' of dates, just as in [`create_id_starting.table()`] (but in contrast to the
#' overlap arguments used in starting tables, here the default for `age.overlap`
#' is `"start"` and not `"any"`). Note that by default `from` is set to the very
#' first birthdate in the database, as indicated with the option `first.event`
#' and `to` is internally set as the last observation date.
#'
#' The arguments `age.min` and `age.max` enable you to define the age range of
#' the offspring. The unit for the ages is `"year"` by default, but you can
#' change that using the argument `unit`.
#'
#' How the age range is compared to the interval of dates is defined by the
#' argument `age.overlap`. To best understand how this argument work, do look at
#' the definition of the argument above (the little drawings should be
#' particularly useful). See section **Examples** below, for some practical
#' examples.
#'
#' ## Filiation
#'
#' Only offspring related to the given IDs in a fashion specified by `filiation`
#' (default = all biological offspring but no adoptions) are extracted.
#'
#' @section Geeky details for developers:
#'
#' When creating new functions, all filtering should be done by passing down
#' arguments to `create_id_offspring.table()`. This function returns an
#' unduplicated output, but it also provides the duplicated request as an
#' attribute of the output called "input". This allows to duplicate the output
#' in the top level function (see `fetch_id_id.offspring()` for a template).
#' This is necessary since `check_function_output()` cannot (and should not)
#' handle both a duplicated input and a duplicated output.
#'
#' @name offspring
#' @aliases offspring offsprings repro reproduction
#' @inheritParams arguments
#'
#' @examples
#'
#' ## loading dummy data for examples
#'
#' load_package_database.dummy()
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use create_id_offspring.table()
#' #----------------------------------------------------------------------------
#'
#' # Note: other functions show here are heavily dependent on this function
#' # so it is best to first well understand this function
#'
#'
#' ### Retrieving all offspring from the database:
#' create_id_offspring.table()
#'
#' ### Retrieving all offspring that survived at least to 6-month old:
#' create_id_offspring.table(age.min = 6, unit = "months")
#'
#' ### Retrieving all offspring that survived 2 years before 1997-01-01:
#' create_id_offspring.table(age.min = 2, to = "1997-01-01")
#'
#' ### Retrieving all offspring that survived 2 years before 1997-01-01 with less clutter:
#' create_id_offspring.table(age.min = 2, to = "1997-01-01",
#'                           drop.na.offspring = TRUE, drop.fromto = TRUE)
#'
#' ### Retrieving all offspring born before 1996-01-01:
#' create_id_offspring.table(to = "1996-01-01")
#'
#' ### Retrieving all offspring born between 1996-01-01 and 1997-01-01:
#' create_id_offspring.table(from = "1996-01-01", to = "1997-01-01")
#'
#' ### Retrieving all offspring born before 1996-01-01 and who reached 2 years before 1997-01-01:
#' # Note: this is a little more complex since it involves 2 different usages of "to"
#' # Here `drop.fromto = TRUE` is not just for limiting clutter;
#' # it also prevents clashes during the joint.
#' if (require("dplyr")) {
#'   inner_join(create_id_offspring.table(to = "1996-01-01",
#'                                        drop.na.offspring = TRUE, drop.fromto = TRUE),
#'              create_id_offspring.table(age.min = 2, to = "1997-01-01",
#'                                        drop.na.offspring = TRUE, drop.fromto = TRUE))
#' }
#'
#' ### Retrieve offspring from A-001 born after "1979-04-14" and those born after "1996-12-11":
#' create_id_offspring.table(ID = "A-011", from = c("1979-04-14", "1996-12-11"))
#'
#' ### Retrieve offspring from A-011 born after "1979-04-14"
#' ### and those of A-001 born after "1996-12-11":
#' create_id_offspring.table(ID = c("A-011", "A-001"),
#'                           from = c("1979-04-14", "1996-12-11"))
#'
#' ### Retrieve offspring from individuals that did not reproduce:
#' create_id_offspring.table(ID = "A-058")
#' create_id_offspring.table(ID = "A-058", drop.na.offspring = TRUE) # same with row dropped
#'
#' ### Retrieve offspring born between 2 dates for several individuals:
#' create_id_offspring.table(ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
#'                           from = "1994-01-01", to = "1995-01-01")
#'
#' ### Retrieve offspring only born after study started:
#' create_id_offspring.table(first.event = "observation")
#'
#' ### Retrieve offspring only born after study started (alternative):
#' create_id_offspring.table(from = "1996-04-12")
#'
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use fetch functions built around create_id_offspring.table()
#' #----------------------------------------------------------------------------
#'
#' ### Extracting the ID of offspring that survived 6 months for 4 potential parents
#' fetch_id_id.offspring(ID = c("A-001", "A-002", "A-002", "L-006"), age.min = 6, unit = "month")
#'
#' ### Count the lifetime reproductive success for 3 potential parents:
#' fetch_id_number.offspring(ID = c("A-001", "A-100", "L-003"))
#'
#' ### Count the total number of offspring that reached 2 years old for 3 potential parents:
#' fetch_id_number.offspring(ID = c("A-001", "A-100", "L-003"), age.min = 2)
#'
#' ### Identify dependent offspring that 3 potential parents had on 1997-01-01:
#' fetch_id_id.offspring.dependent(ID = c("A-001", "A-100", "L-003"), at = "1997-01-01")
#'
#' ### Count dependent offspring on 1997-01-01 among 3 potential parents:
#' fetch_id_number.offspring.dependent(ID = c("A-001", "A-100", "L-003"), at = "1997-01-01")
#'
#' ### Identify who had dependent offspring on 1997-01-01 among 3 potential parents:
#' fetch_id_has.offspring.dependent(ID = c("A-001", "A-100", "L-003"), at = "1997-01-01")
#'
#' ### Identify when 2 potential parents first gave birth:
#' fetch_id_date.birth.first(ID = c("A-001", "L-003"))
#'
#' ### Identify when 2 potential parents first gave birth to offspring that survived 3 yrs:
#'
#' fetch_id_date.birth.first(ID = c("A-001", "L-003"), age.min = 3)
#'
#' ### Identify when 2 potential parents first conceived:
#' fetch_id_date.conception.first(ID = c("A-001", "L-003"))
#'
#' ### Estimate interbirth intervals for 2 potential parents:
#' fetch_id_IBI(ID = c("A-001", "L-003"))
#'
#' ### Estimate interbirth intervals for 2 potential parents
#' ### and only counting offspring that survived 18 months:
#' fetch_id_IBI(ID = c("A-001", "L-003"), age.min = 18, unit = "month")
#'
NULL

#' @describeIn offspring create a tidy table with offspring retained after
#'   applying selection criteria (see section **Selection criteria**). The table
#'   also contains the `from` and `to` interval scanned to detect them, the
#'   birthdates of the offspring, and the offspring-parent relationship
#'   (mother_genetic, mother_social, mother_social_genetic, father) which is
#'   called 'filiation'. Note that by default the functions returns at least one
#'   row per parent, so even if no offspring exists a row will be present. You
#'   can override this default by setting `drop.na.offspring = TRUE`.
#'
#' @export

create_id_offspring.table <- function(ID = NULL, from = NULL, to = NULL, at = NULL,
                                      age.min = 0, age.max = Inf, age.overlap = "start", unit = "year",
                                      filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                      drop.na.offspring = FALSE, drop.fromto = FALSE,
                                      .fill = TRUE, first.event = "birthdate", debug = FALSE) {

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  ## check and process argument:
  ID <- check_function_arg.ID(ID, .fill = TRUE)

  age.min <- check_function_arg.age(age.min, arg.max.length = 1L)
  age.max <- check_function_arg.age(age.max, arg.max.length = 1L)
  age.overlap <- check_function_arg.overlap(age.overlap)

  filiation <- check_function_arg.filiation(filiation, .fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 .fill = .fill,
                                                 min.date = min.date,
                                                 max.date = max.date,
                                                 arg.max.length = Inf)
  from       <- date_range$from
  to         <- date_range$to

  #If at is provided (or from and to are the same) then we ignore the overlap argument
  if (all(from == to) && (age.overlap != "any")) {
    message("'age.overlap' is ignored because 'at' is specified")
    age.overlap <- "any"
  }

  ## input table with all combinations of ID and from/to:
  input <- dplyr::tibble(ID = !!ID,
                         from = !!from,
                         to = !!to)

  ## reduce to unique combinations:
  unique_input <- dplyr::distinct(input)

  ## how to handle death depends on the overlap argument:
  na.if.dead <- FALSE
  if (age.overlap %in% c("within", "end")) {
    na.if.dead <- TRUE
  }

  ## extract all offspring with filiation and birthdate:
  extract_database_table(tbl.names = "hyenas") |>
    dplyr::select(offspringID = "ID", "birthdate", "mothergenetic", "mothersocial", "father") |>
    tidyr::pivot_longer(cols = c("mothergenetic":"father"),
                        names_to = "filiation", values_to = "parentID",
                        values_drop_na = TRUE, values_transform = list(parentID = as.character)) |>
    dplyr::filter(.data$parentID %in% !!ID) |>
    dplyr::summarise(n = dplyr::n(),
                     first_filiation = dplyr::first(.data$filiation),
                     birthdate = dplyr::first(.data$birthdate), .by = c("parentID", "offspringID")) |>
    dplyr::mutate(#offspringID = v(.data$offspringID),
                  filiation = dplyr::case_when(.data$n > 1 ~ "mother_social_genetic",
                                               .data$first_filiation == "mothergenetic" ~ "mother_genetic",
                                               .data$first_filiation == "mothersocial" ~ "mother_social",
                                               .default = .data$first_filiation),
                  starting_date = fetch_id_date.at.age(ID = .data$offspringID, age = !!age.min, unit = !!unit, na.if.dead = TRUE),
                  age.max.date =  fetch_id_date.at.age(ID = .data$offspringID, age = !!age.max, unit = !!unit, na.if.dead = na.if.dead),
                  age.death = fetch_id_date.death(ID = .data$offspringID),
                  ending_date = dplyr::case_when(!!age.max == Inf ~ !!max.date,
                                                 !!age.max < Inf & is.na(.data$age.death) ~ .data$age.max.date,
                                                 !!age.max < Inf & (!is.na(.data$age.death) & .data$age.death > .data$age.max.date) ~ .data$age.max.date,
                                                 !!age.max < Inf & (!is.na(.data$age.death) & .data$age.death <= .data$age.max.date) & age.overlap != "any" ~ .data$age.max.date,
                                                 !!age.max < Inf & (!is.na(.data$age.death) & .data$age.death <= .data$age.max.date) & age.overlap == "any" ~ .data$age.death)) |>
    dplyr::select(-"n", -"first_filiation", -"age.max.date", -"age.death") |>
    #Join in from/to to allow for a vector of different from/to dates
    dplyr::left_join(relationship = "many-to-many", x = _, y = unique_input, by = c("parentID" = "ID")) -> all_offspring

  #browser()
  ## filter based on age overlap (if needed):
  if (nrow(all_offspring) > 0 &&
      ((age.min > 0 || age.max < Inf) ||
       any(from != find_pop_date.birth.first()) || any(to != find_pop_date.observation.last()))) {

    if (length(unique(from)) == 1 && length(unique(to)) == 1) {
      ## fast approach for simple cases
      all_offspring <- create_id_overlap.table(input.tbl = all_offspring,
                                                from = all_offspring$from[1], to = all_offspring$to[1],
                                                overlap = age.overlap,
                                                .internal = TRUE)
    } else {
      ## slower approach but allows for different from/to dates
      res <- apply(all_offspring, 1, \(row) { ## FIXME: perhaps not rowwise but break in groups of common from/to
          row <- tibble::as_tibble_row(row)
          row$from <- as.Date(row$from)
          row$to <- as.Date(row$to)
          create_id_overlap.table(input.tbl = row,
                                  from = row$from, to = row$to, overlap = age.overlap,
                                  .internal = TRUE)})

      all_offspring <- do.call("rbind", res)
    }
  }

  ## filter by filiation (if needed):
  if (!all(check_function_arg.filiation(NULL, .fill = TRUE) %in% filiation)) {
    all_offspring  |>
      dplyr::filter(.data$filiation %in% !!filiation) -> all_offspring
  }

  ## select the columns to output:
  all_offspring |>
    dplyr::select("parentID", "offspringID", "birthdate", "filiation", "from", "to") -> df_offspring_from_parents

  ## check output:
  check_function_output(input.tbl = unique_input,
                        output.tbl = df_offspring_from_parents,
                        join.by = c(ID = "parentID", from = "from", to = "to"),
                        duplicates = "output", debug = debug) -> output

  ## add input table as argument for allowing duplicated input in fetch:
  attr(output, "input") <- input
  #print(output)

  ## remove row with no offspring if needed:
  if (drop.na.offspring) {
    output |>
      dplyr::filter(!is.na(.data$offspringID)) -> output
  }

  ## remove columns from and to if needed:
  if (drop.fromto) {
    output |>
      dplyr::select(-"from", -"to") -> output
  }

  output

}


#' @describeIn offspring fetch all offspring retained after applying selection
#'   criteria (see section **Selection criteria**).
#'
#' @export

fetch_id_id.offspring <- function(ID, from = NULL, to = NULL, at = NULL,
                                  age.min = 0, age.max = Inf, age.overlap = "start",
                                  unit = "year",
                                   .fill = TRUE,
                                   filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                   first.event = "birthdate", debug = FALSE) {

  if ((length(from) > 1 && length(from) != length(ID)) ||
      (length(to) > 1 && length(to) != length(ID)) ||
      (length(at) > 1 && length(at) != length(ID))) {
    stop("The arguments `from`, `to` and `at` must have the same length as `ID`, be `NULL`, or be of length 1.")
  }

  create_id_offspring.table(ID = ID, from = from, to = to, at = at,
                            age.min = age.min, age.max = age.max, age.overlap = age.overlap,
                            unit = unit,
                            .fill = .fill, filiation = filiation, first.event = first.event) -> df_offspring

  df_offspring |>
    dplyr::summarise(offspringID = list(unique(.data$offspringID)), .by = c("parentID", "from", "to")) -> df_offspring_job

  check_function_output(input.tbl = attr(df_offspring, "input"),
                        output.tbl = df_offspring_job,
                        join.by = c(ID = "parentID", from = "from", to = "to"),
                        duplicates = "input", debug = debug) -> output
  output |>
    dplyr::pull(.data$offspringID) -> output

  names(output) <- ID ## FIXME, this could be done directly inside check_function_output, see issue #310
  output

}


#' @describeIn offspring fetch the number of offspring retained after applying
#'   selection criteria (see section **Selection criteria**).
#'
#' @export

fetch_id_number.offspring <- function(ID, from = NULL, to = NULL, at = NULL,
                                      age.min = 0, age.max = Inf, age.overlap = "start",
                                      unit = "year",
                                      .fill = TRUE,
                                      filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                      first.event = "birthdate", debug = FALSE) {

  if ((length(from) > 1 && length(from) != length(ID)) ||
      (length(to) > 1 && length(to) != length(ID)) ||
      (length(at) > 1 && length(at) != length(ID))) {
    stop("The arguments `from`, `to` and `at` must have the same length as `ID`, be `NULL`, or be of length 1.")
  }

  create_id_offspring.table(ID = ID, from = from, to = to, at = at,
                            age.min = age.min, age.max = age.max, age.overlap = age.overlap,
                            unit = unit,
                            .fill = .fill, filiation = filiation, first.event = first.event) -> df_offspring

  df_offspring |>
    dplyr::summarise(offspringN = length(unique(.data$offspringID[!is.na(.data$offspringID)])), .by = c("parentID", "from", "to")) -> df_offspring_job

  check_function_output(input.tbl = attr(df_offspring, "input"),
                        output.tbl = df_offspring_job,
                        join.by = c(ID = "parentID", from = "from", to = "to"),
                        duplicates = "input", debug = debug) -> output

  output |>
    dplyr::pull(.data$offspringN) -> output

  names(output) <- ID ## FIXME, this could be done directly inside check_function_output, see issue #310
  output

}


#' @describeIn offspring fetch the ID of dependent offspring retained after
#'   applying selection criteria (see section **Selection criteria**). By default,
#'   individuals are considered dependent until 1yo. Dependent offspring are
#'   only those that are socially dependent, therefore offspring with filiation
#'   father or mother_genetic are ignored.
#'
#' @export

fetch_id_id.offspring.dependent <- function(ID, from = NULL, to = NULL, at = NULL,
                                            age.dependent = 1, unit = "year",
                                            .fill = TRUE,
                                            first.event = "birthdate", debug = FALSE) {

  fetch_id_id.offspring(ID = ID,
                        from = from, to = to, at = at,
                        age.min = 0, age.max = age.dependent, age.overlap = "any",
                        unit = "year",
                        .fill = .fill,
                        filiation = "mother_social_genetic",
                        first.event = first.event, debug = debug)

}


#' @describeIn offspring fetch the number of dependent offspring retained after
#'   applying selection criteria (see section **Selection criteria**). By default,
#'   individuals are considered dependent until 1yo. Dependent offspring are
#'   only those that are socially dependent, therefore offspring with filiation
#'   father or mother_genetic are ignored.
#'
#' @export

fetch_id_number.offspring.dependent <- function(ID, from = NULL, to = NULL, at = NULL,
                                                age.dependent = 1, unit = "year",
                                                .fill = TRUE,
                                                first.event = "birthdate", debug = FALSE) {

  id.offspring <- fetch_id_id.offspring.dependent(ID = ID, from = from, to = to, at = at,
                                                  age.dependent = age.dependent, unit = unit,
                                                  .fill = .fill,
                                                  first.event = first.event, debug = debug)

  sapply(id.offspring, \(x) length(unique(x[!is.na(x)])))
}


#' @describeIn offspring fetch whether an individual has at least one dependent
#'   offspring after applying selection criteria (see section **Description**).
#'
#' @export
#'
fetch_id_has.offspring.dependent <- function(ID, from = NULL, to = NULL, at = NULL,
                                             age.dependent = 1, unit = "year",
                                             .fill = TRUE,
                                             first.event = "birthdate", debug = FALSE) {

  fetch_id_number.offspring.dependent(ID = ID, from = from, to = to, at = at,
                                      age.dependent = age.dependent, unit = unit,
                                      .fill = .fill,
                                      first.event = first.event, debug = debug) > 0

}


#' @describeIn offspring fetch the date at which a given individual has given
#'   birth to its first (known) offspring among those retained after applying
#'   selection criteria (see section **Selection criteria**)
#'
#' @export

fetch_id_date.birth.first <- function(ID, from = NULL, to = NULL, at = NULL,
                                      age.min = 0, age.max = Inf, age.overlap = "start",
                                      unit = "year",
                                      .fill = TRUE,
                                      filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                      first.event = "birthdate", debug = FALSE) {

  if ((length(from) > 1 && length(from) != length(ID)) ||
      (length(to) > 1 && length(to) != length(ID)) ||
      (length(at) > 1 && length(at) != length(ID))) {
    stop("The arguments `from`, `to` and `at` must have the same length as `ID`, be `NULL`, or be of length 1.")
  }

  create_id_offspring.table(ID = ID, from = from, to = to, at = at,
                            age.min = age.min, age.max = age.max, age.overlap = age.overlap,
                            unit = unit,
                            .fill = .fill, filiation = filiation, first.event = first.event) -> df_offspring

  df_offspring |>
    dplyr::summarise(firstbirth = dplyr::first(.data$birthdate), .by = c("parentID", "from", "to")) -> df_offspring_job

  check_function_output(input.tbl = attr(df_offspring, "input"),
                        output.tbl = df_offspring_job,
                        join.by = c(ID = "parentID", from = "from", to = "to"),
                        duplicates = "input", debug = debug) -> output

  output |>
    dplyr::pull(.data$firstbirth) -> output

  names(output) <- ID ## FIXME, this could be done directly inside check_function_output, see issue #310
  output
}


#' @describeIn offspring fetch the date at which a given individual has
#'   conceived its first known offspring among those retained after applying
#'   selection criteria (see section **Selection criteria**). Note that conception is
#'   here defined as the offspring birthdate minus 110 days.
#'
#' @export

fetch_id_date.conception.first <- function(ID, from = NULL, to = NULL, at = NULL,
                                           age.min = 0, age.max = Inf, age.overlap = "start",
                                           unit = "year",
                                           .fill = TRUE,
                                           filiation = c("mother_genetic", "mother_social_genetic", "father"),
                                           first.event = "birthdate", debug = FALSE) {

  fetch_id_date.birth.first(ID = ID, from = from, to = to, at = at,
                            age.min = age.min, age.max = age.max, age.overlap = age.overlap,
                            unit = unit,
                            .fill = .fill,
                            filiation = filiation,
                            first.event = first.event, debug = debug) - lubridate::days(110)

}


#' @describeIn offspring fetch InterBirth Intervals between offspring retained
#'   after applying selection criteria (see section **Selection criteria**). The
#'   IBI is return in the same unit as the one set to select ages (i.e. "year"
#'   by default), and is thus defined with the argument `unit`. Note also that
#'   the length of IBI is one less than the number of offspring (the first
#'   offspring does not count and there is no interval for it).
#'
#' @export

fetch_id_IBI <- function(ID, from = NULL, to = NULL, at = NULL,
                         age.min = 0, age.max = Inf, age.overlap = "start",
                         unit = "year",
                         .fill = TRUE,
                         filiation = c("mother_genetic", "mother_social_genetic", "father"),
                         first.event = "birthdate", debug = FALSE) {

  if ((length(from) > 1 && length(from) != length(ID)) ||
      (length(to) > 1 && length(to) != length(ID)) ||
      (length(at) > 1 && length(at) != length(ID))) {
    stop("The arguments `from`, `to` and `at` must have the same length as `ID`, be `NULL`, or be of length 1.")
  }

  create_id_offspring.table(ID = ID, from = from, to = to, at = at,
                            age.min = age.min, age.max = age.max, age.overlap = age.overlap,
                            unit = unit,
                            .fill = .fill, filiation = filiation, first.event = first.event) -> df_offspring

  df_offspring |>
    dplyr::summarise(IBI = list(lubridate::interval(dplyr::lag(.data$birthdate), .data$birthdate)[-1]/lubridate::duration(1, units = unit)),
                     .by = c("parentID", "from", "to")) -> df_offspring_job

  check_function_output(input.tbl = attr(df_offspring, "input"),
                        output.tbl = df_offspring_job,
                        join.by = c(ID = "parentID", from = "from", to = "to"),
                        duplicates = "input", debug = debug) -> output

  output |>
    dplyr::pull(.data$IBI) -> output

  names(output) <- ID ## FIXME, this could be done directly inside check_function_output, see issue #310
  output

}

