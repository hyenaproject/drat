#' Fetch the number of individuals
#'
#' The functions described here all returns a list of numbers
#' of individuals under the criteria specified.
#' Here are a few thing to know about these functions:
#' - The core function doing the actual work is always `fetch_clan_number()`. You can
#' either call this core function directly and customise all its arguments, or
#' for simplicity, you can use the other functions (e.g.
#' `fetch_clan_number.male.all()`). These latter functions are shortcuts
#' for `fetch_clan_number()` where sex and lifestage are already specified.
#' Users should probably rely on these secondary functions unless they
#' want something complex which is not directly obtainable by such shortcuts
#' (such as a combination of life history stages).
#' - The secondary functions are named following the scheme
#' `fetch_clan_number.SEX.LIFESTAGE()` where `SEX` is a placeholder that can be
#' `male`, `female` or `anysex` (which contains males, females and individuals
#' of unknown sex) and where `LIFESTAGE` is a placeholder for `all`, `cub`,
#' `subadult`, `natal`, `adult`, `philopatric`, `foreigner`, `disperser`,
#' `transient`, `selector` or `dead`. Note that all combinations are programmed
#' even if the don't make biological sense (e.g.
#' `fetch_clan_number.female.transient()`).
#' - All `fetch_clan_number.xxx()` function described here have a matching
#' `fetch_pop_number.xxx()` function. The `pop` function return the individuals for all
#' clans (both crater and rim clans, default) unless the argument `main.clans` is
#' set to `TRUE`. Again, the `fetch_pop_number.xxx()` functions are shortcuts using
#' `fetch_clan_number.xxx()` behind the curtains. The benefits of using the
#' `fetch_pop_number.xxx()` functions is that you do not need to enumerate the clans.
#'- All these functions take the same arguments as
#'[`create_id_starting.table()`], so they allow for time windows specification
#'with arguments `from` and `to`, as well as overlap between the clans or
#'lifestages and the time window. For example, you can count individuals that had
#'a particular lifestage either at the beginning, at the end, or during the
#'entire time period by setting the argument `lifestage.overlap` to the
#'adequate value (see section **Arguments** below). The same is true of the
#'clan.
#'
#' @export
#' @inheritParams arguments
#' @name fetch_clan_number
NULL


#' @describeIn fetch_clan_number retrieve the number of individuals for given clan(s), sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#' load_package_database.dummy()
#'
#' #### Example of fetch_clan_number usage:
#'
#' fetch_clan_number(clan = c("A", "A"), lifestage = c("philopatric", "cub"),
#'                   from = "1996-04-12", to = "1997-12-30",
#'                   clan.overlap = "any", lifestage.overlap = "any")
#'
#' if(require("dplyr")) {
#' tibble(clan = c("A", "A"),
#'       lifestage = c("philopatric", "cub"),
#'       from = "1996-04-12", to = "1997-12-30",
#'       clan.overlap = "any",
#'       lifestage.overlap = "any") %>%
#'       mutate(number = fetch_clan_number(clan = clan, lifestage = lifestage,
#'                                         from = from, to = to,
#'                                         clan.overlap = clan.overlap,
#'                                         lifestage.overlap = lifestage.overlap))
#' }
fetch_clan_number <- function(clan = NULL, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                              clan.overlap = "any", lifestage.overlap = "any",
                              CPUcores = NULL, .parallel.min = 1000,
                              verbose = TRUE) {

  list_IDS <- fetch_clan_id(clan = clan, sex = sex, lifestage = lifestage, at = at, from = from, to = to,
                            clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                            CPUcores = CPUcores, .parallel.min = .parallel.min)

  sapply(list_IDS, length)
}


#' @describeIn fetch_clan_number retrieve the number of individuals in the whole population for given sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_pop_number usage:
#'
#' fetch_pop_number(lifestage = c("philopatric", "cub"),
#'                   from = "1996-04-12", to = "1997-12-30",
#'                   clan.overlap = "any", lifestage.overlap = "any")
#'
#' fetch_pop_number(main.clans = FALSE, lifestage = c("philopatric", "cub"),
#'                   from = "1996-04-12", to = "1997-12-30",
#'                   clan.overlap = "any", lifestage.overlap = "any")
#'
fetch_pop_number <- function(main.clans = FALSE, sex = NULL, lifestage = NULL, at = NULL, from = NULL, to = NULL,
                             clan.overlap = "any", lifestage.overlap = "any",
                             CPUcores = NULL, .parallel.min = 1000,
                             verbose = TRUE) {

  clans <- find_clan_name.all(main.clans =  check_function_arg.logical(main.clans))

  fetch_clan_number(clan = list(clans), sex = sex, lifestage = lifestage, at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number retrieve the number of males for given clan(s), sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_clan_number.male.all usage:
#'
#' # fetch the number of all males of clans A and L:
#' fetch_clan_number.male.all(clan = c("A", "L"))
#'
fetch_clan_number.male.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "!dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number retrieve the number of males in the whole population for sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_pop_number.male.all usage:
#'
#' # count all males for the main clans:
#' fetch_pop_number.male.all()
#'
#' # count all males for the whole population:
#' fetch_pop_number.male.all(main.clans = FALSE)
#'
fetch_pop_number.male.all <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "!dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of male cubs for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.cub <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "cub", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of male cubs in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.cub <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "cub", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadult males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.subadult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "subadult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadult males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.subadult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "subadult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.natal <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "natal", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.natal <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "natal", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of foreigner males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.foreigner <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "foreigner", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of males with lifestage 'foreigner_1' or 'founder_male' for given clan(s) and time requirement(s)
#'
#' NOTE: This function exists to maintain backwards compatibility and will likely be depracated.
#' @export
fetch_clan_number.male.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_clan_number()` with lifestage c('foreigner_1', 'founder_male') instead")

  fetch_clan_number(clan = clan, sex = "male", lifestage = list(c("foreigner_1", "founder_male")), at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of foreigner males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.foreigner <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "foreigner", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of males with lifestage 'foreigner_1' or 'founder_male' in the entire population for given time requirement(s)
#'
#' NOTE: This function exists to maintain backwards compatibility and will likely be depracated.
#' @export
fetch_pop_number.male.immigrant <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_pop_number()` with lifestage c('foreigner_1', 'founder_male') instead")

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = list(c("foreigner_1", "founder_male")), at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adult males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "adult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adult males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.adult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {


  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "adult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of philopatric males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "philopatric", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of philopatric males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.philopatric <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "philopatric", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number fetch the number of male dispersers for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "disperser", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of male dispersers in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.disperser <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "disperser", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number fetch the number of transient males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "transient", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of transient males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.transient <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "transient", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number fetch the number of male selectors for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "selector", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of male selectors in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.selector <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "selector", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number fetch the number of dead males for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.male.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "male", lifestage = "dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dead males in the entire population for given time requirement(s)
#' @export
fetch_pop_number.male.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                           clan.overlap = "any", lifestage.overlap = "any",
                                           CPUcores = NULL, .parallel.min = 1000,
                                           verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "male", lifestage = "dead", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number retrieve the number of females for given clan(s), sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_clan_number.female.all usage:
#'
#' # fetch the number of all females of clans A and L:
#' fetch_clan_number.female.all(clan = c("A", "L"))
#'
fetch_clan_number.female.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = NULL, at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number retrieve the number of females in the whole population for sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_pop_number.female.all usage:
#'
#' # count all females for the main clans:
#' fetch_pop_number.female.all()
#'
#' # count all females for the whole population:
#' fetch_pop_number.female.all(main.clans = FALSE)
#'
fetch_pop_number.female.all <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = NULL, at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female cubs for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.cub <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                       clan.overlap = "any", lifestage.overlap = "any",
                                       CPUcores = NULL, .parallel.min = 1000,
                                       verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "cub", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female cubs in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.cub <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                      clan.overlap = "any", lifestage.overlap = "any",
                                      CPUcores = NULL, .parallel.min = 1000,
                                      verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "cub", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadult females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.subadult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "subadult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadult females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.subadult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                           clan.overlap = "any", lifestage.overlap = "any",
                                           CPUcores = NULL, .parallel.min = 1000,
                                           verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "subadult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.natal <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "natal", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.natal <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "natal", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of foreigner females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.foreigner <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "foreigner", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of females with lifestage 'foreigner_1' for given clan(s) and time requirement(s)
#'
#' NOTE: This function exists to maintain backwards compatibility and will likely be depracated.
#' @export
fetch_clan_number.female.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_clan_number()` with lifestage c('foreigner_1', 'founder_male') instead")

  fetch_clan_number(clan = clan, sex = "female", lifestage = c("foreigner_1"), at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of foreigner females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.foreigner <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "foreigner", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of females with lifestage "foreigner_1" in the entire population for given time requirement(s)
#'
#' NOTE: This function exists to maintain backwards compatibility and will likely be depracated.
#'@export
fetch_pop_number.female.immigrant <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_pop_number()` with lifestage c('foreigner_1') instead")

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = c("foreigner_1"), at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adult females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {


  fetch_clan_number(clan = clan, sex = "female", lifestage = "adult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adult females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.adult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {

fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "adult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)

}

#' @describeIn fetch_clan_number fetch the number of philopatric females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "philopatric", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of philopatric females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.philopatric <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "philopatric", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female dispersers for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "disperser", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female dispersers in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.disperser <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "disperser", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of transient females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "transient", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of transient females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.transient <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                           clan.overlap = "any", lifestage.overlap = "any",
                                           CPUcores = NULL, .parallel.min = 1000,
                                           verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "transient", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female selectors for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "selector", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of female selectors in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.selector <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                           clan.overlap = "any", lifestage.overlap = "any",
                                           CPUcores = NULL, .parallel.min = 1000,
                                           verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "selector", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dead females for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.female.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = "female", lifestage = "dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dead females in the entire population for given time requirement(s)
#' @export
fetch_pop_number.female.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = "female", lifestage = "dead", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number retrieve the number of individuals of any sex for given clan(s), sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_clan_number.anysex.all usage:
#'
#' # fetch the number of all individuals of clans A and L:
#' fetch_clan_number.anysex.all(clan = c("A", "L"))
#'
fetch_clan_number.anysex.all <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "!dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}



#' @describeIn fetch_clan_number retrieve the number of all individuals in the whole population for sex(es), lifestage(s) and time requirement(s)
#' @export
#' @examples
#'
#' #### Example of fetch_pop_number.male.all usage:
#'
#' # count all individuals for the main clans:
#' fetch_pop_number.anysex.all()
#'
#' # count all males for the whole population:
#' fetch_pop_number.anysex.all(main.clans = FALSE)
#'
fetch_pop_number.anysex.all <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = NULL, at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of cubs of anysex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.cub <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "cub", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of cubs of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.cub <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "cub", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadults of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.subadult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "subadult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of subadults of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.subadult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "subadult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal individuals of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.natal <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                           clan.overlap = "any", lifestage.overlap = "any",
                                           CPUcores = NULL, .parallel.min = 1000,
                                           verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "natal", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of natal individuals of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.natal <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                          clan.overlap = "any", lifestage.overlap = "any",
                                          CPUcores = NULL, .parallel.min = 1000,
                                          verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "natal", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of all foreigner individuals for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.foreigner <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "foreigner", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of all individuals with lifestage 'foreigner_1' or 'founder_male' for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.immigrant <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_clan_number()` with lifestage c('foreigner_1', 'founder_male') instead")

  fetch_clan_number(clan = clan, sex = NULL, lifestage = list(c("foreigner_1", "founder_male")), at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of all foreigner individuals in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.foreigner <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                            clan.overlap = "any", lifestage.overlap = "any",
                                            CPUcores = NULL, .parallel.min = 1000,
                                            verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "foreigner", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of individuals with lifestage 'foreigner_1' or 'founder_male' in the entire population for given time requirement(s)
#'
#' NOTE: This function exists to maintain backwards compatibility and will likely be depracated.
#' @export
fetch_pop_number.anysex.immigrant <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  .Deprecated(msg = "Immigrant functions will be removed from newer versions of hyenaR. Use `fetch_pop_number()` with lifestage c('foreigner_1', 'founder_male') instead")

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = list(c("foreigner_1", "founder_male")), at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adults of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.adult <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                         clan.overlap = "any", lifestage.overlap = "any",
                                         CPUcores = NULL, .parallel.min = 1000,
                                         verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "adult", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of adult of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.adult <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                        clan.overlap = "any", lifestage.overlap = "any",
                                        CPUcores = NULL, .parallel.min = 1000,
                                        verbose = TRUE) {


  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "adult", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of philopatric individuals of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.philopatric <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                                 clan.overlap = "any", lifestage.overlap = "any",
                                                 CPUcores = NULL, .parallel.min = 1000,
                                                 verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "philopatric", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of philopatric individuals of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.philopatric <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                                clan.overlap = "any", lifestage.overlap = "any",
                                                CPUcores = NULL, .parallel.min = 1000,
                                                verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "philopatric", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dispersers of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.disperser <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                               clan.overlap = "any", lifestage.overlap = "any",
                                               CPUcores = NULL, .parallel.min = 1000,
                                               verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "disperser", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dispersers of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.disperser <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "disperser", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of transients of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.transient <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "transient", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of transient individuals of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.transient <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "transient", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of selectors of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.selector <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "selector", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of selectors of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.selector <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "selector", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}


#' @describeIn fetch_clan_number fetch the number of dead individuals of any sex for given clan(s) and time requirement(s)
#' @export
fetch_clan_number.anysex.dead <- function(clan = NULL, at = NULL, from = NULL, to = NULL,
                                              clan.overlap = "any", lifestage.overlap = "any",
                                              CPUcores = NULL, .parallel.min = 1000,
                                              verbose = TRUE) {

  fetch_clan_number(clan = clan, sex = NULL, lifestage = "dead", at = at, from = from, to = to,
                    clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                    CPUcores = CPUcores, .parallel.min = .parallel.min)
}

#' @describeIn fetch_clan_number fetch the number of dead individuals of any sex in the entire population for given time requirement(s)
#' @export
fetch_pop_number.anysex.dead <- function(main.clans = FALSE, at = NULL, from = NULL, to = NULL,
                                             clan.overlap = "any", lifestage.overlap = "any",
                                             CPUcores = NULL, .parallel.min = 1000,
                                             verbose = TRUE) {

  fetch_pop_number(main.clans = main.clans, sex = NULL, lifestage = "dead", at = at, from = from, to = to,
                   clan.overlap = clan.overlap, lifestage.overlap = lifestage.overlap,
                   CPUcores = CPUcores, .parallel.min = .parallel.min)
}
