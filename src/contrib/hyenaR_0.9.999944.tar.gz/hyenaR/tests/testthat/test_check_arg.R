context("Test check_function_arg.xxx functions")

test_that("check_function_arg.ID works as intended", {

  expect_error(check_function_arg.ID("ZZZ"))

  expect_warning(check_function_arg.ID("ZZZ", strict = FALSE))

  ref <- 122L
  job <- length(check_function_arg.ID(.fill = TRUE))
  expect_equal(ref, job)

  ref <- c("A-010", NA, "A-010")
  job <- check_function_arg.ID(c("A-010", NA, "A-010"))
  expect_equal(ref, job)

  ref <- "character"
  job <- class(check_function_arg.ID(NA))
  expect_equal(ref, job)

})


test_that("check_function_arg.period works as intended", {

  expect_error(check_function_arg.period("90"))

  ref <- new("Period", .Data = 0, year = 0, month = 0, day = 90, hour = 0, minute = 0)
  job <- check_function_arg.period("90 days")

  expect_equal(ref, job)
})


test_that("check_function_arg.filiation works as intended", {

  expect_error(check_function_arg.filiation("social"))

  ref <- c("mother_social", "mother_genetic")
  job <- check_function_arg.filiation(c("mother_social", "mother_genetic"))

  expect_equal(ref, job)
})

test_that("check_function_arg.ranks works as intended", {
  expect_error(check_function_arg.ranks(1:2, std = TRUE))
  expect_error(check_function_arg.ranks(-2, std = FALSE))
  expect_error(check_function_arg.ranks(c(1, 2.4), std = FALSE))
})

test_that("check_function_arg.lineage works as intended", {

  expect_error(check_function_arg.lineage("mother"))

  ref <- c("mothersocial", "father")
  job <- check_function_arg.lineage(c("mothersocial", "father"))

  expect_equal(ref, job)
})

test_that("check_function_arg.date works as intended", {

  #Fails if we start with the wrong format (i.e. not in order yy-mm-dd)
  expect_error(check_function_arg.date(c("01/01/1996", "1996-05-01")))

  #Fails if wrong format occurs later
  expect_error(check_function_arg.date(c("1996-05-01", "01/01/1996")))

  #Fails if we used two (accepted) formats
  #If we use lubridate::as_date() (which we want to use because it preserves timezone)
  #Then this is no longer an issue (i.e. it can successfully parse multiple yy/mm/dd formats)
  # expect_error(check_function_arg.date(c("1996-05-01", "1996/10/01")))

  #Succeeds with YYYY-MM-DD or YYYY/MM/DD
  ref <- structure(c(9617, 9770), class = "Date")
  job1 <- check_function_arg.date(c("1996-05-01", "1996-10-01"))
  job2 <- check_function_arg.date(c("1996/05/01", "1996/10/01"))
  expect_equal(ref, job1)
  expect_equal(ref, job2)

  #Succeeds with NAs
  ref3a <- structure(c(9617, NA), class = "Date")
  job3a <- check_function_arg.date(c("1996/05/01", NA))
  expect_equal(ref3a, job3a)

  #Succeeds with Infs
  ref3b <- structure(c(9617, Inf), class = "Date")
  job3b <- check_function_arg.date(c(as.Date("1996/05/01"), Inf))
  expect_equal(ref3b, job3b)

  #Fails with NULL if fill != TRUE
  expect_error(check_function_arg.date(date = NULL, .fill = FALSE))

  #Fails with NULL if .fill == TRUE but fill.value is NULL or incorrect
  expect_error(check_function_arg.date(date = NULL, .fill = TRUE, fill.value = NULL))
  expect_error(check_function_arg.date(date = NULL, .fill = TRUE, fill.value = "1900/01/01"))

  #Fails with dates out of boundaries
  expect_error(check_function_arg.date("1977-12-25"))
  expect_error(check_function_arg.date("1977/12/25"))
  expect_error(check_function_arg.date("1998-12-25"))
  expect_error(check_function_arg.date("1998/12/25"))

  #Fills NULL if fill.value is provided
  ref4 <- as.Date("1996-04-12")
  job4 <- check_function_arg.date(date = NULL, .fill = TRUE, fill.value = find_pop_date.observation.first())
  expect_equal(ref4, job4)

})

test_that("check_function_arg.litter.ID works as intended", {
  ref <- "A-001_003"
  job <- check_function_arg.litter.ID("A-001_003")
  expect_equal(ref, job)
})

test_that("check_function_arg.litter.type works as intended", {
  ref <- list(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = c(0, 0, 0),
              social.daughters.nb = c(0, 0, 0), social.sons.nb = c(0, 0, 0), social.unknown.nb = c(0, 0, 0))
  job <- check_function_arg.litter.type(daughters.nb = c(1, 0, 1), sons.nb = c(0, 2, 1), unknown.nb = 0,
                                        social.daughters.nb = 0, social.sons.nb = 0, social.unknown.nb = 0)
  expect_equal(ref, job)
})

test_that("check_function_arg.logical works as intended", {
  ref <- TRUE
  job <- check_function_arg.logical(TRUE)
  expect_equal(ref, job)
})

test_that("check_function_arg.date.fromtoat works as intended", {

  #Fails when incorrect date format is used in fromtoat
  expect_error(check_function_arg.date.fromtoat(from = "01/01/1996", to = "1996-10-02"))
  expect_error(check_function_arg.date.fromtoat(from = "1996-10-01", to = "02/01/1996"))
  expect_error(check_function_arg.date.fromtoat(at = "02/01/1996"))

  #Fails when multiple (acceptable) date formats are used
  #We use use lubridate::as_date() (which we want because it preserves time zone)
  #Then this no longer fails. It can parse many date formats in yy/mm/dd
  # expect_error(check_function_arg.date.fromtoat(from = c("1996-10-01", "19960101"), to = "1996/10/02"))

  #Fails when from/to and at are used
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", to = "1996-05-01", at = "1997-01-01"))
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", at = "1997-01-01"))
  expect_error(check_function_arg.date.fromtoat(to = "1997-10-01", at = "1997-01-01"))

  #Fails when from !<= to
  expect_error(check_function_arg.date.fromtoat(from = "1997-10-01", to = "1996-05-01"))

  #at returns equal values
  ref1 <- structure(as.list(structure(c(9770, 9770), class = "Date")), names = c("from", "to"))
  job1 <- check_function_arg.date.fromtoat(at = "1996-10-01")
  expect_equal(ref1, job1)

  #from/to return different values
  ref2 <- structure(as.list(structure(c(9617, 9770), class = "Date")), names = c("from", "to"))
  job2 <- check_function_arg.date.fromtoat(from = "1996-05-01", to = "1996-10-01")
  expect_equal(ref2, job2)

  #Fill values when from or to are not provided with min/max values
  ref3 <- list(from = structure(9598, class = "Date"), to = structure(10226, class = "Date"))
  job3 <- check_function_arg.date.fromtoat(.fill = TRUE,
                                           max.date = find_pop_date.observation.last(),
                                           min.date = find_pop_date.observation.first())
  expect_equal(ref3, job3)

  ref4 <- list(from = structure(9862, class = "Date"), to = structure(10226, class = "Date"))
  job4 <- check_function_arg.date.fromtoat(from = "1997-01-01", .fill = TRUE,
                                           max.date = find_pop_date.observation.last())
  expect_equal(ref4, job4)

  ref5 <- list(from = structure(9598, class = "Date"), to = structure(10196, class = "Date"))
  job5 <- check_function_arg.date.fromtoat(to = "1997-12-01", .fill = TRUE,
                                           min.date = find_pop_date.observation.first())
  expect_equal(ref5, job5)

  #Fails when fill is FALSE
  expect_error(check_function_arg.date.fromtoat(.fill = FALSE))

  #Fails when .fill == TRUE but max/min values are incorrect
  expect_error(check_function_arg.date.fromtoat(.fill = TRUE))
  expect_error(check_function_arg.date.fromtoat(from = "1997-01-01", .fill = TRUE, max.date = "1900-12-01"))
  expect_error(check_function_arg.date.fromtoat(to = "1997-01-01", .fill = TRUE, min.date = "1900-12-01"))

  #Allows for NAs
  check_function_arg.date.fromtoat(from = "1997/01/01", to = NA)
  check_function_arg.date.fromtoat(from = NA, to = "1997/01/01")
  check_function_arg.date.fromtoat(at = NA)

})

test_that("check_function_output works as intended", {


  ########## fetch scenario
  in_1_fetch <- tibble::tibble(ID = c("A-100", "A-100", "A-101", NA))

  out_1_fetch <- tibble::tibble(ID = c("A-100", "A-100",  "A-101", NA), ## matching different key
                                offspringID = c("A-999", "A-998", NA, "A-997"))

  expect_error(check_function_output(input.tbl = in_1_fetch,
                                     output.tbl = out_1_fetch,
                                     join.by = "ID",
                                     duplicates = "input",
                                     output.IDcolumn = "sex",
                                     debug = FALSE)) ## matching different key

  ###
  out_2_fetch <- tibble::tibble(ID = c("A-100", "A-100","A-101", NA),  ## matching different key (eventhoug they are simillar)
                                sex = c("Female", "Female", "Male", NA))

  expect_error(check_function_output(input.tbl = in_1_fetch,
                                     output.tbl = out_2_fetch,
                                     join.by = "ID",
                                     duplicates = "input",
                                     output.IDcolumn = "sex",
                                     debug = FALSE))


  ###
  out_3_fetch <- tibble::tibble(ID = c("A-100", "A-101", NA),
                                sex = c("Female", "Male", NA))


  ref1 <- c("Female", "Female", "Male", NA)
  job1 <- check_function_output(input.tbl = in_1_fetch,
                                output.tbl = out_3_fetch,
                                join.by = "ID",
                                duplicates = "input",
                                output.IDcolumn = "sex",
                                debug = FALSE)


  expect_equal(job1, ref1)

  ### create scenario // need unique input
  in_1_create <- tibble::tibble(ID = c("A-100", "A-100", "A-101", NA),
                        date = c("1999-01-01", "2001-01-01", "1999-01-01",NA))

  out_1_create <- tibble::tibble(ID = c("A-100", "A-100", "A-100", "A-101", NA),
                         date = c("1999-01-01", "2001-01-01","2001-01-01", "1999-01-01", NA),
                         offspringID = c("A-999", "A-998", "A-450", NA, NA))

  expect_error(check_function_output(input.tbl = in_1_create,
                                     output.tbl = out_1_create,
                                     join.by = "ID", ## duplicated ID in input.tbl
                                     duplicates = "output",
                                     output.IDcolumn = NULL,
                                     debug = FALSE))
  ###
  ref2 <- tibble::tibble(ID = c("A-100", "A-100", "A-100", "A-101", NA),
                 date = c("1999-01-01", "2001-01-01",  "2001-01-01", "1999-01-01", NA),
                 offspringID = c("A-999", "A-998", "A-450", NA, NA))

  job2 <- check_function_output(input.tbl = in_1_create,
                                output.tbl = out_1_create,
                                join.by = c("ID", "date"), ## unique combination of ID and date
                                duplicates = "output",
                                output.IDcolumn = NULL,
                                debug = FALSE)

  expect_equal(ref2, job2)

  ## missmatches in variable types:
  in_1 <- tibble::tibble(ID = factor(c("A-100", "A-100", "A-101", NA)))
  out_1 <- tibble::tibble(ID = c("A-100", "A-101", NA))
  expect_error(check_function_output(input.tbl = in_1,
                                     output.tbl = out_1,
                                     join.by = "ID", ## unique combination of ID and date
                                     duplicates = "input",
                                     output.IDcolumn = "ID",
                                     debug = FALSE))

})


test_that("check_function_arg.CPUcores works as intended", {
  expect_error(check_function_arg.CPUcores(Inf))
  expect_error(check_functiob_arg.CPUcored(NA))
  expect_equal(check_function_arg.CPUcores(2, verbose = FALSE), 2)
  expect_equal(check_function_arg.CPUcores(NULL), 2)
})


test_that("check_function_arg.verbose works as intended", {
  expect_error(check_function_arg.verbose(NA))
  expect_error(check_function_arg.verbose("bla"))
  expect_true(check_function_arg.verbose(NULL))
  expect_true(check_function_arg.verbose(TRUE))
  expect_false(check_function_arg.verbose(FALSE))
})

test_that("check_function_arg.lifestage works as intended", {

  #Works with regular life stages and allows for multiple life stages by default
  ref1 <- c("cub", "subadult")
  job1 <- check_function_arg.lifestage(c("cub", "subadult"))
  expect_equal(ref1, job1)

  #Fills in all life stages except dead when .fill = TRUE and fill.dead = FALSE
  ref2 <- c("cub", "disperser", "foreigner_1", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "subadult", "transient",
            "founder_male", "unknown",
            "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job2 <- check_function_arg.lifestage(.fill = TRUE)
  expect_equal(sort(ref2), sort(job2))

  #Negates a single lifestage when using !
  ref3 <- c("cub", "disperser", "foreigner_1", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "subadult", "transient",
            "founder_male", "unknown",
            "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job3 <- check_function_arg.lifestage(lifestage = "!dead")
  expect_equal(sort(ref3), sort(job3))

  #Negates multiple lifestages using !
  ref4 <- c("disperser", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "subadult", "transient",
            "founder_male", "unknown",
            "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job4 <- check_function_arg.lifestage(lifestage = c("!foreigner_1", "!cub"))
  expect_equal(sort(ref4), sort(job4))

  #Recodes meta-lifestages correctly
  ref5a <- c("disperser", "philopatric", "selector_2", "selector_3",
             "selector_4", "selector_5")
  job5a <- check_function_arg.lifestage(lifestage = "selector")
  expect_equal(sort(ref5a), sort(job5a))

  ref5b <- c("disperser", "foreigner_1", "natal", "philopatric", "selector_2",
             "selector_3", "selector_4", "selector_5", "transient",
             "founder_male", "unknown",
             "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job5b <- check_function_arg.lifestage(lifestage = "adult")
  expect_equal(sort(ref5b), sort(job5b))

  ref5c <- c("cub", "dead", "disperser", "foreigner_1", "natal", "philopatric",
             "selector_2", "selector_3", "selector_4", "selector_5", "subadult",
             "transient",
             "founder_male", "unknown",
             "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job5c <- check_function_arg.lifestage(lifestage = "all")
  expect_equal(sort(ref5c), sort(job5c))

  ref5d <- c("cub", "natal", "subadult")
  job5d <- check_function_arg.lifestage(lifestage = "preselector")
  expect_equal(sort(ref5d), sort(job5d))

  ref5e <- c("foreigner_1", "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job5e <- check_function_arg.lifestage(lifestage = "foreigner")
  expect_equal(sort(ref5e), sort(job5e))

  ref5f <- c("cub", "subadult", "natal", "philopatric")
  job5f <- check_function_arg.lifestage(lifestage = "native")
  expect_equal(sort(ref5f), sort(job5f))

  ref5g <- c("philopatric", "disperser", "founder_male", "selector_2", "selector_3",
             "selector_4", "selector_5",
             "foreigner_1", "foreigner_2", "foreigner_3", "foreigner_4", "foreigner_5")
  job5g <- check_function_arg.lifestage(lifestage = "sexually_active")
  expect_equal(sort(ref5g), sort(job5g))

  #Negates meta-lifestages correctly
  ref7 <- c("cub", "natal", "subadult", "transient", "unknown")
  job7 <- check_function_arg.lifestage(lifestage = "!sexually_active")
  expect_equal(sort(ref7), sort(job7))

  #Order of lifestage output is alphabetical
  job8  <- check_function_arg.lifestage(lifestage = c("philopatric", "disperser"))
  job9  <- check_function_arg.lifestage(lifestage = c("disperser", "philopatric"))
  job10 <- check_function_arg.lifestage(lifestage = c("!cub", "!subadult", "!natal", "!transient",
                                                      "!foreigner", "!selector_2", "!selector_3", "!selector_4",
                                                      "!selector_5", "!founder_male",
                                                      "!foreigner_2", "!foreigner_3", "!foreigner_4",
                                                      "!foreigner_5", "!unknown"))
  expect_equal(sort(job8), sort(job9))
  expect_equal(sort(job9), sort(job10))

  #Fails when too many life stages are provided
  expect_error(check_function_arg.lifestage(lifestage = c("cub", "subadult"), arg.max.length = 1))

  #Fails when incorrect life stages are given
  expect_error(check_function_arg.lifestage(lifestage = "wrong!"))

  #Fails when trying to negate and add at the same time
  expect_error(check_function_arg.lifestage(lifestage = c("!dead", "adult")))

  #Fails when no lifestage are provided and .fill = FALSE
  expect_error(check_function_arg.lifestage(lifestage = NULL, .fill = FALSE))

  #Recoding new 'alive' lifestage works as expected
  ref11 <- check_function_arg.lifestage(.fill = TRUE)
  job11 <- check_function_arg.lifestage(lifestage = "alive")
  expect_equal(ref11, job11)

})

test_that("check_function_arg.age works as intended", {

  #Fails if given character string
  expect_error(check_function_arg.age("ZZZ"))

  #Fails if given negative value
  expect_error(check_function_arg.age(-10))

  #Works for integer and double
  expect_equal(10L, check_function_arg.age(10L))
  expect_equal(6.5, check_function_arg.age(6.5))

  #Add test for working with vector
  expect_equal(c(10L, 11L), check_function_arg.age(age = c(10L, 11L)))

})

test_that("check_function_arg.location.weather behaves as expected", {

  #Can take a single correct location
  expect_equal(check_function_arg.location.weather("acacia"), "acacia")

  #Can take multiple correct locations
  expect_equal(check_function_arg.location.weather(c("acacia", "ngoitokitok")), c("acacia", "ngoitokitok"))

  #Can take duplicate (correct) inputs
  expect_equal(check_function_arg.location.weather(c("acacia", "acacia")), c("acacia", "acacia"))

  #Throws error if we give a location that is not accepted
  expect_error(check_function_arg.location.weather("fail"))

})

test_that("check_function_arg.station behaves as expected", {

  #Can take a single correct station
  expect_equal(check_function_arg.station("jua"), "jua")

  #Can take multiple correct stations
  expect_equal(check_function_arg.station(c("jua", "upepo")), c("jua", "upepo"))

  #Can take duplicate (correct) stations
  expect_equal(check_function_arg.station(c("jua", "jua")), c("jua", "jua"))

  #Throws error if we give a station that is not accepted
  expect_error(check_function_arg.station("fail"))

})

test_that("check_function_arg.variable.weather behaves as expected", {

  #Can take a single correct variable
  expect_equal(check_function_arg.variable.weather("temp"), "air_temp")

  #Can take multiple correct variables
  expect_equal(check_function_arg.variable.weather(c("temp", "rain")), c("air_temp", "precip"))

  #Will fill when NULL
  expect_equal(check_function_arg.variable.weather(NULL), c("air_temp", "precip", "precip_max_hourly", "relative_humidity",
                                                            "atmospheric_pressure", "battery_percent"))

  #Throws error if we give a location that is not accepted
  expect_error(check_function_arg.variable.weather("fail"))

})

test_that("check_df_sf behaves as expected", {

  #This should succeed
  input <- data.frame(latitude = c(1, 2, 3), longitude = c(2, 3, 4))
  expect_equal(check_df_sf(input), input)

  #This should fail!
  input2 <- data.frame(lat = c(1, 2, 3), long = c(2, 3, 4))
  expect_error(check_df_sf(input2))

})

test_that("check_weatherstation_metadata.all behaves as expected", {

  #This meta-data should pass fine
  pass_metadata <- structure(list(file_number = c(1L, 1L, 2L, 2L),
                                  metadata_category = c("configuration",
                                                        "location", "configuration", "location"),
                                  data = list(structure(list(info = c("device_name", "site_name", "serial_number", "device_type",
                                                                      "firmware_version", "hardware_version", "measurement_interval"),
                                                             value = c("jua", "ngoitokitok", "z6-08626", "zl6", "2.07.3",
                                                                       "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L)),
                                              structure(list(info = c("device_name",
                                                                      "site_name", "serial_number", "device_type", "firmware_version",
                                                                      "hardware_version", "measurement_interval"),
                                                             value = c("jua",
                                                                       "ngoitokitok", "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L))),
                                  any_error = c(FALSE, FALSE, FALSE, FALSE),
                                  messages = list(NA_character_, NA_character_, NA_character_,
                                                  NA_character_)),
                             row.names = c(NA, -4L),
                             class = c("tbl_df", "tbl", "data.frame"))

  expect_equal(check_weatherstation_metadata.all(pass_metadata), pass_metadata)

  #This will fail because coordinates don't match
  fail_metadata <- structure(list(file_number = c(1L, 1L, 2L, 2L),
                                  metadata_category = c("configuration",
                                                        "location", "configuration", "location"),
                                  data = list(structure(list(info = c("device_name", "site_name", "serial_number", "device_type",
                                                                      "firmware_version", "hardware_version", "measurement_interval"),
                                                             value = c("jua", "ngoitokitok", "z6-08626", "zl6", "2.07.3",
                                                                       "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L)),
                                              structure(list(info = c("device_name",
                                                                      "site_name", "serial_number", "device_type", "firmware_version",
                                                                      "hardware_version", "measurement_interval"),
                                                             value = c("jua",
                                                                       "ngoitokitok", "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L))),
                                  any_error = c(FALSE, FALSE, FALSE, FALSE),
                                  messages = list(NA_character_, NA_character_, NA_character_,
                                                  NA_character_)),
                             row.names = c(NA, -4L),
                             class = c("tbl_df", "tbl", "data.frame"))

  expect_error(check_weatherstation_metadata.all(fail_metadata))

  #This will fail because serial numbers don't match
  fail_metadata <- structure(list(file_number = c(1L, 1L, 2L, 2L),
                                  metadata_category = c("configuration",
                                                        "location", "configuration", "location"),
                                  data = list(structure(list(info = c("device_name", "site_name", "serial_number", "device_type",
                                                                      "firmware_version", "hardware_version", "measurement_interval"),
                                                             value = c("jua", "ngoitokitok", "z6-08627", "zl6", "2.07.3",
                                                                       "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L)),
                                              structure(list(info = c("device_name",
                                                                      "site_name", "serial_number", "device_type", "firmware_version",
                                                                      "hardware_version", "measurement_interval"),
                                                             value = c("jua",
                                                                       "ngoitokitok", "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L))),
                                  any_error = c(FALSE, FALSE, FALSE, FALSE),
                                  messages = list(NA_character_, NA_character_, NA_character_,
                                                  NA_character_)),
                             row.names = c(NA, -4L),
                             class = c("tbl_df", "tbl", "data.frame"))

  expect_error(check_weatherstation_metadata.all(fail_metadata))

  #This will throw warning because data collection frequency differs
  warn_metadata <- structure(list(file_number = c(1L, 1L, 2L, 2L),
                                  metadata_category = c("configuration",
                                                        "location", "configuration", "location"),
                                  data = list(structure(list(info = c("device_name", "site_name", "serial_number", "device_type",
                                                                      "firmware_version", "hardware_version", "measurement_interval"),
                                                             value = c("jua", "ngoitokitok", "z6-08626", "zl6", "2.07.3",
                                                                       "3", "20_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L)),
                                              structure(list(info = c("device_name",
                                                                      "site_name", "serial_number", "device_type", "firmware_version",
                                                                      "hardware_version", "measurement_interval"),
                                                             value = c("jua",
                                                                       "ngoitokitok", "z6-08626", "zl6", "2.07.3", "3", "30_minutes"),
                                                             error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -7L)),
                                              structure(list(info = c("latitude", "longitude", "logger_time",
                                                                      "time_zone", "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
                                                                      "altitude"),
                                                             value = c("-3.2094856", "35.6006366", "11/30/21_12:00:50",
                                                                       "utc+03", "12", "5", "1096", "1759.987"),
                                                             error = c(FALSE, FALSE,
                                                                       FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
                                                             message = c(NA_character_,
                                                                         NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
                                                                         NA_character_, NA_character_)),
                                                        class = c("tbl_df", "tbl", "data.frame"),
                                                        row.names = c(NA, -8L))),
                                  any_error = c(FALSE, FALSE, FALSE, FALSE),
                                  messages = list(NA_character_, NA_character_, NA_character_,
                                                  NA_character_)),
                             row.names = c(NA, -4L),
                             class = c("tbl_df", "tbl", "data.frame"))

  expect_warning(job <- check_weatherstation_metadata.all(warn_metadata))
  expect_equal(job, warn_metadata)

})

test_that("check_function_arg.clan works as intended", {

  #Fails when given wrong clan
  expect_error(check_function_arg.clan(clan = "WRONG!"))

  #Works when given correct clans (including Y)
  # ref <- c("A", "S", "Y")
  # job <- check_function_arg.clan(c("A", "S", "Y"))
  # expect_equal(ref, job)

  #Returns clans if asked
  ref2 <- sort(c("A", "L", "M", "N", "S"))
  job2 <- sort(check_function_arg.clan(.fill = TRUE, main.clans = TRUE))
  expect_equal(ref2, job2)

  #Can return all clans (including Y)
  # ref3 <- sort(c("A", "L", "M", "N", "S", "Y", "X"))
  # job3 <- sort(check_function_arg.clan(.fill = TRUE, main.clans = FALSE))
  # expect_equal(ref3, job3)

})

