context("Test recode_xxx functions")

test_that("recode_offspring.sex_litter.type returns an output of the correct class", {
  expect_equal(class(recode_offspring.sex_litter.type(1, 1, 1, 1, 1, 1)), "character")
})

test_that("recode_offspring.sex_litter.type returns the correct output", {
  ref <- list(daughters.nb = 1, sons.nb = 1, unknown.nb = 1, social.daughters.nb = 1, social.sons.nb = 1, social.unknown.nb = 1)
  job <- check_function_arg.litter.type(1, 1, 1, 1, 1, 1)
  expect_equal(ref, job)
})

test_that("recode_lifestage_meta.to.raw returns the correct output", {
  ref1 <- c("disperser", "foreigner_1", "natal", "philopatric", "selector_2",
            "selector_3", "selector_4", "selector_5", "transient",
            "founder_male", "unknown",
            "foreigner_2",
            "foreigner_3", "foreigner_4", "foreigner_5")
  job1 <- recode_lifestage_meta.to.raw("adult")
  expect_identical(sort(ref1), sort(job1))

  ref2 <- c("disperser", "philopatric", "selector_2", "selector_3",
            "selector_4", "selector_5")
  job2 <- recode_lifestage_meta.to.raw("selector")
  expect_identical(sort(ref2), sort(job2))
})

test_that("recode_rank.abs_rank.std returns the correct output", {
  ref <- seq(1, -1, length = 10)
  job <- recode_rank.abs_rank.std(1:10)
  expect_equal(ref, job)
})

test_that("Excel date-time converter matches expected output", {

  ref <- structure(1602593217, class = c("POSIXct", "POSIXt"), tzone = "UTC")
  job <- recode_numeric_excel.to.date(44117.5326, tz = "UTC")

  expect_identical(ref, job)

})

test_that("We can recode to snake case correctly", {

  #Should convert everything to lower case snake *except* when the term ID occurs
  #at the end of the character string

  #Test 1: Can convert single character string
  job1 <- recode_chr_snake.case("Device Name")
  ref1 <- "device_name"
  expect_equal(job1, ref1)

  #Test 2: Can work on vectors
  job2 <- recode_chr_snake.case(c("Device Name", "Hyena ID", "Kid ID"))
  ref2 <- c("device_name", "hyena_ID", "kid_ID")
  expect_equal(job2, ref2)

})

test_that("We can recode a data frame into sf object", {

  #Input weather data example
  input <- load_data_weatherstation.file(system.file("extdata/weather_Mlima", "weather_data_test1.xlsx",
                                                     package = "hyenaR"))

  #Recode
  job1 <- recode_df_sf(input, crs = 4326)

  expect_equal(class(job1)[1], "sf")
  expect_equal(sf::st_crs(job1), sf::st_crs(4326))

  #We can use custom CRS if desired
  #This is the projection for Kenya and TZ
  job2 <- recode_df_sf(input, crs = 32736)

  expect_equal(class(job2)[1], "sf")
  expect_equal(sf::st_crs(job2), sf::st_crs(32736))

})
