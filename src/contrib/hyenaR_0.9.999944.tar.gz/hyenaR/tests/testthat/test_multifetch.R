context("Test multifetch_xxx functions")

test_that("all multifetch functions return the correct type of output", {

  expect_equal(class({
    create_id_starting.table(clan = "A", at = "1997-01-01") %>%
      mutate(date = as.Date("1997-01-01")) %>%
      join_allranks()
  })[1], "tbl_df")
  expect_equal(class(multifetch_id_offspring.count("A-001"))[1], "tbl_df")
  expect_equal(class(multifetch_litter_offspring.count("A-001_003"))[1], "tbl_df")
  expect_equal(class(multifetch_id_birth.info("A-001"))[1], "tbl_df")

})

test_that("multifetch_id_offspring.count returns the correct output", {
  ref <-
    structure(
      list(
        n_females = 3L,
        n_males = 3L,
        n_unknown = 0L
      ),
      row.names = c(NA,-1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- multifetch_id_offspring.count("A-001")
  expect_equal(ref, job)
})

test_that("multifetch_litter_offspring.count returns the correct output",
          {
            ref <-
              structure(
                list(
                  female = 1L,
                  male = 1L,
                  unknown = 0L,
                  social.female = 0L,
                  social.male = 0L,
                  social.unknown = 0L
                ),
                row.names = c(NA,-1L),
                class = c("tbl_df", "tbl", "data.frame")
              )
            job <- multifetch_litter_offspring.count("A-001_003")
            expect_equal(ref, job)
          })

test_that("multifetch_clan_obsv.effort returns the correct output", {

  expect_equal(class(multifetch_clan_obsv.effort(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  ref <-
    structure(
      list(
        effort_adult = c(11/34, 21/26),
        effort_cub = c(10/23, 16/20),
        effort_all = c(21/57, 37/46)
      ),
      row.names = c(NA,-2L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  #We keep the new argument just to make sure we can compare new & and old method
  #Use Aug 97 to check that conception sightings are removed
  job <- multifetch_clan_obsv.effort(clan = c("A", "L"), from = "1997-08-01", to = "1997-09-01")
  expect_equal(ref, job)

})

test_that("multifetch_id_birth.info works as intended", {
  ref <- structure(
    list(
      sex = c("female", "female", "male"),
      motherID = c(NA,"A-015", "A-006"),
      fatherID = c(NA, "A-045", "A-045"),
      birthdate = structure(c(6715,8906, 10088),
                            class = "Date"),
      clan.birth = c("A", "A", "A"),
      clan.conception = c(NA, "A", "A")),
    row.names = c(NA,-3L),
    class = c("tbl_df", "tbl", "data.frame"))
  job <- multifetch_id_birth.info(ID = c("A-001", "A-008", "A-100"))
  expect_equal(ref, job)
})

test_that("multifetch_weather_temp.summary works as intended", {

  #Works for one station
  ref1 <- structure(list(from = "2021-10-01",
                         to = "2021-10-31",
                         station = "jua",
                         ngoitokitok_air_temp_mean = 19.4981458333333,
                         ngoitokitok_air_temp_max = 28.96,
                         ngoitokitok_air_temp_min = 8.31,
                         ngoitokitok_air_temp_sd = 4.65329532170195),
                    class = "data.frame", row.names = c(NA, -1L))
  job1 <- data.frame(from = "2021-10-01", to = "2021-10-31",
                     station = "jua") %>%
    dplyr::mutate(multifetch_weather_temp.summary(from = from, to = to, station = station))
  expect_equal(ref1, job1)

  #Works for multiple stations
  ref2 <- structure(list(from = "2021-10-01", to = "2021-10-31", acacia_air_temp_mean = 19.9839583333333,
                         ngoitokitok_air_temp_mean = 19.4981458333333, acacia_air_temp_max = 29.01,
                         ngoitokitok_air_temp_max = 28.96, acacia_air_temp_min = 13.35,
                         ngoitokitok_air_temp_min = 8.31, acacia_air_temp_sd = 3.74950080384318,
                         ngoitokitok_air_temp_sd = 4.65329532170195), class = "data.frame", row.names = c(NA, -1L))
  job2 <- data.frame(from = "2021-10-01", to = "2021-10-31") %>%
    dplyr::mutate(multifetch_weather_temp.summary(from = from, to = to, station = c("jua", "upepo")))
  expect_equal(ref2, job2)
})

test_that("multifetch_weather_temp.summary works as intended", {

  #Works for one station
  ref1 <- structure(list(from = "2021-10-01", to = "2021-10-31", station = "jua",
                         ngoitokitok_precip_mean = 0.013125, ngoitokitok_precip_max = 2.2,
                         ngoitokitok_precip_min = 0, ngoitokitok_precip_sd = 0.119237344473101),
                    class = "data.frame", row.names = c(NA, -1L))
  job1 <- data.frame(from = "2021-10-01", to = "2021-10-31",
                     station = "jua") %>%
    dplyr::mutate(multifetch_weather_rain.summary(from = from, to = to, station = station))
  expect_equal(ref1, job1)

  #Works for multiple stations
  ref2 <- structure(list(from = "2021-10-01", to = "2021-10-31", acacia_precip_mean = 0.0118279569892473,
                         ngoitokitok_precip_mean = 0.013125, acacia_precip_max = 11.6,
                         ngoitokitok_precip_max = 2.2, acacia_precip_min = 0, ngoitokitok_precip_min = 0,
                         acacia_precip_sd = 0.330099359374071, ngoitokitok_precip_sd = 0.119237344473101),
                    class = "data.frame", row.names = c(NA, -1L))
  job2 <- data.frame(from = "2021-10-01", to = "2021-10-31") %>%
    dplyr::mutate(multifetch_weather_rain.summary(from = from, to = to, station = c("jua", "upepo")))
  expect_equal(ref2, job2)
})
