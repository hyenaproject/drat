context("Test functions related to spatial tasks")

## ID LEVEL

test_that("fetch_id_track.table returns the correct output", {
  ref <-
    list(`A-001` = structure(list(x_ = numeric(0), y_ = numeric(0),
                                  t_ = structure(numeric(0), tzone = "Africa/Dar_es_Salaam", class = c("POSIXct",
                                                                                                       "POSIXt")), ID = character(0), sighting_clan = character(0),
                                  from = structure(numeric(0), class = "Date"), to = structure(numeric(0), class = "Date")), row.names = integer(0), class = c("track_xyt",
                                                                                                                                                               "track_xy", "tbl_df", "tbl", "data.frame"), crs_ = structure(list(
                                                                                                                                                                 input = NA_character_, wkt = NA_character_), class = "crs")),
         `A-010` = structure(list(x_ = c(782356.642286882, 780785.760256484,
                                         780583.931808614, 778037.112194223, 778324.512399059), y_ = c(9649140.37939068,
                                                                                                       9651209.90456915, 9651910.75478834, 9648690.63977541, 9652580.0386083
                                         ), t_ = structure(c(832683000, 835513440, 837240300, 837839280,
                                                             837843000), tzone = "Africa/Dar_es_Salaam", class = c("POSIXct",
                                                                                                                   "POSIXt")), ID = c("A-010", "A-010", "A-010", "A-010", "A-010"
                                                                                                                   ), latitude = c(-3.17117, -3.1525, -3.14617, -3.17533, -3.14017
                                                                                                                   ), longitude = c(35.5405, 35.52633, 35.5245, 35.50167, 35.50417
                                                                                                                   ), sighting_clan = c("A", "A", "A", "A", "A"), from = structure(c(9496,
                                                                                                                                                                                     9496, 9496, 9496, 9496), class = "Date"), to = structure(c(9709,
                                                                                                                                                                                                                                                9709, 9709, 9709, 9709), class = "Date")), row.names = c(NA,
                                                                                                                                                                                                                                                                                                         5L), class = c("track_xyt", "track_xy", "tbl_df", "tbl",
                                                                                                                                                                                                                                                                                                                        "data.frame"), crs_ = structure(list(input = NA_character_,
                                                                                                                                                                                                                                                                                                                                                             wkt = NA_character_), class = "crs")))
  options(hyenaR_crs = 32736) ## just in case the system is not set as the default
  job <- fetch_id_track.table(c("A-001", "A-010"),
                              from = c("1996/10/01", "1996/01/01"),
                              to = c("1996/10/02", "1996/08/01"))
  #Check CRS is the same
  expect_equal(amt::get_crs(job[[1]]), sf::st_crs(32736))
  expect_equal(amt::get_crs(job[[2]]), sf::st_crs(32736))
  #Check other elements (ignoring CRS)
  job_dropcrs <- lapply(job, FUN = \(x){attr(x, "crs_") <- sf::st_crs(NA); return(x)})
  expect_equal(ref, job_dropcrs)

  ## Also works with alternative CRS
  options(hyenaR_crs = 4326)
  ref2 <-
    list(`A-001` = structure(list(x_ = numeric(0), y_ = numeric(0),
                                  t_ = structure(numeric(0), tzone = "Africa/Dar_es_Salaam", class = c("POSIXct",
                                                                                                       "POSIXt")), ID = character(0), sighting_clan = character(0),
                                  from = structure(numeric(0), class = "Date"), to = structure(numeric(0), class = "Date")), row.names = integer(0), class = c("track_xyt",
                                                                                                                                                               "track_xy", "tbl_df", "tbl", "data.frame"), crs_ = structure(list(
                                                                                                                                                                 input = NA_character_, wkt = NA_character_), class = "crs")),
         `A-010` = structure(list(x_ = c(35.5405, 35.52633, 35.5245,
                                         35.50167, 35.50417), y_ = c(-3.17117, -3.1525, -3.14617,
                                                                     -3.17533, -3.14017), t_ = structure(c(832683000, 835513440,
                                                                                                           837240300, 837839280, 837843000), tzone = "Africa/Dar_es_Salaam", class = c("POSIXct",
                                                                                                                                                                                       "POSIXt")), ID = c("A-010", "A-010", "A-010", "A-010", "A-010"
                                                                                                                                                                                       ), latitude = c(-3.17117, -3.1525, -3.14617, -3.17533, -3.14017
                                                                                                                                                                                       ), longitude = c(35.5405, 35.52633, 35.5245, 35.50167, 35.50417
                                                                                                                                                                                       ), sighting_clan = c("A", "A", "A", "A", "A"), from = structure(c(9496,
                                                                                                                                                                                                                                                         9496, 9496, 9496, 9496), class = "Date"), to = structure(c(9709,
                                                                                                                                                                                                                                                                                                                    9709, 9709, 9709, 9709), class = "Date")), row.names = c(NA,
                                                                                                                                                                                                                                                                                                                                                                             5L), class = c("track_xyt", "track_xy", "tbl_df", "tbl",
                                                                                                                                                                                                                                                                                                                                                                                            "data.frame"), crs_ = structure(list(input = NA_character_,
                                                                                                                                                                                                                                                                                                                                                                                                                                 wkt = NA_character_), class = "crs")))

  job2 <- fetch_id_track.table(c("A-001", "A-010"),
                               from = c("1996/10/01", "1996/01/01"),
                               to = c("1996/10/02", "1996/08/01"))
  #Check CRS is the same
  expect_equal(amt::get_crs(job2[[1]]), sf::st_crs(4326))
  expect_equal(amt::get_crs(job2[[2]]), sf::st_crs(4326))
  #Check other elements (ignoring CRS)
  job2_dropcrs <- lapply(job2, FUN = \(x){attr(x, "crs_") <- sf::st_crs(NA); return(x)})
  expect_equal(ref2, job2_dropcrs)
  options(hyenaR_crs = 32736)

})

test_that("fetch_id_homerange returns the correct output", {

  #Also works with alternative crs
  ref2 <-
    structure(
      list(structure(list(), class = c(
        "XY", "POLYGON", "sfg"
      )), structure(
        list(structure(
          c(782356.642286882, 778324.512399059,
            780583.931808614, 782356.642286882, 9649140.37939068, 9652580.0386083,
            9651910.75478834, 9649140.37939068),
          dim = c(4L, 2L),
          dimnames = list(c("1", "4", "3", "1"), c("x_", "y_"))
        )), class = c("XY", "POLYGON", "sfg")
      )),
      class = c("sfc_POLYGON", "sfc"),
      precision = 0,
      bbox = structure(
        c(xmin = 778324.512399059,
          ymin = 9649140.37939068, xmax = 782356.642286882, ymax = 9652580.0386083),
        class = "bbox"
      ),
      crs = structure(list(input = NA_character_,
                           wkt = NA_character_), class = "crs"),
      n_empty = 1L)

  job2 <- fetch_id_homerange(c("A-001", "A-010"),
                             from = c("1996/10/01", "1996/01/01"),
                             to = c("1996/10/02", "1996/08/01"))
  #Check CRS is the same
  expect_equal(sf::st_crs(job2), sf::st_crs(32736))
  #Check other elements (ignoring CRS)
  expect_equal(ref2, sf::st_set_crs(job2, NA))

  options(hyenaR_crs = 4326)
  ref <-
    structure(
      list(structure(list(), class = c(
        "XY", "POLYGON", "sfg"
      )), structure(
        list(structure(
          c(35.5405001848823, 35.5041709438393,
            35.5245005733263, 35.5405001848823,
            -3.17116905652504, -3.14016945001626,
            -3.14616916655118, -3.17116905652504),
          dim = c(4L, 2L),
          dimnames = list(c("1", "4", "3", "1"), c("x_", "y_"))
        )), class = c("XY", "POLYGON", "sfg")
      )),
      class = c("sfc_POLYGON", "sfc"),
      precision = 0,
      bbox = structure(
        c(xmin = 35.5041709438393,
          ymin = -3.17116905652504,
          xmax = 35.5405001848823,
          ymax = -3.14016945001626
        ),
        class = "bbox"
      ),
      crs = structure(list(input = NA_character_,
                           wkt = NA_character_), class = "crs"),
      n_empty = 1L)

  skip_if_not_installed("lwgeom")
  job <- fetch_id_homerange(c("A-001", "A-010"),
                            from = c("1996/10/01", "1996/01/01"),
                            to = c("1996/10/02", "1996/08/01"))
  #Check CRS is the same
  expect_equal(sf::st_crs(job), sf::st_crs(4326))
  #Check other elements (ignoring CRS)
  expect_equal(ref, sf::st_set_crs(job, NA))
  options(hyenaR_crs = 32736)

})

test_that("fetch_id_homerange.area returns the correct output", {
  ref <- c(`A-001` = NA, `A-010` = 2.544828)
  skip_if_not_installed("lwgeom")
  job <- fetch_id_homerange.area(c("A-001", "A-010"),
                                  from = c("1996/10/01", "1996/01/01"),
                                  to = c("1996/10/02", "1996/08/01"))
  expect_equal(ref, job, tolerance = 0.01)

  #Also works with alternative CRS
  #We should actually get almost identical area. So should match previous ref
  options(hyenaR_crs = 4326)
  job2 <- fetch_id_homerange.area(c("A-001", "A-010"),
                                 from = c("1996/10/01", "1996/01/01"),
                                 to = c("1996/10/02", "1996/08/01"))
  expect_equal(ref, job2, tolerance = 0.01)
  options(hyenaR_crs = 32736)

})


## CLAN LEVEL

test_that("fetch_clan_track.table returns the correct output", {

  ref2 <-
    list(
      A = structure(
        list(
          x_ = numeric(0),
          y_ = numeric(0),
          t_ = structure(
            numeric(0),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct", "POSIXt")
          ),
          ID = character(0),
          sighting_clan = character(0),
          clan = character(0),
          from = structure(numeric(0), class = "Date"),
          to = structure(numeric(0), class = "Date")
        ),
        row.names = integer(0),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(list(input = NA_character_,
                              wkt = NA_character_), class = "crs")
      ),
      L = structure(
        list(
          x_ = c(789171.906088063, 789042.61314397,
                 788577.996029234, 788539.802358731, 783781.489356657),
          y_ = c(9646855.15935022,
                 9646744.83818192, 9646414.06903856, 9645824.41265073, 9648307.04301946),
          t_ = structure(
            c(827992380, 827992500, 827992920, 827993400, 827996280),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct",
                      "POSIXt")
          ),
          ID = c("L-011", "L-009", "L-009", "L-002", "L-004"),
          latitude = c(-3.19167, -3.19267, -3.19567, -3.201, -3.17867),
          longitude = c(35.60183, 35.60067, 35.5965, 35.59617, 35.55333),
          sighting_clan = c("L", "L", "L", "L", "L"),
          clan = c("L", "L", "L", "L", "L"),
          from = structure(c(9556, 9556, 9556, 9556, 9556), class = "Date"),
          to = structure(c(9587, 9587, 9587, 9587, 9587), class = "Date")
        ),
        row.names = c(NA, 5L),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(list(input = NA_character_,
                              wkt = NA_character_), class = "crs")
      )
    )
  job2 <- fetch_clan_track.table(c("A", "L"),
                                 sex = "female",
                                 lifestage = "adult",
                                 from = c("1996/10/01", "1996/03/01"),
                                 to = c("1996/10/02", "1996/04/01"))
  #Check CRS is the same
  expect_equal(amt::get_crs(job2[[1]]), sf::st_crs(32736))
  expect_equal(amt::get_crs(job2[[2]]), sf::st_crs(32736))
  #Check other elements (ignoring CRS)
  job2_dropcrs <- lapply(job2, FUN = \(x){attr(x, "crs_") <- sf::st_crs(NA); return(x)})
  expect_equal(ref2, job2_dropcrs)

  #Also works with alternative CRS
  options(hyenaR_crs = 4326)
  ref <-
    list(
      A = structure(
        list(
          x_ = numeric(0),
          y_ = numeric(0),
          t_ = structure(
            numeric(0),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct", "POSIXt")
          ),
          ID = character(0),
          sighting_clan = character(0),
          clan = character(0),
          from = structure(numeric(0), class = "Date"),
          to = structure(numeric(0), class = "Date")
        ),
        row.names = integer(0),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(list(input = NA_character_,
                              wkt = NA_character_), class = "crs")
      ),
      L = structure(
        list(
          x_ = c(35.60183, 35.60067, 35.5965, 35.59617, 35.55333),
          y_ = c(-3.19167,-3.19267,-3.19567,-3.201,-3.17867),
          t_ = structure(
            c(827992380, 827992500, 827992920, 827993400, 827996280),
            tzone = "Africa/Dar_es_Salaam",
            class = c("POSIXct",
                      "POSIXt")
          ),
          ID = c("L-011", "L-009", "L-009", "L-002", "L-004"),
          sighting_clan = c("L", "L", "L", "L", "L"),
          clan = c("L", "L", "L", "L", "L"),
          from = structure(c(9556, 9556, 9556, 9556, 9556), class = "Date"),
          to = structure(c(9587, 9587, 9587, 9587, 9587), class = "Date")
        ),
        row.names = c(NA, 5L),
        class = c("track_xyt", "track_xy", "tbl_df", "tbl", "data.frame"),
        crs_ = structure(list(input = NA_character_,
                              wkt = NA_character_), class = "crs")
      )
    )
  job <- fetch_clan_track.table(c("A", "L"),
                                sex = "female",
                                lifestage = "adult",
                                from = c("1996/10/01", "1996/03/01"),
                                to = c("1996/10/02", "1996/04/01"))
  #Check CRS is the same
  expect_equal(amt::get_crs(job[[1]]), sf::st_crs(4326))
  expect_equal(amt::get_crs(job[[2]]), sf::st_crs(4326))
  #Check other elements (ignoring CRS)
  job_dropcrs <- lapply(job, FUN = \(x){attr(x, "crs_") <- sf::st_crs(NA); return(x)})
  expect_equal(ref, job_dropcrs)
  options(hyenaR_crs = 32736)

})

test_that("fetch_clan_homerange returns the correct output", {

  ref2 <-
    structure(
      list(structure(list(), class = c(
        "XY", "POLYGON", "sfg"
      )), structure(
        list(structure(
          c(788539.802358731, 788577.996029234,
            789171.906088063, 788539.802358731, 9645824.41265073, 9646414.06903856,
            9646855.15935022, 9645824.41265073),
          dim = c(4L, 2L),
          dimnames = list(c("4", "3", "1", "4"), c("x_", "y_"))
        )), class = c("XY",
                      "POLYGON", "sfg")
      )),
      class = c("sfc_POLYGON", "sfc"),
      precision = 0,
      bbox = structure(
        c(xmin = 788539.802358731,
          ymin = 9645824.41265073, xmax = 789171.906088063, ymax = 9646855.15935022),
        class = "bbox"
      ),
      crs = structure(list(input = NA_character_,
                           wkt = NA_character_), class = "crs"),
      n_empty = 1L)

  job2 <- fetch_clan_homerange(c("A", "L"),
                               sex = "female",
                               lifestage = "adult",
                               from = c("1996/10/01", "1996/03/01"),
                               to = c("1996/10/02", "1996/04/01"))
  #Check CRS is the same
  expect_equal(sf::st_crs(job2), sf::st_crs(32736))
  #Check other elements (ignoring CRS)
  expect_equal(ref2, sf::st_set_crs(job2, NA))

  #Also works with other CRS
  options(hyenaR_crs = 4326)
  ref <-
    structure(
      list(structure(list(), class = c(
        "XY", "POLYGON", "sfg"
      )), structure(
        list(structure(
          c(35.5961701680519, 35.5965005733263,
            35.6018301848823, 35.5961701680519,
            -3.20099953198148, -3.19566916655118,
            -3.19166905652504, -3.20099953198148),
          dim = c(4L, 2L),
          dimnames = list(c("4", "3", "1", "4"), c("x_", "y_"))
        )), class = c("XY",
                      "POLYGON", "sfg")
      )),
      class = c("sfc_POLYGON", "sfc"),
      precision = 0,
      bbox = structure(
        c(xmin = 35.5961701680519,
          ymin = -3.20099953198148,
          xmax = 35.6018301848823,
          ymax = -3.19166905652504
        ),
        class = "bbox"
      ),
      crs = structure(list(input = NA_character_,
                           wkt = NA_character_), class = "crs"),
      n_empty = 1L)

  skip_if_not_installed("lwgeom")
  job <- fetch_clan_homerange(c("A", "L"),
                              sex = "female",
                              lifestage = "adult",
                              from = c("1996/10/01", "1996/03/01"),
                              to = c("1996/10/02", "1996/04/01"))
  #Check CRS is the same
  expect_equal(sf::st_crs(job), sf::st_crs(4326))
  #Check other elements (ignoring CRS)
  expect_equal(ref, sf::st_set_crs(job, NA))
  options(hyenaR_crs = 32736)

})

test_that("fetch_clan_homerange.area returns the correct output", {

  ref <- c(A = NA, L = 0.1672087)

  skip_if_not_installed("lwgeom")
  job <- fetch_clan_homerange.area(c("A", "L"),
                                    sex = "female",
                                    lifestage = "adult",
                                    from = c("1996/10/01", "1996/03/01"),
                                    to = c("1996/10/02", "1996/04/01"))
  expect_equal(ref, job, tolerance = 0.01)

  #Also works with alternative CRS
  job2 <- fetch_clan_homerange.area(c("A", "L"),
                                   sex = "female",
                                   lifestage = "adult",
                                   from = c("1996/10/01", "1996/03/01"),
                                   to = c("1996/10/02", "1996/04/01"))
  expect_equal(ref, job2, tolerance = 0.01)

})


context("Test presence of spatial objets")

test_that("sf_hyenaR is available and of correct length", {
  expect_length(sf_hyenaR, 12)
})

