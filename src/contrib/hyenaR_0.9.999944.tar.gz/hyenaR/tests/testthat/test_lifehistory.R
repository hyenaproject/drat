context("Test life history data")

test_that("create_id_life.history.table returns data frame", {
  expect_true(inherits(create_id_life.history.table(), "data.frame"))
})

test_that("censored.to.last.sighting argument works correctly", {

  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040", "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080, 7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079, 7444, Inf, 9232, 9597, 9687, Inf), class = "Date"),
        isrightcensored = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE),
        isleftcensored = c(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE)
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA,-7L)
    )

  job <- create_id_life.history.table(c("A-001", "A-040"), censored.to.last.sighting = FALSE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-040", "A-040",
               "A-040", "A-040"),
        clan = c("A", "A", "A", "A", "A", "A", "A"),
        life_stage = c(
          "cub",
          "subadult",
          "philopatric",
          "cub",
          "subadult",
          "natal",
          "philopatric"
        ),
        starting_date = structure(c(6715, 7080,
                                    7445, 8868, 9233, 9598, 9688), class = "Date"),
        ending_date = structure(c(7079,
                                  7444, 10147, 9232, 9597, 9687, 10057), class = "Date"),
        isrightcensored = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE),
        isleftcensored = c(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE)
      ),
      row.names = c(NA,-7L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  job2 <- create_id_life.history.table(c("A-001", "A-040"), censored.to.last.sighting = TRUE)
  expect_identical(ref2, job2)

})

test_that("Founder males are classified correctly", {

  ## All males that were adult at start of study and have clan X birth should be founder male


  ## Test founder individuals behave as expected
  ref <- structure(list(ID = c("A-011", "A-011", "A-011", "A-011"),
                         clan = c("X", "X", "X", "A"),
                         life_stage = c("cub", "subadult", "unknown", "founder_male"),
                         starting_date = structure(c(8139, 8504, 8869, 9598), class = "Date"),
                         ending_date = structure(c(8503, 8868, 9597, Inf), class = "Date"),
                         isrightcensored = c(FALSE, FALSE, FALSE, TRUE),
                         isleftcensored = c(TRUE, TRUE, TRUE, FALSE)),
                    row.names = c(NA, -4L), class = c("tbl_df", "tbl", "data.frame"))

  job <- create_id_life.history.table(ID = "A-011")

  expect_identical(ref, job)

})

test_that("create_id_life.history.table returns the correct output", {

  ## Test that the function produces a warning when not cached
  expect_warning(uncached <- create_id_life.history.table(ID = c("A-001", "A-040"), .cache = FALSE))

  #Test that cached and non-cached output are the same beyond the ending date
  cached   <- create_id_life.history.table(ID = c("A-001", "A-040"), .cache = TRUE)
  uncached %>%
    dplyr::rename(ending_date = "ending_date_na_as_na") %>%
    dplyr::select(-"ending_date_na_as_last_sighting") -> uncached
  expect_identical(cached, uncached)

  ## Same with censoring
  expect_warning(uncached <- create_id_life.history.table(ID = c("A-001", "A-040"),
                                                          censored.to.last.sighting = TRUE,
                                                          .cache = FALSE))
  cached   <- create_id_life.history.table(ID = c("A-001", "A-040"),
                                           censored.to.last.sighting = TRUE,
                                           .cache = TRUE)
  uncached %>%
    dplyr::rename(ending_date = "ending_date_na_as_last_sighting") %>%
    dplyr::select(-"ending_date_na_as_na") -> uncached
  expect_identical(cached, uncached)

})
