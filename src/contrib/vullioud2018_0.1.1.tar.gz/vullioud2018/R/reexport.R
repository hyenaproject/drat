#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`