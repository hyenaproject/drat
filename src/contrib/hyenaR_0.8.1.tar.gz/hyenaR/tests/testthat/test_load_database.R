context("Test that we can load the (dummy) database with load_database()")

test_that("load_database() creates a hidden global object and returns a message when loading dummy data", {

  # Message saying we are using the dummy database
  expect_message(load_database())
  expect_true(exists(".database"))
})
