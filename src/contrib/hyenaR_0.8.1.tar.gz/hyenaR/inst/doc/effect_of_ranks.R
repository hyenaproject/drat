## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
set.seed(1L) ## fix random generator
time1 <- proc.time()
library(hyenaR) ## attach and detach to make sure it is not attached! (otherwise no display message...).
detach(name = "package:hyenaR", unload = TRUE)

## ----split ranks--------------------------------------------------------------
threshold_ranks <- 0.33

## ----loading packages---------------------------------------------------------
library(hyenaR)
library(dplyr)

## ----downloading data, eval = FALSE-------------------------------------------
#  download_primary_data(destfolder = "source_data")  ## only run if database has been updated

## ----build database, eval = FALSE---------------------------------------------
#  build_database(csv_path = "source_data")  ## only run if database has been updated

## ----to not rerun vignette in check if file missing, echo = FALSE-------------
if (!file.exists("source_data/Fisidata.sqlite")) knitr::opts_chunk$set(eval = FALSE)

## ----load database------------------------------------------------------------
load_database(db = "source_data/Fisidata.sqlite")  ## run each time!

## ----create basetable, warning = FALSE----------------------------------------
my_data <- create_basetable()

my_data

## ----create sex, warning = FALSE----------------------------------------------
my_data %>%
   mutate(sex = fetch_sex(ID),
          birthdate = fetch_birthdate(ID)) -> my_data

my_data

## ----fetch dates--------------------------------------------------------------
my_data %>%
  mutate(date2 = fetch_date(ID, age = 2),
         date5 = fetch_date(ID, age = 5)) -> my_data_surv

my_data_surv

## ----fetch surv 2 and 5-------------------------------------------------------
my_data_surv %>%
  mutate(alive2 = fetch_is_alive(ID, date = date2),
         alive5 = fetch_is_alive(ID, date = date5)) -> my_data_surv

my_data_surv

## ----fetch birth rank, warning = FALSE, message = FALSE-----------------------
my_data_surv %>%
  mutate(birthrank = fetch_birthrankstd(ID),
         rank2 = fetch_rankstd(ID, date = date2),
         birthrank_cat = recode_rankstd_to_cat(birthrank, probs = threshold_ranks),
         rank2_cat = recode_rankstd_to_cat(rank2, probs = threshold_ranks)) -> my_data_surv

my_data_surv

## ----tibble options--------------------------------------------------------------------------
options(tibble.width = Inf, width = 95)
my_data_surv

## ----skim data, message = FALSE--------------------------------------------------------------
library(skimr)  ## load the package; if not found just run install.packages("skimr") beforehand! 
skim(my_data_surv)

## ----set skim options------------------------------------------------------------------------
skim_with(character =
            list(missing = get_skimmers("character")[[1]][["missing"]],
                 complete = get_skimmers("character")[[1]][["complete"]],
                 counts = get_skimmers("factor")[[1]][["top_counts"]]),
          append = FALSE)

## ----skim data2------------------------------------------------------------------------------
skim(my_data_surv)

## ----survival to age 2 rough-----------------------------------------------------------------
my_data_surv %>%
  group_by(birthrank_cat, sex) %>%
  summarise(surv2 = mean(alive2, na.rm = TRUE),
            N = n())

## ----survival to age 2 rough no sex----------------------------------------------------------
my_data_surv %>%
  filter(!is.na(birthrank_cat)) %>%
  group_by(birthrank_cat) %>%
  summarise(surv2 = mean(alive2, na.rm = TRUE),
            N = n())

## ----survival to age 2 clean-----------------------------------------------------------------
my_data_surv %>%
  mutate(observable3yr = fetch_is_observable(ID, duration = 3)) %>% 
  filter(!is.na(birthrank_cat) & observable3yr) -> my_data_surv2_clean

skim(my_data_surv2_clean)

## ----survival to age 2 summarise-------------------------------------------------------------
my_data_surv2_clean %>%
  group_by(birthrank_cat) %>%
  summarise(surv2 = mean(alive2, na.rm = TRUE), N = n()) -> table_surv2_summarised

table_surv2_summarised

## ----survival to age 5 clean-----------------------------------------------------------------
my_data_surv %>%
  mutate(observable6yr = fetch_is_observable(ID, duration = 6)) %>% 
  filter(!is.na(rank2_cat) & observable6yr & alive2) -> my_data_surv5_clean
  
my_data_surv5_clean %>%
  group_by(rank2_cat) %>%
  summarise(surv5 = mean(alive5, na.rm = TRUE), N = n()) -> table_surv5_summarised

table_surv5_summarised

## ----def odds_ratio--------------------------------------------------------------------------
odds_ratio <- function(p1, p2) (p1/(1 - p1))/(p2/(1 - p2))

## example:
odds_ratio(0.1, 0.2)

## ----apply odds surv 2-----------------------------------------------------------------------
table_surv2_summarised %>%
  mutate(surv2_bottom = surv2[grepl("100%", birthrank_cat)], ## retrieve survival of low ranking's ID
         odds_ratio = odds_ratio(surv2, surv2_bottom)) -> table_surv2_summarised

table_surv2_summarised

## ----apply odds surv 5-----------------------------------------------------------------------
table_surv5_summarised %>%
  mutate(surv5_bottom = surv5[grepl("100%", rank2_cat)],
         odds_ratio = odds_ratio(surv5, surv5_bottom)) -> table_surv5_summarised

table_surv5_summarised

## ----bind surv tables 1----------------------------------------------------------------------
table_surv2_summarised %>%
            rename(social_rank = birthrank_cat,
                   survival = surv2) %>%
            mutate(what = "survival to 2 yrs \n (all non-censored)") %>%
            select(-surv2_bottom) -> table_surv2_summarised_clean

table_surv2_summarised_clean

## ----bind surv tables 2----------------------------------------------------------------------
table_surv5_summarised %>%
            rename(social_rank = rank2_cat,
                   survival = surv5) %>%
            mutate(what = "survival to 5 yrs \n (all non-censored alive at 2") %>%
            select(-surv5_bottom) -> table_surv5_summarised_clean

table_surv5_summarised_clean

## ----bind surv tables 3----------------------------------------------------------------------
bind_rows(table_surv2_summarised_clean,
          table_surv5_summarised_clean) -> table_surv_for_plot

table_surv_for_plot

## ----load ggplot2----------------------------------------------------------------------------
library(ggplot2)

## ----plot surv, fig.align = 'center', fig.width = 7------------------------------------------
table_surv_for_plot %>%
  ggplot(aes(y = survival, x = social_rank)) +
    geom_bar(stat = "identity", fill = "red") +
    geom_text(aes(label = paste0("N = ", N, ""), y = 0), vjust = -1) + 
    geom_text(aes(label = paste0("+", signif(odds_ratio, 3), " x")), hjust = 0.5, vjust = -1) +
    labs(y = "Survival probability", x = "Social rank") +
    facet_wrap(~ what) + 
    scale_y_continuous(expand = expand_scale(add = c(0, 0.1)))

## ----plot surv 2, fig.align = 'center', fig.width = 7----------------------------------------
theme_set(theme_light())  ## all plots will use a simple theme

table_surv_for_plot %>%
  ggplot(aes(y = survival, x = social_rank)) +
    geom_bar(stat = "identity", fill = "red") +
    geom_text(aes(label = paste0("N = ", N, ""), y = 0), vjust = -1) + 
    geom_text(aes(label = paste0("+", signif(odds_ratio, 3), " x")), hjust = 0.5, vjust = -1) +
    labs(y = "Survival probability", x = "Social rank") +
    facet_wrap(~ what) + 
    scale_y_continuous(expand = expand_scale(add = c(0, 0.1)))

## ----calc_diff2levels------------------------------------------------------------------------
calc_diff2levels <- function(data, y, x, family) {
  data <- as.data.frame(data)
  data$x_f <- factor(data[, x])
  f <- as.formula(paste(y, "~ x_f"))
  model <- glm(f, family = family, data = data)
  out <- as.numeric(confint(multcomp::glht(model,
                                           linfct = multcomp::mcp(x_f = c(1, -1))))$confint)
  names(out) <- c("estimate", "lwr", "upr")
  out
}

## ----CI surv---------------------------------------------------------------------------------
results_surv <- bind_rows(
  signif(exp(calc_diff2levels(my_data_surv2_clean,
                              y = "alive2",
                              x = "birthrank_cat",
                              family = "binomial")), 3),
  signif(exp(calc_diff2levels(my_data_surv5_clean,
                              y = "alive5",
                              x = "rank2_cat",
                              family = "binomial")), 3)) %>%
  mutate(what = c("Odd of surviving till 2 yrs",
                  "Odd of surviving between 2 and 5 yrs"),
         sex = "both",
         N = c(nrow(my_data_surv2_clean),
               nrow(my_data_surv5_clean)))

results_surv

## ----retrieve offspring----------------------------------------------------------------------
data_offspring <- create_offspringtable(ID = find_IDs())

data_offspring

## ----identify offspring of parents under 5---------------------------------------------------
data_offspring %>%
  mutate(date5_parent = fetch_date(ID, age = 5),
         birthdate_offspring = fetch_birthdate(offspring),
         date2_offspring = fetch_date(offspring, age = 2),
         alive2_offspring = fetch_is_alive(offspring, date = date2_offspring),
         observable2_offspring = fetch_is_observable(offspring, duration = 2),
         all_offspring5 = birthdate_offspring < date5_parent & observable2_offspring,
         surviving_offspring5 = (birthdate_offspring < date5_parent) &
                                       alive2_offspring & observable2_offspring) -> data_offspring

data_offspring

skim(data_offspring)

## ----count offspring of parents under 5------------------------------------------------------
data_offspring %>%
  group_by(ID) %>%
  summarise(all_offspring5 = sum(all_offspring5),
            surviving_offspring5 = sum(surviving_offspring5)
            ) -> table_offspring5

table_offspring5

## ----offspring, warning = FALSE--------------------------------------------------------------
table_offspring5 %>%
  mutate(sex = fetch_sex(ID),
         observable5 = fetch_is_observable(ID, duration = 5),
         date5 = fetch_date(ID, age = 5),
         alive5 = fetch_is_alive(ID, date5),
         rank5 = ifelse(sex == "male",
                        fetch_selrankstd(ID, date = date5),
                        fetch_genderrankstd(ID, date = date5)),
         rank5_cat = recode_rankstd_to_cat(rank5, probs = threshold_ranks)
         ) -> table_offspring5

table_offspring5

## ----offspring summary-----------------------------------------------------------------------
table_offspring5 %>%
  filter(observable5 & alive5 & !is.na(rank5_cat) & !is.na(sex)) -> table_offspring5_clean

table_offspring5_clean %>%
  group_by(rank5_cat, sex) %>%
  summarise(mean_RS = mean(all_offspring5, na.rm = TRUE),
            N = n()) %>%
  mutate(who = "All offspring") %>%
  group_by(sex) %>%
  mutate(mean_RS_bottom = mean_RS[grepl("100%", rank5_cat)],
         ratio = mean_RS/mean_RS_bottom) -> table_all_offspring5_summarised

table_all_offspring5_summarised

## ----offspring summary 2---------------------------------------------------------------------
table_offspring5_clean %>%
  group_by(rank5_cat, sex) %>%
  summarise(mean_RS = mean(surviving_offspring5, na.rm = TRUE),
            N = n()) %>%
  mutate(who = "Offspring surviving till 2 yrs") %>%
  group_by(sex) %>%
  mutate(mean_RS_bottom = mean_RS[grepl("100%", rank5_cat)],
         ratio = mean_RS/mean_RS_bottom) -> table_surviving_offspring5_summarised

table_surviving_offspring5_summarised

## ----offspring summary 3---------------------------------------------------------------------
table_offspring5_summarised <- bind_rows(table_all_offspring5_summarised,
                                                table_surviving_offspring5_summarised)

table_offspring5_summarised

## ----offspring all situations plot, fig.align = 'center', fig.width = 5----------------------
table_offspring5_summarised %>%
  ggplot(aes(y = mean_RS, x = 1, fill = rank5_cat)) +
  geom_bar(stat = "identity", position = "dodge2") +
  geom_text(aes(label = paste0("N = ", N, ""), y = 0),
            position = position_dodge2(width = 0.9), vjust = -1) + 
  geom_text(aes(label = paste0("+", signif(ratio, 3), " x")),
            position = position_dodge2(width = 0.9), hjust = 0.5, vjust = -1) +
  labs(y = "Number of offspring produced before 5", x = "") +
  scale_fill_discrete(name = "Social rank") +
  scale_y_continuous(expand = expand_scale(add = c(0, 1))) +
  facet_wrap(~ who + sex) +   
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank())

## ----stats offspring nb----------------------------------------------------------------------
bind_rows(
  signif(exp(calc_diff2levels(df <- table_offspring5_clean %>% filter(sex == "female"),
                   y = "all_offspring5",
                   x = "rank5_cat",
                   family = poisson(link = "log"))), 3),
   signif(exp(calc_diff2levels(dm <- table_offspring5_clean %>% filter(sex == "male"),
                   y = "all_offspring5",
                   x = "rank5_cat",
                   family = poisson(link = "log"))), 3),
    signif(exp(calc_diff2levels(df2 <- table_offspring5_clean %>% filter(sex == "female"),
                   y = "surviving_offspring5",
                   x = "rank5_cat",
                   family = poisson(link = "log"))), 3),
    signif(exp(calc_diff2levels(dm2 <- table_offspring5_clean %>% filter(sex == "male"),
                   y = "surviving_offspring5",
                   x = "rank5_cat",
                   family = poisson(link = "log"))), 3)) %>%
  mutate(what = c("Number of all offspring before 5 yrs",
                  "Number of all offspring before 5 yrs",
                  "Number of surviving offspring before 5 yrs",
                  "Number of surviving offspring before 5 yrs"),
         sex = c("female", "male", "female", "male"),
         N  = c(nrow(df), nrow(dm), nrow(df2), nrow(dm2))) -> results_offspring_nb

results_offspring_nb

## ----plot age conception, fig.align = 'center', fig.width = 5, warning = FALSE---------------
my_data %>%
  mutate(date_1repro = fetch_date_at_first_conception(ID),
         age_1repro = fetch_age(ID, date = date_1repro),
         date5 = fetch_date(ID, age = 5),
         rank_5 = fetch_rankstd(ID, date = date5),
         rank5_cat = recode_rankstd_to_cat(rank_5, probs = threshold_ranks)) %>%
  filter(!is.na(sex) & !is.na(rank5_cat)) %>%
  ggplot(aes(x = age_1repro)) +
    geom_histogram(binwidth = 1, fill = "red") +
    scale_x_continuous(limits = c(0, 15), breaks = 0:15) +
    labs(y = "Number of hyenas", x = "Age at first reproduction") +
    facet_wrap(~ rank5_cat + sex, scales = "free_y")

## ----repro data, warning = FALSE-------------------------------------------------------------
my_data %>%
  mutate(date_1repro = fetch_date_at_first_conception(ID),
         age_1repro = fetch_age(ID, date = date_1repro),
         date5 = fetch_date(ID, age = 5),
         alive5 = fetch_is_alive(ID, date = date5),
         rank_5 = ifelse(sex == "male",
                         fetch_selrankstd(ID, date = date5),
                         fetch_genderrankstd(ID, date = date5)),
         rank5_cat = recode_rankstd_to_cat(rank_5, probs = threshold_ranks)) -> my_data_1repro

my_data_1repro

skim(my_data_1repro)

## ----age 1 repro no censoring----------------------------------------------------------------
my_data_1repro %>%
  group_by(rank5_cat, sex) %>%
  summarise(mean_age_1repro = mean(age_1repro, na.rm = TRUE),
            N = n())

## ----repro data left censoring---------------------------------------------------------------
my_data_1repro %>%
  mutate(left_censored = fetch_is_censored_left(ID)) %>%
  filter(!left_censored, alive5) %>%
  select(-left_censored, -alive5) -> my_data_1repro

skim(my_data_1repro)

## ----age at first reproduction---------------------------------------------------------------
my_data_1repro %>%
  group_by(rank5_cat, sex) %>%
  summarise(mean_age_1repro = mean(age_1repro, na.rm = TRUE), N = n())

## ----age at first reproduction 2-------------------------------------------------------------
my_data_1repro %>%
  filter(!is.na(sex) & !is.na(rank5_cat)) -> my_data_1repro_clean

my_data_1repro_clean %>%
  group_by(rank5_cat, sex) %>%
  summarise(mean_age_1repro = mean(age_1repro, na.rm = TRUE), N = n()) -> table_1repro_summarised

table_1repro_summarised

## ----age at first reproduction ratio---------------------------------------------------------
table_1repro_summarised %>%
  group_by(sex) %>%
   mutate(mean_age_1repro_bottom = mean_age_1repro[grepl("100%", rank5_cat)],
          ratio = mean_age_1repro/mean_age_1repro_bottom) -> table_1repro_summarised

table_1repro_summarised

## ----plot first reproduction, fig.align = 'center', fig.width = 5----------------------------
table_1repro_summarised %>%
  ggplot(aes(y = mean_age_1repro, x = 1, fill = rank5_cat)) +
  geom_bar(stat = "identity", position = "dodge2") +
  geom_text(aes(label = paste0("N = ", N, ""), y = 0),
            position = position_dodge2(width = 0.9), vjust = -1) + 
  geom_text(aes(label = paste0("+", signif(ratio, 3), " x")),
            position = position_dodge2(width = 0.9), hjust = 0.5, vjust = -1) +
  labs(y = "Age at first reproduction (yrs)", x = "") +
  scale_y_continuous(expand = expand_scale(add = c(0, 1))) +
  scale_fill_discrete(name = "Social rank") + 
  facet_wrap(~ sex) +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank())

## ----stats repro 1---------------------------------------------------------------------------
bind_rows(
  signif(exp(calc_diff2levels(df <- my_data_1repro_clean %>% filter(sex == "female"),
                   y = "age_1repro",
                   x = "rank5_cat",
                   family = gaussian(link = "log"))), 3),
   signif(exp(calc_diff2levels(dm <- my_data_1repro_clean %>% filter(sex == "male"),
                   y = "age_1repro",
                   x = "rank5_cat",
                   family = gaussian(link = "log"))), 3)) %>%
  mutate(what = c("Age at 1st reproduction", "Age at 1st reproduction"),
         sex = c("female", "male"),
         N  = c(nrow(df), nrow(dm))) -> results_age_repro

results_age_repro

## ----age at first selection, warning = FALSE-------------------------------------------------
my_data %>%
  filter(sex == "male") %>%
  mutate(date2 = fetch_date(ID, age = 2),
         first_selection = fetch_date_at_first_selection(ID),
         age_1selection = fetch_age(ID, date = first_selection),
         observable5 = fetch_is_observable(ID, duration = 5),
         rank2 = fetch_nativerankstd(ID, date = date2),
         rank2_cat = recode_rankstd_to_cat(rank2, probs = threshold_ranks)) -> my_data_1selection

my_data_1selection

skim(my_data_1selection)

## ----age at first selection clean------------------------------------------------------------
my_data_1selection %>%
  filter(!is.na(rank2_cat) & !is.na(first_selection) & observable5) -> my_data_1selection_clean

my_data_1selection_clean

skim(my_data_1selection_clean)

## ----age at first selection summarise--------------------------------------------------------
my_data_1selection_clean %>%
  group_by(rank2_cat) %>%
  summarise(mean_age_1selection = mean(age_1selection),
            N = n()) -> table_1selection_summarised

table_1selection_summarised

## ----age at first selection ratio------------------------------------------------------------
table_1selection_summarised %>%
   mutate(mean_age_1selection_bottom = mean_age_1selection[grepl("100%", rank2_cat)],
          ratio = mean_age_1selection/mean_age_1selection_bottom) -> table_1selection_summarised

table_1selection_summarised

## ----age at first selection plot, fig.align='center', fig.width=5----------------------------
table_1selection_summarised %>%
  ggplot(aes(y = mean_age_1selection, x = rank2_cat, fill = rank2_cat)) +
  geom_bar(stat = "identity", position = "dodge2") +
  geom_text(aes(label = paste0("N = ", N, ""), y = 0),
            position = position_dodge2(width = 0.9), vjust = -1) + 
  geom_text(aes(label = paste0("+", signif(ratio, 3), " x")),
            position = position_dodge2(width = 0.9), hjust = 0.5, vjust = -1) +
  labs(y = "Age at first selection (yrs)", x = "") +
  scale_y_continuous(expand = expand_scale(add = c(0, 1))) +
  scale_fill_discrete(name = "Social rank")

## ----stats selection 1-----------------------------------------------------------------------
bind_rows(
  signif(exp(calc_diff2levels(dm <- my_data_1selection_clean,
                   y = "age_1selection",
                   x = "rank2_cat",
                   family = gaussian(link = "log"))), 3)) %>%
  mutate(what = "Age at 1st selection",
         sex = "male",
         N  = nrow(dm)) -> results_age_selection

results_age_selection

## ----gd offspring----------------------------------------------------------------------------
create_offspringtable(ID = find_IDs()) %>%
  mutate(sex = fetch_sex(ID),
         date10 = fetch_date(ID, age = 10),
         obs10 = fetch_is_observable(ID, 10),
         alive10 = fetch_is_alive(ID, date10)) %>%
  filter(sex == "female" & obs10 & alive10) -> mothers
  
create_offspringtable(ID = unique(mothers$offspring)) %>%
  rename(gd_offspring = offspring,
         offspring = ID) %>%
  group_by(offspring) %>%
  summarise(gd_offspring = length(offspring)) %>%
  filter(!is.na(offspring)) -> children

mothers %>%
  left_join(children, by = "offspring") %>%
  group_by(ID) %>%
  summarise(gd_offspring = sum(gd_offspring)) %>%
  mutate(date5 = fetch_date(ID, age = 5),
         rank5 = fetch_genderrankstd(ID, date = date5),
         rank5_cat = recode_rankstd_to_cat(rank5, probs = threshold_ranks)) -> table_gd_offspring

table_gd_offspring %>%
  group_by(rank5_cat) %>%
  summarise(mean_gd_offspring = mean(gd_offspring, na.rm = TRUE)) %>%
  mutate(mean_gd_offspring_bottom = mean_gd_offspring[grepl("100%", rank5_cat)],
         ratio = mean_gd_offspring/mean_gd_offspring_bottom) -> table_gd_offspring_summarised

table_gd_offspring_summarised


dplyr::bind_cols(!!!signif(exp(calc_diff2levels(df <- table_gd_offspring,
                            y = "gd_offspring",
                            x = "rank5_cat",
                            family = poisson(link = "log"))), 3)) %>%
mutate(what = "Number of gd offspring before 10 yrs",
       sex = "female",
       N  = nrow(df)) -> results_gd_offspring_nb

results_gd_offspring_nb

## ----all ratios------------------------------------------------------------------------------
bind_rows(results_surv,
          results_age_repro,
          results_offspring_nb,
          results_age_selection,
          results_gd_offspring_nb) %>%
mutate(what = factor(what, levels = unique(what)),
       sex = factor(sex, levels = c("male", "female", "both"))) -> all_results

all_results

## ----all ratios plot, fig.align = 'center', fig.width = 10-----------------------------------
all_results %>%
  ggplot(aes(y = estimate, x = what, ymin = lwr, ymax = upr, fill = sex)) +
    geom_bar(stat = "identity", position = position_dodge2(width = 0.9)) +
    geom_errorbar(width = 0.1, position = position_dodge(width = 0.9)) +
    geom_text(aes(label = paste0("N = ", N, "")),
              size = 2.5, vjust = 2, hjust = 0, position = position_dodge(width = 0.9)) + 
    geom_hline(yintercept = 1, linetype = "dashed", col = "black") +
    labs(y = "Top ranking / Bottom ranking", x = "Life history trait", fill = "Sex") +
    coord_flip()

## ----time, echo = FALSE, eval = TRUE---------------------------------------------------------
time2 <- proc.time()
time_ran <- round(c(time2 - time1)[[3]])
version_hyenaR <- packageVersion("hyenaR")

## ----build vignette, eval = FALSE------------------------------------------------------------
#  devtools::build_vignettes(install = TRUE)
#  devtools::load_all()
#  browseVignettes("hyenaR")

## ----sessioninfo-----------------------------------------------------------------------------
sessionInfo()

