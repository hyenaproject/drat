#' Compute ranks on a vector without accounting for ties
#'
#' This function computes compute the ranks of the elements of a vector as [`rank()`][`rank`] does.
#' The difference is how the two functions deal with ties. The function [`rank()`][`rank`] keeps
#' incrementing the ranks in case of ties, so that `rank(c(1, 2, 2, 3))` will produce `c(1, something, something, 4)`.
#' What `something` is depends on the particular setting used for the argument `ties.method`. In
#' contrast  `ranking_no_tie(c(1, 2, 2, 3))` generates `c(1, 2, 2, 3)` in such a case. We use this
#' function for example to establish litter indexes, based on the rank of the birthdate of the
#' offsprings.
#'
#' @param x A numeric, complex, character or logical vector.
#'
#' @return A numeric vector of the same length as x.
#'
#' @export
#'
#' @examples
#' ranking_no_tie(c(1, 2, 2, 3))
#' ranking_no_tie(c(10, 20, 20, 30))
#' ranking_no_tie(c(1, NA, 2, 2, 3))
#' ranking_no_tie(c(2, NA, 1, 2, 3))
#' ranking_no_tie(c(NA, NA, NA))
#' ranking_no_tie(NA)
#' ranking_no_tie(c(b = 2, a = 1))
#'
ranking_no_tie <- function(x) {

  ## sort the vector:
  x_sorted <- sort(x)

  ## initialise the output:
  ranks <- numeric(length(x_sorted))
  ranks[1] <- 1

  ## compute ranks:
  if (length(x_sorted) > 1) {
    for (i in 2:length(x_sorted)) {
      if (x_sorted[i] == x_sorted[i - 1]) {
          ranks[i] <- ranks[i - 1]
        } else {
          ranks[i] <- ranks[i - 1] + 1
        }
    }
  }

  ## resort as original:
  out <- ranks[match(x, x_sorted)]

  ## add names as in original:
  names(out) <- names(x)

  ## output:
  out
}
