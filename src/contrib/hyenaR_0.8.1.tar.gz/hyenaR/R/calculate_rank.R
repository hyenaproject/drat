#' Determine the rank of given hyena(s) on a given date
#'
#' Uses python functions written by Ilja to determine
#' the rank and standardised rank of given individuals
#' at a given date.
#'
#' @param input Can take a dataframe/tibble or named list.
#' Input should have two columns/list items called `name` (name of hyenas) and `date` ("YYYY-MM-DD").
#' @param python_loc Location of python on the computer. If unspecified,
#' will search in PATH.
#'
#' @return Will return a tibble with ranks calculated for each individual
#' @export
#' @import reticulate
#' @import dplyr
#' @import purrr
#'
#' @examples
#'
#' # Run with dummy database
#' load_database()
#' calculate_rank(input = data.frame(
#'   ID = c("A-080", "M-094"),
#'   date = c("1997-01-01", "1996-07-01")
#' ))
#' \dontrun{
#'
#' load_database(file.choose())
#' calculate_rank(input = data.frame(ID = "A-001", date = "1988-05-21"))
#' calculate_rank(input = data.frame(ID = "A-100", date = "1997-08-15"))
#' calculate_rank(input = data.frame(
#'   ID = c("A-001", "A-100"),
#'   date = c("1988-05-21", "1997-08-15")
#' ))
#' }
#'
calculate_rank <- function(input, python_loc = NA) {

  # Check the input file is in the correct format
  if (class(input)[1] == "matrix" | (is.vector(input) & !class(input)[1] == "list")) {
    stop("input variable must be either a dataframe, tibble or named list")
  }

  if (class(input$date) == "Date") {
    input$date <- as.character(input$date)
  }

  # Assign main to prevent global variable check issue
  main <- NULL

  # Specify location of python on your system
  use_python(python_loc)

  # Run python code to include my extra functions AND Ilja's function library
  py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))
  py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))

  # Run the main_R function to get ranks of all individuals Before we can do
  # this, we need to input our data in a different format. Instead of being a
  # dataframe, it should be a list, with each item being another list with hyena
  # ID and date. Map over the dataframe using df_to_list() function.
  input <- map2(.x = input$ID, .y = input$date, .f = df_to_list)

  # Use this file in the python function designed for R...
  output_file <- py$main_R(.database$db, input)

  # This is now a dictionary.
  # Essentially, this behaves like a dataframe (you get extract a column with dataframe$x)
  # However, it doesn't display and can't be indexed!
  # Therefore, we map across this whole dictionary with dict_to_df. This outputs an unnamed list.
  output_R_temp <- map(.x = names(output_file), .f = dict_to_df, output_file)
  # we then assign list names from the original file
  names(output_R_temp) <- names(output_file)
  # And finally, we use bind_rows to convert it into a dataframe
  # Python provides None when data is missing...R translates this into NULL rather than NA.
  # For cases where no rank could be determined, we need to map through and replace these with NAs.

  prototype <- list(
    clan = NA_character_,
    rank_std = NA_real_,
    nat_rank = NA_integer_,
    clantotal = NA_integer_,
    nat_rank_std = NA_real_,
    ID = NA_character_,
    gender_rank_std = NA_real_,
    adnat_rank_std = NA_real_,
    adnat_rank = NA_integer_,
    clanadults = NA_integer_,
    rank = NA_integer_,
    sel_rank_std = NA_real_,
    date = as.Date(NA),
    gender_rank = NA_integer_,
    sel_rank = NA_integer_
  )


  ## replace nested NULL by NA and fix classes using prototype:
  for (var in names(output_R_temp)) {
    for (ii in seq_along(output_R_temp[[var]])) {
      if (is.null(output_R_temp[[var]][[ii]])) {
        output_R_temp[[var]][[ii]] <- prototype[[var]]
      } else {
        class(output_R_temp[[var]][[ii]]) <- class(prototype[[var]])
      }
    }
  }

  dplyr::as_tibble(lapply(output_R_temp, unlist)) %>%
    ## Convert rank to proper data type.
    ## 'rank' columns should be integer because it is a count of position.
    ## 'rank_std' columns should be numeric because they are standardised and so are not always whole numbers.
    dplyr::mutate_at(.vars = dplyr::vars(dplyr::contains("rank"), -dplyr::contains("rank_")), .funs = as.integer) %>%
    dplyr::mutate_at(.vars = dplyr::vars(dplyr::contains("rank_std")), .funs = as.numeric) -> output_R

  # Check to see if any have failed and throw a warning
  apply(output_R, 1, FUN = function(x) {
    if (all(is.na(x[!names(x) %in% c("ID", "clan", "date")]))) {
      warning(paste0("Could not recover rank information for individual ", x["ID"], " on date ", x["date"], "."))
    }
  })

  . <- clan <- date <- NULL ## To please R CMD check

  return(output_R)
}
