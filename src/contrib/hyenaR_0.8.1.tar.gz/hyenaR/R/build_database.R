#' Download the primary data
#'
#' By default the function downloaded the CSVs files from our Github repository
#' and put them in a folder called "source_data" that is created (if not
#' existing) in your working directory.
#'
#' @note The authentification to GitHub is done using a Personal
#' Access Token (PAT), see [`get_token()`][`get_token`].
#'
#' @param repos Name of the GitHub repository (default:
#'   "hyenaproject/data")
#' @param destfolder Name of the folder in which the data are put into (default:
#'   "source_data")
#'
#' @return Nothing
#' @export
#'
#' @examples
#' \dontrun{
#'
#' download_primary_data(destfolder = "~/Downloads/CSV")
#' }
download_primary_data <- function(repos = "hyenaproject/data", destfolder = "source_data") {
  repos <- gh::gh(paste0("GET /repos/", repos, "/contents"),
    .token = get_token())
  urls <- unlist(lapply(repos, function(file) ifelse(is.null(file$download_url), NA, file$download_url)))
  files <- unlist(lapply(repos, function(file) file$name))
  index_for_download <- grepl("*.csv", files)
  files_to_download <- files[index_for_download]
  url_to_download <- urls[index_for_download]
  if (!dir.exists(destfolder)) {
    dir.create(destfolder, recursive = TRUE)
  }
  if (length(url_to_download) > 0) {
    path_destination <- normalizePath(destfolder, mustWork = FALSE)
    sapply(1:length(url_to_download), function(i) {
      if (!is.na(url_to_download[i])) {
        utils::download.file(url_to_download[i],
          destfile = paste0(path_destination, "/", files_to_download[i])
        )
      }
    })
    message(paste0("The downloaded files are in the folder ", normalizePath(destfolder)))
  } else {
    warning("No file to download")
  }
  return(invisible(NULL))
}


#' Get the Personal Access Token for GitHub
#'
#' For downloading the full data, you need to have created a Personal Access Token (PAT) in Github.
#' This function tries to find this token on your system and, failing that, asks for it directly.
#'
#' @note For developers: for the token to work, it is necessary to activate the scope "repo"
#' in GitHub for the user which you want to authorise.
#'
#' @return The token as a character string.
#' @export
#'
#' @examples
#' \dontrun{
#' get_token()
#' }
#'
get_token <- function() {
  token <- Sys.getenv('GITHUB_PAT', "")
  if (token == "") {
  message("No token has been found in your .Renviron file!")
    if (interactive()) {
      action <- utils::menu(
        choices = c("input the token manually", "abort"),
        title = "What do you want to do? (press 1 or 2 and then hit the return key)"
      )
      if (action == 2) return(invisible(NULL))
      if (action == 1) {
        message("Please, enter the token (without quotes) and hit the return key")
        token <- scan("", what = "character", n = 1)
        }
    }
  message("For next time, perhaps you would like to add your token to the .Renviron file by simply adding the following line to your .Renviron file: GITHUB_PAT = your_token.")
  cat("\n")
  message("How to edit the .Renviron file?")
  message("-> the easiest way is to install the R package usethis and then type 'usethis::edit_r_environ()'.")
  message("NB: after editing .Renviron, you must restart R.")
  cat("\n")
  } else {
    message("The following token has been found on your system and will be used:")
    message(crayon::green(token))
    message("If the token is no longer valid, you must change it in your .Renviron file!")
    cat("\n")
    message("How to edit the .Renviron file?")
    message("-> the easiest way is to install the R package usethis and then type 'usethis::edit_r_environ()'.")
    message("NB: after editing .Renviron, you must restart R.")
    cat("\n")
  }
return(token)
}


#############################################################################################################################

#' Generate csv's used to create the dummy database.
#'
#' Generate .csv files to create the dummy database.
#' This includes real data for two years of the dataset (1996 - 1997).
#' @param csv_path File path. Location of true .csv files are located.
#' @param save_path File path. Location where the dummy .csv files should be saved. Files will be saved in a folder 'dummy data' within the save_path.
#'
#' @return Generates .csv files for the years 1996 - 1997 in the Ngorongoro hyena data.
#' @export
#'
#' @examples
#' \dontrun{
#' build_dummy_data(path = "real_data/location", save_path = "dummy_data/location")
#' }

build_dummy_data <- function(csv_path = utils::choose.dir(),
                             save_path = NULL) {
  if (is.null(save_path)) {
    save_path <- csv_path
  }

  file_paths <- list.files(path = csv_path, pattern = ".csv", full.names = TRUE)

  #Ignore the "dens", "weighing", "rainfall", and "NCAA" prey abundance
  file_paths <- file_paths[!grepl("dens|weighing|rainfall|NCAA", file_paths)]

  purrr::walk(
    .x = file_paths,
    .f = ~ {

      file_path_split <- strsplit(.x, split = "/|\\\\")
      file_name <- gsub(pattern = ".csv|CSV", replacement = "", x = file_path_split[[1]][length(file_path_split[[1]])])

      file <- read.csv(.x, stringsAsFactors = FALSE) %>%
        dplyr::mutate_at(
          .vars = vars(contains("date")),
          as.Date, format = "%Y-%m-%d"
        )

      assign(x = file_name, value = file, envir = sys.frames()[[1]])
    }
  )

  # Generate a new folder for dummy data
  if (!dir.exists(paste0(save_path, "\\dummy_data"))) {
    dir.create(paste0(save_path, "\\dummy_data"), recursive = TRUE)
  }

  #Identify those individuals born in Airstrip and Lamala before 1998.
  born_indv <- hyenas %>%
    dplyr::filter(birthclan %in% c("A", "L") & birthdate < as.Date("1998-01-01")) %>%
    dplyr::pull(name)

  #Join in all individuals in the selection table
  disp_indv <- selections %>%
    dplyr::filter(destination %in% c("A", "L") & date < as.Date("1998-01-01")) %>%
    dplyr::pull(name)

  #Combine the two together
  early_indv <- c(born_indv, disp_indv)

  #Now, go through every table and filter according to these individuals and the date
  all_tables <- ls()
  all_tables <- all_tables[!all_tables %in% c("born_indv", "csv_path", "save_path",
                                              "disp_indv", "early_indv", "file_paths",
                                              "all_tables")]

  purrr::pwalk(.l = list(all_tables),
               .f = ~{

                 eval(parse(text = ..1)) -> data

                 #If there is a date column, filter by date
                 if(any(grepl("date", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = vars(contains("date")),
                                      .vars_predicate = ~. < as.Date("1998-01-01")) -> data

                 } else if(any(grepl("^year$", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = vars(matches("^year$")),
                                      .vars_predicate = ~. < 1998) -> data

                 }

                 #If there is a date column, filter by date
                 if(any(grepl("^name$", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = vars(matches("^name$")),
                                      .vars_predicate = ~. %in% early_indv) -> data

                 } else if(any(grepl("party", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = vars(contains("party")),
                                      .vars_predicate = ~. %in% early_indv) -> data

                 }

                 #For the selections table, only include dispersal INTO Airstrip and Lamala
                 #not out!
                 #This is because if an individual disperses out and we try to find its rank we get an
                 #error because it dispersed into a clan with no individuals (we deleted all other clans)
                 #This means that the results using the dummy data will not be exactly correct
                 #If we want results that are biologically correct that we can use for tests
                 #we will need to select specific individuals that we know haven't been affected by this
                 #change.
                 if(any(grepl("destination", colnames(data)))){

                   data %>%
                     dplyr::filter(destination %in% c("A", "L")) -> data

                 }

                 #For the rankchanges table, only include rank changes that occurred in Airstrip and Lamala.
                 #Same comment as above.
                 if(..1 == "rankchanges"){

                   data %>%
                     dplyr::filter(clan %in% c("A", "L")) -> data

                 }

                 #Make all comments columns NA (except for the remarks column used by Alex)
                 if(any(grepl("deathconfirmed|deathcause|comments|adoption|description|cause|interaction", colnames(data)))){

                   data %>%
                     dplyr::mutate_at(.vars = vars(contains("deathconfirmed"), contains("deathcause"),
                     contains("comments"), contains("adoption"), contains("description"), contains("cause"),
                     contains("interaction")),
                                      .funs = ~ NA) -> data

                 }

                 #For the remarks column in sightings, make NA unless it contains the info used by Alex
                 if(..1 == "sightings"){

                   data %>%
                     dplyr::mutate(remarks = dplyr::case_when(grepl("BBC", .$remarks) ~ "identified in BBC documentary",
                                                              grepl("one-day", .$remarks) ~ "one-day visit"),
                                   denname = NA, age = NA, sex = NA) -> data

                 }

                 if(..1 == "sucklings"){

                   data %>%
                     dplyr::mutate(remarks = NA,
                                   latitude = NA, longitude = NA) -> data

                 }

                 #Save data
                 data %>%
                   utils::write.csv(file = paste0(save_path, "\\dummy_data\\", ..1, ".csv"))

               })

  collectiondate <- hyenas <- injuries <- interactions <- mother <- ID <- NULL
  observationtime <- party1 <- party2 <- rainfall <- rankchanges <- samples <- selections <- NULL
  sightings <- sucklings <- transects <- videos <- weighing <- year <- birthdate <- NULL
  birthclan <- name <- destination <- NULL

  return(invisible(NULL))
}

#############################################################################################################################

#' Build hyena database from .csv files
#'
#' Build a .sqlite database of hyena data using primary .csv files. This function can be used to build
#' the dummy database (using .csv files in ./inst/extdata) or the full database using \code{\link{download_primary_data}} (see examples).
#'
#' The build process involves the calculation of a number of variables. These include:
#' \itemize{
#'   \item deathdate in the deaths table. Date of last sighting for all individuals seen >1 year ago.
#'   \item 'conception sightings' in the sightings table. When parentage of a
#'   cub is known, parents are 'sighted' on the estimated day of conception (110
#'   days before birth).
#'   \item date_lastsighting in the hyenas table. Last date that an individual was listed in the sightings table.
#'   \item firstlitter table. The date of conception (110 days before birth) of the first litter for each male.
#' }
#' @param dbname Name of new sqlite database to create.
#' @param csv_path Location of .csv files used for building database.
#' @param save_path Location where new database will be saved. By default, this is the same as the location of csv files.
#' @param overwrite Default behaviour if dbname already exists.
#' yes: Overwrite old database file.
#' no: Generate new dbname with todays date and version number.
#' prompt: User is prompted to choose a behaviour.
#' If function is run non-interactively (e.g. on the cluster) a default behaviour (TRUE or FALSE) \strong{must} be supplied.
#'
#' @return Creates an sqlite database.
#' @export
#'
#' @examples
#'
#' #Example using dummy data
#' #build_database(dbname = "example_db", csv_path = "./inst/extdata")
#'
#' \dontrun{
#' #Example using real primary data
#' download_primary_data(destfolder = "~/Downloads/CSV")
#' build_database(csv_path = "~/Downloads/CSV")
#' }
#'
build_database <- function(dbname = "Fisidata", csv_path = "source_data", save_path = NULL, overwrite = c("prompt", "yes", "no")) {

  ## Call choose.dir() if it is used as argument:
  force(csv_path)
  force(save_path)

  ## Use match arg to determine clash behaviour:
  ## (by default, the user will be prompted if a database already exists with same location and name)
  overwrite <- match.arg(overwrite) ##  'prompt' is default as it is the first argument

  ## If no explicit save path is provided, simply save in csv location:
  if (is.null(save_path)) {
    save_path <- csv_path
  }

  ## Assign NULL to please R CMD check:
  hyenas <- sightings <- selections <- clans <- dens <- injuries <- rainfall <- NULL
  interactions <- observationtime <- samples <- sucklings <- videos <- weighing <- NULL
  menu <- total <- year <- Month <- Year <- NULL

  # Fix the path (e.g. remove trailing "/")
  path <- normalizePath(save_path, mustWork = FALSE)
  csv_path <- normalizePath(csv_path, mustWork = FALSE)

  # Build full path for database
  db_path <- paste(save_path, paste0(dbname, ".sqlite"), sep = "/")

  # If the file already exists...
  if (file.exists(db_path)) {

    # Check if the session is being run interactively
    # or the user hasn't provided a default behaviour for dealing with clashes...
    if (interactive() & overwrite == "prompt") {

      # Allow the user to choose whether they: a) overwrite the file b) create a new file (with custom name based on current date).
      overwrite <- menu(
        choices = c("Overwrite the original file", "Create a new database file"),
        title = "A database with the same name already exists. What do you want to do?"
      )

      ## Convert menu outcome to match 'yes' and 'no' option from the 'overwrite' argument
      overwrite <- dplyr::case_when(
        overwrite == 1 ~ "yes",
        overwrite == 2 ~ "no"
      )
    } else if (!interactive() & overwrite == "prompt") {
      stop("User prompt is not possible in non-interactive mode.
           Please provide a default behaviour to deal with database name clashes. Use the argument 'overwrite'.")
    }

    # If they choose to overwrite the file, delete the original and continue.
    # (Not ideal because the delete takes time, actual overwrite would be better but SQL problems)
    if (overwrite == "yes") {
      message("Database name exists. Overwriting old database file...")
      file.remove(db_path)

      # Otherwise, create a new file that has todays date
    } else {

      # In case somebody tries to do this twice on the same day (creating another file path clash)
      # Add a version number after the date
      version_number <- 2

      # As long as the file path clashes, increase the version number.
      while (file.exists(db_path)) {
        db_path <- paste(path, paste0(paste(dbname, Sys.Date(), version_number, sep = "_"), ".sqlite"), sep = "/")

        version_number <- version_number + 1
      }

      message(paste0("Database name exists. Database saved as: ", paste(dbname, Sys.Date(), version_number - 1, sep = "_")))
    }
  }

  # Create SQLite db for hyenas
  db_new <- DBI::dbConnect(RSQLite::SQLite(), dbname = db_path)

  # Load all csv files
  files <- list.files(path = csv_path, pattern = ".csv", full.names = TRUE)

  # Don't include tables with 'Demo', I'm not quite sure how tables inter-relate to each other.
  files <- files[!grepl(pattern = "demo|Demo", x = files)]

  tables_to_do <- purrr::map_dfr(.x = files, .f = function(file_path) {

    # Determine file name (used to name tables) from full path
    file_name <- strsplit(file_path, "/")[[1]][length(strsplit(file_path, "/")[[1]])]
    file_name <- gsub(pattern = "CSV|csv|\\.", replacement = "", x = file_name)

    X <- utils::read.csv(file = file_path, header = TRUE, sep = ",", stringsAsFactors = FALSE, na.strings = c("", " ", "NA"))

    X %>%
      # Remove any empty columns? Do we want to do this?
      # Don't do this atm because it causes problems between bootstrap of dummy and real data.
      # select_if(.predicate = ~{!all(is.na(..1))}) %>%
      # Trim all character columns (i.e. remove trailing/leading whitespace)
      dplyr::mutate_if(.predicate = is.character, .funs = trimws) %>%
      # Make any 'clan' column uppercase (i.e. should always be 'F' not 'f')
      dplyr::mutate_at(dplyr::vars(
        dplyr::contains("clan"),
        dplyr::contains("origin"),
        dplyr::contains("destination")
      ), toupper) %>%
      ## Change column 'name' to column 'ID'
      dplyr::rename_at(
        .vars = dplyr::vars(dplyr::matches("^name$")),
        ~ "ID"
      ) -> X

    # Output a tibble with the name and data
    return(tibble::tibble(name = file_name, data = list(X)))
  })

  # Make all names lower case to prevent any issues from case changes
  tables_to_do$name <- tolower(tables_to_do$name)

  # Check that all tables needed to make views are present
  if (!all(c("hyenas", "sightings") %in% tables_to_do$name)) {
    stop("The hyenas and sightings .csv must be present to bootstrap the database.")
  }

  # The table called 'sightings' should be renamed 'raw_sightings'
  # sightings is now created as a view
  tables_to_do[which(tables_to_do$name == "sightings"), ]$name <- "raw_sightings"

  # The table called 'hyenas' should be renamed 'raw_hyenas'
  # hyenas is now created as a view
  tables_to_do[which(tables_to_do$name == "hyenas"), ]$name <- "raw_hyenas"

  # For rainfall data, adjust the structure
  if(any(grepl("rainfall", tables_to_do$name))){

    tables_to_do[which(tables_to_do$name == "rainfall"), ]$data[[1]] %>%
      dplyr::filter(!is.na(location)) %>%
      # Remove the TOTAL column (this can be calculated easily)
      dplyr::select(-total) %>%
      # Gather data so that there are columns year, month and rainfall.
      tidyr::gather(key = "Month", value = "Rainfall", -year, -location) %>%
      # Change month to be a numeric
      dplyr::mutate(Month = lubridate::month(lubridate::parse_date_time(Month, orders = "b"))) %>%
      dplyr::rename(Year = year, Location = location) %>%
      # Arrange chronologically
      dplyr::arrange(Year, Month) -> tables_to_do[which(tables_to_do$name == "rainfall"), ]$data[[1]]

  }

  # Before building the database run a number of data checks.
  # These checks are specified in check_db.R
  check <- full_record_check(
    hyenas = tables_to_do$data[tables_to_do$name == "raw_hyenas"][[1]],
    selections = tables_to_do$data[tables_to_do$name == "selections"][[1]],
    sightings = tables_to_do$data[tables_to_do$name == "raw_sightings"][[1]]
  )

  # Add tables to the database
  purrr::pwalk(.l = tables_to_do, .f = ~ {
    DBI::dbWriteTable(conn = db_new, name = ..1, value = ..2, row.names = FALSE)
  })

  # Determine the date these database files come from.
  # In some cases, we may try and bootstrap old files (e.g. dummy dataset) and so we can't make things relative to the computer clock.
  # Instead, we always make it relative to the last sighting in the sightings table.
  tables_to_do$data[[which(tables_to_do$name == "raw_sightings")]] %>%
    dplyr::pull(date) %>%
    as.Date(format = "%Y-%m-%d") %>%
    max() -> max_sighting

  # Create adults view
  Query1 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW adults AS SELECT raw_hyenas.ID, raw_hyenas.sex, date(birthdate, '+2 years') AS dateadult, date(MAX(sightings.date), '+1 day') AS deathdate, mothergenetic, mothersocial, DNA FROM raw_hyenas JOIN sightings ON (raw_hyenas.ID == sightings.ID) GROUP BY raw_hyenas.ID HAVING deathdate > dateadult"
  )
  DBI::dbClearResult(Query1)

  # Create sightings view that also contains conception views (i.e. 110 days before the birthdate of cubs where parentage is known)
  # Seems that UNION doesn't work with SELECT *?? for now I spell out all...
  Query2 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW sightings AS SELECT date(birthdate, '-110 days') AS date, '00:00' AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 1 AS sex, 'Estimated from conception' as remarks, father AS ID, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM raw_hyenas WHERE father <> '' UNION
                    SELECT birthdate AS date, '00:00' AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 2 AS sex, 'Estimated from conception' as remarks, mothergenetic AS ID, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM raw_hyenas WHERE mothergenetic <> '' UNION
                    SELECT date, time, latitude, longitude, denname, age, sex, remarks, ID, name2, clanID, denstop, prey, obsstart, obsstop, sucklingID, denhole, injuryID, earR, earL, altitude, waypoint, observer FROM raw_sightings"
  )
  DBI::dbClearResult(Query2)

  # Make the hyenas table into a view that also includes last sighting (with contraceptions included.)
  Query3 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW hyenas AS SELECT * FROM
                             raw_hyenas
                             NATURAL LEFT JOIN (SELECT ID AS ID, max(date(date)) AS date_lastsighting FROM sightings WHERE ID <> '' GROUP BY ID)"
  )
  DBI::dbClearResult(Query3)

  # Create deaths view
  # We now build this from the previous 'all_sightings' view because we want to account for conception date when estimating death
  # i.e. we need to consider that if an individual is known to have conceived of a cub it must have been alive!!
  Query4 <- DBI::dbSendQuery(
    conn = db_new,
    paste0("CREATE VIEW deaths AS SELECT ID, date(max(date), '+1 day') as deathdate FROM sightings GROUP BY ID HAVING deathdate < date(date('", max_sighting, "'), '-1 years') AND ID <> ''")
  )
  DBI::dbClearResult(Query4)

  # First litter view
  Query5 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW firstlitter AS SELECT father AS male, MIN(date(birthdate, '-110 days')) AS date_first_litter FROM raw_hyenas WHERE father > 0 GROUP BY father"
  )
  DBI::dbClearResult(Query5)

  DBI::dbDisconnect(db_new)

  if (check) {
    message(crayon::green("Database built!!"))
  } else {
    message(crayon::yellow("Database built but !!contains issues!!"))
  }

  return(invisible(NULL))
}
