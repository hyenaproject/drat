#' Deprecated function. Use [extract_database] instead.
#'
#' extract_db() is now [extract_database]. Please use this function instead.
#' @export

extract_db <- function() .Deprecated("extract_database")

###############################################################################

#' Extract data frames from the hyena database.
#'
#' Extract data frames from the hyena database loaded with [load_database]. Can
#' be used to extract a single table or multiple tables.
#'
#' @param tables Which tables you wish to load.
#'
#' @return If only one table is requested, will return a single `tibble`. If
#'   multiple tables are requested, will return a list of `tibbles`.
#' @export
#'
#' @examples
#'
#' # Load the dummy dataset
#' load_database()
#'
#' # Extract the hyenas table from the dummy database
#' hyenas <- extract_database(tables = "hyenas")
#'
#' # Extract the hyenas and deaths table from the dummy database
#' # as a list
#' data_list <- extract_database(tables = c("hyenas", "deaths"))
extract_database <- function(tables = NULL) {
  table_name <- data <- NULL ## Satisfy R CMD check

  if (!exists(".database")) {
    stop("Please call load_database() before attempting to extract data tables.")
  }

  possible_tables <- .database$database$table_name

  ## extract all tables if not specified otherwise:
  if (is.null(tables)) {
    tables <- possible_tables
  }

  ## check that requested table name exists in the database:
  if (!all(tables %in% possible_tables)) {
    wrong_tables <- tables[which(!tables %in% possible_tables)]

    stop(paste0("These table names are not in the database: ", paste(wrong_tables, collapse = ", "), ".\n\nThe possible table names are: ", paste(possible_tables, collapse = ", "), ".\n\nPlease check your spelling and try again."))
  }

  ## create a list of all the requested data tables:
  output_list <- .database$database %>%
    dplyr::filter(table_name %in% tables) %>%
    dplyr::pull(data)

  ## If only one table is requested return a single tibble object, rather than a
  ## list:
  if (length(tables) == 1) {
    return(output_list %>% `[[`(1))

    ## If more than one table is requested return a list of tibbles:
  } else {
    names(output_list) <- tables
    return(output_list)
  }
}


#' Extract all available info on a given hyena.
#'
#' This function returns all rows from primary tables which contain in their ID column the
#' ID provided as argument. The empty rows, columns and tables are dropped to make
#' the information available easier to visualise.
#'
#' Note that if the ID of the hyenas is mentioned in a column that is not the column ID, then
#' the information is not retained by this function (such as in table `interactions`).
#'
#' @param ID The ID code of hyena(s).
#'
#' @return A list of tables.
#' @export
#'
#' @examples
#' load_database()
#' extract_all_info("A-001")
extract_all_info <- function(ID) {
  all <- extract_database()
  ## remove tables without ID as column and without the individidual(s) in the ID column:
  tables <- lapply(all, function(tbl) {
    if ("ID" %in% colnames(tbl)) {
      tbl[tbl$ID %in% ID, ]
      } else data.frame()})
  ## remove empty rows:
  tables <- lapply(tables, function(tbl) {
    to_delete_row <- apply(tbl, 1, function(x) all(is.na(x)))
    tbl[!to_delete_row, ]
  })
  ## remove empty columns:
  tables <- lapply(tables, function(tbl) {
    to_delete_col <- apply(tbl, 2, function(x) all(is.na(x)))
    tbl[, !to_delete_col]
  })
  ## remove empty tables:
  null_info <- unlist(lapply(tables, function(x) nrow(x) == 0))
  tables[!null_info]
}

