## tells R CMD check to ignore testing whether those objects have no binding

utils::globalVariables(".database")
