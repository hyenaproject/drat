#' Plot adult sex ratio over time
#'
#' Plot adult sex ratio (female/number adults) for given clans over a specified period.
#' @param clan Name of clan(s) of interest. If left blank will return a summary of all clans in the specified database.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param time_steps Size of time steps over which sex ratio is calculated (months).
#'
#' @return A ggplot figure.
#' @export
#' @import ggplot2
#'
#' @examples
#'
#' # Load data (use dummy dataset)
#' load_database()
#'
#' # Plot sex ratio for all clans until 2000.
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_sexratio(start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6)
#'
#' # Make the same plot for just a single clan
#' # Note that in this scenario there will be no line showing mean sex ratio
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_sexratio(clan = "A", start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6)
plot_sexratio <- function(clan = c("A", "E", "F", "L", "M", "N", "S", "T"), start_date = Inf, end_date = Inf, time_steps = 3) {

  # Assign NULL to avoid global binding NOTE
  . <- adult_sex_ratio <- NULL

  sightings <- extract_database(tables = "sightings")

  # If no start_date is provided, use the first proper date of sightings (May 1995)
  # There are sightings before this, but they are so few we will discount them.
  # The use could include them by changing start date if they wish.
  if (is.infinite(start_date)) {
    start_date <- lubridate::ymd("1996-05-01")
  }

  # Similar, if end_date is not provided, use the latest date of sightings records.
  if (is.infinite(end_date)) {
    end_date <- lubridate::ymd(sightings %>%
      summarise(latest_date = max(date, na.rm = T)) %>%
      collect() %>%
      .$latest_date)
  }

  # Ensure that start and end date are in date format
  start_date <- lubridate::ymd(start_date)
  end_date <- lubridate::ymd(end_date)

  # Determine all possible dates using the specified time_step
  calc_dates <- start_date
  cutoff_date <- lubridate::period(time_steps, units = "month")

  while (max(calc_dates) <= end_date - cutoff_date) {
    calc_dates <- append(calc_dates, values = max(calc_dates) + cutoff_date)
  }

  # Determine sex ratios of each clan
  plot_data <- clan_summary(clan = clan, date = calc_dates)

  if (length(clan) > 1) {

    # Determine the mean sex ratio for all clans on each date
    mean_data <- plot_data %>%
      group_by(date) %>%
      summarise(mean = mean(adult_sex_ratio, na.rm = T))

    # Generate plot
    ggplot() +
      geom_hline(yintercept = 0.5, lty = 2, size = 1) +
      geom_path(data = plot_data, aes(x = date, y = adult_sex_ratio, colour = clan), size = 1.1) +
      geom_path(data = mean_data, aes(x = date, y = mean), colour = "black", size = 2.5) +
      theme_classic() +
      scale_y_continuous(breaks = c(0, 0.25, 0.5, 0.75, 1), limits = c(0, 1))
  } else {

    # Generate plot
    ggplot() +
      geom_hline(yintercept = 0.5, lty = 2) +
      geom_path(data = plot_data, aes(x = date, y = adult_sex_ratio), colour = "black", size = 1) +
      theme_classic() +
      scale_y_continuous(breaks = c(0, 0.25, 0.5, 0.75, 1), limits = c(0, 1))
  }
}


##################################################################################################

#' Plot age ratio over time
#'
#' Plot age ratio (adults/clan size) for given clans over a specified period.
#' @param clan Name of clan(s) of interest. If left blank will return a summary of all clans in the specified database.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param time_steps Size of time steps over which sex ratio is calculated (months).
#'
#' @return A ggplot figure.
#' @export
#' @import ggplot2
#'
#' @examples
#'
#' # Load data (use dummy dataset)
#' load_database()
#'
#' # Plot age ratio for all clans until 2000.
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_ageratio(start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6)
#'
#' # Make the same plot for just a single clan
#' # Note that in this scenario there will be no line showing mean age ratio
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_ageratio(clan = "A", start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6)
plot_ageratio <- function(clan = c("A", "E", "F", "L", "M", "N", "S", "T"), start_date = Inf, end_date = Inf, time_steps = 3) {

  # Assign to NULL to prevent global variable NOTE
  . <- age_ratio <- NULL

  sightings <- extract_database(tables = "sightings")

  # If no start_date is provided, use the first proper date of sightings (May 1995)
  # There are sightings before this, but they are so few we will discount them.
  # The use could include them by changing start date if they wish.
  if (is.infinite(start_date)) {
    start_date <- lubridate::ymd("1996-05-01")
  }

  # Similar, if end_date is not provided, use the latest date of sightings records.
  if (is.infinite(end_date)) {
    end_date <- lubridate::ymd(sightings %>%
      summarise(latest_date = max(date, na.rm = T)) %>%
      collect() %>%
      .$latest_date)
  }

  # Ensure that start and end date are in date format
  start_date <- lubridate::ymd(start_date)
  end_date <- lubridate::ymd(end_date)

  # Determine all possible dates using the specified time_step
  calc_dates <- start_date
  cutoff_date <- lubridate::period(time_steps, units = "month")

  while (max(calc_dates) <= end_date - cutoff_date) {
    calc_dates <- append(calc_dates, values = max(calc_dates) + cutoff_date)
  }

  # Determine sex ratios of each clan
  plot_data <- clan_summary(clan = clan, date = calc_dates)

  if (length(clan) > 1) {

    # Determine the mean sex ratio for all clans on each date
    mean_data <- plot_data %>%
      group_by(date) %>%
      summarise(mean = mean(age_ratio, na.rm = T))

    # Generate plot
    ggplot() +
      geom_hline(yintercept = 0.5, lty = 2, size = 1) +
      geom_path(data = plot_data, aes(x = date, y = age_ratio, colour = clan), size = 1.1) +
      geom_path(data = mean_data, aes(x = date, y = mean), colour = "black", size = 2.5) +
      theme_classic() +
      scale_y_continuous(breaks = c(0, 0.25, 0.5, 0.75, 1), limits = c(0, 1))
  } else {

    # Generate plot
    ggplot() +
      geom_hline(yintercept = 0.5, lty = 2) +
      geom_path(data = plot_data, aes(x = date, y = age_ratio), colour = "black", size = 1) +
      theme_classic() +
      scale_y_continuous(breaks = c(0, 0.25, 0.5, 0.75, 1), limits = c(0, 1))
  }
}

##################################################################################################

#' Plot size of clans over time
#'
#' Plot total number of individuals in each clan over a specified period.
#'
#' @param clan Name of clan(s) of interest. If left blank will return a summary of all clans in the specified database.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param time_steps Size of time steps over which sex ratio is calculated (months).
#' @param age Which individuals should be included? Can be adults only ("adult"), cubs only ("cubs"), or all individuals ("all", default).
#' @param facet Logical. Should clans be presented together (FALSE) or in facets (TRUE)?
#'
#' @return A ggplot figure.
#' @export
#' @import ggplot2
#'
#' @examples
#'
#' # Load data (use dummy dataset)
#' load_database()
#'
#' # Plot sex ratio for all clans until 2000.
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_clansize(start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6, facet = FALSE)
#'
#' # Make the same plot for just a single clan
#' # Note that in this scenario there will be no line showing mean sex ratio
#' # N.B. This is using the dummy dataset so results are nonsense, just for example.
#' plot_clansize(clan = "A", start_date = "1996-06-01", end_date = "1997-01-01", time_steps = 6)
plot_clansize <- function(clan = c("A", "E", "F", "L", "M", "N", "S", "T"), start_date = Inf, end_date = Inf, time_steps = 3, age = "all", facet = TRUE) {

  # Assign variables to NULL to avoid global variable NOTE
  . <- clan_size <- nr_adults <- yvar <- NULL

  sightings <- extract_database(tables = "sightings")

  # If no start_date is provided, use the first proper date of sightings (May 1995)
  # There are sightings before this, but they are so few we will discount them.
  # The use could include them by changing start date if they wish.
  if (is.infinite(start_date)) {
    start_date <- lubridate::ymd("1996-05-01")
  }

  # Similar, if end_date is not provided, use the latest date of sightings records.
  if (is.infinite(end_date)) {
    end_date <- lubridate::ymd(sightings %>%
      summarise(latest_date = max(date, na.rm = T)) %>%
      collect() %>%
      .$latest_date)
  }

  # Ensure that start and end date are in date format
  start_date <- lubridate::ymd(start_date)
  end_date <- lubridate::ymd(end_date)

  # Determine all possible dates using the specified time_step
  calc_dates <- start_date
  cutoff_date <- lubridate::period(time_steps, units = "month")

  while (max(calc_dates) <= end_date - cutoff_date) {
    calc_dates <- append(calc_dates, values = max(calc_dates) + cutoff_date)
  }

  # Determine sex ratios of each clan
  plot_data <- clan_summary(clan = clan, date = calc_dates)

  if (age == "all") {
    plot_data <- plot_data %>% mutate(yvar = clan_size)
  } else if (age == "adult") {
    plot_data <- plot_data %>% mutate(yvar = nr_adults)
  } else if (age == "cub") {
    plot_data <- plot_data %>% mutate(yvar = nr_adults)
  }

  if (length(clan) > 1) {
    if (facet == FALSE) {

      # Determine the mean sex ratio for all clans on each date
      mean_data <- plot_data %>%
        group_by(date) %>%
        summarise(mean = mean(yvar, na.rm = T))

      # Generate plot
      ggplot() +
        geom_path(data = plot_data, aes(x = date, y = yvar, colour = clan), size = 1.1) +
        geom_path(data = mean_data, aes(x = date, y = mean), colour = "black", size = 2) +
        theme_classic()
    } else {

      # Generate plot
      ggplot() +
        geom_path(data = plot_data, aes(x = date, y = yvar, colour = clan), size = 1.1) +
        theme_classic() +
        facet_wrap(facets = ~clan)
    }
  } else {

    # Generate plot
    ggplot() +
      geom_path(data = plot_data, aes(x = date, y = yvar), colour = "black", size = 1) +
      theme_classic()
  }
}
