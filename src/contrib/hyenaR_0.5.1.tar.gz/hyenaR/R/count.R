#' Count hyena(s)
#'
#' These functions allows for counting hyenas. There are used to count how many
#' hyenas fullfill certain criteria, for given clan(s) and at given date(s). All
#' ```count_xxx``` functions rely on their counterpart from the
#' [find_family], and differ in that they output a single number instead of a
#' vector. Note also that the ID are here also not repeated, so counts
#' correspond to those of unique individuals.
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @param clan The letter of the clan(s). If `NULL` (default), returns
#'   information for the whole population.
#' @param date The date(s) using the format "YYYY-MM-DD".
#' @name count_family
#' @aliases count_family count
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#' load_database()
NULL


#' @describeIn count_family count all adults
#' @export
#' @examples
#'
#' #### Simple example of count_adults usage:
#' count_adults(clan = c("A", "L"), date = "1997/01/01")
count_adults <- function(clan = NULL, date) {
  length(find_adults(clan = clan, date = date))
}


#' @describeIn count_family count all individuals.
#' @export
#' @examples
#'
#' #### Detailed example of count_all usage:
#' ### note: what is shown here also applies to all other count_xxx functions
#'
#' ### count all hyenas from 2 clans at a single date:
#' count_all(clan = c("A", "L"), date = "1997/02/01")
#'
#' ### count all hyenas from 2 clans alive at one date per clan:
#' count_all(clan = c("A", "L"), date = c("1997/02/01", "1996/11/21"))
count_all <- function(clan = NULL, date) {
  length(find_IDs(clan = clan, date = date))
}


#' @describeIn count_family count all females
#' @export
#' @examples
#'
#' #### Simple example of count_females usage:
#' count_females(clan = c("A", "L"), date = "1997/01/01")
count_females <- function(clan = NULL, date) {
  length(find_females(clan = clan, date = date))
}


#' @describeIn count_family count all immigrants
#' @export
#' @examples
#'
#' #### Simple example of count_immigrants usage:
#' count_immigrants(clan = c("A", "L"), date = "1997/01/01")
count_immigrants <- function(clan = NULL, date) {
  length(find_immigrants(clan = clan, date = date))
}


#' @describeIn count_family count all males
#' @export
#' @examples
#'
#' #### Simple example of count_males usage:
#' count_males(clan = c("A", "L"), date = "1997/01/01")
count_males <- function(clan = NULL, date) {
  length(find_males(clan = clan, date = date))
}

