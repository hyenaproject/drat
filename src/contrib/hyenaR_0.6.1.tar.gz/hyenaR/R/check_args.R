#' Functions checking arguments
#'
#' These functions check that the input arguments are correct, correct them if
#' possible, and throw an error otherwise.
#'
#' More functions to come...
#'
#' @note Developers should add more functions here to check more arguments.
#'
#' @param unit The unit argument for functions working with durations.
#' @param strict Whether the test should be strict (TRUE: default) and fail if not satisfied, or
#'   less strict (FALSE) and drop unknown argument values.
#'
#' @name check_args
#'
#' @return The corrected arguments.
#'
#' @examples
#' ## Load the dummy dataset:
#' load_database()
NULL


#' @describeIn check_args Check the argument 'clan'
#'
#' This function should not be directly used by the user.
#'
#' @param clan A vector of clan letter(s) (quoted).
#' @param fill Wether to output all possibilities if the argument is missing (TRUE) or not (FALSE:
#'   default).
#' @export
#' @examples
#' check_arg_clan(c("A", "L"))
#' check_arg_clan(fill = TRUE)
#' \donttest{
#' check_arg_clan(c("A", "EEE"))
#' check_arg_clan(c("A", "EEE"), strict = FALSE)
#'}
#'
check_arg_clan <- function(clan = NULL, strict = TRUE, fill = FALSE) {
  possible_clans <- find_clans()
  if (is.null(clan)) {
    if (fill) return(possible_clans)
    stop("The argument 'clan' has not been defined.")
  } else {
    if (any(!clan[!is.na(clan)] %in% possible_clans)) {
      if (strict) {
        stop(paste(c("The argument 'clan' contains clan(s) not corresponding to possible ones:",
                   unique(clan[!is.na(clan) & !clan %in% possible_clans])), collapse = " "))
      } else {
        warning("Clan(s) not corresponding to possible ones have been dropped.")
        clan <- clan[clan %in% possible_clans]
      }
    }
  }
  clan
}


#' @describeIn check_args Check the argument 'column' for extraction in the table hyenas.
#'
#' This function should not be directly used by the user.
#'
#' @param column The column name (quoted).
#' @param table The name of the table in which the column is supposed to be (quoted).
#' @export
#' @examples
#' check_arg_column("sex", table = "hyenas")
check_arg_column <- function(column, table) {
  if (length(column) != 1) {
    stop("The argument 'column' should be of length 1.")
  }
  if (length(table) != 1) {
    stop("The argument 'table' should be of length 1.")
  }
  table <- extract_database(tables = table)
  if (!column %in% colnames(table)) {
    stop("The argument 'column' does not correspond to a column name!")
  }
  column
}



#' @describeIn check_args Check arguments 'date'.
#'
#' This function should not be directly used by the user.
#'
#' @param date A vector of date(s) (quoted).
#' @export
#' @examples
#' check_arg_date("1996/12/21")
check_arg_date <- function(date) {
  if (missing(date)) {
    stop("The argument 'date' has not been defined.")
  }
  tryCatch(as.Date(date), error = function(cond) {
    stop("The argument 'date' is incorrect. It should be of the same format as e.g. '2000/02/29'.")
  })
}


#' @describeIn check_args Check arguments 'duration'.
#'
#' This function should not be directly used by the user.
#'
#' @param duration A vector of duration(s) (as class `numeric` or `Duration`).
#' @export
#' @examples
#' check_arg_duration(10)
#' check_arg_duration(lubridate::duration(10, "year"))
check_arg_duration <- function(duration) {
  if (missing(duration) | is.null(duration) | !class(duration) %in% c("numeric", "Duration")) {
    stop("The argument 'duration' has not been defined.")
  }
  duration
}


#' @describeIn check_args Check the argument 'ID'
#'
#' This function should not be directly used by the user.
#'
#' @param ID A vector of ID(s) (quoted).
#' @export
#' @examples
#' check_arg_ID("A-001")
#' check_arg_ID(fill = TRUE)
#' \donttest{
#' check_arg_ID(c("A-100", "Z-100"))
#' check_arg_ID(c("A-100", "Z-100"), strict = FALSE)
#' }
check_arg_ID <- function(ID = NULL, strict = TRUE, fill = FALSE) {
  possible_IDs <- find_IDs()
  if (is.null(ID)) {
    if (fill) return(possible_IDs)
    stop("The argument 'ID' has not been defined.")
  } else {
    if (any(!ID[!is.na(ID)] %in% possible_IDs)) {
      if (strict) {
        stop("The argument 'ID' contains ID(s) not corresponding to possible ones.")
      } else {
        warning("ID(s) not corresponding to possible ones have been dropped.")
        ID <- ID[ID %in% possible_IDs]
      }
    }
  }
  ID
}


#' @describeIn check_args Check the argument 'unit'
#' @export
#' @examples
#' check_arg_unit(c("day", "days", "week", "weeks"))
check_arg_unit <- function(unit) {
  unit %>% purrr::map_chr(~ case_when(
    .x == "days" ~ "day",
    .x == "weeks" ~ "week",
    .x == "months" ~ "month",
    .x == "years" ~ "year",
    TRUE ~ .x
  )) -> unit

  if (!all(unit %in% c("day", "week", "month", "year"))) {
    stop("The argument(s) 'unit' must be 'day', 'week', 'month', or 'year'!")
  }
  unit
}


#' Function checking if the database is loaded and if it is the dummy one
#'
#' This function should not be directly used by the user.
#'
#' Note for developers: this function triggers an error with an informative
#' message if there is no loaded database. It also displays a message if the
#' dummy database is the one that has been loaded by [load_database].
#'
#' @return This function returns nothing directly.
#' @export
#'
#' @seealso [load_database]
#'
#' @examples
#' load_database()
#' check_database()
check_database <- function() {
  if (!exists(".database")) {
    stop("No loaded database. See ?load_database")
  }

  if (attr(.database, "dummy")) {
    message("Using the dummy dataset!")
  }

  invisible(NULL)
}
