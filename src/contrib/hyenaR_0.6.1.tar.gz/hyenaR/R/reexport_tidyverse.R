## Note: reexporting functions makes then available to examples without having to load the packages!

#' @importFrom dplyr %>%
#' @export
dplyr::`%>%`

#' @importFrom dplyr full_join
#' @export
dplyr::full_join

#' @importFrom dplyr left_join
#' @export
dplyr::left_join

#' @importFrom dplyr mutate
#' @export
dplyr::mutate

#' @importFrom dplyr select
#' @export
dplyr::select

#' @importFrom dplyr rename
#' @export
dplyr::rename

#' @importFrom dplyr filter
#' @export
dplyr::filter

#' @importFrom dplyr bind_rows
#' @export
dplyr::bind_rows

#' @importFrom dplyr group_by
#' @export
dplyr::group_by

#' @importFrom dplyr group_modify
#' @export
dplyr::group_modify

#' @importFrom dplyr ungroup
#' @export
dplyr::ungroup

#' @importFrom dplyr summarise
#' @export
dplyr::summarise

#' @importFrom dplyr summarize
#' @export
dplyr::summarize

#' @importFrom dplyr n
#' @export
dplyr::n

#' @importFrom dplyr case_when
#' @export
dplyr::case_when

#' @importFrom tidyr expand
#' @export
tidyr::expand

#' @importFrom tidyr crossing
#' @export
tidyr::crossing

#' @importFrom tidyr gather
#' @export
tidyr::gather

#' @importFrom tidyr spread
#' @export
tidyr::spread

#' @importFrom tidyr separate
#' @export
tidyr::separate

#' @importFrom tidyr nest
#' @export
tidyr::nest

#' @importFrom tidyr unnest
#' @export
tidyr::unnest

#' @importFrom tibble tibble
#' @export
tibble::tibble
