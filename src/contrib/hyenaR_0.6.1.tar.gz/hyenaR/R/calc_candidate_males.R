#' Determine all candidate males for a female
#'
#' Extract candidate males (adult males in the clan)
#' on a given date.
#'
#' @param female Focal female
#' @param focal_date Date at which to estimate candidate males (YYYY-MM-DD)
#'
#' @return A tibble with male names and age
#' @export
#'
#' @examples
#'
#' # Load dummy data
#' load_database()
#'
#' # Estimate males
#' calc_candidate_males("A-001", focal_date = "1997-01-01")
calc_candidate_males <- function(female, focal_date) {
  birthdate <- deathdate <- ID <- destination <- sex <- . <- current_clan <- age <- adult <- NULL

  hyenas <- extract_database(tables = "hyenas")
  selections <- extract_database(tables = "selections")
  deaths <- extract_database(tables = "deaths")
  focal_date <- as.Date(focal_date, format = "%Y-%m-%d")

  # Check the female was alive on this date!
  if (hyenas[["birthdate"]][which(hyenas$ID == female)] > focal_date | (female %in% deaths$ID &&
    deaths[["deathdate"]][which(deaths$ID == female)] <= focal_date)) {
    stop(paste0("The focal female was not alive on ", focal_date))
  }

  # Firstly, we determine the clan of the female.
  # Check that she never moved (rare but it happens!)
  if (!female %in% selections$ID) {
    fem_clan <- hyenas[["birthclan"]][which(hyenas$ID == female)]
  } else {
    fem_clan <- selections[["destination"]][which(selections$ID == female & date < focal_date)]
  }

  # Check that the female isn't somewhere outside of the main clans
  if (!fem_clan %in% c("A", "E", "F", "L", "M", "N", "S", "T")) {
    stop("The focal female was outside one of the main clans on this date")
  }

  # Determine dispersals of all individuals before the focal date (to determine current clan)
  disp_clan <- selections %>%
    filter(date < focal_date) %>%
    group_by(ID) %>%
    slice(n()) %>%
    summarise(current_clan = destination)

  # Determine the current clan of all MALES (we don't care about females now)
  clan_summary <- hyenas %>%
    left_join(deaths, by = "ID") %>%
    filter(sex == "male" &
      birthdate < focal_date &
      (is.na(deathdate) | deathdate > focal_date)) %>%
    # Determine the current clan of each individual
    mutate(current_clan = pmap_chr(
      .l = list(
        focal = .$ID,
        birthclan = .$birthclan
      ),
      .f = function(focal, birthclan, disp_clan) {
        if (focal %in% disp_clan$ID) {
          return(filter(disp_clan, ID == focal) %>%
            pull(current_clan))
        } else {
          return(birthclan)
        }
      }, disp_clan = disp_clan
    )) %>%
    # Filter only those individuals in the females clan
    filter(current_clan == fem_clan) %>%
    # Calculate age of all individuals
    mutate(
      age = pmap_dbl(
        .l = list(
          birthdate = .$birthdate,
          deathdate = .$deathdate
        ),
        .f = calc_age, age_units = "months", end_date = focal_date
      ),
      adult = age >= 24
    ) %>%
    # Let's just exclude non-adult males
    filter(adult)

  return(clan_summary[, c("ID", "age")])
}
