context("Test join_xxx functions")

test_that("all join functions return the correct type of output", {

  expect_equal(class({
    create_basetable(clan = "A", date = "1997-01-01") %>%
      join_allranks()
  })[1], "tbl_df")

})
