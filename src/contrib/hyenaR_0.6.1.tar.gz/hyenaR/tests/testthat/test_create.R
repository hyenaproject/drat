context("Test create_xxx functions")

test_that("all create functions return the correct type", {
  expect_equal(class(create_basetable(clan = c("A", "L"), date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L"), date = c("1997/01/01", "2011/01/01")))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = "A", date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = NULL, date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L")))[1], "tbl_df")
  expect_equal(class(create_basetable())[1], "tbl_df")
  expect_equal(class(create_basetable_from_IDs(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_offspringtable(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_matestable(ID = c("A-080", "L-094")))[1], "tbl_df")
})
