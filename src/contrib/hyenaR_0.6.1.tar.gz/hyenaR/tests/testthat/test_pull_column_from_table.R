context("Test pull_column_from_table functions")


test_that("pull_column_from_table is robust", {
  test1 <- pull_column_from_table(column = "sex", table = "hyenas")
  n <- .database$database$data$hyenas$ID
  test2 <- fetch_sex(ID = n)
  foo <- function(ID) fetch_sex(ID = ID)
  test3 <- foo(ID = n)
  expect_identical(test1, test2)
  expect_identical(test2, test3)
})
