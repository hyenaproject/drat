#' Generate dummy database for running examples.
#'
#' @param n How many individuals should be generated?
#'
#' @return Creates an sqlite database in extdata of the R package.
#' @export
#' @import DBI
#' @import RSQLite
#' @import dplyr
#' @import purrr
#' @importFrom stats runif
#'
#' @examples
#' #Create dummy database of 200 individuals
#' #N.B. This is not run.
#' #generate_dummy(n = 200)

generate_dummy <- function(n = 200){

  #Assign NULL to variable names to avoid binding NOTE in R CHECKS
  birthclan <- birthdate <- deathdate <- sex <- name <- NULL
  current_clan <- origin <- destination <- clan <- selection <- . <- mothersocial <- NULL
  mothergenetic <- father <- currentclan <- litterdominance <- NULL

  set.seed(666)

  #Generate date range
  min_date <- as.Date("1997-12-01", format = "%Y-%m-%d")
  max_date <- as.Date("2017-12-01", format = "%Y-%m-%d")
  possible_clans <- c("A", "E", "F", "L", "M", "N", "S", "T")

  #Create a sequence of all possible dates
  date_seq <- seq(min_date, max_date, by = "days")

  #Generate some basic data on individuals
  #This will be used to fill in snapshots, deaths, hyenas, and selections
  dummy_adults <- tibble::data_frame(id = seq(1, n, 1),
                             birthclan = possible_clans[round(runif(n, min = 1, max = 8))],
                             name = paste0(birthclan, "-", sprintf("%03d", id)),
                             sex = sample(c(1, 2, NA), size = n, replace = TRUE),
                             birthdate = date_seq[runif(n, 1, length(date_seq))]) %>%
    #Use map function to define death date
    mutate(deathdate = purrr::map_dbl(.x = birthdate, .f = generate_deathdate, date_seq = date_seq),
           deathdate = as.Date(deathdate, origin = "1970-01-01"),
           #Determine current clan...
           currentclan = purrr::pmap_chr(.l = list(birthclan, sex, birthdate, deathdate), .f = function(birthclan, sex, birthdate, deathdate, unique_clans = possible_clans){

             #If it's female, it's just their birthclan
             if(!is.na(sex) && sex == 2){

               return(birthclan)

             } else {

               birthdate <- as.Date(birthdate, origin = "1970-01-01")
               if(is.na(deathdate)){

                 deathdate <- max(date_seq) + 1

               } else {

                 deathdate <- as.Date(deathdate, origin = "1970-01-01")

               }

               #If it's male and they're older than 2
               if(birthdate < as.Date("2015-12-01", format = "%Y-%m-%d") &
                  (difftime(deathdate, birthdate)/365) > 2){

                 #Pick a clan at random...
                 return(unique_clans[!unique_clans %in% birthclan][runif(1, 1, 7)])

               } else {

                 #Otherwise it's their birthclan
                 return(birthclan)

               }

             }

           }))

  #Now that we have all this data about our hyenas...separate it into data in the same structure as our real database
  deaths <- dummy_adults %>%
    select(name, deathdate) %>%
    filter(!is.na(deathdate)) %>%
    mutate(deathdate = as.character(deathdate))

  selections <- dummy_adults %>%
    filter(sex == 1 & birthclan != currentclan) %>%
    mutate(date = purrr::map2_chr(.x = birthdate, .y = deathdate, .f = function(birthdate, deathdate){

      birthdate <- as.Date(birthdate, format = "%Y-%m-%d")

      if(is.na(deathdate)){

        deathdate <- max(date_seq) + 1

      } else {

        deathdate <- as.Date(deathdate, format = "%Y-%m-%d")

      }

      new_date_seq <- date_seq[date_seq > birthdate + lubridate::years(2) & date_seq < deathdate]

      output_date <- as.character(as.Date(new_date_seq[round(runif(1, 1, length(new_date_seq)))], origin = "1970-01-01"))

      return(output_date)

    }),
    id = seq(1, n())) %>%
    select(id, name, origin = birthclan, destination = currentclan, date)

  snapshots <- dummy_adults %>%
    filter(is.na(deathdate) | deathdate > min_date) %>%
    #Join in selection info to determine clan location
    left_join(dplyr::select(selections, name, origin, destination, date), by = "name") %>%
    mutate(clan = purrr::pmap_chr(.l = list(birthclan, origin, destination, date), .f = function(birthclan, origin, destination, date){

      if(is.na(origin) | as.Date(date, format = "%Y-%m-%d") > min_date){

        return(birthclan)

      } else {

        return(destination)

      }

    }),
    selection = ifelse(clan != birthclan, "disperser", NA),
    date = as.character(min_date)) %>%
    arrange(clan, name) %>%
    group_by(clan) %>%
    mutate(rank = seq(1, n(), 1)) %>%
    select(date, clan, rank, name, selection)

  hyenas <- dummy_adults %>%
    mutate(mothersocial = purrr::pmap_chr(.l = list(name, birthdate, birthclan), .f = generate_mothers, adults_dataset = .),
           mothergenetic = mothersocial, birthdate = as.character(birthdate), litterdominance = NA,
           father = NA) %>%
    select(id, name, sex, birthclan, birthdate, mothergenetic, mothersocial, father, litterdominance)

  #Combine sightings of births and deaths
  sightings <- dplyr::bind_rows(hyenas %>%
                                  select(date = birthdate, name = name),
                                deaths %>%
                                  select(date = deathdate, name = name)) %>%
    rowwise() %>%
    mutate(clanID = strsplit(name, "-")[[1]][1])

  #Create samples data for a few individuals (some with dispersal)
  samples_indv <- hyenas %>%
    slice(1:10) %>%
    left_join(deaths, by = "name")

  samples <- pmap_df(.l = list(name = samples_indv$name,
                      birthdate = as.numeric(lubridate::ymd(samples_indv$birthdate)),
                      deathdate = as.numeric(lubridate::ymd(samples_indv$deathdate))),
            .f = function(name, birthdate, deathdate){

              if(is.na(deathdate)){

                #Make it Jan 2019 (i.e. very large)
                deathdate <- 17897

              }

              return(data_frame(code = paste0("N", birthdate), collectiondate = as.character(lubridate::as_date(runif(n = 1, min = birthdate, max = deathdate), origin = "1970-01-01")),
                     name = name, species = "hy", type = "faeces"))

            })

  #Create the dummy dataset file
  #If file exists, remove it and make new...
  if(file.exists("./inst/extdata/dummy_db.sqlite")){

    file.remove("./inst/extdata/dummy_db.sqlite")

  }

  file.create("./inst/extdata/dummy_db.sqlite")

  #Connect to new database
  dummy_connection <- DBI::dbConnect(RSQLite::SQLite(), "./inst/extdata/dummy_db.sqlite")

  #Add files to database
  DBI::dbWriteTable(dummy_connection, "hyenas", hyenas)
  DBI::dbWriteTable(dummy_connection, "snapshots", snapshots)
  DBI::dbWriteTable(dummy_connection, "selections", selections)
  DBI::dbWriteTable(dummy_connection, "deaths", deaths)
  DBI::dbWriteTable(dummy_connection, "sightings", sightings)
  DBI::dbWriteTable(dummy_connection, "samples", samples)
  DBI::dbWriteTable(dummy_connection, "rankchanges",
                    data.frame(id = NA, date = NA, clan = NA, name = NA, higher = NA, lower = NA, description = NA, reason = NA))


  #Disconnect
  DBI::dbDisconnect(dummy_connection)

}

##############################################################

#' Generate death dates for dummy individuals.
#'
#' This file is used internally during \code{\link{generate_dummy}}.
#' @param birthdate birthdate of individuals.
#' @param date_seq Sequence of possible dates in which the dummy database covers.

generate_deathdate <- function(birthdate, date_seq){

  is_alive <- round(runif(1, 0, 1))

  if(is_alive){

    return(NA)

  } else {

    new_date_seq <- date_seq[date_seq > birthdate]

    return(new_date_seq[round(runif(1, 1, length(new_date_seq)))])

  }
}

#######################################################

#' Generate mother ID for dummy individuals.
#'
#' This file is used internally during \code{\link{generate_dummy}}.
#' @param focal_name Name of individuals
#' @param focal_birthdate Birthdate of individual
#' @param focal_clan Clan of individual
#' @param adults_dataset Dataframe containing all dummy individuals

generate_mothers <- function(focal_name, focal_birthdate, focal_clan, adults_dataset){

  #Assign NULL to variable names to avoid binding NOTE in R CHECKS
  name <- sex <- birthdate <- deathdate <- birthclan <- . <- NULL

  focal_birthdate <- as.Date(focal_birthdate, origin = "1970-01-01")

  #Create a subset of existing data that:
  #- Doesn't include current individual.
  #- Are female
  #- Were at least 3 yo at birth
  #- Were not dead at birth
  #- Were in the same clan
  potential_mums <- adults_dataset %>%
    filter(name != focal_name & sex == 2 & (birthdate + lubridate::years(3)) < focal_birthdate & deathdate > focal_birthdate & birthclan == focal_clan)

  if(nrow(potential_mums) == 0){

    return(NA)

  } else {

    return(potential_mums %>% slice(round(runif(1, 1, n()))) %>% .$name)

  }

}
