##FUNCTIONS USED FOR ESTIMATING DEMOGRAPHY

#' Determine age of a specific individual for \code{\link{indv_summary}}.
#'
#' @param age_units Units with which age should be measured.
#' @param birthdate Birthdate of individual.
#' @param deathdate Deathdate of individual (if it exists).
#' @param end_date End date of the focal period.
#'
#' @return Returns the age of an individual in specified units.

calc_age <- function(age_units, birthdate, deathdate, end_date){

  birthdate <- lubridate::ymd(birthdate)
  deathdate <- lubridate::ymd(deathdate)
  end_date  <- lubridate::ymd(end_date)

  lastdate <- ifelse(is.na(deathdate) | !is.na(deathdate) & deathdate > end_date, end_date, deathdate)

  lastdate <- as.Date(lastdate, origin = "1970-01-01")

  if(age_units == "season"){

    return(as.numeric(round((lastdate - birthdate)/(365/2)) * 0.5))

  } else if(age_units == "years"){

    return(as.numeric(lastdate - birthdate)/365)

  } else if(age_units == "months"){

    return(interval(birthdate, lastdate)%/%months(1))

  } else {

    return(round(as.numeric(difftime(lastdate, birthdate, units = age_units))))

  }

}

#####################################################################################

#' Determine current clan for an individual in a given period for \code{\link{indv_summary}}.
#'
#' Determines:
#' - Whether an individual dispersed during the focal period.
#' - Clan they were in at the start of the focal period.
#' - Clan they were in at the end of the focal period.#'
#'
#' @param focal_indv Name of focal individual.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param selections Selections table in the database
#' @param birthclan Clan where the individual was born.
#' @param pb R6 progress bar object.
#'
#' @import dplyr
#'
#' @return Returns a tibble with focal name and calculated variables.

calc_currentclan <- function(focal_indv, sex, age, start_date, end_date, selections, birthclan, pb){

  #Assign NULL to avoid global binding NOTE
  name <- destination <- . <- status <- dispersal <- NULL

  if(start_date == "-Inf"){

    start_date <- -Inf

  } else {

    start_date <- lubridate::ymd(start_date)

  }

  end_date   <- lubridate::ymd(end_date)

  indv_selections <-  selections %>%
    #Subset selections to just include the current individual.
    filter(name == focal_indv) %>%
    collect()

  #If there are no records of dispersals for this individual EVER..
  if(nrow(indv_selections) == 0){

    #If it's a male or has no sex give it no dispersal info
    if(is.na(sex) | sex == "Male"){

      #Then it could never have dispersed, so make everything NA
      dispersal <- NA
      status    <- "Pre-disperser"
      tenure    <- NA

    #Otherwise, if it's a female, say that it is undispersed (and has no tenure)
    } else {

      dispersal <- FALSE
      status    <- "Undispersed"

      #These individuals do not have a tenure, this is a male only variable!
      tenure <- NA

    }

    #Then just output a tibble with start and end clan the same as birthclan
    #Give it a status of undispersed.
    pb$tick()$print()

    return(data_frame(name = focal_indv, dispersal = dispersal, status = status, start_clan = birthclan, current_clan = birthclan, tenure = tenure))

  #Otherwise, if the individual has made a selection at some point in its life...
  } else {

    earlier_disp <- subset(indv_selections, date < start_date)

    #If there were no selections BEFORE the period of interest (or they were all philopatric)
    if(nrow(earlier_disp) == 0 | all(earlier_disp$origin == earlier_disp$destination)){

      #Make start_clan the same as birthclan
      start_clan <- birthclan

      #Make tenure = NA. Tenure is only relevant once an individual has dispersed...
      tenure <- NA

      nr_disp <- 0

    #Otherwise, if there have been earlier selection that were not philopatric
    } else {

      #...make start_clan the destination of the latest selection before the start date
      start_clan <- indv_selections %>%
        filter(lubridate::ymd(date) < start_date) %>%
        slice(n()) %>%
        .$destination

      #Make a variable tenure_start, that is the date that the individual first entered its current clan
      tenure_start <- lubridate::ymd(indv_selections %>%
        filter(lubridate::ymd(date) < start_date) %>%
        slice(n()) %>%
        .$date)

      #Determine the tenure at the current start_date (in months)
      tenure <- interval(tenure_start, start_date)%/%months(1)

      nr_disp <- sum(earlier_disp$origin != earlier_disp$destination)

    }

    #If there were any dispersals AFTER the start date and before the end date (i.e. during the focal period)
    if(any(lubridate::ymd(indv_selections$date) >= start_date & lubridate::ymd(indv_selections$date) < end_date)){

      #Save the destination clan as end_clan...
      end_clan <- indv_selections %>%
        filter(lubridate::ymd(date) >= start_date & lubridate::ymd(date) < end_date) %>%
        slice(n()) %>%
        .$destination

      dispersal <- TRUE

      #Reset tenure to 0
      tenure <- 0

      #Make the number of dispersals 1 more then it was previously
      nr_disp <- nr_disp + 1

    } else {

      #Otherwise, the end clan is the same as the start clan
      end_clan <- start_clan

      #There is no dispersal and tenure is unchanged.
      dispersal <- FALSE

    }

    #If birth_clan is the same as the end_clan
    if(birthclan == end_clan){

      #If it's a male, this means it has made a selection decision but it stayed philopatric
      if(is.na(sex) | sex == "Male"){

        #Then it's a philopatric male and it's not counted as a dispersal
        status    <- "Philopatric"

      #Otherwise, if it's female, we just say it's not dispersed
      } else {

        status <- "Undispersed"
        tenure <- NA

      }

    #Otherwise, if they have changed clans since they were born then it is considered to have dispersed (regardless of sex)
    } else {

      #Make it first time or second time disperser based on previous dispersal events
      if(nr_disp == 1){

        status <- "Primary_disperser"

      } else if(nr_disp > 1){

        status <- "Secondary_disperser"

      }

    }

    pb$tick()$print()

    browser(expr = !is.character(status))

    return(data_frame(name = focal_indv, dispersal = dispersal, status = status, start_clan = start_clan, current_clan = end_clan, tenure = tenure))

  }

}

############################################################################################

calc_motherrank <- function(rank_std, sex, age, focal_mothergenetic, focal_mothersocial, date, deaths, data){

  #In cases where there is no gender rank...
  if(is.na(rank_std)){

    #And we're dealing with a cub
    if(age < 24){

      #If it has a social mother listed (preferable to genetic mother only for rank)
      if(!is.na(focal_mothersocial)){

        #If the mother was alive in the period of measurement...
        if(focal_mothersocial %in% data$name){

          #Return the gender rank of that mother
          return(filter(data, name == focal_mothersocial) %>%
                   .$rank_std)

          #Otherwise, if the social mother is not present we need to estimate her rank at another point
        } else {

          mother_last <- filter(deaths, name == focal_mothersocial) %>%
            rename(date = deathdate) %>%
            collect()

          return(as.numeric(calculate_rank(db = db, input = mother_last) %>%
                              .$rank_std))

        }

        #Do the same for the genetic mother if social mother is not provided
      } else if(!is.na(focal_mothergenetic)){

        #If the mother was alive in the period of measurement...
        if(focal_mothergenetic %in% data$name){

          #Return the gender rank of that mother
          return(filter(data, name == focal_mothergenetic) %>%
                   .$rank_std)

          #Otherwise, if the social mother is not present we need to estimate her rank at another point
        } else {

          mother_last <- filter(deaths, name == focal_mothergenetic) %>%
            rename(date = deathdate) %>%
            collect()

          return(as.numeric(calculate_rank(db = db, input = mother_last) %>%
                              .$rank_std))

        }

      } else {

        return(NA)

      }

    #If the individual is an adult but has no gender rank, leave it as NA
    } else {

      return(NA)

    }

  } else {

    return(as.numeric(rank_std))

  }

}

#############################################################################

#' Determine reproductive state of individual during a given period for \code{\link{indv_summary}}.
#'
#' Determines:
#' - Whether an individual has given birth (FEMALE ONLY)
#' - Current reproductive success (MALE AND FEMALE)
#' - Whether twins have been produced (FEMALE ONLY)
#'
#' @param focal_indv Name of focal individual.
#' @param focal_sex Sex of focal individual.
#' @param start_date Start of focal period.
#' @param end_date End of focal period.
#' @param hyena Hyena table from the database.
#'
#' @return Returns a tibble with focal name and the three determined variables.

calc_repro <- function(focal_indv, focal_sex, start_date, end_date, hyena){

  #Assing NULL to prevent global variable note
  father <- birthdate <- mothergenetic <- NULL

  if(is.na(focal_sex) || focal_sex == "Male"){

    #Create a subset of hyenas that were born between the start and end date and had this indv as mother...
    all_offspring <- hyena %>%
      collect() %>%
      filter(father == focal_indv & lubridate::ymd(birthdate) >= start_date & lubridate::ymd(birthdate) < end_date) %>%
      summarise(total = n())

    return(data_frame(name = focal_indv, repro = NA, RS = all_offspring$total, twin = NA))

  } else {

    #Create a subset of hyenas that were born between the start and end date and had this indv as mother...
    all_offspring <- hyena %>%
      collect() %>%
      filter(mothergenetic == focal_indv & lubridate::ymd(birthdate) >= start_date & lubridate::ymd(birthdate) < end_date) %>%
      #Determine if any offspring are cubs by seeing if they have a duplicate birthdate.
      mutate(twin = duplicated(birthdate))

    return(data_frame(name = focal_indv, repro = nrow(all_offspring) > 0, RS = nrow(all_offspring), twin = any(all_offspring$twin)))

  }

}

#################################################################################

##FUNCTIONS USED TO CONVERT ITEM TYPES WHEN USING RETICULATE AND PYTHON.

#' Convert a dataframe to a list with items for each dataframe column.
#'
#' @param x First column
#' @param y Second column
#'
#' @return Returns a list with two items for column 1 and 2.

df_to_list <- function(x, y){

  return(list(name = x[1], date = y[1]))

}

#' Convert a dictionary output by python to a dataframe.
#'
#' @param x Vector of dictionary keys
#' @param dict Dictionary object output by python.
#'
#' @return A dataframe with one column for each dictionary key.

dict_to_df <- function(x, dict){

  return(dict[x])

}

#################################################################################

#EXTRACT RAW CLAN SUMMARIES WITH GEN_STATE IN PYTHON

#' Extract raw clan summary for \code{\link{clan_summary}}.
#'
#' @param db Location of database provided by \code{\link{clan_summary}}.
#' @param clan Code of clan.
#' @param date Date of summary. YYYY-MM-DD
#' @param python_loc Location of python on the computer. If unspecified,
#' will search in PATH.
#'
#' @import DBI
#' @import RSQLite
#' @import dplyr
#'
#' @return A tibble with raw clan information.

get_rawclan_summary <- function(db = NULL, clan = NULL, date = NULL, python_loc = NA){

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Specify location of python on your system
  use_python(python_loc)

  #Run python code to include my extra functions AND Ilya's function library
  py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))
  py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))

  #Generate state of clans on each date
  output_file <- py$clan_summary(db, dates = date)

  dbDisconnect(connection)

  return(output_file)

}

#################################################################################

#UPDATE AND PRUNE DRAT REPOSITORY

#' Update the version of hyenaR in the drat folder.
#'
#' __This is an internal function__. Updates the version of hyenaR in the drat folder.
#' First update the version number in DESCRIPTION.
#'
#' @param drat_folder Location of drat folder.
#'
#' @import drat
#' @import devtools

update_drat <- function(drat_folder = NULL){

  if(is.null(drat_folder)){

    print("Please select the location of the drat folder...")

    drat_folder <- choose.dir()

  }

  print("Build package...")
  devtools::build()

  print("Update in drat...")
  targz <- list.files(pattern = "tar.gz", path = "..", full.names = TRUE)
  drat::insertPackage(targz, repodir = drat_folder)

  print("Prune out old version...")
  drat::pruneRepo(repopath = drat_folder, remove = TRUE)

}
