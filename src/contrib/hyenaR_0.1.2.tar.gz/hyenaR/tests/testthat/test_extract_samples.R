context("Test extract_samples function")

test_that("extract_samples works with no dates provided", {

  output_summary <- extract_samples()

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$collectiondate), "Date")
  #Test that there are no NAs
  expect_true(!any(is.na(output_summary)))


})

test_that("extract_samples works with dates provided", {

  output_summary <- extract_samples(start_date = "2016-01-01", end_date = "2016-12-31")

  #Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  #Test that date is in date format
  expect_equal(class(output_summary$collectiondate), "Date")
  #Test that there are no NAs
  expect_true(!any(is.na(output_summary)))

  #This is known data, so we check that it gives us the right number of rows
  expect_equal(nrow(output_summary), 2)
  expect_equal(output_summary$dispersal_status[1], "Undispersed")


})
