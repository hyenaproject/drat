import sqlite3
import os

def square_numbers(nums):
    for i in nums:
        yield (i*i)

#Use to connect to database in other python files.
def connect_db(db):

    return sqlite3.connect(db)

#Overwrite Ilya's format_rank function to give NULL when values are missing.
#Convert a float into a string with three decimal places if a float is provided.
def format_rank_new(val):

    return None if val is None else '{0:.3f}'.format(val)

#Function that inputs and R list and outputs a python Dict.
#We will convert these into dataframes in R to prevent the need to import pandas (which requires installing Anaconda it seems)
#Take db location information and list name
def main_R(db, dataframe):
    
    #make connection to database file
    db = sqlite3.connect(db)

    lines = dataframe
    date_index = defaultdict(list)
    #For each line in the data...
    for line in lines:
        #Create a new dictionary item...the key is each date in the input date (in datetime format)
        # ...each item is a list.
        # ...inside each list is a dictionary which equates to the information in each row of the input data
        date_index[parse_date(line['date'])].append(line)

    #Create a chronological list of all dates
    dates = sorted(date_index.keys())

    #Create a dictionary of empty lists with each key being a new header of the output data.
    headers = ['date', 'name', 'clan', 'clantotal', 'clanadults', 'rank', 'rank_std',
                  'gender_rank', 'gender_rank_std', 'nat_rank', 'nat_rank_std', 'adnat_rank',
                  'adnat_rank_std', 'sel_rank', 'sel_rank_std']
    output_data = defaultdict(list)
    for header_name in headers:
        output_data[header_name]

    # Generate a hierarchy for each clan from the dates in the provided csv
    # Loop through every hierarchy, generated on each date in each clan..
    for date, state, index in gen_states(db, dates, verbose=False):
        #For every date in the input data file
        for line in date_index[date]:
            #Extract the name of the focal individual we're interested in, their clan name and their position in the hierarchy (i.e. index)
            name = line['name']
            try:
                clan = state[index[name]]
            except KeyError:
                raise KeyError("Individual {0} is not recorded in any of the clan hierarchies on date {1}. Check that it was alive on this date!".format(name, date))
            animal_index = index_of_name(clan, name)

            output_data['name'].append(name)
            output_data['date'].append(line['date'])

            #Save clanname, clan size and number of adults for the clan of the focal individual at the focal date.
            output_data['clan'].append(index[name])
            output_data['clantotal'].append(len(clan))
            output_data['clanadults'].append(len([animal for animal in clan if is_adult(animal, date)]))

            #Extract rank of the clan of the focal individual on the focal date mixing males and females...
            rank, rank_std = rank_clan(clan, lambda x: True)
            #Save the absolute and standardised rank of the focal individual
            output_data['rank'].append(rank[animal_index])
            output_data['rank_std'].append(format_rank_new(rank_std[animal_index]))

            #Determine the gender specific rank of the focal individual
            gender_rank, gender_rank_std = merge_rank_pairs(rank_clan(clan, lambda x: is_adult(x, date) and (x.male is True)),
                                                              rank_clan(clan, lambda x: is_adult(x, date) and (x.male is False)))
            output_data['gender_rank'].append(gender_rank[animal_index])
            output_data['gender_rank_std'].append(format_rank_new(gender_rank_std[animal_index]))

            #Determine the native adult/subadult rank of the focal individual 
            nat_rank, nat_rank_std = rank_clan(clan, lambda x: (not is_cub(x, date)) and x.native)
            output_data['nat_rank'].append(nat_rank[animal_index])
            output_data['nat_rank_std'].append(format_rank_new(nat_rank_std[animal_index]))

            #Determine the native adult (not subadult) rank of the focal individual
            adnat_rank, adnat_rank_std = rank_clan(clan, lambda x: is_adult(x, date) and x.native)
            output_data['adnat_rank'].append(adnat_rank[animal_index])
            output_data['adnat_rank_std'].append(format_rank_new(adnat_rank_std[animal_index]))

            #Determine the immigrant rank of the focal individual
            sel_rank, sel_rank_std = rank_clan(clan, lambda x: x.selection is not None)
            output_data['sel_rank'].append(sel_rank[animal_index])
            output_data['sel_rank_std'].append(format_rank_new(sel_rank_std[animal_index]))

    return output_data

#Function that inputs and R list and outputs a python Dict.
#We will convert these into dataframes in R to prevent the need to import pandas (which requires installing Anaconda it seems)
#Take db location information and list name
def clan_summary(db, dates):

    #Check if there is 1 date or >1 date (if >1 it will be a list item)
    if type(dates) != list:
        dates = [dates]

    output_data = defaultdict(list)

    headers = ["date", "indv_summary"]
    for header_name in headers:
        output_data[header_name]

    for date in dates:

        current_gen = gen_states(sqlite3.connect(db), [parse_date(date)], verbose=False)

        for date, ranks, clan in current_gen:

            output_data['date'].append(date)
            output_data['indv_summary'].append(ranks)

    return output_data


def process_death(animals, clan_index, event):
    """Remove references to the deceased animal."""

    name = event['name']

    try:
        clan = animals[clan_index[name]]
    except KeyError:
        raise KeyError("Individual {0} is not recorded in any clan. Check that it has a record in the hyenas table!".format(name))
    
    del clan[index_of_name(clan, name)]
    del clan_index[name]