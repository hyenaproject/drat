#### THIS FILE IS A DRAFT, IT HAS NOT BEEN FULLY CHECKED AND
## FUNCTIONS HAVE NOT BEEN DISPATCHED TO THEIR RESPECTIVE FILES
#### BUT PERHAPS THEY SHOULD NOT...

#' Internal function to extract the selection event
#'
#' @param ID The ID code of hyena(s).
#'
#' @return A list with a tibble of selection events for each individual.
#' @export
#'
#' @examples
#' # Run with dummy database
#' load_database()
#' calculate_selection_events(ID = c("A-001", "A-100"))
#'
calculate_selection_events <- function(ID = NULL) {

  ID <- check_arg_ID(ID)
  selections <- extract_database("selections")

  output <- purrr::map(.x = ID,
                       ~ list(selections[selections$ID %in% .x, ]),
                       .progress = FALSE)
  names(output) <- ID
  unlist(output, recursive = FALSE)
}


#' @describeIn create_family create a tidy table with individuals and their selection events.
#'
#' @export
#' @examples
#' #### Simple examples of create_selection_events usage:
#' load_database()
#' create_selection_events()
#'
#' ### count selection events for each individuals (birth = 1)
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'  create_selection_events() %>%
#'    mutate(sex = fetch_sex(ID)) %>%
#'      group_by(ID, sex) %>%
#'      summarise(n = n()) -> foo
#'   table(foo$n, foo$sex)
#' }
#'
create_selection_events <- function(ID = NULL) {
  ID <- unique(ID) ### added by colin
  input <- tibble::tibble(ID = check_arg_ID(ID, fill = TRUE))

  selection_events_list <- calculate_selection_events(ID = input$ID)
  selection_events_df <- do.call("rbind", selection_events_list) ## looses empty rows

  input %>%
    dplyr::mutate(destination = fetch_birthclan(ID = ID),
           date = fetch_birthdate(ID = ID)) %>%
    dplyr::full_join(selection_events_df, by = c("ID", "destination", "date")) %>% ## restore empty rows but does not conserve ID ranking
    dplyr::select(-origin) %>%
    dplyr::rename(clan = destination) %>%
    dplyr::arrange(ID, date) -> output

  return(output)

  destination <- origin <- NULL ## to please R CMD check
}

#' @describeIn fetch_family fetch the selection status of a given hyena.
#' @export
#' @examples
#' fetch_selection_status(ID = c("A-001"),
#'                        date = c("1997-01-01"))
#'
#' \dontrun{
#' load_database(file.choose())
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_basetable() %>%
#'      mutate(selection = fetch_selection_status(ID = ID, date = "2010/01/01")) %>%
#'      filter(selection == "selector_2")
#'  }
#' }
#'
fetch_selection_status <- function(ID, date, debug = FALSE) {
  input_full <- dplyr::tibble(ID = check_arg_ID(ID),
                              focal_date = check_arg_date(date))

  input <-  input_full  %>% unique()

  ## add age, sex, date first conception:
  input %>%
    dplyr::mutate(age = fetch_age(ID, date = focal_date),
                  sex = fetch_sex(ID),
                  first_conception = fetch_date_at_first_conception(ID)) -> input

  ## add whether individuals have conceived before focal date or not:
  input %>%
    dplyr::mutate(has_conceived = dplyr::case_when(
                      is.na(first_conception) ~ FALSE,
                      !is.na(first_conception) & (first_conception <= focal_date) ~ TRUE,
                      !is.na(first_conception) & (first_conception > focal_date) ~ FALSE)
                  ) -> input

  ## add selection events:
  input %>%
    dplyr::left_join(x = create_selection_events(ID = input$ID), y = ., by = "ID") -> output

  ## remove dispersion events after focal date:
  output %>%
    dplyr::filter(date <= focal_date) -> output

  if (debug) return(output)

  ## compare clans:
  output %>%
    dplyr::group_by(ID, focal_date) %>%
    dplyr::mutate(previous_clan = dplyr::lag(clan),
                  same_clan_as_previous = previous_clan == clan) -> output

  ## count dispersion events:
  output %>%
    dplyr::group_by(ID, focal_date) %>%
    dplyr::summarise(events = dplyr::n(),
                     same_clan_as_previous = dplyr::last(same_clan_as_previous)) %>%
    dplyr::left_join(x = input, y = ., by = c("ID", "focal_date")) -> output

  ## label dispersion status:
  output %>%
    dplyr::mutate(status = dplyr::case_when(
                       age <= 1 & !has_conceived & events == 1 ~ "cub", ## for both sexes
                       age > 1 & age <=2 & !has_conceived & events == 1 ~ "subadult",
                       sex == "female" & (age > 2 | has_conceived) & events == 1 ~ "natal",
                       sex == "male" & age > 2 & events == 1 ~ "natal",
                       is.na(sex) & age > 2 & events == 1 ~ "natal",
                       events == 2 & same_clan_as_previous == TRUE ~ "philopatric",
                       events == 2 & same_clan_as_previous == FALSE ~ "disperser",
                       events > 2 ~ paste0("selector_", events - 1),
                       TRUE ~ NA_character_
                       )
                  ) -> output

  input_full %>%
    left_join(output) -> output_full

  return(output_full$status)

  focal_date <- clan <- previous_clan <- same_clan_as_previous <- NULL ## to please R CMD check
}

################################################################################
################################################################################
### Find() version of the fetch_selection_status

#' @describeIn find_family find the number of philopatric males in a given clan at a given time.
#' @export
#' @examples
#' find_philopatrics_beta(clan = c("A", "A"),
#'                        date = c("1997-01-01", "1997-11-17"))
#'
#' \dontrun{
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   load_database(file.choose())
#'   sight <- extract_database("sightings")
#'   sight <- sight %>%
#'   mutate(clan = fetch_clan(ID, date_time),
#'          philo = find_philopatrics_beta(clan = clan, date = date_time))
#' }
#' }
find_philopatrics_beta <- function(clan, date){

  focal_date <- as.Date(date)
  table <- tibble(focal_date = focal_date,
                  clan1 = clan) %>% unique()


  base_t <- create_basetable(clan = table$clan1, date = table$focal_date) %>%
    mutate(sex = fetch_sex(ID = ID)) %>%
    filter(sex == "male") %>%
    mutate(status = fetch_selection_status(ID = ID, date = date)) %>%
    group_by(clan, date) %>%
    summarise(philopatrics = sum(status == "philopatric", na.rm = T))

  imput <- tibble(clan = clan, date = focal_date)

  out <- imput %>% left_join(base_t, by = c("clan", "date")) %>% pull(philopatrics)

  return(out)
  ID <- sex <- status <- philopatrics <- NULL
}

#' @describeIn find_family find the number of selectors males (moved more than once) in a given clan at a given time.
#' @export
#' @examples
#' find_selectors_beta(clan = c("A", "A"),
#'                        date = c("1997-01-01", "1997-11-17"))
#'
#' \dontrun{
#' load_database(file.choose())
#' sight <- extract_database("sightings")
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   sight <- sight %>%
#'   mutate(clan = fetch_clan(ID, date_time),
#'          philo = find_selectors_beta(clan = clan, date = date_time))
#' }
#' }
find_selectors_beta <- function(clan, date){
  focal_date <- as.Date(date)
  table <- tibble(focal_date = focal_date,
                  clan1 = clan) %>% unique()


  base_t <- create_basetable(clan = table$clan1, date = table$focal_date) %>%
    mutate(sex = fetch_sex(ID = ID)) %>%
    filter(sex == "male") %>%
    mutate(status = fetch_selection_status(ID = ID, date = date)) %>%
    group_by(clan, date) %>%
    summarise(selectors_x = sum(stringr::str_detect(status, "selector"), na.rm = T))

  imput <- tibble(clan = clan, date = focal_date)

  out <- imput %>% left_join(base_t, by = c("clan", "date")) %>% pull(selectors_x)

  return(out)
  ID <- sex <- status <- selectors_x <- NULL
}



#' @describeIn find_family find the number of natal males in a given clan at a given time.
#' @export
#' @examples
#' find_natals_beta(clan = c("A", "A"),
#'                        date = c("1997-01-01", "1997-11-17"))
#'
#' \dontrun{
#' load_database(file.choose())
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   sight <- extract_database("sightings")
#'   sight <- sight %>%
#'   mutate(clan = fetch_clan(ID, date_time),
#'          philo = find_natals_beta(clan = clan, date = date_time))
#' }
#' }
find_natals_beta <- function(clan, date){
  focal_date <- as.Date(date)
  table <- tibble(focal_date = focal_date,
                  clan1 = clan) %>% unique()


  base_t <- create_basetable(clan = table$clan1, date = table$focal_date) %>%
    mutate(sex = fetch_sex(ID = ID)) %>%
    filter(sex == "male") %>%
    mutate(status =fetch_selection_status(ID = ID, date = date)) %>%
    group_by(clan, date) %>%
    summarise(natal = sum(status == "natal", na.rm = T))

  imput <- tibble(clan = clan, date = focal_date)

  out <- imput %>% left_join(base_t, by = c("clan", "date")) %>% pull(natal)

  return(out)
  ID <- sex <- status <- natal <- NULL
}


#' @describeIn find_family find the number of dispersers males in a given clan at a given time.
#' @export
#' @examples
#' find_dispersers_beta(clan = c("A", "A"),
#'                        date = c("1997-01-01", "1997-11-17"))
#'
#' \dontrun{
#' load_database(file.choose())
#' sight <- extract_database("sightings")
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   sight <- sight %>%
#'   mutate(clan = fetch_clan(ID, date_time),
#'          philo = find_dispersers_beta(clan = clan, date = date_time))
#'   }
#' }
find_dispersers_beta <- function(clan, date){
  focal_date <- as.Date(date)
  table <- tibble(focal_date = focal_date,
                  clan1 = clan) %>% unique()


  base_t <- create_basetable(clan = table$clan1, date = table$focal_date) %>%
    mutate(sex = fetch_sex(ID = ID)) %>%
    filter(sex == "male") %>%
    mutate(status = fetch_selection_status(ID = ID, date = date)) %>%
    group_by(clan, date) %>%
    summarise(dispersers = sum(status == "disperser", na.rm = T))

  imput <- tibble(clan = clan, date = focal_date)

  out <- imput %>% left_join(base_t, by = c("clan", "date")) %>% pull(dispersers)

  return(out)
  ID <- sex <- status <- dispersers <- NULL
}
