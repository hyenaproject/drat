#' Create tidy tables with hyena(s)
#'
#' These functions allow for the creating a tidy table in which each row correspond to an
#' individual. Depending on the function, individuals can be repeated or not. All functions from the
#' create family, provide at least a column with the ID of the hyena, and possibly other columns
#' depending on the function and the defined arguments. The produced tables are always of format
#' [tibble::tibble] and can be used as the basic structure around which you can add additional
#' columns using the functions from the [fetch_family].
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @param ID The ID code of hyena(s).
#' @param clan The letter of the clan(s). If `NULL` (default), returns
#'   information for the whole population.
#' @param date The date(s) using the format "YYYY-MM-DD". If `NULL` (default), the clan (if defined)
#'   will be interpreted as the birth clan.
#'
#' @return A tidy table
#'
#' @name create_family
#' @aliases create_family create
#'
#' @examples
#'
#'
#' ### Load the dummy dataset (needed for all examples below):
#' load_database()
NULL


#' @describeIn create_family deprecated function! Use [create_basetable()] instead.
#'
#' @export

create <- function() .Deprecated("create_basetable")


#' @describeIn create_family create a table with hyenas.
#' @export
#' @examples
#'
#' #### Simple examples of create_basetable usage:
#'
#' ### create a table for all individuals:
#' create_basetable()
#'
#' ### create a table for all individuals born in clan A:
#' create_basetable(clan = "A")
#'
#' ### create a table for two clans at one date:
#' create_basetable(clan = c("A", "L"), date = "1997/01/01")
#'
#' ### create a table for two clans, with one date per clan:
#' create_basetable(clan = c("A", "L"), date = c("1997/01/01", "1997/01/02"))
#'
#' ### combining create_basetable and fetch functions to get sex and age of clan "A" on
#' ### christmas day 2015:
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#' create_basetable(clan = "A", date = "2015/12/25") %>%
#'   mutate(
#'     sex = fetch_sex(ID = ID),
#'     age = fetch_age(ID = ID, date = date)
#'   )
#'  }
create_basetable <- function(clan = NULL, date = NULL) {

  if (length(date) > 1 & length(clan) != length(date)) {
    stop("This function does not cope with a different number (>1) of dates and clans. If you think it would be useful, please inform the developers!")
  }

  if (!is.null(clan) & is.null(date)) {
    message(paste0("Since the argument date is NULL but clan is not, clan(s) are assumed to refer to the ", crayon::red$bold("birth clan(s)"), "!"))
  }

  ## If clan are not defined, all clans are considered:
  doclan <- ifelse(is.null(clan), FALSE, TRUE)
  clan <- check_arg_clan(clan, fill = TRUE)

  ## Deal with no date being defined:
  if (is.null(date)) {
    extract_database(tables = "hyenas") %>%
      dplyr::filter(birthclan %in% !!clan) %>%
      dplyr::select(ID, birthclan) -> output
    if (!doclan) {
      output %>%
        dplyr::select(-birthclan) -> output
    }
    return(output)
  }

  ## Deal with date being defined:
  date <- check_arg_date(date)

  input <- tibble::tibble(clan = clan, date = date)

  ## Create a list with one element per clan/date combination:
  clan_members <- purrr::pmap_df(input, ~ get_clan_members(date = ..2, clan = ..1, min_age = 0) %>%
    dplyr::mutate(date = ..2))

  clan_members %>%
    dplyr::rename(
      clan = currentclan
    ) %>%
    dplyr::select(-native) %>%
    dplyr::arrange(clan, date, ID) -> output

  birthclan <- ID <- currentclan <- native <- NULL ## to please R CMD check

  output
}


#' @describeIn create_family deprecated function! Use [create_basetable()] instead.
#'
#' @export
create_basetable_for_all <- function() .Deprecated("create_basetable")


#' @describeIn create_family create a table with hyenas based on their ID.
#'
#' @export
#' @examples
#'
#' #### Simple examples of create_basetable usage:
#' create_basetable_from_IDs(c("A-001", "L-003", "A-100"))
#'
create_basetable_from_IDs <- function(ID) {
  tibble::tibble(ID = check_arg_ID(ID))
}


#' @describeIn create_family create a tidy table with individuals and their reproductive mates.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_matestable usage:
#' load_database()
#' create_matestable(c("A-001", "L-003", "A-100"))
#'
create_matestable <- function(ID = NULL) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  mates_list <- calculate_mates(ID = ID)
  mates_df <- utils::stack(mates_list)

  mates_df %>%
    tibble::as_tibble() %>%
    dplyr::transmute(ID = as.character(ind), mate = values) -> mates_tbl

  input %>%
    dplyr::left_join(mates_tbl, by = "ID") -> output

  ind <- values <- NULL ## to please R CMD check

  output
}


#' @describeIn create_family create a tidy table with individuals and their offspring.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_offspringtable usage:
#' load_database()
#' create_offspringtable(c("A-001", "L-003", "A-100"))
#'
create_offspringtable <- function(ID = NULL) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  offspring_list <- calculate_offspring(ID = ID)
  offspring_df <- utils::stack(offspring_list)

  offspring_df %>%
    tibble::as_tibble() %>%
    dplyr::transmute(ID = as.character(.data$ind),
                     offspring = .data$values) -> offspring_tbl

  input %>%
    dplyr::left_join(offspring_tbl, by = "ID") -> output

  rownames(output) <- NULL

  output
}


#' @describeIn create_family create a tidy table with individuals, their offspring and the litter ID.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_offspringtable_with_litter usage:
#' load_database()
#' create_offspringtable_with_litter(c("A-001", "L-003", "A-098"))
#'
create_offspringtable_with_litter <- function(ID = NULL) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  sexes <- fetch_sex(ID)
  if (any(is.na(sexes)) || any(sexes == "male")) {
    stop("the function create_offspring_litter_table can only work with females, perhaps you used ID corresponding to males and to an unknown sex.")
  }

  create_offspringtable(ID = ID) %>%
    dplyr::mutate(birthdate = fetch_birthdate(ID = .data$offspring)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::mutate(litter_order = ranking_no_tie(.data$birthdate),
           litter_ID = dplyr::if_else(is.na(.data$offspring), NA_character_, paste(ID, .data$litter_order, sep = "_"))) %>%
    dplyr::ungroup() %>%
    dplyr::select(-.data$litter_order, -.data$birthdate) -> output

  rownames(output) <- NULL

  output
}


#' @describeIn create_family create a tidy table with individuals and their litters.
#'
#' @export
#' @examples
#'
#' #### Simple example of create_litter_table usage:
#' load_database()
#' create_littertable(c("A-001", "L-003", "A-098"))
#'
create_littertable <- function(ID = NULL) {

  input <- tibble::tibble(ID = check_arg_ID(ID))

  create_offspringtable_with_litter(ID = ID) %>%
    select(-.data$offspring) %>%
    dplyr::distinct() -> output

  rownames(output) <- NULL

  output
}


