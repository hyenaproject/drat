#' Identify all offspring produced
#'
#' This function is for internal use only. For users, please use [create_offspringtable()] instead.
#'
#' The function takes as an input the `ID` of one or several hyena(s) and produces a list of all
#' the offspring for each `ID`. The argument `genetic` can be used to specify if the genetic or
#' adopted offspring should be found (this only applies for mothers as for fathers the distinction
#' does not apply). When looking for offspring, the function search the hyenas that contain the `ID`
#' of the potential parents as mother or father.
#'
#' @param ID The ID of hyena(s).
#' @param genetic Whether to look for the genetic mother (TRUE, default) or the social one (FALSE).
#'
#' @return The list of all the offspring for each individual.
#' @export
#'
#' @examples
#' ## Finding children for two hyenas in the dummy dataset:
#' load_database()
#' calculate_offspring(c("A-100", "L-200"))
#' \dontrun{
#' ## Finding children for two hyenas in the full dataset:
#' load_database(file.choose())
#' calculate_offspring(c("A-001", "L-200"))
#'
#' ## Finding children for all hyenas in the full dataset:
#' hyenas <- extract_database("hyenas")
#' calculate_offspring(hyenas$ID)
#' }
#'
calculate_offspring <- function(ID, genetic = TRUE) {
  #ID <- check_arg_ID(ID)  ## do not check as user level functions should!

  mother <- ifelse(genetic, "mothergenetic", "mothersocial")
  hyenas <- extract_database("hyenas")

  output <- furrr::future_map(
    .x = ID,
    ~ list(hyenas$ID[(!is.na(hyenas[[mother]]) & (hyenas[[mother]] == .x)) |
      (!is.na(hyenas$father) & (hyenas$father == .x))]), .progress = FALSE
  )
  names(output) <- ID
  unlist(output, recursive = FALSE)
}



#' Identify all known mates
#'
#' This function is for internal use only. For users, please use [create_matestable()] instead.
#'
#' The function takes as an input the `ID` of one or several hyena(s) and produces a list of all
#' the mates for each `ID`. A mate is here defined as an individual with which one made an
#' offspring. When looking for mates, the function search the hyenas that contain the `ID` of the
#' potential parents as mother or father.
#'
#' @param ID The ID of hyena(s).
#'
#' @return The list of all the mates for each individual.
#' @export
#'
#' @examples
#' load_database()
#' calculate_mates(c("A-001", "L-003"))
#'
#' \dontrun{
#' load_database(file.choose())
#' mates <- calculate_mates(find_IDs())
#' }
#'
calculate_mates <- function(ID) {
  #ID <- check_arg_ID(ID)  ## do not check as user level functions should!

  hyenas <- extract_database("hyenas")

  output <- furrr::future_map(
    .x = ID,
    ~ list({
      which_females    <- which(hyenas$mothergenetic %in% .x)
      which_males      <- which(hyenas$father %in% .x)
      mates_of_females <- unique(hyenas$mothergenetic[which_males])
      mates_of_males   <- unique(hyenas$father[which_females])
      mates <- c(mates_of_females, mates_of_males)
      mates[!is.na(mates)]
      }), .progress = FALSE
  )

  names(output) <- ID
  unlist(output, recursive = FALSE)
}

