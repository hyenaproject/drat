## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----help, eval = FALSE-------------------------------------------------------
#  help(package = 'hyenaR')

