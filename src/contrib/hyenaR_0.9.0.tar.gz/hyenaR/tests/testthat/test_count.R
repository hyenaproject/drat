context("Test count_xxx functions")

test_that("all count functions return the correct type", {
  expect_equal(class(count_all(clan = c("A", "L"), date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_all(clan = c("A", "L"), date = c("1997/01/01", "2011/01/01")))[1], "integer")
  expect_equal(class(count_all(clan = "A", date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_all(clan = NULL, date = "1997/01/01"))[1], "integer")

  expect_equal(class(count_males(clan = c("A", "L"), date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_males(clan = c("A", "L"), date = c("1997/01/01", "2011/01/01")))[1], "integer")
  expect_equal(class(count_males(clan = "A", date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_males(clan = NULL, date = "1997/01/01"))[1], "integer")

  expect_equal(class(count_females(clan = c("A", "L"), date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_females(clan = c("A", "L"), date = c("1997/01/01", "2011/01/01")))[1], "integer")
  expect_equal(class(count_females(clan = "A", date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_females(clan = NULL, date = "1997/01/01"))[1], "integer")

  expect_equal(class(count_adults(clan = c("A", "L"), date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_adults(clan = "A", date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_adults(clan = NULL, date = "1997/01/01"))[1], "integer")

  expect_equal(class(count_immigrants(clan = c("A", "L"), date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_immigrants(clan = "A", date = "1997/01/01"))[1], "integer")
  expect_equal(class(count_immigrants(clan = NULL, date = "1997/01/01"))[1], "integer")

  expect_equal(class(count_selection_status(clan = c("A", "L"), date = "1997/01/01", status = "philopatric"))[1], "integer")
  expect_equal(class(count_selection_status(clan = "A", date = "1997/01/01", status = "philopatric"))[1], "integer")
  expect_equal(class(count_selection_status(clan = NULL, date = "1997/01/01", status = "philopatric"))[1], "integer")
})
