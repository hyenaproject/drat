context("Test fetch_xxx_yyy functions")

test_that("all fetch functions return the correct type of vector", {
  expect_equal(class(fetch_sex(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_birthclan(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_birthdate(ID = c("A-080", "L-001")))[1], "Date")
  expect_equal(class(fetch_mothergenetic(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_mothersocial(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_father(ID = c("A-080", "L-001")))[1], "character")
  expect_equal(class(fetch_litterdominance(ID = c("A-018", "M-007")))[1], "integer")

  expect_equal(class(fetch_birthrank(ID = c("A-080")))[1], "integer")
  expect_equal(class(fetch_birthrankstd(ID = c("A-080")))[1], "numeric")

  expect_equal(class(fetch_birthdate(ID = c("A-080", "L-001")))[1], "Date")
  expect_equal(class(fetch_date_at_first_selection(ID = c("A-011", "A-040")))[1], "Date")
  expect_warning(class(fetch_date_at_first_selection(ID = c("A-001", "A-002")))[1], "Date")

  expect_equal(class(fetch_lifespan(ID = c("A-080", "L-001")))[1], "numeric")

  expect_equal(class(fetch_offspring_number(ID = c("A-001", "A-100", "L-003")))[1], "integer")
  expect_equal(class(fetch_date_at_first_conception(ID = c("A-001", "L-003")))[1], "Date")

  expect_equal(class(fetch_tenure(ID = c("A-011", "A-040"), date = "2000-01-01"))[1], "numeric")

  expect_equal(class(fetch_age(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))[1], "numeric")
  expect_equal(class(fetch_age(ID = "A-080", date = c("1997-01-01", "1996-07-01")))[1], "numeric")
  expect_equal(class(fetch_age(ID = c("A-080", "L-001"), date = "1996-07-01"))[1], "numeric")
  expect_equal(class(fetch_date(ID = c("A-080", "L-001"), age = c(2, 3), unit = c("days", "week")))[1], "Date")

  expect_equal(class(fetch_is_immigrant(ID = c("A-080", "L-001"), date = "1998-01-01"))[1], "logical")
  expect_equal(class(fetch_is_native(ID = c("A-080", "L-001"), date = "1998-01-01"))[1], "logical")

  expect_equal(class(fetch_first_observed_date(ID = c("A-080", "L-001")))[1], "Date")

  expect_equal(class(fetch_last_observed_date(ID = c("A-080", "L-001")))
  [1], "Date")
  expect_equal(class(fetch_is_observed(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "logical")
  expect_equal(class(fetch_is_alive(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "logical")
  expect_equal(class(fetch_rank(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "integer")
  expect_equal(class(fetch_rankstd(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "numeric")
  expect_equal(class(fetch_genderrank(ID = c("A-001", "N-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "integer")
  expect_equal(class(fetch_genderrankstd(ID = c("A-001", "N-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "numeric")
  expect_equal(class(fetch_nativerank(ID = c("A-001", "N-001"), date = c("1997-01-01", "1996-07-01")))
               [1], "integer")
  expect_equal(class(fetch_nativerankstd(ID = c("A-001", "N-001"), date = c("1997-01-01", "1996-07-01")))
               [1], "numeric")
  expect_equal(class(fetch_clan(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "character")
  expect_equal(class(fetch_clanadults(ID = c("A-080", "L-001"), date = c("1997-01-01", "1996-07-01")))
  [1], "integer")
  expect_equal(class(fetch_is_censored_left(ID = c("A-080", "L-001")))[1], "logical")
  expect_equal(class(fetch_is_observable(ID = c("A-080", "L-001"), duration = 3))[1], "logical")
  expect_equal(class(fetch_is_selector(c("A-040", "A-040"), c("A", "A"), c("1996-07-10", "1996-07-12")))[1], "logical")
  expect_equal(class(fetch_support_natives(ID = c("A-001", "A-100"), date = c("1997-01-04", "1997-11-30")))[1], "numeric")
  expect_equal(class(fetch_support_all(ID = c("A-011", "A-100"), date = c("1997-01-04", "1997-11-30")))[1], "numeric")
  expect_equal(class(fetch_support_immigrants(ID = c("A-011", "A-100"), date = c("1997-01-04", "1997-06-30")))[1], "numeric")
  expect_equal(class(fetch_dna(ID = c("A-011", "A-100"))), "character")
})

test_that("fetch_dna returns 'yes' if the hyena is genetically typed, otherwise 'no'", {
  ref <- c("yes", "no")
  job <- fetch_dna(c("A-001", "A-002"))
  expect_equal(ref, job)
})

test_that("fetch_is_selector returns the correct output", {
  ref <- c(FALSE, TRUE)
  job <- fetch_is_selector( c("A-040", "A-040" ), c("A", "A"), c("1996-07-10", "1996-07-12"))
  expect_equal(ref, job)
})
