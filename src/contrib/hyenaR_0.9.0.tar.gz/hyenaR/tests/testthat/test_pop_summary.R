context("Test pop_summary function")

test_that("Returns a complete summary when no date provided", {
  output_summary <- pop_summary(date = "1997-01-01")

  # Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  # Test that date is in date format
  expect_equal(class(output_summary$date), "Date")
  # Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$pop_size)
  & is.numeric(output_summary$active_clans)
  & is.numeric(output_summary$average_size))
})

test_that("Returns a summary when multiple dates provided", {
  output_summary <- pop_summary(date = c("1996-05-01", "1997-01-01"))

  # Test that returned object is a tibble
  expect_equal(class(output_summary)[1], "tbl_df")
  # Test that date is in date format
  expect_equal(class(output_summary$date), "Date")
  # Test that pop_size, active_clans and average_size columns are all numeric
  expect_true(is.numeric(output_summary$pop_size)
  & is.numeric(output_summary$active_clans)
  & is.numeric(output_summary$average_size))
})

test_that("Returns a message when a too recent date is provided", {

  expect_message(pop_summary(date = c("2100-01-01")))

})
