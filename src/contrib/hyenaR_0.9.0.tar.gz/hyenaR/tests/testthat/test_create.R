context("Test create_xxx functions")

test_that("all create functions return the correct type", {
  expect_equal(class(create_basetable(clan = c("A", "L"), date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L"), date = c("1997/01/01", "2011/01/01")))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = "A", date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = NULL, date = "1997/01/01"))[1], "tbl_df")
  expect_equal(class(create_basetable(clan = c("A", "L")))[1], "tbl_df")
  expect_equal(class(create_basetable())[1], "tbl_df")
  expect_equal(class(create_basetable_from_IDs(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_offspringtable(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_matestable(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_offspringtable_with_litter(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_littertable(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_matingtable(c("A-001", "L-003", "A-098")))[1], "tbl_df")
})


test_that("create_littertable returns the correct ouput", {
  ref <- structure(list(ID = c("A-001", "A-001", "A-001", "A-001", "L-003", "A-098"),
                        litter_ID = c("A-001_1", "A-001_2", "A-001_3", "A-001_4", "L-003_1", NA)),
                   class = c("tbl_df", "tbl", "data.frame"),
                   row.names = c(NA, -6L))
  job <- create_littertable(c("A-001", "L-003", "A-098"))
  expect_equal(ref, job)
})


test_that("create_offspringtable_with_litter returns the correct ouput", {
  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "L-003", "A-098"),
        offspring = c("A-010", "A-018", "A-046", "A-084", "A-088", "A-089", "L-089", NA),
        litter_ID = c("A-001_1", "A-001_2", "A-001_2", "A-001_3", "A-001_4", "A-001_4", "L-003_1", NA)),
      row.names = c(NA,-8L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  job <- create_offspringtable_with_litter(c("A-001", "L-003", "A-098"))
  expect_equal(ref, job)
})

test_that("create_matingtable returns the correct output", {
  ref <-
    structure(
      list(
        ID = c("A-001", "A-001", "A-001", "A-001", "A-001", "A-001", "L-003", "A-098"),
        mate = c("A-045", "A-045", NA, NA, NA, NA, "L-043", NA),
        date = as.Date(c("1994-06-03", "1995-01-28", "1995-01-28", "1995-06-20", "1996-08-24", "1996-08-24", "1995-04-20", NA ))
      ),
      row.names = c(NA, -8L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- create_matingtable(c("A-001", "L-003", "A-098"))
  expect_identical(ref, job)
})

