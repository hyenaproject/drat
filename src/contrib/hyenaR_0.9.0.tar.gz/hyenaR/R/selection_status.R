#' Internal function to extract the selection events
#'
#' @param ID The ID code of hyena(s).
#'
#' @return A list with a tibble of selection events for each individual.
#' @export
#'
#' @examples
#' # Run with dummy database
#' load_database()
#' calculate_selection_events(ID = c("A-001", "A-100"))
#'
calculate_selection_events <- function(ID = NULL) {

  ID <- check_arg_ID(ID)
  selections <- extract_database("selections")

  output <- purrr::map(.x = ID,
                       ~ list(selections[selections$ID %in% .x, ]),
                       .progress = FALSE)
  names(output) <- ID
  unlist(output, recursive = FALSE)
}


#' @describeIn create_family create a tidy table with individuals and their selection events.
#'
#' @export
#' @examples
#' #### Simple examples of create_selection_events usage:
#' load_database()
#' create_selection_events()
#'
#' ### count selection events for each individuals (birth = 1)
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'  create_selection_events() %>%
#'    mutate(sex = fetch_sex(ID)) %>%
#'      group_by(ID, sex) %>%
#'      summarise(n = n()) -> foo
#'   table(foo$n, foo$sex)
#' }
#'
create_selection_events <- function(ID = NULL) {

  ID <- check_arg_ID(ID, fill = TRUE)

  if (length(ID) != length(unique(ID))) {
    warning("Some ID were duplicated and have been dropped in create_selection_events()")
    ID <- unique(ID)
  }

  input <- tibble::tibble(ID = ID)

  selection_events_list <- calculate_selection_events(ID = input$ID)
  selection_events_df <- do.call("rbind", selection_events_list) ## looses empty rows

  input %>%
    dplyr::mutate(destination = fetch_birthclan(ID = .data$ID),
           date = fetch_birthdate(ID = .data$ID)) %>%
    dplyr::full_join(selection_events_df, by = c("ID", "destination", "date")) %>% ## restore empty rows but does not conserve ID ranking
    dplyr::select(-.data$origin) %>%
    dplyr::rename(clan = .data$destination) %>%
    dplyr::arrange(.data$ID, .data$date) -> output

  output
}

#' @describeIn fetch_family fetch the selection status of a given hyena.
#' @export
#' @examples
#' fetch_selection_status(ID = c("A-001"),
#'                        date = c("1997-01-01"))
#'
#' \dontrun{
#' load_database(file.choose())
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   create_basetable() %>%
#'      mutate(selection = fetch_selection_status(ID = ID, date = "2010/01/01")) %>%
#'      filter(selection == "selector_2")
#'  }
#' }
#'
fetch_selection_status <- function(ID, date, debug = FALSE) {
  input_full <- dplyr::tibble(ID = check_arg_ID(ID),
                              focal_date = check_arg_date(date))

  ## reduce to unique case for speed up:
  input <-  unique(input_full)

  ## add age, sex, date first conception:
  input %>%
    dplyr::mutate(age = fetch_age(.data$ID, date = .data$focal_date),
                  sex = fetch_sex(.data$ID),
                  first_conception = fetch_date_at_first_conception(.data$ID)) -> input

  ## add whether individuals have conceived before focal date or not:
  input %>%
    dplyr::mutate(has_conceived = dplyr::case_when(
                      is.na(.data$first_conception) ~ FALSE,
                      !is.na(.data$first_conception) & (.data$first_conception <= .data$focal_date) ~ TRUE,
                      !is.na(.data$first_conception) & (.data$first_conception > .data$focal_date) ~ FALSE)
                  ) -> input

  ## add selection events:
  input %>%
    dplyr::left_join(x = create_selection_events(ID = unique(input$ID)), y = ., by = "ID") -> output

  ## remove dispersion events after focal date:
  output %>%
    dplyr::filter(.data$date <= .data$focal_date) -> output

  if (debug) return(output)

  ## compare clans:
  output %>%
    dplyr::group_by(.data$ID, .data$focal_date) %>%
    dplyr::mutate(previous_clan = dplyr::lag(.data$clan),
                  same_clan_as_previous = .data$previous_clan == .data$clan,
                  is_transient = .data$clan == "Y") -> output

  ## count dispersion events:
  output %>%
    dplyr::group_by(.data$ID, .data$focal_date) %>%
    dplyr::summarise(events = dplyr::n() - sum(.data$is_transient), ## transient state do not count!
                     same_clan_as_previous = dplyr::last(.data$same_clan_as_previous),
                     is_transient = dplyr::last(.data$is_transient)) %>%
    dplyr::left_join(x = input, y = ., by = c("ID", "focal_date")) -> output

  ## label dispersion status:
  output %>%
    dplyr::mutate(status = dplyr::case_when(
      .data$age <= 1 & !.data$has_conceived & .data$events == 1 ~ "cub", ## for both sexes
      .data$age > 1 & .data$age <=2 & !.data$has_conceived & .data$events == 1 ~ "subadult",
      is.na(.data$sex) & .data$age > 2 & .data$events == 1 ~ "natal",
      .data$sex == "male" & .data$age > 2 & .data$events == 1 ~ "natal",
      .data$sex == "female" & (.data$age > 2 | .data$has_conceived) & .data$events == 1 ~ "philopatric",
      .data$events == 2 & .data$same_clan_as_previous == TRUE & !.data$is_transient ~ "philopatric",
      .data$events == 2 & .data$same_clan_as_previous == FALSE & !.data$is_transient ~ "disperser",
      .data$events > 1 & .data$is_transient ~ "transient",
      .data$events > 2 & !.data$is_transient ~ paste0("selector_", .data$events - 1),
       TRUE ~ NA_character_
       )) -> output

  ## merge to original input to reduplicate the information and reorder as in original:
  input_full %>%
    left_join(output, by = c("ID", "focal_date")) -> output_full

  return(output_full$status)
}
