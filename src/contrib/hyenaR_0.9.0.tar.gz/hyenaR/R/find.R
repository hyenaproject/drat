#' Obtain information about clans or the population
#'
#' These functions allows for the creating of vectors with various information about given clans or
#' the whole population. There are used to find out for example which hyenas exist, which clans
#' exist, the first sighting date for the whole population and so forth.
#'
#' All ```find_xxx``` functions output a vector which items are not repeated (they are unique).
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @param clan The letter of the clan(s). If `NULL` (default), returns
#'   information for the whole population.
#' @param date The date(s) using the format "YYYY-MM-DD". If `NULL` (default), returns
#'   information for the entire study period.
#' @name find_family
#' @aliases find_family find
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_database()
NULL


#' @describeIn find_family find all adults
#' @export
#' @examples
#'
#' #### Simple example of find_adults usage:
#' find_adults(clan = c("A", "L"), date = "1997/01/01")
find_adults <- function(clan = NULL, date = NULL) {
  if (!is.null(date) & length(date) > 1) stop("The function find_adults() cannot handle multiple dates.")
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(age = fetch_age(ID = ID, date = date)) %>%
    dplyr::filter(age > 2) %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  ID <- age <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family create a vector of all clans
#'
#' @param only_main A logical indicating whether to select only the 8 crater
#' floor clans (TRUE, default) or all known clans (FALSE)
#'
#' @export
#' @examples
#'
#' #### Example of find_clans usage:
#'
#' ### find all clans in the data:
#' find_clans(only_main = FALSE)
#'
#' ### find all crater floor clans in the data:
#' find_clans()
#'
find_clans <- function(only_main = TRUE) {

  extract_database("hyenas") %>%
    dplyr::pull(birthclan) -> clans

  clans <- sort(unique(clans))

  if (only_main) {
    main_possible <- c("A", "E", "F", "L", "M", "N", "S", "T")
    clans <- clans[clans %in% main_possible]
  }

  birthclan <- NULL ## to please R CMD check

  clans
}



#' @describeIn find_family find all females
#' @export
#' @examples
#'
#' #### Simple example of find_female usage:
#' find_females(clan = c("A", "L"), date = "1997/01/01")
find_females <- function(clan = NULL, date = NULL) {
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(sex = fetch_sex(ID = ID)) %>%
    dplyr::filter(sex == "female") %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  id <- sex <- ID <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find date of first sighting.
#' @param from_conception Whether the data of the first sighting is estimated from dates inferred from conception (TRUE) or not (FALSE: default).
#' @export
#' @examples
#'
#' #### Example of find_firstsighting usage:
#' find_firstsighting()
#' find_firstsighting(from_conception = TRUE)
find_firstsighting <- function(from_conception = FALSE) {
  sightings <- extract_database("sightings")
  if (from_conception) return(min(as.Date(sightings$date_time)))
  min(as.Date(sightings$date_time[is.na(sightings$remarks) |
                                    (!is.na(sightings$remarks) & (sightings$remarks != "Estimated from conception") &
                                       !grepl(pattern = "identified in BBC documentary", x = sightings$remarks) &
                                       !grepl(pattern = "one-day visit", x = sightings$remarks))]))
}


#' @describeIn find_family create a vector of all individuals.
#' @export
#' @examples
#'
#' #### Detailed example of find_IDs usage:
#' ### note: what is shown here also applies to all other find_xxx functions
#'
#' ### find all hyenas from 2 clans at a single date:
#' find_IDs(clan = c("A", "L"), date = "1997/02/01")
#'
#' ### find all hyenas alive from 2 clans at one date per clan:
#' find_IDs(clan = c("A", "L"), date = c("1997/02/01", "1996/11/21"))
#'
#' ### find all hyenas in the data:
#' find_IDs()
find_IDs <- function(clan = NULL, date = NULL) {

  clan <- check_arg_clan(clan, fill = TRUE)

  if (is.null(date)) {
    extract_database("hyenas") %>%
      dplyr::filter(birthclan %in% {{clan}}) -> output
  } else {
    create_basetable(clan = {{clan}}, date = {{date}}) -> output
  }

  birthclan <- NULL ## to please R CMD check

  sort(output$ID)
}



#' @describeIn find_family find all immigrants
#'
#' Note that this function does not consider the sex.
#' @export
#' @examples
#'
#' #### Simple example of find_immigrants usage:
#' find_immigrants(clan = c("A", "L"), date = "1997/01/01")
find_immigrants <- function(clan = NULL, date = NULL) {
  if (!is.null(date) & length(date) > 1) stop("The function find_immigrants() cannot handle multiple dates.")
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(clan = fetch_clan(ID = ID, date = date),
                  birthclan = fetch_birthclan(ID),
                  immigrant = birthclan != clan) %>%
    dplyr::filter(immigrant) %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  birthclan <- ID <- immigrant <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find date of last sighting.
#' @export
#' @examples
#'
#' #### Example of find_lastsighting usage:
#' find_lastsighting()
find_lastsighting <- function() {
  sightings <- extract_database("sightings")
  max(as.Date(sightings$date_time))
}


#' @describeIn find_family find all males
#' @export
#' @examples
#'
#' #### Simple example of find_males usage:
#' find_males(clan = c("A", "L"), date = "1997/01/01")
find_males <- function(clan = NULL, date = NULL) {
  tibble::tibble(ID = find_IDs(clan = clan, date = date)) %>%
    dplyr::mutate(sex = fetch_sex(ID = ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::arrange(ID) %>%
    dplyr::pull(ID) -> output

  id <- sex <- ID <- NULL ## to please R CMD check

  output
}


#' @describeIn find_family find all deaths between 2 dates
#' @export
#' @param from The starting date of the interval (included).
#' @param to The ending date of the interval (included).
#' @examples
#'
#' #### Simple example of find_scan_deaths usage:
#' find_scan_deaths(from = "1996/09/01")
#' find_scan_deaths(to = "1999/01/01")
#' find_scan_deaths(from = "1996/09/10", to = "1999/01/01")
find_scan_deaths <- function(from = NULL, to = NULL) {
  ## checking inputs:
  if (length(from) > 1 || length(to) > 1) {
    stop("The function find_scan_deaths() cannot handle multiple dates for 'from' and 'to'.")
  }

  if (is.null(from)) {
    from <- find_firstsighting()
  }

  if (is.null(to)) {
    to <- find_lastsighting()
  }

  from <- check_arg_date(from)
  to <- check_arg_date(to)

  create_basetable() %>%
    mutate(death_date = fetch_deathdate(ID = .data$ID)) %>%
    filter(.data$death_date >= !!from & .data$death_date <= !!to) -> output

  output$ID
}


#' @describeIn find_family find individuals of a given selection status (of both sexes) in given clan(s) at a given time.
#' @inheritParams check_arg_status
#' @export
#' @examples
#' #### Simple example of find_philopatrics usage:
#' find_selection_status(clan = c("A", "L"), date = "1997/02/01", status = "philopatric")
#'
find_selection_status <- function(clan = NULL, date, status) {

  ## checking inputs:
  clan <- check_arg_clan(clan = clan, fill = TRUE)

  if (!is.null(date) & length(date) > 1) {
    stop("The function find_selection_status() cannot handle multiple dates.")
  }

  date <- check_arg_date(date)
  status <- check_arg_status(status)

  ## remove duplicates:
  input <- tibble(date = date,
                  clan = clan) %>% unique()

  ## retrieve selection status and filter:
  create_basetable(clan = input$clan, date = input$date) %>%
    mutate(status = fetch_selection_status(ID = .data$ID, date = .data$date)) %>%
    filter(status == !!status) -> output

  output$ID
}

