#' Calculate observation effort for hyena clans
#'
#' Calculate the observation effort for a given clan over a given date range.
#' Observation effort is proportion of known individuals observed on a given date.
#' N.B. This assumes that number of individuals sighted is related to observer effort.
#' @param db Location of database. If unspecified, will use dummy database file for examples.
#' @param start_date Start date of focal period.
#' @param end_date End date of focal period.
#' @param clans Name of clan(s) of interest. If left blank will return a summary of all clans in the specified database.
#' @param age_class Age class to use for estimating observer effort. Can be "adult", "cub", or "both".
#'
#' @return A data frame with observation effort for chosen clans over given dates.
#' @export
#'
#' @examples
#'
#' #Estimate observer effort for clan A
#' calc_obsveffort(clans = "A", start_date = "2003-01-01", end_date = "2003-12-01")

calc_obsveffort <- function(db = NULL, clans = NA, start_date = -Inf, end_date = Inf, age_class = "both"){

  #Assign NULL to avoid global variable NOTE
  clanID <- name <- dateadult <- clan <- nr_adults <- nr_cubs <- NULL

  #If database location is not provided, use stored database file
  if(is.null(db)){

    db = system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  }

  #Establish a connection with the database
  connection <- dbConnect(SQLite(), db)

  #Convert start and end_date to date objects
  if(!is.infinite(start_date)){

    start_date <- lubridate::ymd(start_date)

  } else {

    start_date <- lubridate::ymd("1995-01-05")

  }

  if(!is.infinite(end_date)){

    end_date <- lubridate::ymd(end_date)

  } else {

    end_date <- lubridate::ymd(tbl(connection, "sightings") %>% summarise(latest_date = max(date, na.rm = T)) %>% collect())

  }

  #If clans is NA, assume we're wanting observer effort for all clans
  if(is.na(clans)){

    clans <- c("A", "E", "F", "L", "M", "N", "S", "T")

  }

  if(age_class == "adult"){

    #Extract information on when individuals became adults
    adults <- tbl(connection, "adults")

    #Extract sightings data and subset to just cover the start and end date
    total_sightings <- tbl(connection, "sightings") %>%
      #Filter to only include the specified clans
      filter(date >= start_date & date <= end_date & clanID %in% clans) %>%
      #Subset just to variables we want
      select(date, name, clanID) %>%
      #Link dateadult for every observed individual
      left_join(select(adults, name, dateadult), by = "name") %>%
      #Filter only those individuals that were adults on the date of observation
      filter(date >= dateadult) %>%
      #Determine total number of sightings of each clan on each date
      group_by(date, clanID) %>%
      summarise(total_sightings = n_distinct(name)) %>%
      collect() %>%
      ungroup()

    #Determine which clans were observed on each date
    sightings_perdate <- total_sightings %>%
      group_by(date) %>%
      summarise(clanID = list(clans))

    #For every date where sightings were taken, determine the number of hyenas in the clans sighted at that time
    pb <- dplyr::progress_estimated(n = nrow(sightings_perdate))

    clan_size <- pmap_df(.l = list(date = sightings_perdate$date, clan = sightings_perdate$clanID),
                         .f = function(db, date, clan){

                           pb$tick()$print()

                           clan_summary(db = db, date = date, clan = clan)

                         }, db = db)

    #For every day between the specified start and end date and for the chosen clans determine the observer effort as number sightings/clan size.
    #When no sightings were made on a given date we assume the clan was not observed
    #N.B. This could be a problem if they look for a clan and couldn't find them...but for now we are assuming that a clan could be found if it was being focused on.
    #An alternative is to use observation time table...need to consider more later.
    obsv_effort <- expand.grid(date = seq(start_date, end_date, by = "days"), clanID = clans, stringsAsFactors = FALSE) %>%
      left_join(total_sightings %>% mutate(date = lubridate::ymd(date)), by = c("date", "clanID")) %>%
      left_join(select(clan_size, date, clanID = clan, nr_adults), by = c("date", "clanID")) %>%
      transmute(date = date, clanID = clanID, obs_effort = round(pmap_dbl(.l = list(total_sightings = total_sightings, nr_adults = nr_adults),
                                                                      .f = function(total_sightings, nr_adults){

                                                                        if(is.na(total_sightings)){

                                                                          return(0)

                                                                        } else {

                                                                          return(total_sightings/nr_adults)

                                                                        }

                                                                      }), digits = 3))

  } else if(age_class == "cub"){

    #Extract information on when individuals became adults
    adults <- tbl(connection, "adults")

    #Extract sightings data and subset to just cover the start and end date
    total_sightings <- tbl(connection, "sightings") %>%
      #Filter to only include the specified clans
      filter(date >= start_date & date <= end_date & clanID %in% clans) %>%
      #Subset just to variables we want
      select(date, name, clanID) %>%
      #Link dateadult for every observed individual
      left_join(select(adults, name, dateadult), by = "name") %>%
      #Filter only those individuals that were adults on the date of observation
      filter(date < dateadult) %>%
      #Determine total number of sightings of each clan on each date
      group_by(date, clanID) %>%
      summarise(total_sightings = n_distinct(name)) %>%
      collect() %>%
      ungroup()

    #Determine which clans were observed on each date
    sightings_perdate <- total_sightings %>%
      group_by(date) %>%
      summarise(clanID = list(clans))

    #For every date where sightings were taken, determine the number of hyenas in the clans sighted at that time
    pb <- dplyr::progress_estimated(n = nrow(sightings_perdate))

    clan_size <- pmap_df(.l = list(date = sightings_perdate$date, clan = sightings_perdate$clanID),
                         .f = function(db, date, clan){

                           pb$tick()$print()

                           clan_summary(db = db, date = date, clan = clan)

                         }, db = db)

    #For every day between the specified start and end date and for the chosen clans determine the observer effort as number sightings/clan size.
    #When no sightings were made on a given date we assume the clan was not observed
    #N.B. This could be a problem if they look for a clan and couldn't find them...but for now we are assuming that a clan could be found if it was being focused on.
    #An alternative is to use observation time table...need to consider more later.
    obsv_effort <- expand.grid(date = seq(start_date, end_date, by = "days"), clanID = clans, stringsAsFactors = FALSE) %>%
      left_join(total_sightings %>% mutate(date = lubridate::ymd(date)), by = c("date", "clanID")) %>%
      left_join(select(clan_size, date, clanID = clan, nr_cubs), by = c("date", "clanID")) %>%
      transmute(date = date, clanID = clanID, obs_effort = round(pmap_dbl(.l = list(total_sightings = total_sightings, nr_cubs = nr_cubs),
                                                                          .f = function(total_sightings, nr_cubs){

                                                                            if(is.na(total_sightings)){

                                                                              return(0)

                                                                            } else {

                                                                              return(total_sightings/nr_cubs)

                                                                            }

                                                                          }), digits = 3))

  } else if(age_class == "both") {

    #Extract sightings data and subset to just cover the start and end date
    total_sightings <- tbl(connection, "sightings") %>%
      #Filter to only include the specified clans
      filter(date >= start_date & date <= end_date & clanID %in% clans) %>%
      #Subset just to variables we want
      select(date, name, clanID) %>%
      #Determine total number of sightings of each clan on each date
      group_by(date, clanID) %>%
      summarise(total_sightings = n_distinct(name)) %>%
      collect() %>%
      ungroup()

    #Determine which clans were observed on each date
    sightings_perdate <- total_sightings %>%
      group_by(date) %>%
      summarise(clanID = list(clans))

    #For every date where sightings were taken, determine the number of hyenas in the clans sighted at that time
    pb <- dplyr::progress_estimated(n = nrow(sightings_perdate))

    clan_size <- pmap_df(.l = list(date = sightings_perdate$date, clan = sightings_perdate$clanID),
                         .f = function(db, date, clan){

                           pb$tick()$print()

                           clan_summary(db = db, date = date, clan = clan)

                         }, db = db)

    #For every day between the specified start and end date and for the chosen clans determine the observer effort as number sightings/clan size.
    #When no sightings were made on a given date we assume the clan was not observed
    #N.B. This could be a problem if they look for a clan and couldn't find them...but for now we are assuming that a clan could be found if it was being focused on.
    #An alternative is to use observation time table...need to consider more later.
    obsv_effort <- expand.grid(date = seq(start_date, end_date, by = "days"), clanID = clans, stringsAsFactors = FALSE) %>%
      left_join(total_sightings %>% mutate(date = lubridate::ymd(date)), by = c("date", "clanID")) %>%
      left_join(select(clan_size, date, clanID = clan, clan_size), by = c("date", "clanID")) %>%
      transmute(date = date, clanID = clanID, obs_effort = round(pmap_dbl(.l = list(total_sightings = total_sightings, clan_size = clan_size),
                                                                          .f = function(total_sightings, clan_size){

                                                                            if(is.na(total_sightings)){

                                                                              return(0)

                                                                            } else {

                                                                              return(total_sightings/clan_size)

                                                                            }

                                                                          }), digits = 3))

  }

  return(obsv_effort)

}
