#' Obtain information about clans or the population
#'
#' These functions allows for the creating of vectors with various information about given clans or
#' the whole population. There are used to find out for example which hyenas exist, which clans
#' exist, the first sighting date for the whole population and so forth.
#'
#' All ```find_xxx``` functions output a vector which items are not repeated (they are unique).
#'
#' These functions can be used with inputs of length 1 or using vector.
#'
#'   information for the whole population.
#' @inheritParams arguments
#' @name find_family
#' @aliases find_family find
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL


#' @describeIn find_family Create a vector of all clans
#'
#' @export
#' @examples
#'
#' #### Example of find_clan_name.all usage:
#'
#' ### find all clans in the data:
#' find_clan_name.all(main.clans = FALSE)
#'
#' ### find all crater floor clans in the data:
#' find_clan_name.all()
#'
find_clan_name.all <- function(main.clans = TRUE, full.clan.names = FALSE) {

  extract_database_table("hyenas") %>%
    dplyr::pull(.data$birthclan) -> clans

  clans <- sort(unique(clans))

  clan_details <- extract_database_table("clans")

  if (main.clans) {

    clan_details %>%
      dplyr::filter(.data$location1 == "floor") %>%
      dplyr::pull(.data$clanID) -> main_possible

    clans <- clans[clans %in% main_possible]

  }

  if(full.clan.names){

    clan_details %>%
      dplyr::filter(.data$clanID %in% clans) %>%
      dplyr::pull(.data$clanname) -> clans

  }

  clans

}


#' @describeIn find_family find date of first sighting.
#' @export
#' @examples
#'
#' #### Example of find_pop_date.observation.first usage:
#' find_pop_date.observation.first()
#' find_pop_date.observation.first(from.conception = TRUE)
find_pop_date.observation.first <- function(from.conception = FALSE) {
  sightings <- extract_database_table("sightings")
  if (from.conception) return(min(as.Date(sightings$date_time)))
  min(as.Date(sightings$date_time[is.na(sightings$remarks) |
                                    (!is.na(sightings$remarks) & (sightings$remarks != "Estimated from conception") &
                                       !grepl(pattern = "identified in BBC documentary", x = sightings$remarks) &
                                       !grepl(pattern = "one-day visit", x = sightings$remarks))]))
}


#' @describeIn find_family find date of last sighting.
#' @export
#' @examples
#'
#' #### Example of find_pop_date.observation.last usage:
#' find_pop_date.observation.last()
find_pop_date.observation.last <- function() {
  sightings <- extract_database_table("sightings")
  if (any(is.na(sightings$date_time))) {
    warning("Some sighting dates are unknown in the dataset, please correct that.")
  }
  max(as.Date(sightings$date_time), na.rm = TRUE)
}


#' @describeIn find_family find litters born in the population at a given time.
#'
#' @export
#' @examples
#' #### Simple example of find_pop_litterID usage:
#' find_pop_litterID()
#' find_pop_litterID(from = "1994-01-01", to = "1995-01-01")
#'
find_pop_litterID <- function(from = NULL, to = NULL, at = NULL,
                              fill = TRUE, main.clans = TRUE, first.event = "birthdate") {

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to
  clan      <- find_clan_name.all(main.clans = main.clans)

  create_offspring_starting.table(find_pop_id(), from, to) %>%
    dplyr::mutate(birth.clan = fetch_id_clan.birth(.data$offspringID)) %>%
    dplyr::filter(!is.na(.data$offspringID) & .data$birth.clan %in% clan) -> offspring.table

  offspring.table %>%
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID, filiation = "mother_genetic")) -> litter.genetic
  ## retrieve the litters made up of only social cubs. Before those were ignored
  offspring.table %>%
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID, filiation = "mother_social")) -> litter.social

  rbind(litter.genetic, litter.social) %>%
    dplyr::filter(!is.na(.data$litterID)) %>%
    dplyr::distinct(.data$litterID) -> litters

  litters$litterID
}


#' @describeIn find_family find litters born in the given clans at a given time.
#'
#' @export
#' @examples
#' #### Simple example of find_clan_litterID usage:
#' find_clan_litterID(clan = c("A", "L"), first.event = "observation")
#' find_clan_litterID(clan = c("A", "L"), from = "1994-01-01", to = "1995-01-01")
#'
find_clan_litterID <- function(clan, from = NULL, to = NULL, at = NULL,
                               fill = TRUE, main.clans = TRUE, first.event = "birthdate") {

  min.date <- switch(first.event,
                     birthdate = find_pop_date.birth.first(),
                     observation = find_pop_date.observation.first(),
                     conception = find_pop_date.conception.first())
  max.date <- find_pop_date.observation.last()

  clan       <- check_function_arg.clan(clan, fill = fill)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
                                                 fill = fill,
                                                 min.date = min.date,
                                                 max.date = max.date)
  from       <- date_range$from
  to         <- date_range$to

  tibble(litterID = find_pop_litterID(main.clans = main.clans)) %>%
    arrange(.data$litterID) %>%
    mutate(from = from,
           to = to,
           litter.birth = fetch_litter_date.birth(.data$litterID),
           ## I assume that the clan of the litter is the clan of the mother at the litter birthdate
           litter.mother = substr(.data$litterID, start = 1, stop = 5),
           litter.clan = fetch_id_clan.current(.data$litter.mother, at = .data$litter.birth)) %>%
    filter(.data$litter.clan %in% clan, .data$litter.birth >= .data$from, .data$litter.birth <= .data$to) -> clan.litters

  clan.litters$litterID
}

#' @describeIn find_family Returns earliest birthdate from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.birth.first()

find_pop_date.birth.first <- function(){

  find_vector_min(fetch_database_column(column = "birthdate", tbl.name = "hyenas"))

}

#' @describeIn find_family Returns latest birthdate from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.birth.last()

find_pop_date.birth.last <- function(){

  find_vector_max(fetch_database_column(column = "birthdate", tbl.name = "hyenas"))

}

#' @describeIn find_family Returns earliest known conception from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.conception.first()

find_pop_date.conception.first <- function(){

  find_pop_date.birth.first() - lubridate::days(110)

}

#' @describeIn find_family Returns latest known conception from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.conception.last()

find_pop_date.conception.last <- function(){

  find_pop_date.birth.last() - lubridate::days(110)

}
