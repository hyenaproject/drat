#' Load all database tables for internal use in functions
#'
#' By design, the database loaded by these functions will be stored in a hidden
#' environment. We do that so that other functions have access to it without the
#' user being tempted to interfere with it.
#' [load_package_database.dummy] will load a dummy database and [load_package_database.full] allow you to work on the full database.
#' If you wish to retrieve tables to work with them directly, use [extract_database_table] instead.
#' If you think that the original table should be modified, the best practice is to modify the
#' original .csv files on GitHub (only Oliver should do that).
#'
#'
#' These functions can be used with inputs of length 1 or using vector.
#' @name load_package_database
#' @aliases load_package_database
#' @inheritParams arguments
#' @seealso [extract_database_table]
#' @return This function returns nothing directly, but it creates a tibble of
#'   tables and table names stored in a hidden environment.
NULL

#' @describeIn  load_package_database
#' @export
#' @examples
#' # Load the dummy dataset
#' load_package_database.dummy()

load_package_database.dummy <- function() {

  ## create environment storing the data base:
  .database <<- new.env()
  attr(.database, "name") <- "environment storing the database and its path"
  attr(.database, "dummy") <- TRUE

  message("Using the dummy dataset!")

  db.path <- system.file("extdata", "dummy_db.sqlite", package = "hyenaR", mustWork = TRUE)

  ## connect to the database:
  connection <- DBI::dbConnect(RSQLite::SQLite(), db.path)
  table_names <- DBI::dbListTables(connection)

  ## import each table from the database using .extract_table (see below):
  database <- tibble::tibble(
    table_name = table_names,
    data = purrr::map(
      .x = table_names,
      .f = ~ .extract_table(.x, connection)
    )
  )

  ## store the database and its path in the hidden environment:
  assign(x = "database", value = database, envir = .database)
  assign(x = "db.path", value = db.path, envir = .database)

  ## disconnect from the database:
  DBI::dbDisconnect(conn = connection)

  invisible(NULL)
}

#' @describeIn  load_package_database
#' @export

load_package_database.full <- function(db.path = NULL) {

  db.path <- check_function_arg.path(db.path, mustWork = TRUE)

  .database <<- new.env()
  attr(.database, "name") <- "environment storing the database and its path"
  attr(.database, "dummy") <- FALSE


  if (!grepl(pattern = ".sqlite", db.path)) {

    sqlite_file_paths <- list.files(path = db.path, pattern = ".sqlite", full.names = TRUE)

    if (length(sqlite_file_paths) > 1) {
      sqlite_file_names <- list.files(path = db.path, pattern = ".sqlite")

      choice <- utils::menu(
        choices = sqlite_file_names,
        title = "Multiple sqlite files exist in this folder. Which should be used?"
      )

      db.path <- sqlite_file_paths[choice]
    } else {
      db.path <- sqlite_file_paths
    }
  }

  ## connect to the database:
  connection <- DBI::dbConnect(RSQLite::SQLite(), db.path)
  table_names <- DBI::dbListTables(connection)

  ## import each table from the database using .extract_table (see below):
  database <- tibble::tibble(
    table_name = table_names,
    data = purrr::map(
      .x = table_names,
      .f = ~ .extract_table(.x, connection)
    )
  )

  ## store the database and its path in the hidden environment:
  assign(x = "database", value = database, envir = .database)
  assign(x = "db.path", value = db.path, envir = .database)

  ## disconnect from the database:
  DBI::dbDisconnect(conn = connection)

  ## display message if time since last sighting if long:
  now <- Sys.Date()
  last <- find_pop_date.observation.last()
  days_since_last <- as.numeric(now - last)
  colour <- dplyr::case_when(days_since_last < 31 ~ "green",
                             days_since_last > 30 && days_since_last < 61 ~ "yellow",
                             days_since_last > 60 ~  "red")

  message(paste0("The last observation in the loaded database is ", crayon::style(paste(days_since_last, "days old"), bg = colour), "!"))
  if (days_since_last > 30) {
    message("Perhaps you should update it!\n For this:\n 1. download the new data (see, ?download_package_csv)\n 2. rebuild the database (see ?build_package_database.full)")
  }
  invisible(NULL)
}

####################################################################################

.extract_table <- function(.x, connection) {
  output.tbl <- dplyr::tbl(connection, .x) %>%
    dplyr::collect(output.tbl)

  ## If the table contains date and time data unite it into one date_time column (POSIXct)
  if (all(c("date", "time") %in% colnames(output.tbl))) {
    output.tbl %>%
      tidyr::unite(col = "date_time", date, time, sep = " ", remove = TRUE) %>%
      dplyr::mutate_at(
        .vars = dplyr::vars(contains("date_time")),
        as.POSIXct, tz = "Africa/Dar_es_Salaam",
        format = "%Y-%m-%d %H:%M"
      ) -> output.tbl

    ## In one case, the observationtime table, there are two cols that should be datetime,
    ## the departure and arrival column.
  }

  if (all(c("departure", "arrival") %in% colnames(output.tbl))) {
    output.tbl %>%
      tidyr::unite(col = "departure_date_time", date, departure, sep = " ", remove = FALSE) %>%
      tidyr::unite(col = "arrival_date_time", date, arrival, sep = " ", remove = TRUE) %>%
      dplyr::select(-departure) %>%
      dplyr::mutate_at(
        .vars = dplyr::vars(contains("date_time")),
        as.POSIXct, tz = "Africa/Dar_es_Salaam",
        format = "%Y-%m-%d %H:%M"
      ) -> output.tbl
  }
  output.tbl %>%
    ## There may be other date columns that should be converted to date format
    dplyr::mutate_at(
      .vars = dplyr::vars(dplyr::contains("date"), -dplyr::contains("date_time")),
      as.Date, format = "%Y-%m-%d", origin = "1970-01-01"
    ) %>%
    dplyr::mutate_at(
      .vars = dplyr::vars(dplyr::contains("sex")),
      ~ dplyr::case_when(
        .x == 1 ~ "male",
        .x == 2 ~ "female",
        TRUE ~ NA_character_
      )
    ) -> output.tbl

  time <- departure <- arrival <- NULL ## to please R CMD check

  return(output.tbl)
}
