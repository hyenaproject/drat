#' Download the primary data
#'
#' Downloads the .csv files from our GitHub repository and puts them in a folder specified with the
#' argument `csv.output.folder`.
#'
#' By default, the data will be stored in a folder called "source_data" that will be created (if not
#' already present) in your working directory.
#'
#' You can use the geeky argument `.git.ref` to download older versions of the `*.csv` files, which
#' can be useful if you want to replicate results for a given paper.
#'
#' @note The authentification to GitHub is done using a Personal Access Token (PAT), see
#'   [`find_system_token.github()`][`find_system_token.github`].
#'
#' @inheritParams arguments
#'
#' @return The path where the data are stored (invisibly).
#' @export
#'
#' @examples
#' \dontrun{
#' download_package_csv(csv.output.folder = "~/Downloads/CSV")
#' }
download_package_csv <- function(csv.output.folder = "source_data", .git.ref = "master", .clean.old.csv = NULL) {

  csv.output.folder <- check_function_arg.path(csv.output.folder)

  ## retrieve info from GitHub:
  repos <- gh::gh("/repos/:user/:repo/contents",
                  user = 'hyenaproject', repo = 'data', ref = .git.ref, ## nb: ref is somehow passed to contents (GH API black magic)
                  .token = find_system_token.github())

  ## extract file names and urls:
  sizes <- unlist(lapply(repos, function(file) file$size)) ## we want to download largest file first
  orders <- order(sizes, decreasing = FALSE)
  urls <- unlist(lapply(repos, function(file) ifelse(is.null(file$download_url), NA, file$download_url)))[orders]
  files <- unlist(lapply(repos, function(file) file$name))[orders]

  ## only keep csv:
  index_for_download <- grepl("*.csv", files)
  files_to_download <- files[index_for_download]
  url_to_download <- urls[index_for_download]

  ## abort if nothing to download:
  if (length(url_to_download) == 0) {
    stop("No file to download. Check your inputs and your internet connection.")
  }

  if (!dir.exists(csv.output.folder)) {
    ## create the folder if not existing:
    dir.create(csv.output.folder, recursive = TRUE)
  } else {## only if the folder is not new
    old_csv <- list.files(path = csv.output.folder, pattern = "*.csv", full.names = TRUE)
    length_csv <- length(old_csv)
    if (length_csv > 1) {
      if (is.null(.clean.old.csv) && interactive()) {
        ## ask to cleanup the folder if needed:
        message(crayon::yellow(paste("Your folder already contains", length_csv, "(old) csv files,")))
        action <- 3
        while (action == 3) {
          action <- utils::menu(
            choices = c("Delete these files (recommended if you don't have files you must keep) and download new files",
                        "Keep these files and download new files",
                        "Show the names of the old csv files and show this menu again",
                        crayon::red("Abort!")),
            title = "what do you want to do? (press 1, 2, 3, or 4 to indicate your choice, and then hit the return key)"
          )
          ## display old file names if requested:
          if (action == 3) {
            cat("Your folder contains the following csv files:\n", crayon::blue(paste(basename(old_csv)), "\n"), "\n")
          }
        }
        if (action == 1) {
          file.remove(old_csv)
        } else if (action == 4) {
          message(crayon::red("Download aborted by user"))
          return(invisible(NULL))
        }
      } else {## when is.null(.clean.old.csv) && interactive() is FALSE
        if (is.null(.clean.old.csv)) {
          .clean.old.csv <- FALSE  ## turn NULL as FALSE to set safe default
        }
        if (.clean.old.csv) { ## only when user set input to TRUE
          file.remove(old_csv)
        }
      }
    }
  }

  ## the actual downloading job:
  sapply(1:length(url_to_download), function(i) {
    if (!is.na(url_to_download[i])) {
      utils::download.file(url_to_download[i],
                           destfile = paste0(csv.output.folder, "/", files_to_download[i]))
    }
  }) ## FIXME?: if the download fail, we must check what happens, if the error is unclear,
  ## we could add a tryCatch here:
  # sapply(1:length(url_to_download), function(i) {
  #   if (!is.na(url_to_download[i])) {
  #     tryCatch(utils::download.file(url_to_download[i],
  #                                   destfile = paste0(csv.output.folder, "/", files_to_download[i])),
  #              error = function(e) stop(crayon::red(paste("Failed to download", files_to_download[i]))))
  #   }
  # })

  message(paste0("The downloaded files are in the folder ", csv.output.folder))

  return(invisible(csv.output.folder))
}


#' Get the Personal Access Token for GitHub
#'
#' For downloading the full data, you need to have created a Personal Access Token (PAT) in GitHub.
#' This function tries to find this token on your system and, failing that, asks for it directly.
#'
#' For smooth usage, you should have your PAT in your .Renviron file.
#' How to edit the .Renviron file? The easiest way is to install the R package **{usethis}** and
#' then type 'usethis::edit_r_environ()'. NB: after editing .Renviron, you must restart R.
#'
#' @note For developers: for the token to work, it is necessary to activate the scope "repo"
#' in GitHub for the user which you want to authorise.
#'
#' @return The token as a character string.
#' @export
#'
#' @examples
#' \dontrun{
#' find_system_token.github()
#' }
#'
find_system_token.github <- function() {
  token <- Sys.getenv('GITHUB_PAT', "")
  if (token == "") {
    message("No token has been found in your .Renviron file!")
    if (interactive()) {
      action <- utils::menu(
        choices = c("input the token manually", "abort"),
        title = "What do you want to do? (press 1 or 2 and then hit the return key)"
      )
      if (action == 2) return(invisible(NULL))
      if (action == 1) {
        message("Please, enter the token (without quotes) and hit the return key")
        token <- scan("", what = "character", n = 1)
      }
    }
    message("For next time, perhaps you would like to add your token to the .Renviron file by simply adding the following line to your .Renviron file: GITHUB_PAT = your_token.")
    cat("\n")
    message("How to edit the .Renviron file?")
    message("-> the easiest way is to install the R package usethis and then type 'usethis::edit_r_environ()'.")
    message("NB: after editing .Renviron, you must restart R.")
    cat("\n")
  } else {
    message("The following token has been found on your system and will be used:")
    message(crayon::green(token))
    message("If the token is no longer valid, you must change it in your .Renviron file!")
    message("See ?find_system_token.github for details")
    cat("\n")
  }
  return(token)
}


#############################################################################################################################

#' Generate csv's used to create the dummy database.
#'
#' Generate .csv files to create the dummy database.
#' This includes real data for two years of the dataset (1996 - 1997).
#'
#' @inheritParams arguments
#' @return Generates .csv files for the years 1996 - 1997 in the Ngorongoro hyena data.
#' @export
#'
#' @examples
#' \dontrun{
#' ## Run the following to add dummy CSV in the package:
#' build_package_database.dummy(csv.input.folder = "~/Downloads/CSV",
#'                              csv.output.folder = "inst/extdata")
#' }

build_package_database.dummy <- function(csv.input.folder = utils::choose.dir(),
                                         csv.output.folder = NULL) {
  if (is.null(csv.output.folder)) {
    csv.output.folder <- csv.input.folder
  }

  csv.input.folder <- check_function_arg.path(csv.input.folder)
  csv.output.folder <- check_function_arg.path(csv.output.folder)

  file_paths <- list.files(path = csv.input.folder, pattern = ".csv", full.names = TRUE)

  #Ignore the "dens", "weighing", "rainfall", and "NCAA" prey abundance
  file_paths <- file_paths[!grepl("dens|weighing|rainfall|NCAA", file_paths)]

  purrr::walk(
    .x = file_paths,
    .f = ~ {
      file_path_split <- strsplit(.x, split = "/|\\\\")
      file_name <- gsub(pattern = ".csv|CSV", replacement = "", x = file_path_split[[1]][length(file_path_split[[1]])])

      file <- read.csv(.x, stringsAsFactors = FALSE) %>%
        dplyr::mutate_at(
          .vars = vars(contains("date") | contains("deathconfirmed")),
          ~as.Date(dplyr::na_if(., "")), format = "%Y-%m-%d"
        )

      assign(x = file_name, value = file, envir = sys.frames()[[1]])
    }
  )

  #Identify those individuals born in Airstrip and Lamala before 1998.
  born_indv <- hyenas %>%
    dplyr::filter((birthclan %in% c("A", "L") & birthdate < as.Date("1998-01-01"))
                  | .data$name %in% c("M-004", "S-002")) %>% ## add mothers from other clans
    dplyr::pull(name)

  #Join in all individuals in the selection table
  disp_indv <- selections %>%
    dplyr::filter((destination %in% c("A", "L") & date < as.Date("1998-01-01"))
                  | .data$name %in% c("M-004", "S-002")) %>% ## add mothers from other clans
    dplyr::pull(name)

  #Combine the two together
  early_indv <- c(born_indv, disp_indv)

  #Now, go through every table and filter according to these individuals and the date
  all_tables <- ls()
  all_tables <- all_tables[!all_tables %in% c("born_indv", "csv.input.folder", "csv.output.folder",
                                              "disp_indv", "early_indv", "file_paths",
                                              "all_tables")] ## FIXME: dangerous if there are other things in the global env!

  purrr::pwalk(.l = list(all_tables),
               .f = ~{

                 eval(parse(text = ..1)) -> data

                 #If there is a date column, filter by date
                 if(any(grepl("date", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = dplyr::vars(contains("date")),
                                      .vars_predicate = ~. < as.Date("1998-01-01")) -> data

                 } else if(any(grepl("^year$", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = dplyr::vars(matches("^year$")),
                                      .vars_predicate = ~. < 1998) -> data

                 }

                 #If there is a date column, filter by date
                 if(any(grepl("^name$", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = dplyr::vars(matches("^name$")),
                                      .vars_predicate = ~. %in% early_indv) -> data

                 } else if(any(grepl("party", colnames(data)))){

                   data %>%
                     dplyr::filter_at(.vars = dplyr::vars(contains("party")),
                                      .vars_predicate = ~. %in% early_indv) -> data

                 }

                 #For the selections table, only include dispersal INTO Airstrip and Lamala
                 #not out!
                 #This is because if an individual disperses out and we try to find its rank we get an
                 #error because it dispersed into a clan with no individuals (we deleted all other clans)
                 #This means that the results using the dummy data will not be exactly correct
                 #If we want results that are biologically correct that we can use for tests
                 #we will need to select specific individuals that we know haven't been affected by this
                 #change.
                 if(any(grepl("destination", colnames(data)))){

                   data %>%
                     dplyr::filter(destination %in% c("A", "L")) -> data

                 }

                 #For the rankchanges table, only include rank changes that occurred in Airstrip and Lamala.
                 #Same comment as above.
                 if(..1 == "rankchanges"){

                   data %>%
                     dplyr::filter(clan %in% c("A", "L")) -> data

                 }

                 #Make all comments columns NA (except for the remarks column used by Alex)
                 if(any(grepl("deathcause|comments|adoption|description|cause|interaction", colnames(data)))){

                   data %>%
                     dplyr::mutate_at(.vars = dplyr::vars(contains("deathcause"),
                                                          contains("comments"), contains("adoption"), contains("description"), contains("cause"),
                                                          contains("interaction")),
                                      .funs = ~ NA) -> data

                 }

                 #For the remarks column in sightings, make NA unless it contains the info used by Alex
                 if(..1 == "sightings"){
                   data %>%
                     dplyr::mutate(remarks = dplyr::case_when(grepl("BBC", .data$remarks) ~ "identified in BBC documentary",
                                                              grepl("one-day", .data$remarks) ~ "one-day visit"),
                                   denname = NA, age = NA, sex = NA) -> data

                 }

                 #For the deathconfirmed column in hyenas, make it NA unless it is before our cutoff date
                 if(..1 == "hyenas"){

                   data %>%
                     dplyr::mutate(deathconfirmed = replace(.data$deathconfirmed, .data$deathconfirmed >= as.Date("1998-01-01"), as.Date(NA))) -> data

                 }

                 if(..1 == "sucklings"){

                   data %>%
                     dplyr::mutate(remarks = NA,
                                   latitude = NA, longitude = NA) -> data

                 }

                 assign(x = ..1, value = data, envir = sys.frames()[[1]])

               })

  #For any individuals in hyenas table that don't have a sighting give them a sighting for their birthdate
  hyenas %>%
    dplyr::filter(!.data$name %in% sightings$name) %>%
    dplyr::summarise(date = .data$birthdate,
                     time = "12:00", name = .data$name, clanID = .data$birthclan,
                     sex = .data$sex) -> birth_sightings

  sightings <- dplyr::bind_rows(sightings, birth_sightings)

  #Save data with new sightings included
  purrr::pwalk(.l = list(all_tables),
               .f = ~{

                 eval(parse(text = ..1)) -> data

                 #Save data
                 data %>%
                   utils::write.csv(file = paste0(csv.output.folder, "/", ..1, ".csv"), row.names = FALSE)

               })

  collectiondate <- hyenas <- injuries <- interactions <- mother <- ID <- NULL
  observationtime <- party1 <- party2 <- rainfall <- rankchanges <- samples <- selections <- NULL
  sightings <- sucklings <- transects <- videos <- weighing <- year <- birthdate <- NULL
  birthclan <- name <- destination <- NULL

  return(invisible(NULL))
}

#############################################################################################################################

#' Build hyena database from .csv files
#'
#' Build a .sqlite database of hyena data using primary .csv files. This function can be used to build
#' the dummy database (using .csv files in ./inst/extdata) or the full database using \code{\link{download_package_csv}} (see examples).
#'
#' The build process involves the calculation of a number of variables. These include:
#' \itemize{
#'   \item deathdate in the deaths table. Date of last sighting for all individuals seen >1 year ago.
#'   \item 'conception sightings' in the sightings table. When parentage of a
#'   cub is known, parents are 'sighted' on the estimated day of conception (110
#'   days before birth).
#'   \item date_lastsighting in the hyenas table. Last date that an individual was listed in the sightings table.
#'   \item firstlitter table. The date of conception (110 days before birth) of the first litter for each male.
#' }
#'
#' @inheritParams arguments
#' @return Creates an sqlite database.
#' @export
#'
#' @examples
#'
#' # Example using dummy data
#' #build_package_database.full(db.name = "dummy_db", csv.input.folder = "./inst/extdata")
#'
#' \dontrun{
#' # Example using real primary data
#' download_package_csv(csv.output.folder = "~/Downloads/CSV")
#' build_database(csv.input.folder = "~/Downloads/CSV")
#' }
#'
build_package_database.full <- function(db.name = "Fisidata", csv.input.folder = "source_data", db.output.folder = NULL, overwrite.db = c("prompt", "yes", "no")) {

  ## Call choose.dir() if it is used as argument:
  force(csv.input.folder)
  force(db.output.folder)

  ## Use match arg to determine clash behaviour:
  ## (by default, the user will be prompted if a database already exists with same location and name)
  overwrite.db <- match.arg(overwrite.db) ##  'prompt' is default as it is the first argument

  ## If no explicit save path is provided, simply save in csv location:
  if (is.null(db.output.folder)) {
    db.output.folder <- csv.input.folder
  }

  ## Check paths:
  csv.input.folder <- check_function_arg.path(csv.input.folder)
  db.output.folder <- check_function_arg.path(db.output.folder)

  ## Assign NULL to please R CMD check:
  hyenas <- sightings <- selections <- clans <- dens <- injuries <- rainfall <- NULL
  interactions <- observationtime <- samples <- sucklings <- videos <- weighing <- NULL
  menu <- total <- year <- Month <- Year <- NULL

  # Build full path for database
  db_path <- paste(db.output.folder, paste0(db.name, ".sqlite"), sep = "/")

  # If the file already exists...
  if (file.exists(db_path)) {

    # Check if the session is being run interactively
    # or the user hasn't provided a default behaviour for dealing with clashes...
    if (interactive() & overwrite.db == "prompt") {

      # Allow the user to choose whether they: a) overwrite the file b) create a new file (with custom name based on current date).
      overwrite.db <- menu(
        choices = c("Overwrite the original file", "Create a new database file"),
        title = "A database with the same name already exists. What do you want to do?"
      )

      ## Convert menu outcome to match 'yes' and 'no' option from the 'overwrite.db' argument
      overwrite.db <- dplyr::case_when(
        overwrite.db == 1 ~ "yes",
        overwrite.db == 2 ~ "no"
      )
    } else if (!interactive() & overwrite.db == "prompt") {
      stop("User prompt is not possible in non-interactive mode.
           Please provide a default behaviour to deal with database name clashes. Use the argument 'overwrite.db'.")
    }

    # If they choose to overwrite the file, delete the original and continue.
    # (Not ideal because the delete takes time, actual overwrite would be better but SQL problems)
    if (overwrite.db == "yes") {
      message("Database name exists. Overwriting old database file...")
      file.remove(db_path)

      # Otherwise, create a new file that has todays date
    } else {

      # In case somebody tries to do this twice on the same day (creating another file path clash)
      # Add a version number after the date
      version_number <- 2

      # As long as the file path clashes, increase the version number.
      while (file.exists(db_path)) {
        db_path <- paste(db.output.folder, paste0(paste(db.name, Sys.Date(), version_number, sep = "_"), ".sqlite"), sep = "/")

        version_number <- version_number + 1
      }

      message(paste0("Database name exists. Database saved as: ", paste(db.name, Sys.Date(), version_number - 1, sep = "_")))
    }
  }

  # Create SQLite db for hyenas
  db_new <- DBI::dbConnect(RSQLite::SQLite(), dbname = db_path)

  # Load all csv files
  files <- list.files(path = csv.input.folder, pattern = ".csv", full.names = TRUE)

  # Don't include tables with 'Demo', I'm not quite sure how tables inter-relate to each other.
  files <- files[!grepl(pattern = "demo|Demo", x = files)]

  tables_to_do <- purrr::map_dfr(.x = files, .f = function(file_path) {

    # Determine file name (used to name tables) from full path
    file_name <- strsplit(file_path, "/")[[1]][length(strsplit(file_path, "/")[[1]])]
    file_name <- gsub(pattern = "CSV|csv|\\.", replacement = "", x = file_name)

    X <- utils::read.csv(file = file_path, header = TRUE, sep = ",", stringsAsFactors = FALSE, na.strings = c("", " ", "NA"))

    if (nrow(X) == 0) warning(paste("The file", file_name, "is empty. If you are not creating a dummy database, an issue must have occured while downloading the data. Try to download the data again."))

    X %>%
      # Remove any empty columns? Do we want to do this?
      # Don't do this atm because it causes problems between bootstrap of dummy and real data.
      # select_if(.predicate = ~{!all(is.na(..1))}) %>%
      # Trim all character columns (i.e. remove trailing/leading whitespace)
      dplyr::mutate_if(.predicate = is.character, .funs = trimws) %>%
      # Make any 'clan' column uppercase (i.e. should always be 'F' not 'f')
      dplyr::mutate_at(dplyr::vars(
        dplyr::contains("clan"),
        dplyr::contains("origin"),
        dplyr::contains("destination")
      ), toupper) %>%
      ## Change column 'name' to column 'ID'
      dplyr::rename_at(
        .vars = dplyr::vars(dplyr::matches("^name$")),
        ~ "ID"
      ) -> X

    # Output a tibble with the name and data
    return(tibble::tibble(name = file_name, data = list(X)))
  })

  # Make all names lower case to prevent any issues from case changes
  tables_to_do$name <- tolower(tables_to_do$name)

  # Check that all tables needed to make views are present
  if (!all(c("hyenas", "sightings") %in% tables_to_do$name)) {
    stop("The hyenas and sightings .csv must be present to bootstrap the database.")
  }

  # The table called 'sightings' should be renamed 'raw_sightings'
  # sightings is now created as a view
  tables_to_do[which(tables_to_do$name == "sightings"), ]$name <- "raw_sightings"

  # The table called 'hyenas' should be renamed 'raw_hyenas'
  # hyenas is now created as a view
  tables_to_do[which(tables_to_do$name == "hyenas"), ]$name <- "raw_hyenas"

  # For rainfall data, adjust the structure
  if (any(grepl("rainfall", tables_to_do$name))) {
    tables_to_do[which(tables_to_do$name == "rainfall"), ]$data[[1]] %>%
      dplyr::filter(!is.na(.data$location)) %>%
      # Remove the 'total' column (this can be calculated easily)
      # Remove the 'comments' column
      dplyr::select(-.data$total, -.data$comments) %>%
      # Gather data so that there are columns year, month and rainfall.
      tidyr::gather(key = "Month", value = "Rainfall", -.data$year, -.data$location, -.data$latitude, -.data$longitude) %>%
      # Change month to be a numeric
      dplyr::mutate(Month = lubridate::month(lubridate::parse_date_time(.data$Month, orders = "b"))) %>%
      dplyr::rename(Year = .data$year, Location = .data$location) %>%
      # Arrange chronologically
      dplyr::arrange(.data$Year, .data$Month) -> tables_to_do[which(tables_to_do$name == "rainfall"), ]$data[[1]]

  }

  # Before building the database run a number of data checks.
  # These checks are specified in check_db.R
  check <- check_database_has.full.records(
    hyenas.tbl = tables_to_do$data[tables_to_do$name == "raw_hyenas"][[1]],
    selections.tbl = tables_to_do$data[tables_to_do$name == "selections"][[1]],
    sightings.tbl = tables_to_do$data[tables_to_do$name == "raw_sightings"][[1]]
  )

  # Add tables to the database
  purrr::pwalk(.l = tables_to_do, .f = ~ {

    DBI::dbWriteTable(conn = db_new, name = ..1, value = ..2, row.names = FALSE)

  })

  # Determine the date these database files come from.
  # In some cases, we may try and bootstrap old files (e.g. dummy dataset) and so we can't make things relative to the computer clock.
  # Instead, we always make it relative to the last sighting in the sightings table.
  tables_to_do$data[[which(tables_to_do$name == "raw_sightings")]] %>%
    dplyr::pull(date) %>%
    as.Date(format = "%Y-%m-%d") %>%
    max() -> max_sighting

  # Create adults view
  Query1 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW adults AS SELECT raw_hyenas.ID, raw_hyenas.sex, date(birthdate, '+2 years') AS dateadult, date(MAX(sightings.date), '+1 day') AS deathdate, mothergenetic, mothersocial, DNA FROM raw_hyenas JOIN sightings ON (raw_hyenas.ID == sightings.ID) GROUP BY raw_hyenas.ID HAVING deathdate > dateadult"
  )
  DBI::dbClearResult(Query1)

  # Create sightings view that also contains conception views (i.e. 110 days before the birthdate of cubs where parentage is known)
  # Seems that UNION doesn't work with SELECT *?? for now I spell out all...
  Query2 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW sightings AS SELECT date(birthdate, '-110 days') AS date, '00:00' AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 1 AS sex, 'Estimated from conception' as remarks, father AS ID, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM raw_hyenas WHERE father <> '' UNION
                    SELECT birthdate AS date, '00:00' AS time, NULL AS latitude, NULL as longitude, NULL AS denname, 'ad' AS age, 2 AS sex, 'Estimated from conception' as remarks, mothergenetic AS ID, NULL AS name2, birthclan AS clanID, NULL AS denstop, NULL AS prey, NULL AS obsstart, NULL AS obsstop, NULL AS sucklingID, NULL AS denhole, NULL AS injuryID, NULL AS earR, NULL AS earL, NULL AS altitude, NULL AS waypoint, NULL AS observer FROM raw_hyenas WHERE mothergenetic <> '' UNION
                    SELECT date, time, latitude, longitude, denname, age, sex, remarks, ID, name2, clanID, denstop, prey, obsstart, obsstop, sucklingID, denhole, injuryID, earR, earL, altitude, waypoint, observer FROM raw_sightings"
  )
  DBI::dbClearResult(Query2)

  # Make the hyenas table into a view that also includes last sighting (with contraceptions included.)
  Query3 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW hyenas AS SELECT * FROM
                             raw_hyenas
                             NATURAL LEFT JOIN (SELECT ID AS ID, max(date(date)) AS date_lastsighting FROM sightings WHERE ID <> '' GROUP BY ID)"
  )
  DBI::dbClearResult(Query3)

  # Create deaths view
  # We now build this from the previous 'all_sightings' view because we want to account for conception date when estimating death
  # i.e. we need to consider that if an individual is known to have conceived of a cub it must have been alive!!
  Query4 <- DBI::dbSendQuery(
    conn = db_new,
    paste0("CREATE VIEW deaths AS SELECT ID, COALESCE(hyenas.deathconfirmed, observed.deathdate) AS deathdate FROM hyenas NATURAL LEFT JOIN ( SELECT ID, date(max(date), '+1 day') as deathdate FROM sightings GROUP BY ID HAVING deathdate < date(date('", max_sighting, "'), '-1 years')) AS observed WHERE hyenas.deathconfirmed NOTNULL OR observed.deathdate NOTNULL;")
    # paste0("CREATE VIEW deaths AS SELECT ID, date(max(date), '+1 day') as deathdate FROM sightings GROUP BY ID HAVING deathdate < date(date('", max_sighting, "'), '-1 years') AND ID <> ''")
  )
  DBI::dbClearResult(Query4)

  # First litter view
  Query5 <- DBI::dbSendQuery(
    conn = db_new,
    "CREATE VIEW firstlitter AS SELECT father AS male, MIN(date(birthdate, '-110 days')) AS date_first_litter FROM raw_hyenas WHERE father > 0 GROUP BY father"
  )
  DBI::dbClearResult(Query5)

  DBI::dbDisconnect(db_new)

  if (check) {
    message(crayon::green("Database built!!"))
  } else {
    message(crayon::yellow("Database built but !!contains issues!!"))
  }

  return(invisible(NULL))
}

#' Append a table to the database
#'
#' Adds given table to the database object.
#' This function is called within create functions (e.g. [create_id_life.history.table])
#' when caching is activated. This function should not be
#' called directly by the user.
#'
#'
#' @inheritParams arguments
#' @return Nothing returned
#' @export
#'
#' @examples
#'
#' # Example using dummy data
#' # Create .database object
#' load_package_database.dummy()
#'
#' #Create new table
#' fake_data <- dplyr::tibble(ID = c("A-001", "A-002"),
#'                            date = c("1997-01-01", "1997-02-01"))
#'
#' #Append to database
#' build_package_database.append.table(fake_data, tbl.name = "example_data")
#'
#' #This data can now be called with `extract_database_table`
#' extract_database_table("example_data")
#'
build_package_database.append.table <- function(tbl, tbl.name){

  new_row <- tibble::tibble(
    table_name = tbl.name,
    data = list(tbl)
  )

  .database$database <- dplyr::bind_rows(.database$database, new_row)

  invisible(NULL)

}
