#' Generates and automatically saves .txt files for CERVUS. Each file contains
#' offspring with the same number and proportion of potential genotyped fathers.
#'
#' The generated files will be stored in the `txt.output.folder`.
#'
#' @inheritParams arguments
#' @return Different format of files.
#' @export
#' @examples
#'
#' #### Simple examples of build_cervus_input:
#' \dontrun{
#' build_cervus_input(offspringID = c("A-008", "A-001", "A-086"), txt.output.folder = "your_path")
#'}
build_cervus_input <- function(offspringID, txt.output.folder) {
  txt.output.folder <- check_function_arg.path(txt.output.folder)
  offspringID <- check_function_arg.ID(offspringID)

  create_cervus_input(offspringID) %>%
    dplyr::select(-.data$clan.conception) %>%
    dplyr::mutate(# Add * and . to  distiguish offspring born before and after the beginning of the study
                  symbol = ifelse(.data$birthdate - 110 < find_pop_date.observation.first(), "*", "."),
                  # Remove the dashes
                  birthdate = paste0(substr(.data$birthdate, 1, 4),
                                    substr(.data$birthdate, 6, 7),
                                    substr(.data$birthdate, 9, 11)),
                  prop.typed = round(.data$prop.typed, 3),
                  sex = dplyr::case_when(.data$sex == "female" ~ "F",
                                         .data$sex == "male" ~ "M",
                                         TRUE ~ NA_character_)) %>%
    dplyr::relocate(.data$symbol, before = .data$offspringID) %>%
    dplyr::group_by(.data$N.typed, .data$N.potential, .data$prop.typed) %>%
    dplyr::group_split(.keep = TRUE)  -> table.list

  table.list2 <- list()

  for (i in seq_len(length(table.list))) {
    table.list2[[i]] <- table.list[[i]] %>%
      tidyr::pivot_wider(id_cols = c("symbol", "offspringID", "motherID", "sex", "birthdate", "N.typed",
                                     "N.potential", "prop.typed", "index.candidate", "potential.fatherID"),
                         names_from = .data$index.candidate, values_from = .data$potential.fatherID)
    prop.store <- table.list[[i]]$prop.typed[1]
    N.potential.store <- table.list[[i]]$N.potential[1]
    ## good to have the file named as the proportion and number of tiped individual
    utils::write.table(table.list2[[i]], file = as.character(paste0(txt.output.folder,
                                                            "/cervus_o",
                                                            as.character(prop.store),
                                                            "-",
                                                            as.character(N.potential.store),
                                                            ".txt")),
                quote = FALSE, col.names = FALSE, row.names = FALSE, append = TRUE, sep = "\t")
  }
}
