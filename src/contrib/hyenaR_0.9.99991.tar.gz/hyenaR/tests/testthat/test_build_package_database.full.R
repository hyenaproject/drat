# context("Test that we can build the database")
#
# test_that("build_package_database.full works with the dummy data", {
#
#   #Suppress warnings because there are some date parsing issues from records in the dummy data
#   #This doesn't affect the code.
#   suppressWarnings(build_package_database.full("example_db", csv.input.folder = "../../inst/extdata"))
#
#   #Check that a file has been created
#   expect_true(any(grepl("example_db.sqlite", list.files("../../inst/extdata"))))
#
# })
